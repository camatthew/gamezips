
--Gamma updates after this

--Colors I made for fun: 5700C5 (Brugel), A9BBD8 (Gloeu), CB4927 (Argon Red), 7194BE (Argon Blue), 6688CC (Hydrogen Purple), AACCEE (Hydrogen White), 002089 (Ozone Purple)

local function velocity(i,v,n) --*1
 if tpt.get_property("tmp", i) == 0 then --1
  local angle = math.random(1,n)*(2*math.pi/n)
  tpt.set_property("vx", v*math.cos(angle), i)
  tpt.set_property("vy", v*math.sin(angle), i)
  tpt.set_property("tmp", 1, i)
  end --1
 end --*1

local function attract(i,x,y,a) --*1
 sim.gravMap(x/4,y/4,a)
end --*1

local function superfluid(i,x,y,s,nt,p,h,u) --*1
  if s ~=8 and nt ~=0 and nt - s > 0 then --1
   for r in sim.neighbors(x,y,1,1) do --2
    if math.random(1,u) == 1 then --3
     if sim.partProperty(i, "vy") > 0.5 then --4/2
      sim.partProperty(i, "vy", p+0.5)
     elseif sim.partProperty(i, "vy") < 0.5 then --4/1
      sim.partProperty(i, "vy", p*-1)
      end --4
     end --3
     if math.random(1,h) > 1 then --5
     sim.partProperty(i, "vx", 0)
     end --5
    end --2
   end --1
  end --*1

--Before this, is some important stuff that I have to use here, like extra color list, etc.

local trit = elements.allocate("RADM" , "TRIT")
 elements.element(trit, elements.element(elements.DEFAULT_PT_HYGN))
 elements.property(trit, "Name" , "TRIT")
 elements.property(trit, "Gravity", -0.1)
 elements.property(trit, "Falldown", 2)
 elements.property(trit, "Diffusion", 2)
 elements.property(trit, "Description" , "Tritium, reacts with neutrons and creates fusion.")
 elements.property(trit, "Color", 0xA2A0BF)
 elements.property(trit, "MenuSection", 10)
 function tritDecay(i,x,y,s,n) --*1
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   if math.random(1,3) == 1 then --2/3
   tpt.parts[i].type = tpt.el.neut.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,6) == 3 then --2/2
   tpt.parts[i].type = tpt.el.deut.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,3) == 3 then --2/1
   tpt.parts[i].type = tpt.el.hygn.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x ,y)
   end --2
  end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,250) == 10 then --4
   tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
   end --4
  end --3
 end --*1
 tpt.element_func(tritDecay,trit)
 function neutron(i,x,y,s,n) --*2
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == trit then --2
   if math.random(1,30) == 10 then --2
   tpt.create(x + math.random(-2,2), y + math.random(-1,1), 'neut')
   end --2
  end --1
 end --*2
 tpt.element_func(neutron,tpt.el.neut.id)

local qudr = elements.allocate("RADM" , "QUDR")
 elements.element(qudr, elements.element(elements.DEFAULT_PT_HYGN))
 elements.property(qudr, "Name" , "QUDR")
 elements.property(qudr, "Description" , "Quadrium, reacts with electrons and creates deuterium.")
 elements.property(qudr, "Color", 0x968999)
 elements.property(qudr, "MenuSection", 10)
 elements.property(qudr, "Gravity", -0.1)
 elements.property(qudr, "Falldown", 2)
 elements.property(qudr, "Diffusion", 2)
 function quadDecay(i,x,y,s,n)
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.elec.id then --1
   if math.random(1,3) == 1 then --2/3
   tpt.parts[i].type = tpt.el.elec.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,6) == 3 then --2/2
   tpt.parts[i].type = tpt.el.neut.id 
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,3) == 3 then --2/1
   tpt.parts[i].type = tpt.el.deut.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x ,y)
   end --2
  end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'elec')
  end --4
 end --3
end --*1
tpt.element_func(quadDecay,qudr)
function neutron(i,x,y,s,n) --*2
 if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == qudr then --1
  if math.random(1,30) == 10 then --2
  tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'elec')
  end --2
 end --1
end --*2
tpt.element_func(neutron,tpt.el.elec.id)

local pent = elements.allocate("RADM" , "PENT")
 elements.element(pent, elements.element(elements.DEFAULT_PT_HYGN))
 elements.property(pent, "Name" , "PENT")
 elements.property(pent, "Description" , "Pentium, reacts with protons.")
 elements.property(pent, "Color", 0x8BC2C4)
 elements.property(pent, "Gravity", -0.1)
 elements.property(pent, "Falldown", 2)
 elements.property(pent, "Diffusion", 2)
 elements.property(pent, "MenuSection", 10)
 function pentium(i,x,y,s,n) --*1
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.prot.id then --1
   if math.random(1,3) == 1 then --2/3
    tpt.parts[i].type = tpt.el.prot.id
    sim.pressure(x/4,y/4,75)
    tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,6) == 3 then --2/2
    tpt.parts[i].type = tpt.el.grvt.id
    sim.pressure(x/4,y/4,75)
    tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,3) == 3 then --2/1
    tpt.parts[i].type = tpt.el.brmt.id
    sim.pressure(x/4,y/4,75)
    tpt.set_property("temp", math.huge, x ,y)
    end --2
   end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'prot')
    end --3
   end --4
  end --*1
 tpt.element_func(pentium,pent)
 function neutron(i,x,y,s,n) --*2
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == pent then --1
   if math.random(1,30) == 10 then --2
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'prot')
    end --2
   end --1
  end --*2
 tpt.element_func(neutron,tpt.el.prot.id)

local ogan = elements.allocate("RADM" , "OGAN")
 elements.element(ogan, elements.element(elements.DEFAULT_PT_URAN))
 elements.property(ogan, "Name" , "OGAN")
 elements.property(ogan, "Description" , "Oganesson, very heavy and reactive.")
 elements.property(ogan, "Color", 0x063521)
 elements.property(ogan, "MenuSection", 10)
 function oganesson(i,x,y,s,n)
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   if math.random(1,3) == 1 then --2/3
    tpt.parts[i].type = tpt.el.neut.id
    sim.pressure(x/4,y/4,75)
    tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,6) == 3 then --2/2
    tpt.parts[i].type = tpt.el.plut.id
    sim.pressure(x/4,y/4,75)
    tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,3) == 3 then --2/1
    tpt.parts[i].type = tpt.el.uran.id
    sim.pressure(x/4,y/4,75)
    tpt.set_property("temp", math.huge, x ,y)
    end --2
   end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    end --4
   end --3
  if math.random(1,10000) == 10 then --5
   tpt.set_property("temp", math.huge, x ,y)
   tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'uran') --4
   tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'stne') --4
   tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'plut') --4
   sim.pressure(x/4,y/4,0.1)
   end --5
  end --*1
 tpt.element_func(oganesson,ogan)
  function neutron(i,x,y,s,n) --*2
   if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == ogan then --1
    if math.random(1,30) == 10 then --2
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     end --2
    end --1
   end --*2
 tpt.element_func(neutron,tpt.el.neut.id)

--Fun fact, oganesson has 1000 fundamental particles.

--Reactor fluid will be missed...

local niho = elements.allocate("RADM" , "NIHO")
elements.element(niho, elements.element(elements.DEFAULT_PT_GOLD))
elements.property(niho, "Name" , "NIHO")
elements.property(niho, "Description" , "Nihonium, very explosive and reactive.")
elements.property(niho, "Color", 0x2B4D9B)
elements.property(niho, "MenuSection", 10)
function nihonium(i,x,y,s,n) --*1
 if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
  if math.random(1,3) == 1 then --2/3
   tpt.parts[i].type = tpt.el.neut.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y) 
  elseif math.random(1,6) == 3 then --2/2
   tpt.parts[i].type = tpt.el.plut.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y) 
  elseif math.random(1,3) == 3 then --2/1
   tpt.parts[i].type = tpt.el.uran.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x ,y)
   end --2
  end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    end --4
   end --3
  end --*1
 tpt.element_func(nihonium,niho)
 function neutron(i,x,y,s,n) --*2
   if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == niho then --1
    if math.random(1,30) == 10 then  --2
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut') 
     end --2
    end --1
   end--*2
 tpt.element_func(neutron,tpt.el.neut.id)

local mthn = elements.allocate("RADM", "MTHN")
 elements.element(mthn, elements.element(elements.DEFAULT_PT_CO2))
 elements.property(mthn, "Name" , "MTHN")
 elements.property(mthn, "Description" , "Methane, flammable.")
 elements.property(mthn, "Flammable", 2.55)
 elements.property(mthn, "Color", 0x000A23)
 elements.property(mthn, "Temperature", 366.8)
 elements.property(mthn, "MenuSection", 5)
 elements.property(mthn, "HighPressure", 1.32)
 elements.property(mthn, "HighPressureTransition", elements.RADM_PT_PRPN)

local ptol = elements.allocate("RADM", "PTOL")
 elements.element(ptol, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(ptol, "Name" , "PTOL")
 elements.property(ptol, "Description" , "Petrol, flammable, burns slow.")
 elements.property(ptol, "Flammable", 18.55)
 elements.property(ptol, "Color", 0x1A3000)
 elements.property(ptol, "Temperature", 293.4)
 elements.property(ptol, "MenuSection", 5)
 elements.property(ptol, "LowPressure", -1.45)
 elements.property(ptol, "LowPressureTransition", elements.RADM_PT_MTHN)

local gsol = elements.allocate("RADM", "GSOL")
 elements.element(gsol, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(gsol, "Name" , "GSOL")
 elements.property(gsol, "Description" , "Gasoline, flammable, burns fast.")
 elements.property(gsol, "Flammable", 68.73)
 elements.property(gsol, "Color", 0xFF8F2D)
 elements.property(gsol, "Temperature", 314.65)
 elements.property(gsol, "MenuSection", 5)
 elements.property(gsol, "LowPressure", -0.43)
 elements.property(gsol, "LowPressureTransition", elements.RADM_PT_PTOL)

local prpn = elements.allocate("RADM", "PRPN")
 elements.element(prpn, elements.element(elements.DEFAULT_PT_HYGN))
 elements.property(prpn, "Name" , "PRPN")
 elements.property(prpn, "Description" , "Propane, highly flammable gas.")
 elements.property(prpn, "Flammable", 5.55)
 elements.property(prpn, "Color", 0x820000)
 elements.property(prpn, "Temperature", 366.8)
 elements.property(prpn, "MenuSection", 5)
 elements.property(prpn, "HighPressure", 1.32)
 elements.property(prpn, "HighPressureTransition", elements.RADM_PT_GSOL)
 elements.property(prpn, "Diffusion", 1.03)

local lhyg = elements.allocate("RADM", "LHYG")
 elements.element(lhyg, elements.element(elements.DEFAULT_PT_LOXY))
 elements.property(lhyg, "Name" , "LHYG")
 elements.property(lhyg, "Description" , "Liquid Hydrogen, very cold, makes water with liquid oxygen when burnt. Superfluid.")
 elements.property(lhyg, "Flammable", 23.65)
 elements.property(lhyg, "Color", 0x99BBDD)
 elements.property(lhyg, "Temperature", 14.15)
 elements.property(lhyg, "MenuSection", 7)
 elements.property(lhyg, "Diffusion", 0.1)
 elements.property(lhyg, "HighTemperature", 18.15)
 elements.property(lhyg, "HighTemperatureTransition", elements.DEFAULT_PT_HYGN)
 elements.property(elem.RADM_PT_LHYG, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.5,4,3)
  end --1
  ) --*1

local ethn = elements.allocate("RADM", "ETHN")
elements.element(ethn, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(ethn, "Name" , "ETHN")
elements.property(ethn, "Description" , "Ethane, flammable gas.")
elements.property(ethn, "Flammable", 157.55)
elements.property(ethn, "Color", 0x89FFE3)
elements.property(ethn, "Temperature", 366.8)
elements.property(ethn, "MenuSection", 5)
elements.property(ethn, "LowPressure", -1.07)
elements.property(ethn, "LowPressureTransition", elements.RADM_PT_PRPN)
elements.property(ethn, "Diffusion", 1.03)

local btan = elements.allocate("RADM", "BTAN")
elements.element(btan, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(btan, "Name" , "BTAN")
elements.property(btan, "Description" , "Butane, flammable gas.")
elements.property(btan, "Flammable", 89.55)
elements.property(btan, "Color", 0xD3A50C)
elements.property(btan, "Temperature", 366.8)
elements.property(btan, "MenuSection", 5)
elements.property(btan, "HighPressure", 1.07)
elements.property(btan, "HighPressureTransition", elements.RADM_PT_ETHN)
elements.property(btan, "Diffusion", 1.50)

local lith = elements.allocate("RADM", "LITH")
elements.element(lith, elements.element(elements.DEFAULT_PT_METL))
elements.property(lith, "Name" , "LITH")
elements.property(lith, "Description" , "Lithium, alkali metal. Reactive to water.")
elements.property(lith, "Flammable", 0.95)
elements.property(lith, "Color", 0xC4C0E5)
elements.property(lith, "Temperature", 337.8)
elements.property(lith, "MenuSection", 1)
elements.property(lith, "HighPressure", 1.07)
elements.property(lith, "HighPressureTransition", elements.RADM_PT_FIRE)
 elements.property(elem.RADM_PT_LITH, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~= 0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --4
     if math.random(1,64) == 4 then --5
      sim.partProperty(r, "type", elements.DEFAULT_PT_HYGN)
      if math.random(1,6) == 3 then --6
       sim.pressure(x/4,y/4,1)
       sim.partProperty(i, "temp", 956.42)
       if math.random(1,2) == 2 then --7
        tpt.delete(i)
        end --7
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local lhlm = elements.allocate("RADM", "LHLM")
 elements.element(lhlm, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(lhlm, "Name" , "LHLM")
 elements.property(lhlm, "Description" , "Liquid helium, extremely cold, superfluid.")
 elements.property(lhlm, "Color", 0xEEC0D5)
 elements.property(lhlm, "Temperature", 1.10)
 elements.property(lhlm, "MenuSection", 7)
 elements.property(lhlm, "Diffusion", 0.1)
 elements.property(lhlm, "Falldown", 2)
 elements.property(lhlm, "AirDrag", 0.01)
 elements.property(lhlm, "Gravity", 0.027)
 elements.property(elem.RADM_PT_LHLM, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,1,2,2)
  end --1
 ) --*1

local hlum = elements.allocate("RADM", "HLUM")
elements.element(hlum, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(hlum, "Name" , "HLUM")
elements.property(hlum, "Description" , "Helium, very light. Turns into liquid helium at low temperatures.")
elements.property(hlum, "Color", 0xFFE0F7)
elements.property(hlum, "Temperature", 90.8)
elements.property(hlum, "MenuSection", 6)
elements.property(hlum, "LowTemperature", 4.13)
elements.property(hlum, "LowTemperatureTransition", elements.RADM_PT_LHLM)
elements.property(hlum, "Diffusion", 0.06)
elements.property(hlum, "Falldown", 2)
elements.property(hlum, "AirDrag", 0.01)
elements.property(hlum, "Gravity", -0.028)

elements.property(lhlm, "HighTemperature", 4.16)
elements.property(lhlm, "HighTemperatureTransition", elements.RADM_PT_HLUM)

local lhe3 = elements.allocate("RADM", "LHE3")
 elements.element(lhe3, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(lhe3, "Name" , "LHE3")
 elements.property(lhe3, "Description" , "Liquid helium 3, extremely cold.")
 elements.property(lhe3, "Color", 0xCCA0DF)
 elements.property(lhe3, "Temperature", 1.10)
 elements.property(lhe3, "MenuSection", 7)
 elements.property(lhe3, "Diffusion", 0.1)
 elements.property(lhe3, "Falldown", 2)
 elements.property(lhe3, "AirDrag", 0.01)
 elements.property(lhe3, "AirDrag", 0.01)
 elements.property(lhe3, "Gravity", 0.027)

local he3 = elements.allocate("RADM", "HE3")
elements.element(he3, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(he3, "Name" , "HE3")
elements.property(he3, "Description" , "Helium 3, very light")
elements.property(he3, "Color", 0xDDC0EF)
elements.property(he3, "Temperature", 90.8)
elements.property(he3, "LowTemperature", 4.13)
elements.property(he3, "LowTemperatureTransition", elements.RADM_PT_LHE3)
elements.property(he3, "Diffusion", 0.06)
elements.property(he3, "Falldown", 2)
elements.property(he3, "Weight", 36)
elements.property(he3, "AirDrag", 0.01)
elements.property(he3, "Gravity", -0.033)

elements.property(lhe3, "HighTemperature", 4.16)
elements.property(lhe3, "HighTemperatureTransition", elements.RADM_PT_HE3)
 
local muon = elements.allocate("RADM", "MUON")
elements.element(muon, elements.element(elements.DEFAULT_PT_ELEC))
elements.property(muon, "Name" , "MUON")
elements.property(muon, "Description" , "Muons, decay into electrons.")
elements.property(muon, "Color", 0xE1FF00)
function muonDecay(i,x,y,s,n)
if math.random(1,2000) == 10 then
tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'elec')
tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'elec')
tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'elec')
tpt.delete(i)
end
end
function muonUpdate(i,x,y,s,n)
velocity(i,2,6)
muonDecay(i,x,y,s,n)
end
elements.property(muon,"Update",muonUpdate)

local function funcGraphics(i, colr, colg, colb)
    return 1,ren.FIRE_ADD,255,colr,colg,colb,128,250,255,0
end
elements.property(muon, "Graphics", funcGraphics)

local tauo = elements.allocate("RADM", "TAUO")
elements.element(tauo, elements.element(elements.DEFAULT_PT_ELEC))
elements.property(tauo, "Name" , "TAUO")
elements.property(tauo, "Description" , "Tauons, decay into muons.")
elements.property(tauo, "Color", 0x8D4CFF)
function tauonDecay(i,x,y,s,n)
if math.random(1,1000) == 10 then
tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'muon')
tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'muon')
tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'muon')
tpt.delete(i)
end
end
function tauonUpdate(i,x,y,s,n)
velocity(i,2,3)
tauonDecay(i,x,y,s,n)
end
elements.property(tauo,"Update",tauonUpdate)

local function funcGraphics(i, colr, colg, colb)
    return 1,ren.FIRE_ADD,255,colr,colg,colb,128,141,76,255
end
elements.property(tauo, "Graphics", funcGraphics)

local mlhg = elements.allocate("RADM", "MLHG")
 elements.element(mlhg,elem.element(elem.DEFAULT_PT_GOLD))
 elements.property(mlhg, "Description" , "Metallic hydrogen, explosive. Melts into liquid hydrogen, conductive.")
 elements.property(mlhg,"Name","MLHG")
 elements.property(mlhg, "Temperature", 2.8)
 elements.property(mlhg, "Color", 0x6688CC)
 elements.property(mlhg, "HighTemperature", 4.13)
 elements.property(mlhg, "HighTemperatureTransition", elements.RADM_PT_LHYG)
 function burn(i,x,y,s,n)
 if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.fire.id then
  if math.random(1,3) == 1 then --2/3
   tpt.parts[i].type = tpt.el.embr.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y)
  elseif math.random(1,6) == 3 then --2/2
   tpt.parts[i].type = tpt.el.fire.id
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y)
  elseif math.random(1,3) == 3 then --2/1
   tpt.parts[i].type = tpt.el.smke.id
   sim.pressure(x/4,y/4,0.01)
    tpt.set_property("temp", math.huge, x ,y)
    end --2
   end --1
  end --*1
 tpt.element_func(burn,mlhg)
 
 elements.property(lhyg, "LowTemperature", 4.00)
 elements.property(lhyg, "LowTemperatureTransition", elements.RADM_PT_MLHG)

 elements.property(elements.DEFAULT_PT_HYGN, "LowTemperature", 15.24)
 elements.property(elements.DEFAULT_PT_HYGN, "LowTemperatureTransition", elements.RADM_PT_LHYG)

--Beta updates after this

--P.S. I removed FSAC, sorry FSAC fans, I loved it too, but I had to remove it.

local ntrg = elements.allocate("RADM", "NTRG")
 elements.element(ntrg,elem.element(elem.DEFAULT_PT_HYGN))
 elements.property(ntrg, "Name" , "NTRG")
 elements.property(ntrg, "Description" , "Nitrogen, condenses into liquid nitrogen, heavy.")
 elements.property(ntrg, "Color", 0x6156D8)
 elements.property(ntrg, "Temperature", 234.8)
 elements.property(ntrg, "MenuSection", 6)
 elements.property(ntrg, "MenuVisible", 1)
 elements.property(ntrg, "Diffusion", 2.80)
 elements.property(ntrg, "Gravity", 0.001)
 elements.property(ntrg, "Falldown", 2)
 elements.property(ntrg, "LowTemperature", 68.03)
 elements.property(ntrg, "LowTemperatureTransition", elements.DEFAULT_PT_LN2)

 elements.property(elements.DEFAULT_PT_LN2, "Color", 0x616FDF)
 elements.property(elements.DEFAULT_PT_LN2, "Name", "LNTG")
 elements.property(elements.DEFAULT_PT_LN2, "HighTemperature", 71.26)
 elements.property(elements.DEFAULT_PT_LN2, "HighTemperatureTransition", elements.RADM_PT_NTRG)

 elements.property(elements.DEFAULT_PT_NICE, "Color", 0x7F7FEF)
 elements.property(elements.DEFAULT_PT_NICE, "Name", "FNTG")
 elements.property(elements.DEFAULT_PT_NICE, "Description", "Frozen nitrogen, Very cold, will melt into liquid nitrogen when heated only slightly")


local drsn = elements.allocate("RADM", "DRSN")
 elements.element(drsn,elem.element(elem.DEFAULT_PT_DUST))
 elements.property(drsn, "Name" , "DRSN")
 elements.property(drsn, "Description" , "Dry snow, formed when dry ice is pressurized.")
 elements.property(drsn, "Color", 0xCCDDEE)
 elements.property(drsn, "Temperature", 173.15)
 elements.property(drsn, "MenuSection", 8)
 elements.property(drsn, "MenuVisible", 1)
 elements.property(drsn, "Weight", 1)
 elements.property(drsn, "AirDrag", 0.006)
 elements.property(drsn, "AirLoss", 0.99)
 elements.property(drsn, "Falldown", 1)
 elements.property(drsn, "Gravity", 0.07)
 elements.property(drsn, "HighTemperature", 195.15)
 elements.property(drsn, "HighTemperatureTransition", elements.DEFAULT_PT_CO2)

local ntsn = elements.allocate("RADM", "NTSN")
 elements.element(ntsn,elem.element(elem.DEFAULT_PT_DUST))
 elements.property(ntsn, "Name" , "NTSN")
 elements.property(ntsn, "Description" , "Nitrogen snow, formed when frozen nitrogen is pressurized.")
 elements.property(ntsn, "Color", 0xB989CC)
 elements.property(ntsn, "Temperature", 51.12)
 elements.property(ntsn, "MenuSection", 8)
 elements.property(ntsn, "MenuVisible", 1)
 elements.property(ntsn, "Weight", 1)
 elements.property(ntsn, "AirDrag", 0.006)
 elements.property(ntsn, "AirLoss", 0.99)
 elements.property(ntsn, "Falldown", 1)
 elements.property(ntsn, "Gravity", 0.07)
 elements.property(ntsn, "HighTemperature", 63.10)
 elements.property(ntsn, "HighTemperatureTransition", elements.DEFAULT_PT_LNTG)

 elements.property(elements.DEFAULT_PT_DRIC, "Description", "Dry Ice, formed when carbon dioxide is cooled")
 elements.property(elements.DEFAULT_PT_DRIC, "HighPressure", 1.43)
 elements.property(elements.DEFAULT_PT_DRIC, "HighPressureTransition", elements.RADM_PT_DRSN)

 elements.property(elements.DEFAULT_PT_NICE, "HighPressure", 1.43)
 elements.property(elements.DEFAULT_PT_NICE, "HighPressureTransition", elements.RADM_PT_NTSN)

local hgsn = elements.allocate("RADM", "HGSN")
 elements.element(hgsn,elem.element(elem.DEFAULT_PT_DUST))
 elements.property(hgsn, "Name" , "HGSN")
 elements.property(hgsn, "Description" , "Hydrogen snow, formed when metallic hydrogen is pressurized.")
 elements.property(hgsn, "Color", 0x7799BB)
 elements.property(hgsn, "Temperature", 2.8)
 elements.property(hgsn, "MenuSection", 8)
 elements.property(hgsn, "MenuVisible", 1)
 elements.property(hgsn, "Weight", 1)
 elements.property(hgsn, "AirDrag", 0.006)
 elements.property(hgsn, "AirLoss", 0.99)
 elements.property(hgsn, "Falldown", 1)
 elements.property(hgsn, "Gravity", 0.07)
 elements.property(hgsn, "HighTemperature", 4.13)
 elements.property(hgsn, "HighTemperatureTransition", elements.RADM_PT_LHYG)

 elements.property(mlhg, "HighPressure", 1.43)
 elements.property(mlhg, "HighPressureTransition", elements.RADM_PT_HGSN)

--Alpha updates after this

local grph = elements.allocate("RADM", "GRPH")
 elements.element(grph,elem.element(elem.DEFAULT_PT_METL))
 elements.property(grph, "Name" , "GRPH")
 elements.property(grph, "Description" , "Graphene, extremely durable and heat conductive. Slightly flammable.")
 elements.property(grph, "Color", 0x303036)
 elements.property(grph, "Temperature", 340.8)
 elements.property(grph, "MenuSection", 9)
 elements.property(grph, "MenuVisible", 1)
 elements.property(grph, "Weight", 100)
 elements.property(grph, "HeatConduct", 255)
 elements.property(grph, "Flammable", 0.34)

local derg = elements.allocate("RADM", "DERG")
 elements.element(derg,elem.element(elem.DEFAULT_PT_PHOT))
 elements.property(derg, "Name" , "DERG")
 elements.property(derg, "Description" , "Dark energy, expands quickly.")
 elements.property(derg, "Color", 0x1E0A7F)
 elements.property(derg, "Temperature", 340.8)
 elements.property(derg, "MenuSection", 11)
 elements.property(derg, "MenuVisible", 1)
 elements.property(derg, "Collision", -0.99)
 elements.property(elem.RADM_PT_DERG, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,-0.005)
  velocity(i,1,7)
  end --1
) --*1

local function funcGraphics(i, colr, colg, colb)
    return 1,ren.FIRE_ADD,255,colr,colg,colb,96,30,10,63
end
elements.property(derg, "Graphics", funcGraphics)

local oxsn = elements.allocate("RADM", "OXSN")
 elements.element(oxsn,elem.element(elem.DEFAULT_PT_DUST))
 elements.property(oxsn, "Name" , "OXSN")
 elements.property(oxsn, "Description" , "Oxygen snow, forms when solid oxygen is pressurized.")
 elements.property(oxsn, "Color", 0x90B0FF)
 elements.property(oxsn, "Temperature", 24.31)
 elements.property(oxsn, "MenuSection", 8)
 elements.property(oxsn, "MenuVisible", 1)
 elements.property(oxsn, "Weight", 1)
 elements.property(oxsn, "AirDrag", 0.006)
 elements.property(oxsn, "AirLoss", 0.99)
 elements.property(oxsn, "Falldown", 1)
 elements.property(oxsn, "Gravity", 0.07)
 elements.property(oxsn, "HighTemperature", 30.15)
 elements.property(oxsn, "HighTemperatureTransition", elements.DEFAULT_PT_LOXY)

local moxg = elements.allocate("RADM", "MOXG")
 elements.element(moxg,elem.element(elem.DEFAULT_PT_GOLD))
 elements.property(moxg, "Name" , "MOXG")
 elements.property(moxg, "Description" , "Metallic oxygen, conductive.")
 elements.property(moxg, "HighTemperature", 32.15)
 elements.property(moxg, "Temperature", 19.42)
 elements.property(moxg, "HighTemperatureTransition", elements.DEFAULT_PT_LOXY)
 elements.property(moxg, "Color", 0x54ADB8)
 elements.property(moxg, "HighPressure", 0.76)
 elements.property(moxg, "HighPressureTransition", elements.RADM_PT_OXSN)

 elements.property(elements.DEFAULT_PT_LOXY, "LowTemperature", 31.78)
 elements.property(elements.DEFAULT_PT_LOXY, "LowTemperatureTransition", elements.RADM_PT_MOXG)
 elements.property(elements.DEFAULT_PT_LOXY, "Color", 0x76BEDA)

 elements.property(elements.DEFAULT_PT_NBLE, "Description", "Neon, turns into plasma when electrified")
 elements.property(elements.DEFAULT_PT_NBLE, "Name", "NEON")
 elements.property(elements.DEFAULT_PT_NBLE, "Color", 0x7FFF00)
 elements.property(elements.DEFAULT_PT_NBLE, "Diffusion", 2.14)
 elements.property(elements.DEFAULT_PT_NBLE, "HotAir", 0.0004)
 elements.property(elements.DEFAULT_PT_NBLE, "Gravity", -0.1)

local lneo = elements.allocate("RADM", "LNEO")
 elements.element(lneo,elem.element(elem.DEFAULT_PT_MERC))
 elements.property(lneo, "Name" , "LNEO")
 elements.property(lneo, "Description" , "Liquid neon, cold and conductive.")
 elements.property(lneo, "Temperature", 85.47)
 elements.property(lneo, "Color", 0x70F040)
 elements.property(lneo, "Weight", 3)
 elements.property(lneo, "HighTemperature", 132.45)
 elements.property(lneo, "HighTemperatureTransition", elements.DEFAULT_PT_NBLE)
 elements.property(elem.RADM_PT_LNEO, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.45,3,3)
  end --1
 ) --*1

 elements.property(elements.DEFAULT_PT_NBLE, "LowTemperature", 103.26)
 elements.property(elements.DEFAULT_PT_NBLE, "LowTemperatureTransition", elements.RADM_PT_LNEO)

local ozon = elements.allocate("RADM", "OZON")
 elements.element(ozon,elem.element(elem.DEFAULT_PT_HYGN))
 elements.property(ozon, "Description", "Ozone, turns into oxygen when heated by an object.")
 elements.property(ozon, "Name", "OZON")
 elements.property(ozon, "Color", 0x3242CD)
 elements.property(ozon, "Diffusion", 2.14)
 elements.property(ozon, "HotAir", 0.001)
 elements.property(ozon, "Gravity", -0.01)
 elements.property(elem.RADM_PT_OZON, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~= 0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if sim.partProperty(i, "temp") > 900 then --4
     if math.random(1,128) == 4 then --5
      sim.partChangeType(i, elements.DEFAULT_PT_OXYG)
      end --5
     end --4
    end --3
   end --2  
  end --1
 ) --*1

local lozn = elements.allocate("RADM", "LOZN")
 elements.element(lozn,elem.element(elem.DEFAULT_PT_SOAP))
 elements.property(lozn, "Name" , "LOZN")
 elements.property(lozn, "Description" , "Liquid ozone, cold.")
 elements.property(lozn, "Temperature", 152.34)
 elements.property(lozn, "Color", 0x1031AB)
 elements.property(lozn, "Weight", 3)
 elements.property(lozn, "HighTemperature", 164.52)
 elements.property(lozn, "HighTemperatureTransition", elements.RADM_PT_OZON)
 elements.property(elem.RADM_PT_LOZN, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.333,3,2)
  end --1
 ) --*1

 elements.property(ozon, "LowTemperature", 150.34)
 elements.property(ozon, "LowTemperatureTransition", elements.RADM_PT_LOZN)

 elements.property(elements.DEFAULT_PT_PLSM, "Diffusion", 1)

local bsei = elements.allocate("RADM", "BSEI")
 elements.element(bsei, elements.element(elements.DEFAULT_PT_ELEC))
 elements.property(bsei, "Name" , "BSEI")
 elements.property(bsei, "Description" , "Bose einstein condensates, cold.")
 elements.property(bsei, "Color", 0xCC7CC0)
 elements.property(bsei, "Diffusion", 0.3)
 elements.property(bsei, "Temperature", 0)
 function boseinDecay(i,x,y,s,n) --*1
  if math.random(1,10) == 10 then --1
   sim.partProperty(i, "temp", 0)
   end --1
  end --*1
 function boseinUpdate(i,x,y,s,n) --*2
  velocity(i,2,360)
  boseinDecay(i,x,y,s,n)
  end --*2
 elements.property(bsei,"Update",boseinUpdate)

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.FIRE_ADD,255,colr,colg,colb,192,204,124,192
  end --*1
 elements.property(bsei, "Graphics", funcGraphics)

local cprn = elements.allocate("RADM" , "CPRN")
 elements.element(cprn, elements.element(elements.DEFAULT_PT_PLUT))
 elements.property(cprn, "Name" , "CPRN")
 elements.property(cprn, "Description" , "Copernicium, extremely reactive.")
 elements.property(cprn, "Color", 0x073140)
 elements.property(cprn, "Diffusion", 0.25)
 elements.property(cprn, "MenuSection", 10)
 function copernicium(i,x,y,s,n)
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'uran')
   tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'plut')
   tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'ogan')
   sim.pressure(x/4,y/4,0.01)
   tpt.set_property("temp", math.huge, x, y)
   tpt.parts[i].type = tpt.el.neut.id
   end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    end --4
   end --3
  if math.random(1,10000) == 10 then --5
   tpt.set_property("temp", math.huge, x ,y)
   end --5
  end --*1
 tpt.element_func(copernicium,cprn)
  function neutron(i,x,y,s,n) --*2
   if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == neut then --1
    if math.random(1,30) == 10 then --2
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     end --2
    end --1
   end --*2
 tpt.element_func(neutron,tpt.el.neut.id)

local ptsi = elements.allocate("RADM", "PTSI")
 elements.element(ptsi, elements.element(elements.DEFAULT_PT_BRMT))
 elements.property(ptsi, "Name" , "PTSI")
 elements.property(ptsi, "Description" , "Potassium, alkali metal. Incredibly reactive to water.")
 elements.property(ptsi, "Flammable", 10.95)
 elements.property(ptsi, "Color", 0x09084D)
 elements.property(ptsi, "Temperature", 337.8)
 elements.property(ptsi, "MenuSection", 8)
 elements.property(ptsi, "HighPressure", 1.07)
 elements.property(ptsi, "HighPressureTransition", elements.RADM_PT_FIRE)
 elements.property(ptsi, "Gravity", 0.20)
 elements.property(ptsi, "Weight", 5.13)
 elements.property(elem.RADM_PT_PTSI, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~= 0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --4
     if math.random(1,16) == 4 then --5
      sim.partProperty(r, "type", elements.DEFAULT_PT_FIRE)
      if math.random(1,3) == 3 then --6
       sim.pressure(x/4,y/4,0.2)
       sim.partProperty(i, "temp", 978.56)
       tpt.delete(i)
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local bctr = elements.allocate("RADM", "BCTR")
 elements.element(bctr, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(bctr, "Name" , "BCTR")
 elements.property(bctr, "Description" , "Bacteria, spreads and sticks.")
 elements.property(bctr, "Color", 0xE0FAA1)
 elements.property(bctr, "Diffusion", 0.3)
 elements.property(bctr, "Weight", 30)
 elements.property(bctr, "MenuSection", 11)
 elements.property(elem.RADM_PT_BCTR, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if math.random(1,10) > 1 then --4
     sim.partProperty(i, "vy", 0)
     end --4
    if math.random(1,10) > 1 then --5
     sim.partProperty(i, "vx", 0)
     end --5
    if math.random(1,20) < 4 then --6
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_BCTR)
     end --6
    if math.random(1,40) < 2 then --7
     sim.partKill(i)
     end --7
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WOOD then --8
     if math.random(1,20) < 2 then --9
      sim.partKill(r)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_BCTR)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_BCTR)
      end --9
     end --8
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_PLNT then --10
     if math.random(1,20) < 2 then --11
      sim.partKill(r)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_BCTR)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_BCTR)
      end --11
     end --10
    end --3
   end --2
  end --1
  ) --*1

local naoh = elements.allocate("RADM", "NAOH")
 elements.element(naoh, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(naoh, "Name" , "NAOH")
 elements.property(naoh, "Description", "NaOH aq, makes salt and water with acid.")
 elements.property(naoh, "Color", 0x2140DF)
 elements.property(naoh, "Temperature", 337.8)
 elements.property(naoh, "MenuSection", 7)
 elements.property(naoh, "Hardness", 2)
 elements.property(naoh, "HighPressure", 1.07)
 elements.property(naoh, "HighPressureTransition", elements.RADM_PT_FIRE)
 elements.property(naoh, "Gravity", 0.20)
 elements.property(naoh, "Weight", 5.13)
 elements.property(elem.RADM_PT_NAOH, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~= 0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_ACID then --4
     if math.random(1,16) == 4 then --5
      sim.partProperty(r, "type", elements.DEFAULT_PT_SLTW)
      if math.random(1,4) == 3 then --6
       tpt.delete(i)
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local sdim = elements.allocate("RADM", "SDIM")
elements.element(sdim, elements.element(elements.DEFAULT_PT_METL))
elements.property(sdim, "Name" , "SDIM")
elements.property(sdim, "Description", "Sodium, alkali metal. Very reactive to water.")
elements.property(sdim, "Flammable", 3.95)
elements.property(sdim, "Color", 0xDFEFDF)
elements.property(sdim, "Temperature", 337.8)
elements.property(sdim, "MenuSection", 1)
elements.property(sdim, "HighPressure", 1.07)
elements.property(sdim, "HighPressureTransition", elements.RADM_PT_FIRE)
 elements.property(elem.RADM_PT_SDIM, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~= 0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --4
     if math.random(1,32) == 4 then --5
      sim.partProperty(r, "type", elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "type", elements.RADM_PT_NAOH)
      if math.random(1,3) == 3 then --6
       sim.pressure(x/4,y/4,0.8)
       sim.partProperty(i, "temp", 956.42)
       if math.random(1,2) == 2 then --7
        tpt.delete(i)
        end --7
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local frnc = elements.allocate("RADM", "FRNC")
elements.element(frnc, elements.element(elements.DEFAULT_PT_METL))
elements.property(frnc, "Name" , "FRNC")
elements.property(frnc, "Description", "Francium, alkali metal. Very reactive to water.")
elements.property(frnc, "Flammable", 42.95)
elements.property(frnc, "Color", 0xD1842E)
elements.property(frnc, "Temperature", 337.8)
elements.property(frnc, "MenuSection", 1)
elements.property(frnc, "HighPressure", 0.107)
elements.property(frnc, "HighPressureTransition", elements.RADM_PT_FIRE)
 elements.property(elem.RADM_PT_FRNC, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~= 0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --4
     if math.random(1,16) == 4 then --5
      sim.partProperty(r, "type", elements.DEFAULT_PT_FIRE)
      if math.random(1,2) == 2 then --6
       sim.pressure(x/4,y/4,0.8)
       sim.partProperty(i, "temp", 2956.42)
       if math.random(1,2) == 2 then --7
        tpt.delete(i)
        end --7
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local ltrt = elements.allocate("RADM", "LTRT")
 elements.element(ltrt,elem.element(elem.DEFAULT_PT_DEUT))
 elements.property(ltrt, "Name" , "LTRT")
 elements.property(ltrt, "Description" , "Liquid tritium, neutrons can pass through it. Superfluid.")
 elements.property(ltrt, "Temperature", 23.14)
 elements.property(ltrt, "Color", 0xB3B1CF)
 elements.property(ltrt, "Weight", 3)
 elements.property(ltrt, "HighTemperature", 25.43)
 elements.property(ltrt, "HighTemperatureTransition", elements.RADM_PT_TRIT)
 elements.property(ltrt, "MenuSection", 7)
 elements.property(elem.RADM_PT_LTRT, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.75,2,3)
  end --1
 ) --*1

 elements.property(trit, "LowTemperature", 21.54)
 elements.property(trit, "LowTemperatureTransition", elements.RADM_PT_LTRT)

local lmun = elements.allocate("RADM", "LMUN")
 elements.element(lmun,elem.element(elem.DEFAULT_PT_SOAP))
 elements.property(lmun, "Name" , "LMUN")
 elements.property(lmun, "Description", "Liquid muonium, extremely light. Superfluid.")
 elements.property(lmun, "Temperature", 0.91)
 elements.property(lmun, "Color", 0xCDCD43)
 elements.property(lmun, "Weight", 3)
 elements.property(lmun, "MenuSection", 7)
 elements.property(lmun, "Gravity", 0.04)
 elements.property(elem.RADM_PT_LMUN, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,1.5,2,3)
  end --1
 ) --*1

local munm = elements.allocate("RADM", "MUNM")
elements.element(munm, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(munm, "Name" , "MUNM")
elements.property(munm, "Description" , "Muonium, extremely light. Turns into liquid muonium at very low temperatures.")
elements.property(munm, "Color", 0xBCBC32)
elements.property(munm, "Temperature", 90.8)
elements.property(munm, "MenuSection", 6)
elements.property(munm, "LowTemperature", 1.03)
elements.property(munm, "LowTemperatureTransition", elements.RADM_PT_LMUN)
elements.property(munm, "Diffusion", 0.12)
elements.property(munm, "Falldown", 2)
elements.property(munm, "AirDrag", 0.015)
elements.property(munm, "Gravity", -0.189)

 elements.property(lmun, "HighTemperature", 1.43)
 elements.property(lmun, "HighTemperatureTransition", elements.RADM_PT_MUNM)

local caes = elements.allocate("RADM", "CAES")
elements.element(caes, elements.element(elements.DEFAULT_PT_METL))
elements.property(caes, "Name" , "CAES")
elements.property(caes, "Description", "Caesium, alkali metal. Extremely reactive to water.")
elements.property(caes, "Flammable", 3.95)
elements.property(caes, "Color", 0xACAC8A)
elements.property(caes, "Temperature", 337.8)
elements.property(caes, "MenuSection", 1)
elements.property(caes, "Explosive", 2)
elements.property(caes, "HighPressure", 1.07)
elements.property(caes, "HighPressureTransition", elements.RADM_PT_FIRE)
 elements.property(elem.RADM_PT_CAES, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~= 0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --4
     if math.random(1,32) == 4 then --5
      sim.partProperty(r, "type", elements.DEFAULT_PT_PLSM)
      if math.random(1,3) == 3 then --6
       sim.pressure(x/4,y/4,0.8)
       sim.partProperty(i, "temp", 9956.42)
       if math.random(1,2) == 2 then --7
        tpt.delete(i)
        end --7
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

 elements.property(elem.DEFAULT_PT_LOXY, "Description", "Liquid Oxygen. Very cold, slightly superfluid. Reacts with fire")
 elements.property(elem.DEFAULT_PT_LOXY, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.25,8,5)
  end --1
 ) --*1

local slvr = elements.allocate("RADM", "SLVR")
elements.element(slvr, elements.element(elements.DEFAULT_PT_METL))
elements.property(slvr, "Name" , "SLVR")
elements.property(slvr, "Description", "Silver, resists sulfuric acid. Very heat conductive.")
elements.property(slvr, "Hardness", 0)
elements.property(slvr, "Color", 0xA8A8A8)
elements.property(slvr, "Temperature", 337.8)
elements.property(slvr, "MenuSection", 1)
elements.property(slvr, "HeatConduct", 255)

local nept = elements.allocate("RADM" , "NEPT")
 elements.element(nept, elements.element(elements.DEFAULT_PT_PLUT))
 elements.property(nept, "Name" , "NEPT")
 elements.property(nept, "Description" , "Neptunium, very reactive.")
 elements.property(nept, "Color", 0x557020)
 elements.property(nept, "MenuSection", 10)
 function neptunium(i,x,y,s,n)
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   if math.random(1,4) == 1 then --2/2
    tpt.parts[i].type = elements.DEFAULT_PT_URAN
   elseif math.random(1,10) == 1 then --2/1
    tpt.parts[i].type = elements.RADM_PT_HLUM
    end --2
   end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    tpt.set_property("temp", math.huge, x ,y)
    end --4
   end --3
  if math.random(1,10000) == 10 then --5
   sim.pressure(x/4,y/4,0.1)
   end --5
  end --*1
 tpt.element_func(neptunium,nept)
  function neutron(i,x,y,s,n) --*2
   if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == nept then --1
    if math.random(1,30) == 10 then --2
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     end --2
    end --1
   end --*2
 tpt.element_func(neutron,tpt.el.neut.id)

elements.property(elements.DEFAULT_PT_URAN, "Color", 0x385808)

elements.property(elements.DEFAULT_PT_PLUT, "Color", 0xA87018)

local lrdn = elements.allocate("RADM", "LRDN")
 elements.element(lrdn,elem.element(elem.DEFAULT_PT_SOAP))
 elements.property(lrdn, "Name" , "LRDN")
 elements.property(lrdn, "Description", "Liquid radon. Superfluid.")
 elements.property(lrdn, "Temperature", 0.91)
 elements.property(lrdn, "Color", 0x688830)
 elements.property(lrdn, "Weight", 3)
 elements.property(lrdn, "MenuSection", 7)
 elements.property(lrdn, "Gravity", 0.04)
 elements.property(elem.RADM_PT_LRDN, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.675,4,3)
  end --1
 ) --*1

local radn = elements.allocate("RADM", "RADN")
elements.element(radn, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(radn, "Name" , "RADN")
elements.property(radn, "Description" , "Radon, light gas.")
elements.property(radn, "Color", 0x789840)
elements.property(radn, "Temperature", 301.8)
elements.property(radn, "MenuSection", 6)
elements.property(radn, "LowTemperature", 211.45)
elements.property(radn, "LowTemperatureTransition", elements.RADM_PT_LRDN)
elements.property(radn, "Diffusion", 0.31)
elements.property(radn, "Falldown", 2)
elements.property(radn, "AirDrag", 0.005)
elements.property(radn, "Gravity", -0.11)

 elements.property(lrdn, "HighTemperature", 213.56)
 elements.property(lrdn, "HighTemperatureTransition", elements.RADM_PT_RADN)

local torm = elements.allocate("RADM" , "TORM")
 elements.element(torm, elements.element(elements.DEFAULT_PT_PLUT))
 elements.property(torm, "Name" , "TORM")
 elements.property(torm, "Description" , "Thorium, slightly reactive.")
 elements.property(torm, "Color", 0xA9BBD8)
 elements.property(torm, "MenuSection", 10)
 function thorium(i,x,y,s,n) --*1
  if tpt.get_property("type", x + math.random(-3,3), y + math.random(-3,3)) == tpt.el.neut.id then --1
   if math.random(1,6) == 1 then --2/2
    tpt.parts[i].type = elements.DEFAULT_PT_BRMT
   elseif math.random(1,13) == 1 then --2/1
    tpt.parts[i].type = elements.RADM_PT_RADN
    end --2
   end --1
  if sim.pressure(x/4,y/4) > 2 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    tpt.set_property("temp", math.huge, x ,y)
    end --4
   end --3
  if math.random(1,10000) == 10 then --5
   sim.pressure(x/4,y/4,0.05)
   end --5
  end --*1
 tpt.element_func(thorium,torm)
  function neutron(i,x,y,s,n) --*2
   if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == torm then --1
    if math.random(1,32) == 10 then --2
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     end --2
    end --1
   end --*2
 tpt.element_func(neutron,tpt.el.neut.id)

local fngi = elements.allocate("RADM", "FNGI")
 elements.element(fngi, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(fngi, "Name" , "FNGI")
 elements.property(fngi, "Description" , "Fungi, spreads with spores.")
 elements.property(fngi, "Color", 0x884400)
 elements.property(fngi, "Diffusion", 0.25)
 elements.property(fngi, "MenuSection", 11)
 elements.property(fngi, "Gravity", 0.05)
 elements.property(fngi, "Weight", 31)
 elements.property(elem.RADM_PT_FNGI, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if math.random(1,30) > 1 then --4
     sim.partProperty(i, "vy", 0)
     end --4
    if math.random(1,30) > 1 then --5
     sim.partProperty(i, "vx", 0)
     end --5
    if math.random(1,50) < 4 then --6
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_FNGI)
     end --6
    if math.random(1,80) < 2 then --7
     sim.partKill(i)
     end --7
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_PLNT then --8
     if math.random(1,40) < 2 then --9
      sim.partKill(r)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_FNGI)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_FNGI)
      end --9
     end --8
    end --3
   end --2
  end --1
  ) --*1

local alge = elements.allocate("RADM", "ALGE")
 elements.element(alge, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(alge, "Name" , "ALGE")
 elements.property(alge, "Description" , "Algae, live on water.")
 elements.property(alge, "Color", 0x007700)
 elements.property(alge, "Diffusion", 0.15)
 elements.property(alge, "MenuSection", 11)
 elements.property(alge, "Gravity", 0.09)
 elements.property(alge, "Weight", 29)
 elements.property(elem.RADM_PT_ALGE, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if math.random(1,10) > 1 then --4
     sim.partProperty(i, "vy", 0)
     end --4
    if math.random(1,10) > 1 then --5
     sim.partProperty(i, "vx", 0)
     end --5
    if math.random(1,50) < 4 then --6
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_ALGE)
     end --6
    if math.random(1,80) < 2 then --7
     sim.partKill(i)
     end --7
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --8
     if math.random(1,40) < 2 then --9
      if math.random(1,50) < 2 then --10
       sim.partProperty(r, "type", elements.RADM_PT_ALGE)
       end --10
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_ALGE)
      end --9
     end --8
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WOOD then --11
     if math.random(1,40) < 2 then --12
      sim.partKill(r)
      if math.random(1,40) < 2 then --13
       sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.DEFAULT_PT_CO2)
       end --13
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_ALGE)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.RADM_PT_ALGE)
      end --12
     end --11
    end --3
   end --2
  end --1
  ) --*1

--This one was suggested by T4chy0n

local qtfm = elements.allocate("RADM", "QTFM")
 elements.element(qtfm, elements.element(elements.DEFAULT_PT_PROT))
 elements.property(qtfm, "Name" , "QTFM")
 elements.property(qtfm, "Description" , "Quantum Foam, what subatomic particles are made of.")
 elements.property(qtfm, "Color", 0xB8C8DF)
 elements.property(qtfm, "Diffusion", 0.005)
 function virtuaParticleVanish(i,x,y,s,n) --*1
  if math.random(1,10) == 10 then --1
   sim.partKill(i)
   end --1
  end --*1
 function virtuaParticleUpdate(i,x,y,s,n) --*2
  velocity(i,2,4)
  virtuaParticleVanish(i,x,y,s,n)
  end --*2
 elements.property(qtfm,"Update",virtuaParticleUpdate)

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.FIRE_ADD,255,colr,colg,colb,192,184,200,223
  end --*1
 elements.property(qtfm, "Graphics", funcGraphics)

local hgbs = elements.allocate("RADM", "HGBS")
 elements.element(hgbs, elements.element(elements.DEFAULT_PT_PROT))
 elements.property(hgbs, "Name" , "HGBS")
 elements.property(hgbs, "Description" , "Higgs Boson, decays quickly. Slightly attractive.") 
 elements.property(hgbs, "Color", 0xE8D8AF)
 elements.property(hgbs, "Diffusion", 0.02)
 function higgsBurst(i,x,y,s,n) --*1
  if math.random(1,1000) == 10 then --1
   sim.partKill(i)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   end --1
  end --*1
 function higgsUpdate(i,x,y,s,n) --*2
  attract(i,x,y,0.007)
  velocity(i,3,5)
  higgsBurst(i,x,y,s,n)
  end --*2
 elements.property(hgbs,"Update",higgsUpdate)

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.FIRE_ADD,255,colr,colg,colb,192,238,226,195
  end --*1
 elements.property(hgbs, "Graphics", funcGraphics)

--This one was suggested by ZexagonVNC (aka Tungster24, my friend)

local plnk = elements.allocate("RADM", "PLNK")
 elements.element(plnk, elements.element(elements.DEFAULT_PT_PROT))
 elements.property(plnk, "Name", "PLNK")
 elements.property(plnk, "Description",  "Planck particle, destroys nearby particles.") 
 elements.property(plnk, "Color", 0x001530)
 elements.property(plnk, "Diffusion", 0.01)
 function planckDestroy(i,x,y,s,nt) --*1
  if math.random(1,10) == 10 then --1
   if s ~=8 and nt ~=0 and nt - s > 0 then --2
    for r in sim.neighbors(x,y,1,1) do --3
     if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_DMND then --4
      if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_VACU then --5
       if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_VOID then --6
        sim.partKill(r)
        if math.random(1,15) == 15 then --7
         sim.partKill(i)
         end --7
        end --6
       end --5
      end --4
     end --3
    end --2
   end --1
  end --*1
 function planckUpdate(i,x,y,s,n) --*2
  velocity(i,4,10)
  planckDestroy(i,x,y,s,n)
  end --*2
 elements.property(plnk,"Update",planckUpdate)

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.FIRE_ADD,255,colr,colg,colb,128,128,212,255
  end --*1
 elements.property(plnk, "Graphics", funcGraphics)

local sulf = elements.allocate("RADM", "SULF")
 elements.element(sulf, elements.element(elements.DEFAULT_PT_DUST))
 elements.property(sulf, "Name" , "SULF")
 elements.property(sulf, "Description" , "Sulfur, very flammable.")
 elements.property(sulf, "Flammable", 40.12)
 elements.property(sulf, "Color", 0xA59314)
 elements.property(sulf, "Temperature", 310.2)
 elements.property(sulf, "MenuSection", 8)
 elements.property(sulf, "Gravity", 0.10)
 elements.property(sulf, "Weight", 30.23)
 elements.property(sulf, "Explosive", 1)

local qgp = elements.allocate("RADM", "QGP")
 elements.element(qgp, elements.element(elements.RADM_PT_HLUM))
 elements.property(qgp, "Name" , "QGP")
 elements.property(qgp, "Description" , "Quark-Gluon Plasma, hot.")
 elements.property(qgp, "Color", 0x10FF88)
 elements.property(qgp, "Weight", -1)
 elements.property(qgp, "Collision", -0.99)
 elements.property(qgp, "Diffusion", 0.3)
 function qgpHeat(i,x,y,s,n) --*1
  if math.random(1,50) == 10 then --1
   sim.partProperty(i, "temp", 9725.85)
   end --1
  end --*1
 function qgpUpdate(i,x,y,s,n) --*2
  qgpHeat(i,x,y,s,n)
  end --*2
 elements.property(qgp,"Update",qgpUpdate)

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.FIRE_ADD,255,colr,colg,colb,192,16,255,136
  end --*1
 elements.property(qgp, "Graphics", funcGraphics)

local nedf = elements.allocate("RADM", "NEDF")
 elements.element(nedf, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(nedf, "Name" , "NEDF")
 elements.property(nedf, "Description" , "Neutron-Electron Degenerate Fluid, extremely dense. Perfect superfluid.")
 elements.property(nedf, "Color", 0xCCDDFF)
 elements.property(nedf, "Temperature", 6.10)
 elements.property(nedf, "MenuSection", 7)
 elements.property(nedf, "Falldown", 2)
 elements.property(nedf, "AirDrag", 0.01)
 elements.property(nedf, "Weight", 60)
 elements.property(nedf, "Gravity", 0.08)
 elements.property(elem.RADM_PT_NEDF, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,1.2,9999,1)
  end --1
 ) --*1

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.FIRE_ADD,255,colr,colg,colb,192,204,221,255
  end --*1
 elements.property(nedf, "Graphics", funcGraphics)

 elements.property(qgp, "LowTemperature", 5.63)
 elements.property(qgp, "LowTemperatureTransition", elements.RADM_PT_NEDF)

local lqnt = elements.allocate("RADM", "LQNT")
 elements.element(lqnt, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(lqnt, "Name" , "LQNT")
 elements.property(lqnt, "Description" , "Liquid quintine, extremely cold, superfluid.")
 elements.property(lqnt, "Color", 0x8F1FFF)
 elements.property(lqnt, "Temperature", 1.10)
 elements.property(lqnt, "MenuSection", 7)
 elements.property(lqnt, "Diffusion", 0.1)
 elements.property(lqnt, "Falldown", 2)
 elements.property(lqnt, "AirDrag", 0.01)
 elements.property(lqnt, "Gravity", 0.027)
 elements.property(elem.RADM_PT_LQNT, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.95,3,3)
  end --1
) --*1

local qint = elements.allocate("RADM", "QINT")
elements.element(qint, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(qint, "Name", "QINT")
elements.property(qint, "Description", "Quintine, very light. Turns into liquid quintine at low temperatures.")
elements.property(qint, "Color", 0x7F0EFF)
elements.property(qint, "LowTemperature", 5.64)
elements.property(qint, "LowTemperatureTransition", elements.RADM_PT_LQNT)
elements.property(qint, "Diffusion", 0.078)
elements.property(qint, "MenuSection", 10)
elements.property(qint, "Falldown", 2)
elements.property(qint, "AirDrag", 0.015)
elements.property(qint, "Gravity", -0.013)
function qintDecay(i,x,y,s,n) --*1
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   if math.random(1,3) == 1 then --2/3
   tpt.parts[i].type = elements.RADM_PT_TRIT
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,6) == 3 then --2/2
   tpt.parts[i].type = elements.RADM_PT_HLUM
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x, y)
   elseif math.random(1,3) == 3 then --2/1
   tpt.parts[i].type = elements.DEFAULT_PT_HYGN
   sim.pressure(x/4,y/4,75)
   tpt.set_property("temp", math.huge, x ,y)
  end --1
 end
 if sim.pressure(x/4,y/4) > 1 then
 if math.random(1,250) == 10 then
 tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
 end
 end
 end
 tpt.element_func(qintDecay,qint)
 function neutron(i,x,y,s,n) --*2
 if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == qint then
 if math.random(1,20) == 10 then
 tpt.create(x + math.random(-2,2), y + math.random(-1,1), 'neut')
 end
 end
 end
 tpt.element_func(neutron,tpt.el.neut.id)

 elements.property(lqnt, "HighTemperature", 5.67)
 elements.property(lqnt, "HighTemperatureTransition", elements.RADM_PT_QINT)

local lqdr = elements.allocate("RADM", "LQDR")
 elements.element(lqdr,elem.element(elem.DEFAULT_PT_EXOT))
 elements.property(lqdr, "Name" , "LQDR")
 elements.property(lqdr, "Description" , "Liquid quadrium, electrons can pass through it. Superfluid.")
 elements.property(lqdr, "Temperature", 19.32)
 elements.property(lqdr, "Color", 0xA79AAA)
 elements.property(lqdr, "Weight", 4)
 elements.property(lqdr, "HighTemperature", 21.03)
 elements.property(lqdr, "HighTemperatureTransition", elements.RADM_PT_QUDR)
 elements.property(lqdr, "MenuSection", 7)
 elements.property(elem.RADM_PT_LQDR, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.35,4,6)
  end --1
 ) --*1

 elements.property(qudr, "LowTemperature", 17.54)
 elements.property(qudr, "LowTemperatureTransition", elements.RADM_PT_LQDR)

local lpnt = elements.allocate("RADM", "LPNT")
 elements.element(lpnt,elem.element(elem.DEFAULT_PT_DEUT))
 elements.property(lpnt, "Name" , "LPNT")
 elements.property(lpnt, "Description" , "Liquid pentium. Superfluid.")
 elements.property(lpnt, "Temperature", 12.30)
 elements.property(lpnt, "Color", 0x8BC2C4)
 elements.property(lpnt, "Weight", 4)
 elements.property(lpnt, "HighTemperature", 14.13)
 elements.property(lpnt, "HighTemperatureTransition", elements.RADM_PT_PENT)
 elements.property(lpnt, "MenuSection", 7)
 elements.property(elem.RADM_PT_LPNT, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.325,2,4)
  end --1
 ) --*1

 elements.property(pent, "LowTemperature", 12.4)
 elements.property(pent, "LowTemperatureTransition", elements.RADM_PT_LPNT)


 elements.property(elements.DEFAULT_PT_SMKE, "Name", "ASH")
 elements.property(elements.DEFAULT_PT_SMKE, "Gravity", 0.04)
 elements.property(elements.DEFAULT_PT_SMKE, "MenuSection", 8)
 elements.property(elements.DEFAULT_PT_SMKE, "Advection", 1)
 elements.property(elements.DEFAULT_PT_SMKE, "HotAir", 0)
 elements.property(elements.DEFAULT_PT_SMKE, "Description" , "Ash, burns at high temperatures.")


 elements.property(elements.DEFAULT_PT_HYGN, "Color", 0xAACCEE)
 elements.property(elements.DEFAULT_PT_HYGN, "Gravity", -0.1)
 elements.property(elements.DEFAULT_PT_HYGN, "Falldown", 2)
 elements.property(elements.DEFAULT_PT_HYGN, "Diffusion", 2)

 elements.property(elem.DEFAULT_PT_GLOW, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.008)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_WATR, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.01)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_OIL, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.014)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_MERC, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.021)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_LAVA, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.023)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_MWAX, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.031)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_VIRS, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.025)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_BUBW, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.011)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_SLTW, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.013)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_DSTW, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.009)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_GEL, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.036)
  end --1
) --*1

 elements.property(elem.DEFAULT_PT_SOAP, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.034)
  end --1
) --*1

local mhlm = elements.allocate("RADM", "MHLM")
 elements.element(mhlm,elem.element(elem.DEFAULT_PT_GOLD))
 elements.property(mhlm, "Description", "Metallic helium 3, incredibly cold. Melts into liquid helium 3, conductive.")
 elements.property(mhlm, "Name", "MHLM")
 elements.property(mhlm, "Temperature", 0)
 elements.property(mhlm, "Color", 0xCCA0B3)
 elements.property(mhlm, "HighTemperature", 2.13)
 elements.property(mhlm, "HighTemperatureTransition", elements.RADM_PT_LHLM)
 
 elements.property(lhlm, "LowTemperature", 0.23)
 elements.property(lhlm, "LowTemperatureTransition", elements.RADM_PT_MHLM)

local mhe3 = elements.allocate("RADM", "MHE3")
 elements.element(mhe3,elem.element(elem.DEFAULT_PT_GOLD))
 elements.property(mhe3, "Description", "Metallic helium 3, incredibly cold. Melts into liquid helium 3, conductive.")
 elements.property(mhe3, "Name", "MHE3")
 elements.property(mhe3, "Temperature", 0)
 elements.property(mhe3, "Color", 0x9990CF)
 elements.property(mhe3, "HighTemperature", 2.13)
 elements.property(mhe3, "HighTemperatureTransition", elements.RADM_PT_LHE3)

 elements.property(lhe3, "LowTemperature", 0.23)
 elements.property(lhe3, "LowTemperatureTransition", elements.RADM_PT_MHE3)

local mozn = elements.allocate("RADM", "MOZN")
 elements.element(mozn,elem.element(elem.DEFAULT_PT_GOLD))
 elements.property(mozn, "Description", "Metallic ozone, very cold. Melts into liquid ozone, conductive.")
 elements.property(mozn, "Name", "MOZN")
 elements.property(mozn, "Temperature", 80.95)
 elements.property(mozn, "Color", 0x002089)
 elements.property(mozn, "HighTemperature", 84.21)
 elements.property(mozn, "HighTemperatureTransition", elements.RADM_PT_LOZN)
 
 elements.property(lozn, "LowTemperature", 82.34)
 elements.property(lozn, "LowTemperatureTransition", elements.RADM_PT_MOZN)

 elements.property(elem.DEFAULT_PT_DEUT, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.02)
  end --1
 ) --*

 elements.property(elem.DEFAULT_PT_DESL, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.027)
  end --1
 ) --*1

 elements.property(elem.DEFAULT_PT_ACID, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.039)
  end --1
 ) --*1

 elements.property(elements.DEFAULT_PT_OXYG, "Color", 0x87CFFA)

local u235 = elements.allocate("RADM" , "U235")
 elements.element(u235, elements.element(elements.DEFAULT_PT_PLUT))
 elements.property(u235, "Name" , "U235")
 elements.property(u235, "Description" , "Uranium 235, very reactive.")
 elements.property(u235, "Meltable" , 1)
 elements.property(u235, "HighTemperature", 804.31)
 elements.property(u235, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
 elements.property(u235, "Color", 0x204800)
 elements.property(u235, "MenuSection", 10)
 function uran235(i,x,y,s,n)
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   if math.random(1,10) == 1 then --2/2
    tpt.parts[i].type = elements.DEFAULT_PT_URAN
   elseif math.random(1,50) == 1 then --2/1
    tpt.parts[i].type = elements.DEFAULT_PT_GRVT
   elseif math.random(1,50) == 1 then --2/1
    tpt.parts[i].type = elements.DEFAULT_PT_PLUT
    end --2
   end --1
  if sim.pressure(x/4,y/4) > 5 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    tpt.set_property("temp", math.huge, x ,y)
    end --4
   end --3
  if math.random(1,10000) == 10 then --5
   sim.pressure(x/4,y/4,0.01)
   end --5
  end --*1
 tpt.element_func(uran235,u235)
  function neutron(i,x,y,s,n) --*2
   if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == u235 then --1
    if math.random(1,30) == 10 then --2
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     end --2
    end --1
   end --*2
 tpt.element_func(neutron,elements.DEFAULT_PT_NEUT)

--Suggested by 7VY

local nmfl = elements.allocate("RADM", "NMFL")
 elements.element(nmfl,elem.element(elem.DEFAULT_PT_SOAP))
 elements.property(nmfl, "Description", "Negative mass fluid, accelerates backwards.")
 elements.property(nmfl, "Name", "NMFL")
 elements.property(nmfl, "Advection", -0.5)
 elements.property(nmfl, "Color", 0x00FF88)

 elements.property(derg, "HighPressure", 128)
 elements.property(derg, "HighPressureTransition", elements.RADM_PT_NMFL)

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.FIRE_ADD,255,colr,colg,colb,192,0,255,128
  end --*1
 elements.property(nmfl, "Graphics", funcGraphics)

local dmtr = elements.allocate("RADM", "DMTR")
 elements.property(dmtr, "Name" , "DMTR")
 elements.property(dmtr, "Description" , "Dark matter, attracts.")
 elements.property(dmtr, "Color", 0x1F0C1F)
 elements.property(dmtr, "Temperature", 340.8)
 elements.property(dmtr, "MenuSection", 11)
 elements.property(dmtr, "MenuVisible", 1)
 elements.property(dmtr, "Collision", -0.99)
 elements.property(elem.RADM_PT_DMTR, "Update", --*1
 function(i,x,y) --1
  if sim.partProperty(i, "tmp2") ~=1 then --2
   attract(i,x,y,sim.partProperty(i, "tmp"))
  else
   attract(i,x,y,sim.partProperty(i, "tmp"))
   if sim.partProperty(i, "life") > 0 then --3
   sim.partProperty(i, "life", sim.partProperty(i, "life")-1)
   else
    attract(i,x,y,sim.partProperty(i, "tmp")*-1)
    sim.partProperty(i, "life", 30)
    end --3
   if sim.partProperty(i, "life") > 0 then --4
    sim.partProperty(i, "life", sim.partProperty(i, "life")-1)
   else
    attract(i,x,y,sim.partProperty(i, "tmp"))
    sim.partProperty(i, "life", 30)
   end --4
   end --2
  end --1
) --*1

local function funcGraphics(i, colr, colg, colb)
    return 1,ren.FIRE_ADD,255,colr,colg,colb,96,31,12,31
end
elements.property(dmtr, "Graphics", funcGraphics)

 elements.property(dmtr, "LowPressure", -255)
 elements.property(dmtr, "LowPressureTransition", elements.RADM_PT_DERG)

local lamn = elements.allocate("RADM", "LAMN")
 elements.element(lamn,elem.element(elem.DEFAULT_PT_SOAP))
 elements.property(lamn, "Name" , "LAMN")
 elements.property(lamn, "Description" , "Liquid ammonia. Slightly superfluid.")
 elements.property(lamn, "Temperature", 240.31)
 elements.property(lamn, "Color", 0x8167E6)
 elements.property(lamn, "Weight", 4)
 elements.property(lamn, "MenuSection", 7)
 elements.property(elem.RADM_PT_LAMN, "Update", --*1
 function(i,x,y,s,nt) --1
  superfluid(i,x,y,s,nt,0.325,4,3)
  end --1
 ) --*1

local amon = elements.allocate("RADM", "AMON")
 elements.element(amon,elem.element(elem.DEFAULT_PT_HYGN))
 elements.property(amon, "Name" , "AMON")
 elements.property(amon, "Description" , "Ammonia.")
 elements.property(amon, "Color", 0x8269E9)
 elements.property(amon, "Temperature", 334.8)
 elements.property(amon, "Diffusion", 1.90)
 elements.property(amon, "Falldown", 2)
 elements.property(amon, "Gravity", 0.00)
 elements.property(amon, "LowTemperature", 239.81)
 elements.property(amon, "LowTemperatureTransition", elements.RADM_PT_LAMN)

 elements.property(lamn, "HighTemperature",  241.86)
 elements.property(lamn, "HighTemperatureTransition", elements.RADM_PT_AMON)

local preo = elements.allocate("RADM", "PREO")
 elements.element(preo, elements.element(elements.DEFAULT_PT_PROT))
 elements.property(preo, "Name", "PREO")
 elements.property(preo, "Description",  "Preons, generate matter.") 
 elements.property(preo, "Color", 0xFF00FF)
 elements.property(preo, "Diffusion", 0.01)
 function preonGenerate(i,x,y,s,n) --*1
  if math.random(1,1000) == 10 then --1
   sim.partKill(i)
   sim.partCreate(-1, x, y, elements.RADM_PT_TAUO)
   sim.partCreate(-1, x, y, elements.RADM_PT_TAUO)
   sim.partCreate(-1, x, y, elements.RADM_PT_TAUO)
   sim.partCreate(-1, x, y, elements.RADM_PT_DERG)
   sim.partCreate(-1, x, y, elements.RADM_PT_DERG)
   sim.partCreate(-1, x, y, elements.RADM_PT_DERG)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   sim.partCreate(-1, x, y, elements.RADM_PT_QTFM)
   end --1
  end --*1
 function preonUpdate(i,x,y,s,n) --*2
  velocity(i,4.5,9)
  preonGenerate(i,x,y,s,n)
  end --*2
 elements.property(preo,"Update",preonUpdate)

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.FIRE_ADD,255,colr,colg,colb,128,255,0,255
  end --*1
 elements.property(preo, "Graphics", funcGraphics)

local mlgs = elements.allocate("RADM", "MLGS")
 elements.element(mlgs, elements.element(elements.DEFAULT_PT_METL))
 elements.property(mlgs, "Name" , "MLGS")
 elements.property(mlgs, "Description" , "Metallic glass, strong.")
 elements.property(mlgs, "Color", 0x4F4F5F)
 elements.property(mlgs, "Temperature", 295.15)
 elements.property(mlgs, "HeatConduct", 240)
 elements.property(mlgs, "Meltable", 1)
 elements.property(mlgs, "AirLoss", 0.25)
 elements.property(mlgs, "HighTemperature", 4500)
 elements.property(elem.RADM_PT_MLGS, "Update", --*1
 function(i,x,y) --1
  if math.random(1,40) == 1 then --2
   if sim.pressure(x/4,y/4) > 70 then --3
    sim.partChangeType(i, elements.DEFAULT_PT_BREL)
    end --3
   end --2
  end --1
 ) --*1

 elements.property(elements.DEFAULT_PT_BREL, "Color", 0x484F58)
 elements.property(elements.DEFAULT_PT_BREL, "Name", "ALUM")
 elements.property(elements.DEFAULT_PT_BREL, "Description" , "Aluminium powder, becomes EXOT at high pressure when sparked. Can make thermite.")

 elements.property(elements.DEFAULT_PT_METL, "Color", 0x343846)
 elements.property(elements.DEFAULT_PT_METL, "Name", "STEL")
 elements.property(elements.DEFAULT_PT_METL, "Description" , "Steel, basic conductor. Made from iron and coal.")

 elements.property(elements.DEFAULT_PT_SWCH, "MenuSection", 2)
 elements.property(elements.DEFAULT_PT_DMG, "MenuSection", 5)
 elements.property(elements.DEFAULT_PT_GBMB, "MenuSection", 5)

local plxi = elements.allocate("RADM", "PLXI")
 elements.element(plxi, elements.element(elements.DEFAULT_PT_GLAS))
 elements.property(plxi, "Name" , "PLXI")
 elements.property(plxi, "Description" , "Plexiglass, strong.")
 elements.property(plxi, "Color", 0x4F6F7F)
 elements.property(plxi, "Temperature", 295.15)
 elements.property(plxi, "HeatConduct", 240)
 elements.property(plxi, "Meltable", 1)
 elements.property(plxi, "AirLoss", 1)
 elements.property(plxi, "HighTemperature", 3500)
 elements.property(elem.RADM_PT_PLXI, "Update", --*1
 function(i,x,y) --1
  if math.random(1,40) == 1 then --2
   if sim.pressure(x/4,y/4) > 55 then --3
    if math.random(1,3) == 1 then --4/3
     sim.partChangeType(i, elements.DEFAULT_PT_CLST)
    elseif math.random(1,3) == 3 then --4/2
     sim.partChangeType(i, elements.DEFAULT_PT_PQRT)
    elseif math.random(1,3) == 1 then --4/1
     sim.partChangeType(i, elements.DEFAULT_PT_BGLA)
     end --4
    end --3
   end --2
  end --1
 ) --*1

local fwtr = elements.allocate("RADM", "FWTR")
 elements.element(fwtr, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(fwtr, "Name" , "FWTR")
 elements.property(fwtr, "Description" , "Fluoridated water, slightly corrosive.")
 elements.property(fwtr, "Color", 0x6080B0)
 elements.property(elem.RADM_PT_FWTR, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   if math.random(1,500) == 10 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_DMND then --5
      if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_VACU then --6
       if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_VOID then --7
        if math.random(1,4) == 2 then --8
         sim.partKill(r)
         if math.random(1,15) == 15 then --9
          sim.partKill(i)
          end --9
         end --8
        end --7
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local naf = elements.allocate("RADM", "NAF")
 elements.element(naf, elements.element(elements.DEFAULT_PT_SALT))
 elements.property(naf, "Name" , "NAF")
 elements.property(naf, "Description" , "Fluorine salt, makes fluoridated water with WATR.")
 elements.property(naf, "Color", 0xFFFFCC)
 elements.property(elem.RADM_PT_NAF, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,50) == 10 then --2
   if s ~=8 and nt ~=0 and nt - s > 0 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --5
      sim.partChangeType(i, elements.RADM_PT_FWTR)
      sim.partChangeType(r, elements.RADM_PT_FWTR)
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

 elements.property(elements.DEFAULT_PT_SALT, "Name", "NACL")


local alvp = elements.allocate("RADM", "ALVP")
 elements.element(alvp,elem.element(elem.DEFAULT_PT_BOYL))
 elements.property(alvp, "Name" , "ALVP")
 elements.property(alvp, "Description" , "Alcohol vapors, flammable.")
 elements.property(alvp, "Color", 0x4080F0)
 elements.property(alvp, "Temperature", 302.15)
 elements.property(alvp, "Diffusion", 0.90)
 elements.property(alvp, "Flammable", 90.45)
 elements.property(alvp, "Falldown", 2)
 elements.property(alvp, "Gravity", -0.019)

local alch = elements.allocate("RADM", "ALCH")
 elements.element(alch, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(alch, "Name" , "ALCH")
 elements.property(alch, "Description" , "Alcohol, evaporates slowly.")
 elements.property(alch, "Color", 0x2060F0)
 elements.property(alch, "Weight", 30)
 elements.property(elem.RADM_PT_ALCH, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,1024) == 1024 then --2
   sim.partChangeType(i, elements.RADM_PT_ALVP)
   end --2
  end --1
  ) --*1

 elements.property(alvp, "LowTemperature", 293.27)
 elements.property(alvp, "LowTemperatureTransition", elements.RADM_PT_ALCH)

local slop = elements.allocate("RADM", "SLOP")
 elements.element(slop,elem.element(elem.DEFAULT_PT_SOAP))
 elements.property(slop, "Name" , "SLOP")
 elements.property(slop, "Description" , "Slopane, flammable viscous liquid.")
 elements.property(slop, "Color", 0x404040)
 elements.property(slop, "Temperature", 302.15)
 elements.property(slop, "Falldown", 2)
 elements.property(slop, "Weight" , "30")
 elements.property(slop, "Loss", 0.76)
 elements.property(slop, "AirDrag", 0.01)
 elements.property(slop, "Gravity", 0.04)
 elements.property(slop, "Advection", 0.04)
 elements.property(slop, "Flammable", 10) 
 elements.property(slop, "MenuSection", 5)
 elements.property(elem.RADM_PT_SLOP, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.001)
  end --1
 ) --*1

 elements.property(prpn, "LowPressure", -4.32)
 elements.property(prpn, "LowPressureTransition", elements.RADM_PT_SLOP)

local bmvp = elements.allocate("RADM", "BMVP")
 elements.element(bmvp,elem.element(elem.DEFAULT_PT_BOYL))
 elements.property(bmvp, "Name" , "BMVP")
 elements.property(bmvp, "Description" , "Bromine vapor, burns elements.")
 elements.property(bmvp, "Color", 0x880000)
 elements.property(bmvp, "Temperature", 421.86)
 elements.property(bmvp, "Diffusion", 2.05)
 elements.property(bmvp, "Falldown", 2)
 elements.property(bmvp, "Gravity", -0.013)

local brmn = elements.allocate("RADM", "BRMN")
 elements.element(brmn, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(brmn, "Name" , "BRMN")
 elements.property(brmn, "Description" , "Bromine, sets elements on fire.")
 elements.property(brmn, "Color", 0x401000)
 elements.property(brmn, "Temperature", 328.97)
 elements.property(brmn, "Flammable", 10.45)
 elements.property(brmn, "Weight", 45)
 elements.property(elem.RADM_PT_BRMN, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 2 then --2
   if math.random(1,128) == 128 then --3
    sim.partChangeType(i, elements.RADM_PT_BMVP)
    end --3
   if s ~=8 and nt ~=0 and nt - s > 0 then --4
    for r in sim.neighbors(x,y,1,1) do --5
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_PLNT then --6
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --6
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_WOOD then --7
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --7
     if sim.partProperty(r, "type") == elements.RADM_PT_LITH then --7
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --7
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_COAL then --7
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --7
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --7
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --7
     end --4
    end --3
   end --2
  end --1
  ) --*1


 elements.property(elem.RADM_PT_BMVP, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,10) == 10 then --2
   if math.random(1,2048) == 320 then --3
    sim.partChangeType(i, elements.RADM_PT_BRMN)
    end --3
   if s ~=8 and nt ~=0 and nt - s > 0 then --4
    for r in sim.neighbors(x,y,1,1) do --5
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_PLNT then --6
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --6
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_WOOD then --7
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --7
     if sim.partProperty(r, "type") == elements.RADM_PT_LITH then --7
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --7
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_COAL then --7
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --7
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --7
      sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
      sim.partProperty(i, "temp", 4000)
      end --7
     end --4
    end --3
   end --2
  end --1
  ) --*1

 elements.property(bmvp, "LowTemperature", 326.86)
 elements.property(bmvp, "LowTemperatureTransition", elements.RADM_PT_BRMN)