
-- Functionally identical to restrict_flt() in source
function restrict(f, min, max)
    if f < min then
        return min
    elseif f > max then
        return max
    end
    return f
end
 
elem.allocate("CXI", "POTA")
elem.element(elem.CXI_PT_POTA, elem.element(elem.DEFAULT_PT_DMND))
 
elem.property(elem.CXI_PT_POTA, "Name", "PTAT")
elem.property(elem.CXI_PT_POTA, "Description", "Potato.")
elem.property(elem.CXI_PT_POTA, "Colour", 0xc0a068)
elem.property(elem.CXI_PT_POTA, "MenuVisible", 1)
elem.property(elem.CXI_PT_POTA, "MenuSection", elem.SC_SPECIAL)
 
elem.property(elem.CXI_PT_POTA, "Advection", 0)
elem.property(elem.CXI_PT_POTA, "AirDrag", 0)
elem.property(elem.CXI_PT_POTA, "AirLoss", 0.9)
elem.property(elem.CXI_PT_POTA, "Loss", 0)
elem.property(elem.CXI_PT_POTA, "Collision", 0)
elem.property(elem.CXI_PT_POTA, "Gravity", 0)
elem.property(elem.CXI_PT_POTA, "Diffusion", 0)
elem.property(elem.CXI_PT_POTA, "HotAir", 0)
 
elem.property(elem.CXI_PT_POTA, "Explosive", 0)
elem.property(elem.CXI_PT_POTA, "Flammable", 10)
elem.property(elem.CXI_PT_POTA, "Hardness", 15)
elem.property(elem.CXI_PT_POTA, "Meltable", 0)
elem.property(elem.CXI_PT_POTA, "Weight", 100)
 
elem.property(elem.CXI_PT_POTA, "HeatConduct", 164)
elem.property(elem.CXI_PT_POTA, "Temperature", 295.15)
 
elem.property(elem.CXI_PT_POTA, "Falldown", 0)
elem.property(elem.CXI_PT_POTA, "State", elem.ST_SOLID)
elem.property(elem.CXI_PT_POTA, "Properties", elem.TYPE_SOLID, elem.PROP_NEUTPENETRATE)
 
elem.property(elem.CXI_PT_POTA, "LowPressure", IPL)
elem.property(elem.CXI_PT_POTA, "LowPressureTransition", NT)
elem.property(elem.CXI_PT_POTA, "HighPressure", IPH)
elem.property(elem.CXI_PT_POTA, "HighPressureTransition", NT)
elem.property(elem.CXI_PT_POTA, "LowTemperature", ITL)
elem.property(elem.CXI_PT_POTA, "LowTemperatureTransition", NT)
elem.property(elem.CXI_PT_POTA, "HighTemperature", 800)
elem.property(elem.CXI_PT_POTA, "HighTemperatureTransition", elem.DEFAULT_PT_FIRE)
 
function POTA_Update(i, x, y, ss, nt)
    -- i: particle index
    -- x, y: particle x, y coords
 
    id = sim.partID(x + math.random(-1,1), y + math.random(-1,1))
 
    if id ~= nil and (sim.partProperty(id, "type") == elem.DEFAULT_PT_STKM or sim.partProperty(id, "type") == elem.DEFAULT_PT_STKM2) and sim.partProperty(id, "life") < 65400 then
        sim.partProperty(id, "life", sim.partProperty(id, "life") + 100)
    end
 
    if sim.partProperty(i, "temp") > 373 and sim.partProperty(i, "tmp") < 4 then
        sim.pressure(x / 4, y / 4, sim.pressure(x / 4, y / 4) + 0.0005)
 
        tx = x + math.random(-1,1)
        ty = y + math.random(-1,1)
 
        id = sim.partID(tx, ty)
 
        if id == nil then
            sim.partProperty(i, "tmp", sim.partProperty(i, "tmp") + 1)
            tpt.create(tx, ty, elem.DEFAULT_PT_WTRV)
        end
    end
end
elements.property(elem.CXI_PT_POTA, "Update", POTA_Update)
 
function POTA_Graphics(i, colr, colg, colb)
    -- i: particle index
    -- colr, colg, colb: color red, green, and blue channels
 
    maxtemp = math.max(sim.partProperty(i, "tmp"), sim.partProperty(i, "temp"))
 
    if maxtemp > 400 then
        colr = colr - restrict((maxtemp - 400) / 3, 0, 172)
        colg = colg - restrict((maxtemp - 400) / 4, 0, 140)
        colb = colb - restrict((maxtemp - 400) / 20, 0, 44)
    elseif maxtemp < 273 then
        colr = colr - restrict((273 - maxtemp) / 5, 0, 40)
        colg = colg + restrict((273 - maxtemp) / 4, 0, 40)
        colb = colb + restrict((273 - maxtemp) / 1.5, 0, 150)
    end
 
    -- return cache, pixel mode,
    --        alpha, red, green, blue,
    --        fire alpha, fire red, fire green, fire blue
    return 1, 0x0000001, 0, colr, colg, colb, 0, 0, 0, 0
end
elements.property(elem.CXI_PT_POTA, "Graphics", POTA_Graphics)