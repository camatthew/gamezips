
local sulfur = elem.allocate("BIGDIG", "SULF")
local so2 = elem.allocate("BIGDIG", "SO2")
local sulfacid = elem.allocate("BIGDIG", "H2SO4")

elem.element(sulfur, elem.element(elem.DEFAULT_PT_SAND))
elem.property(sulfur, "Name", "SULF")
elem.property(sulfur, "Description", "Sulfur, heavy particles. Used in explosives, somewhat flammable in the basic form.")
elem.property(sulfur, "Color", 0xCC9900)
elem.property(sulfur, "Flammable", 10)
elem.property(sulfur, "Hardness", 5)
elem.property(sulfur, "Properties", elem.PROP_DEADLY)

local function sulfUpdate(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
    if r~= nil then
        temp = sim.partProperty(i, "temp")
        rtype = sim.partProperty(r, "type")
        if rtype == elem.DEFAULT_PT_OXYG and temp >= 475.15 then
            sim.partKill(i)
            sim.partProperty(r, "type", so2)
        elseif rtype == sulfacid and sim.partProperty(r, "tmp") == 1 then
            sim.partKill(i)
            sim.partProperty(r, "tmp", 0)
        end
    end
end

elem.property(sulfur, "Update", sulfUpdate)

elem.element(so2, elem.element(elem.DEFAULT_PT_BOYL))
elem.property(so2, "Name", "SO2")
elem.property(so2, "Description", "Sulphur dioxide, toxic gas. Creates sulphur acid with DSTW. Made from mixing hot sulphur and oxygen.")
elem.property(so2, "Color", 0x996633)
elem.property(so2, "Properties", elem.PROP_DEADLY+elem.TYPE_GAS)
elem.property(so2, "Diffusion", 2)

local function so2Update(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
    if r~= nil then
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_DSTW then
            sim.partKill(r)
            sim.partProperty(i, "type", sulfacid)
        end
    end
end

elem.property(so2, "Update", so2Update)

elem.element(sulfacid, elem.element(elem.DEFAULT_PT_SOAP))
elem.property(sulfacid, "Name", "HSO4")
elem.property(sulfacid, "Description", "Sulphuric acid (H2SO4). Eats through most things, can be diluted with DSTW/WATR and concentrated with SULF.")
elem.property(sulfacid, "Color", 0xCCCC00)
elem.property(sulfacid, "Weight", 29)

local function h2so4Update(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
    if r~= nil then
        local tmp = sim.partProperty(i, "tmp")
        local type = sim.partProperty(i, "type")
        local rtype = sim.partProperty(r, "type")
        if tmp ~= 1 then
            if rtype == elem.DEFAULT_PT_DSTW then
                sim.partKill(r)
                sim.partProperty(i, "tmp", 1)
            else
                if rtype ~= type and rtype ~= elem.DEFAULT_PT_DMND then
                    sim.partKill(r)
                end
            end
        else
            if rtype == elem.DEFAULT_PT_BCOL then
                sim.partKill(i)
                sim.partProperty(r, "type", elem.DEFAULT_PT_BREL)
            end
        end
    end
end

local function h2so4Graphics(i, colr, colg, colb)
    if sim.partProperty(i, "tmp") == 0 then
        r = 204
        g = 204
        b = 0
    else
        r = 153
        g = 255
        b = 51
    end;
    return 0, 0x00000001, 255, r, g, b, 0, 0, 0, 0
end

elem.property(sulfacid, "Update", h2so4Update)
elem.property(sulfacid, "Graphics", h2so4Graphics)