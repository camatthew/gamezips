
--- RADX

local radio = elements.allocate("TIMO", "RADX")
elements.element(elements.DEFAULT_PT_GLOW)
elem.property(elem.TIMO_PT_RADX, "Name", "RADX")
elem.property(elem.TIMO_PT_RADX, "Colour", 0x148345)
elem.property(elem.TIMO_PT_RADX, "Description", "Transmutative liquid.")
elem.property(elem.TIMO_PT_RADX, "Properties", elem.TYPE_LIQUID+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_NEUTPENETRATE+elem.PROP_HOT_GLOW)
elem.property(elem.TIMO_PT_RADX, "MenuSection", elem.SC_NUCLEAR)
elem.property(elem.TIMO_PT_RADX, "MenuVisible", 1)
elem.property(elem.TIMO_PT_RADX, "Weight", 49.44)
elem.property(elem.TIMO_PT_RADX, "Gravity", .03)
elem.property(elem.TIMO_PT_RADX, "Falldown", 2)
elem.property(elem.TIMO_PT_RADX, "Diffusion", 0.08)
elem.property(elem.TIMO_PT_RADX, "HighTemperature", 3980.15)
elem.property(elem.TIMO_PT_RADX, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
sim.can_move(elem.DEFAULT_PT_PHOT, elem.TIMO_PT_RADX, 2)
sim.can_move(elem.DEFAULT_PT_ELEC, elem.TIMO_PT_RADX, 2)
tpt.element_func(NU, tpt.element('RADX'))

function RADX(i,x,y,s,n)
local mytmp = sim.partProperty(i,'tmp')
local mytemp = sim.partProperty(i,'temp')
local mypres = sim.pressure(x/4,y/4)
local spacer = math.random(1,20)
r = sim.partID(x+math.random(-2,2),y+math.random(-2,2))
	if r~= nil then
	-- STNE
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_STNE then
		--ISOTOPES
		if sim.partProperty(r,'tmp') == 0 then -- ISOTOPE-0
			if mytemp > 546 and mytemp < 995 and math.random(1,118) == 1 then -- Between 273C and 722C
				sim.partProperty(r,'type', elem.DEFAULT_PT_CLST)
			end
			if mytemp > 372 and mytemp < 383 then -- Between 99C and 110C
				sim.partProperty(r,'tmp', 1)
				sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+200)
			end
			if mytemp > 323 and mytemp < 345 and math.random(1,118) == 1 then -- Between 50C and 72C
				sim.partProperty(r,'type', elem.DEFAULT_PT_BREL)
			end
			if mytemp > 246 and mytemp < 275 and math.random(1,118) == 1 then -- Between -27C and 2C
				sim.partProperty(r,'type', elem.DEFAULT_PT_SAND)
			end
		elseif sim.partProperty(r,'tmp') == 1 then -- ISOTOPE-1
			if math.random(1,118) == 1 then
				if mytemp > 246 and mytemp < 271 then -- Between -27C and -2C
					sim.partProperty(r,'tmp', 0)
					sim.partProperty(r,'type', elem.DEFAULT_PT_CNCT)
				end
			end
		end
	end
	-- STNE END
	-- BREL
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BREL then
		if sim.partProperty(r,'tmp') == 0 then -- ISOTOPE-0
			if math.random(1,240) == 1 then
				if mytemp > 289 and mytemp < 325 and math.random(1,20) == 1 then -- Between 16C and 52C
					sim.partProperty(r,'type', elem.DEFAULT_PT_STNE)
				end
				if mytemp > 246 and mytemp < 275 then -- Between -27C and 2C
					sim.partProperty(r,'type', elem.DEFAULT_PT_BRMT)
				end
			end
		end
	end
	-- BREL END
	-- WATR
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_WATR then
		if sim.partProperty(r,'tmp') == 0 then -- ISOTOPE-0
			if mytemp > 271 and mytemp < 289 and math.random(1,44) == 1 then -- Between -2C and 16C
				sim.partProperty(r,'temp', 60)
				sim.partProperty(r,'type', elem.DEFAULT_PT_SNOW)
			end
		end
	end
	-- WATR END
	-- ICE
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_ICE then
		if sim.partProperty(r,'tmp') == 0 then -- ISOTOPE-0
			if mytemp > 271 and mytemp < 289 and math.random(1,44) == 1 then -- Between -2C and 16C
				sim.partProperty(r,'temp', 60)
				sim.partProperty(r,'type', elem.DEFAULT_PT_SNOW)
			end
		elseif sim.partProperty(r,'tmp') == 1 then -- ISOTOPE-1
			if mytemp > 173 and mytemp < 213 and math.random(1,14) == 1 then -- Between -60C and -100C
				sim.partProperty(r,'ctype', elem.TIMO_PT_TACT)
				sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')-700)
			end
		end
	end
	-- ICE END
	-- CNCT
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_CNCT then
		if sim.partProperty(r,'tmp') == 0 then -- ISOTOPE-0
			if math.random(1,125) == 1 then
				if mytemp > 303 and mytemp < 315 then -- Between 30C and 42C
					sim.partProperty(r,'tmp', 1)
					sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')-600)
				end
				if mytemp > 163 and mytemp < 243 then -- Between -110C and -40C
					sim.partProperty(r,'tmp', 1)
					sim.partProperty(r,'type', elem.DEFAULT_PT_BRMT)
				end
				if mytemp > 661 and mytemp < 698 then -- Between 388C and 425C
					sim.partProperty(r,'type', elem.DEFAULT_PT_CLST)
				end
			end 
		elseif sim.partProperty(r,'tmp') == 1 then -- ISOTOPE-1
			if mytemp > 259 and mytemp < 268 then -- Between -14C and -5C
				sim.partProperty(r,'tmp', 1)
				sim.partProperty(r,'type', elem.DEFAULT_PT_ICE)
				sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+1200)
			end
		end
	end
	-- CNCT END
	-- CLST
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_CLST then
		if sim.partProperty(r,'tmp') == 0 then -- ISOTOPE-0
			if math.random(1,150) == 1 then
				if mytemp > 663 and mytemp < 703 then -- Between 390C and 430C
				end
			end
		elseif sim.partProperty(r,'tmp') == 1 then -- ISOTOPE-1
		end 
	end
	-- CLST END
	-- SAND
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SAND then
		if sim.partProperty(r,'tmp') == 0 then -- ISOTOPE-0.
				if mytemp > 663 and mytemp < 703 then -- Between 390C and 430C
					if math.random(1,150) == 1 then 
						sim.partProperty(r,'type', elem.DEFAULT_PT_CLST)
					end
				end
		end
	end
	-- SAND END
	-- BRMT
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BRMT then
		if sim.partProperty(r,'tmp') == 0 then -- ISOTOPE-0.
			if math.random(1,100) == 1 then
				if mytemp > 1086 and mytemp < 1233 then -- Between 813C and 960C
					sim.partProperty(r,'tmp2', math.random(1,3))
					sim.partProperty(r,'type', elem.DEFAULT_PT_PQRT)
				end
			end
			if math.random(1,200) == 1 then
				if mytemp > 526 and mytemp < 533 then -- Between 253C and 260C
					sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
					sim.partProperty(i,'type', elem.DEFAULT_PT_GLOW)
				end
			end
		elseif sim.partProperty(r,'tmp') == 1 then
			if math.random(1,225) == 1 then
				if mytemp > 973 and mytemp < 1023 then -- Between 700C and 750C
					sim.partProperty(r,'tmp2', math.random(4,6))
					sim.partProperty(r,'type', elem.DEFAULT_PT_PQRT)
				end
			end
			if math.random(1,110) == 1 then
				if mytemp > 70 and mytemp < 133 then -- Between -203C and -140C 
					sim.partProperty(r,'type', elem.DEFAULT_PT_BRCK)
				end
			end
		end 
	end
	-- BRMT END
	-- POLO
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_POLO then
		if sim.partProperty(r,'tmp') == 0 then -- ISOTOPE-0.
			if math.random(1,100) == 1 then
				if mytemp > 1086 and mytemp < 1233 then -- Between 813C and 960C
				end
			end
		end
	end
	-- POLO END
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_BGLA and math.random(1,550) == 1 then
			if math.random(1,20) == 1 then 
			sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
			elseif math.random(1,20) == 2 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
			elseif math.random(1,20) == 2 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_STNE)
				if math.random(1,2) == 1 then 
					sim.partProperty(i,'type', elem.DEFAULT_PT_STNE)
				end
			end
		end
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PQRT and math.random(1,850) == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_BGLA)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_RAD)
		end
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_SAND and math.random(1,650) == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
			if math.random(1,220) == 1 then 
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_RAD)
				sim.partProperty(i,'type', elem.DEFAULT_PT_STNE)
			end
		end
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_BCOL and sim.partProperty(i,'temp') > 353.15 and math.random(1,150) == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_DEUT)
			sim.partProperty(r,'life', math.random(240,720))
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_ELEC)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_ELEC)
			tpt.create(x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_ELEC)
			if math.random(1,1320) == 1 then 
				sim.partProperty(i,'type', elem.TIMO_PT_RAD)
			end
		end
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_COAL and math.random(1,350) == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_DEUT)
			sim.partProperty(r,'life', 14,32)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
		end
		--- SOLID REACTIONS
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_BMTL and math.random(1,920) == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_IRON)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), "BCOL")
		end 
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLNT and math.random(1,36) == 1 then
			sim.partProperty(r,'tmp2', sim.partProperty(r,'tmp2') + 35)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_RAD)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_RAD)
		end 
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_IRON and math.random(1,520) == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_GOLD)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
		end
		--- specials
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_ISOZ and math.random(1,40) == 1 then
			sim.partProperty(r,'type', elem.TIMO_PT_RADX)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
			sim.pressure(x/4,y/4, math.abs(mypres) + 3)
		end
	-- URAN
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_URAN then
		if sim.partProperty(r,'tmp') == 0 then
			if math.random(1,540) == 1 then
				sim.partProperty(r,'tmp', 1)
				sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
			end
			if math.random(1,440) == 1 then
				sim.partProperty(r,'tmp', 1)
				sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_EMBR)
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_EMBR)
			end
		elseif sim.partProperty(r,'tmp') == 1 then
			if math.random(1,540) == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_ACT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
			end
		elseif sim.partProperty(r,'tmp') == 8 then --WEAKFORCE ADDER
			sim.partProperty(r,'pavg0', 5) -- SET TO WEAKFORCE 5. 
			sim.partProperty(r,'tmp', 16)
			sim.partProperty(r,'type', elem.TIMO_PT_TACT)
		end
		end
	-- URAN END
	-- PLUT
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT then
			if sim.partProperty(r,'pavg0') == 0 then
				if sim.partProperty(r,'tmp') == 0 then
				elseif sim.partProperty(r,'tmp') == 1 then
					sim.partProperty(r,'type', elem.TIMO_PT_PACT)
					sim.partProperty(r,'tmp', 3)
					sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_STNE)
					sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
					sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
					sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
				end
			end
		end
	-- PLUT END
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_GLOW and math.random(1,40) == 1 then
			if math.random(1,40) == 1 then 
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_RAD)
				sim.partProperty(r,'type', elem.DEFAULT_PT_ISOZ)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
			elseif math.random(1,20) == 1 then
				sim.partProperty(i,'type', elem.TIMO_PT_NUCL)
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_HYGN)
			end
		end
		--- reversions
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_GOLD and math.random(1,520) == 1 then
			if math.random(1,40) == 1 then 
				sim.partProperty(r,'type', elem.DEFAULT_PT_IRON)
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_ISOZ)
			elseif math.random(1,40) == 2 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_IRON)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			end
		end
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT and math.random(1,2520) == 1 and sim.partProperty(r,'tmp') == 2 then
			if math.random(1,40) == 1 then 
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_SALT)
			elseif math.random(1,40) == 2 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_STNE)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			end
		end
		--ACTPACTTACT
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PQRT and math.random(1,350) == 1 then
			local PQRTBREL = math.random(1,4)
			if PQRTBREL == 1 then
				sim.partProperty(r,'type', elem.TIMO_PT_TACT)
			elseif PQRTBREL == 2 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_BREL)
			elseif PQRTBREL == 3 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_BREL)
			elseif PQRTBREL == 4 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)	
			end
		end
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_BMTL and math.random(1,150) == 1 then
		end
		--ACTPACTTACTEND
end
--- SALT REACTIONS
if r~= nil then
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 0 and math.random(1,60) == 1 then 
		sim.partProperty(r,'type', elem.DEFAULT_PT_SALT)
		sim.partProperty(r,'tmp', math.random(3,9))
		sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_HYGN)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 3 and math.random(1,60) == 1 then 
		sim.partProperty(r,'type', elem.DEFAULT_PT_CLST)
		sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_HYGN)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 4 and math.random(1,20) == 1 then 
		sim.partProperty(r,'type', elem.DEFAULT_PT_SAND)
		sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_HYGN)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 5 and math.random(1,30) == 1 and sim.partProperty(i,'temp') < 313.15 then 
		sim.partProperty(r,'type', elem.DEFAULT_PT_PQRT)
		sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_SAND)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 6 and math.random(1,40) == 1 then 
		sim.partProperty(r,'type', elem.DEFAULT_PT_BRMT)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 7 and math.random(1,60) == 1 then 
		sim.partProperty(r,'type', elem.TIMO_PT_NUCL)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 8 and math.random(1,40) == 1 then 
		sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 9 and math.random(1,60) == 1 then 
		sim.partProperty(r,'type', elem.DEFAULT_PT_ISOZ)
		sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_SAND)
		sim.partProperty(i,'temp', math.abs(mytemp) + 62.00)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 11 and math.random(1,2) == 1 then 
		sim.partProperty(r,'type', elem.TIMO_PT_RAD)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') == 12 and math.random(1,25) == 1 then 
		sim.partProperty(r,'type', elem.TIMO_PT_NUCL)
	end
end
--- SALT REACTIONS END
--- PLUT REACTIONS START
---if r~= nil then
---	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_PLUT and sim.partProperty(r,'tmp2') == 0 then
---		sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
---		sim.partProperty(r,'ctype', elem.DEFAULT_PT_NONE)
---		sim.partProperty(r,'tmp', math.random(0,2))
---		sim.partProperty(r,'tmp2', 1)
---		
---		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT and sim.partProperty(r,'tmp') == 0 and math.random(1,40) == 1 and sim.partProperty(r,'tmp2') == 1 then 
---			sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
---		end
---		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT and sim.partProperty(r,'tmp') == 1 and math.random(1,40) == 1 and sim.partProperty(r,'tmp2') == 1 then 
---			sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
---		end
---		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT and sim.partProperty(r,'tmp') == 2 and math.random(1,40) == 1 and sim.partProperty(r,'tmp2') == 1 then 
---			sim.partProperty(r,'type', elem.DEFAULT_PT_HYGN)
---			sim.partProperty(i,'temp', math.abs(mytemp) + 862.00)
---			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_HYGN)
---		end
---end
--- PLUT REACTIONS END
-- transmutation
if r~= nil then
	
	local transmuteRDM = math.random(1,6)
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BRCK then
		if transmuteRDM == 2 then
			sim.partProperty(r,'tmp', math.random(0,2))
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT then
		if sim.partProperty(r,'tmp', 2) then
			if math.random(1,22) == 1 then
				sim.partProperty(r,'type', elem.TIMO_PT_TACT)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_RBDM then
		if transmuteRDM == 1 then
			sim.partProperty(r,'type', elem.TIMO_PT_TACT)
			sim.partProperty(i,'temp', math.abs(mytemp) - 4.00)
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'type', elem.TIMO_PT_PACT)
			sim.partProperty(r,'tmp', math.random(0,2))
			sim.partProperty(r,'temp', math.abs(mytemp) - 18.00)
		elseif transmuteRDM == 3 then
			sim.partProperty(r,'type', elem.TIMO_PT_ACT)
			sim.partProperty(r,'tmp', math.random(0,2))
			if math.random(1,32) == 1 then
				sim.partProperty(i,'type', elem.DEFAULT_PT_GLOW)
				sim.partProperty(i,'tmp', 5)
			end
		end
	end
end
end
tpt.element_func(RADX,radio)


local nucl = elements.allocate("TIMO", "NUCL")
elements.element(elements.DEFAULT_PT_GLOW)
elem.property(elem.TIMO_PT_NUCL, "Name", "NUCL")
elem.property(elem.TIMO_PT_NUCL, "Colour", 0x446735)
elem.property(elem.TIMO_PT_NUCL, "Description", "Radioactive breeding material.")
elem.property(elem.TIMO_PT_NUCL, "Properties", elem.TYPE_LIQUID+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_NEUTPENETRATE+elem.PROP_HOT_GLOW)
elem.property(elem.TIMO_PT_NUCL, "MenuSection", elem.SC_NUCLEAR)
elem.property(elem.TIMO_PT_NUCL, "MenuVisible", 1)
elem.property(elem.TIMO_PT_NUCL, "Weight", 11.44)
elem.property(elem.TIMO_PT_NUCL, "Gravity", .09)
elem.property(elem.TIMO_PT_NUCL, "Falldown", 2)
elem.property(elem.TIMO_PT_NUCL, "Diffusion", 0.015)
elem.property(elem.TIMO_PT_NUCL, "HighTemperature", 3380.15)
elem.property(elem.TIMO_PT_NUCL, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
sim.can_move(elem.DEFAULT_PT_ELEC, elem.TIMO_PT_NUCL, 2)
sim.can_move(elem.DEFAULT_PT_PHOT, elem.TIMO_PT_NUCL, 2)
tpt.element_func(NU, tpt.element('NUCL'))
local function nuclUpdate (i,x,y,s,n)
	local mytemp = sim.partProperty(i,'temp')
	local mypres = sim.pressure(x/4,y/4)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_WATR or sim.partProperty(r,'type') == elem.DEFAULT_PT_WTRV or sim.partProperty(r,'type') == elem.DEFAULT_PT_DSTW then
			if sim.partProperty(i,'temp') > 373.15 then
				sim.pressure(x/4,y/4,math.abs(mypres)+180)
				sim.partProperty(r,'type', elem.DEFAULT_PT_HYGN)
				sim.partProperty(r,'temp', math.abs(mytemp) + 4658.15)
				sim.partProperty(i,'life', 82)
				sim.partProperty(i,'temp', 9724.15)
				tpt.set_property("temp", math.abs(mytemp) + 7162.00, x, y)
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_DEUT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			end
		end
	end
	if r~= nil then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
			if sim.pressure(x/4,y/4) > 3.5 and math.random(1,6) == 1 then
			sim.partProperty(r,'temp', 2724.15)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_NEUT)
			end 
		end 
	end
	if r~= nil then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT and math.random(1,600) == 1 and sim.pressure(x/4,y/4) > 130 then
			sim.pressure(x/4,y/4, math.abs(mypres) + 48)
			sim.partProperty(i,'type', elem.DEFAULT_PT_PLUT)
			sim.partProperty(r,'temp', math.abs(mytemp) + 3712.00)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_POLO)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_STNE)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_RAD)
			sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_NEUT)
		end 
	end
	if r~= nil and sim.partProperty(i,'temp') < 573.15 and math.random(1,100) == 1 then
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
	end 
	if r~= nil and sim.partProperty(i,'temp') > 573.15 and math.random(1,100) == 1 then
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
	end
	if r~= nil and math.random(1,10) == 1 and sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
		sim.partProperty(i,'temp', math.abs(mytemp) + 22.00)
		sim.pressure(x/4,y/4, math.abs(mypres) + 12)
		tpt.set_property("vx", math.random(-2,2), i)
	    tpt.set_property("vy", math.random(-2,2), i)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
	end 
	if r~= nil and sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_POLO and math.random(1,220) == 1 then
		sim.partProperty(i,'temp', math.abs(mytemp) + 122.00)
		sim.pressure(x/4,y/4, math.abs(mypres) + 24)
		sim.partProperty(i,'type', elem.DEFAULT_PT_SALT)
		sim.partProperty(i,'tmp', 7)
		sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_RAD)
		sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_BOYL)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
		if math.random(1,320) == 1 then 
			sim.partKill(r)
		end
	end
	if sim.pressure(x/4,y/4) > 180 and math.random(1,50) == 1 then
		tpt.set_property("temp", math.abs(mytemp) + 6472.00, x+math.random(-1,1), y+math.random(-1,1))
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		tpt.create(x+math.random(-1,2), y+math.random(-1,2), "PROT")
		if math.random(1,12) == 1 then 
			sim.partProperty(i,'temp', math.abs(mytemp) + 9122.00)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_RAD)
			if math.random(1,12) == 1 then
				sim.partProperty(i,'type', elem.DEFAULT_PT_SALT)
				sim.partProperty(i,'tmp', 7)
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_RADX)
			end
		end
	end
	if r~= nil and sim.partProperty(r,'type') == elem.DEFAULT_PT_PROT then
		if sim.pressure(x/4,y/4) > 240 and math.random(1,220) then
		local rdmchance = math.random(1,10)
			if rdmchance == 1 then
				sim.partProperty(i,'type', elem.DEFAULT_PT_SALT)
				sim.partProperty(i,'tmp', math.random(1,12))
			elseif rdmchance == 2 then
				sim.partProperty(i,'type', elem.DEFAULT_PT_SALT)
				sim.partProperty(i,'tmp', math.random(7,11))
			elseif rdmchance == 3 or rdmchance == 4 then
				sim.partProperty(i,'type', elem.TIMO_PT_RADX)
			elseif rdmchance == 5 or rdmchance == 6 or rdmchance == 7 then
				sim.partProperty(i,'type', elem.DEFAULT_PT_SALT)
				sim.partProperty(i,'tmp', 11)
			elseif rdmchance == 8 or rdmchance == 9 or rdmchance == 10 then
				sim.partProperty(i,'type', elem.DEFAULT_PT_PLUT)
			end
		end 
	end 
	if r~= nil and sim.partProperty(r,'type') == elem.TIMO_PT_RADX then
		if sim.pressure(x/4,y/4) < 2 and math.random(1,220) == 1 then
			tpt.set_property("vx", math.random(-1,1), r)
			tpt.set_property("vy", math.random(-1,1), r)
		end
	end
end

tpt.element_func(NUCL,nucl)
elem.property(nucl, "Update",nuclUpdate)

--- radioactive ore 
local RADORE = elements.allocate("TIMO", "RAD")
elements.element(elements.DEFAULT_PT_SAND)
elem.property(elem.TIMO_PT_RAD, "Name", "RAD")
elem.property(elem.TIMO_PT_RAD, "Colour", 0x246355)
elem.property(elem.TIMO_PT_RAD, "Description", "Radioactive ore.")
elem.property(elem.TIMO_PT_RAD, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_NEUTPENETRATE+elem.PROP_HOT_GLOW)
elem.property(elem.TIMO_PT_RAD, "MenuSection", elem.SC_NUCLEAR)
elem.property(elem.TIMO_PT_RAD, "MenuVisible", 1)
elem.property(elem.TIMO_PT_RAD, "Gravity", .04)
elem.property(elem.TIMO_PT_RAD, "Weight", 90)
elem.property(elem.TIMO_PT_RAD, "Falldown", 1)
sim.can_move(elem.DEFAULT_PT_ELEC, elem.TIMO_PT_RAD, 2)
sim.can_move(elem.DEFAULT_PT_PHOT, elem.TIMO_PT_RAD, 2)
tpt.element_func(NU, tpt.element('RAD'))
local function RADUpdate(i,x,y,s,n)
	local mytemp = sim.partProperty(i,'temp')
	local mypres = sim.pressure(x/4,y/4)
	local dis = sim.partProperty(i,'temp')
	local transmuteRDM = math.random(1,6)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
	if dis > 791.15 and sim.partProperty(i,'tmp') == 0 then
		tpt.set_property('tmp', math.random(1,13), x, y)
	end
	end
	local oretype = sim.partProperty(i,'tmp')
if dis > 793.15 and math.random(1,67) == 1 then
	if oretype == 1 then
		sim.partChangeType(i, tpt.element('SALT'))
		sim.partProperty(i,'tmp', math.random(7,8))
	elseif oretype == 2 then
		sim.partChangeType(i, tpt.element('POLO'))
		sim.partProperty(i,'tmp', math.random(0,3))
	elseif oretype == 3 then
		sim.partChangeType(i, tpt.element('GLOW'))
		oretype = nil
	elseif oretype == 4 then
		sim.partProperty(i,'ctype', elem.TIMO_PT_RADX)
		sim.partChangeType(i, tpt.element('LAVA'))
		oretype = nil
	elseif oretype == 5 then
		sim.partChangeType(i, tpt.element('URAN'))
		oretype = nil
	elseif oretype == 6 then
		sim.partChangeType(i, tpt.element('POLO'))
		sim.partProperty(i,'tmp', 1)
	elseif oretype == 7 then
		sim.partProperty(i,'ctype', elem.TIMO_PT_TACT)
		sim.partChangeType(i, tpt.element('LAVA'))
	elseif oretype == 8 then
		sim.partProperty(i,'tmp', math.random(6,11))
		sim.partChangeType(i, tpt.element('SALT'))
	elseif oretype == 9 then
		sim.partProperty(i,'tmp', math.random(0,5))
		sim.partChangeType(i, tpt.element('POLO'))
	elseif oretype == 10 then
		sim.partProperty(i,'tmp', 0)
		sim.partChangeType(i, tpt.element('RADX'))
	elseif oretype == 11 then
		sim.partChangeType(i, tpt.element('TACT'))
		sim.partProperty(i,'tmp', 11)
	elseif oretype == 12 then
		sim.partProperty(i,'temp', 8)
		sim.partProperty(i,'tmp', 2)
		sim.partProperty(i,'ctype', elem.TIMO_PT_TACT)
		sim.partChangeType(i, tpt.element('ICE'))
	elseif oretype == 13 then
		sim.partProperty(i,'ctype', elem.TIMO_PT_PACT)
		sim.partChangeType(i, tpt.element('SNOW'))
	end
end
if r~= nil then
	local transmuteRDM = math.random(1,6)
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
		if sim.pressure(x/4,y/4) > 1 then
		sim.partProperty(r,'temp', math.abs(mytemp) + 62.00)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
		end 
	end 
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_NBLE and sim.partProperty(r,'tmp') == 1 then 
		sim.partProperty(r,'type', elem.DEFAULT_PT_ISOZ)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
		sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
		sim.pressure(x/4,y/4, math.abs(mypres) - 14)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BGLA then
	sim.partProperty(r,'tmp', 5)
		if math.random(1,10) == 1 then
			sim.partProperty(i,'life', sim.partProperty(i,'life')+60+(math.random(-4,4)*3))
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_POLO then
		local chance = math.random(1,5)
		if chance == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
		elseif chance == 2 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_NUCL)
		elseif chance == 3 then
			sim.partProperty(r,'type', elem.TIMO_PT_RAD)
		elseif chance == 4 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_DUST)
		elseif chance == 5 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_GLOW)
			sim.partCreate(-3, x, y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x, y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_DUST)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_CNCT then
		if transmuteRDM == 1 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_POLO)
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_URAN)
			sim.partProperty(r,'tmp', 2)
		elseif transmuteRDM == 3 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_BREL)
		end		
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_PSTE then
		if transmuteRDM == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_GLOW)
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_OIL)
		elseif transmuteRDM == 3 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_BREL)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_FIRE then
		if transmuteRDM == 1 then
			sim.partProperty(r,'temp', sim.partProperty(i,'temp')+(math.random(40,75)*180))
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'life', 650)
			sim.partProperty(r,'type', elem.DEFAULT_PT_EMBR)
		end 
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BMTL then
		if dis < 323.15 then
			if math.random(1,68) == 1 then
				sim.partCreate(-3, x, y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
				if transmuteRDM == 2 then 
					sim.partProperty(r,'type', elem.DEFAULT_PT_BRCK)
					sim.partProperty(r,'type', elem.DEFAULT_PT_BRCK)
				elseif transmuteRDM == 3 then
					sim.partProperty(r,'type', elem.DEFAULT_PT_RBDM)
					sim.partProperty(r,'tmp', transmuteRDM)
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_BMTL)
				end 
			end
		end
		if sim.partProperty(r,'tmp') == 1 then
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			sim.partProperty(r,'ctype', elem.TIMO_PT_RAD)
			if math.random(1,14) == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_CRMC)
				sim.partProperty(r,'temp', sim.partProperty(i,'temp')+260)
				if sim.partProperty(r,'type') == elem.DEFAULT_PT_MERC then
					if transmuteRDM == 1 then
						sim.partProperty(r,'type', elem.DEFAULT_PT_RBDM)
					elseif transmuteRDM == 2 then
						sim.partProperty(r,'type', elem.DEFAULT_PT_RBDM)
					elseif transmuteRDM > 2 then
						if sim.partProperty(r,'type') == elem.DEFAULT_PT_BCOL then
							local DUSTFSEP = math.random(1,2)
							if DUSTFSEP == 1 then
							sim.partProperty(r,'type', elem.DEFAULT_PT_DUST)
							elseif DUSTFSEP == 2 then
							sim.partProperty(r,'type', elem.DEFAULT_PT_BCOL)
							end
						end
					end
				end
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SMKE then
		if dis < 373.15 and transmuteRDM == 6 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_FIRE)
			sim.partProperty(r,'temp', sim.partProperty(r,'temp')-130)
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+260)
			if math.random(1,10) then
				sim.partProperty(i,'type', elem.DEFAULT_PT_PLUT)
			end
		end 
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_IRON then
		sim.partProperty(r,'pavg0', 5) --SET TO NONREACT
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SNOW and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_WATR then
		sim.partProperty(r,'life', 400+math.random(-13,13))
		sim.partProperty(r,'type', elem.DEFAULT_PT_PLSM)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_OXYG then
		if transmuteRDM == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_CFLM)
			sim.partProperty(r,'ctype', elem.TIMO_PT_RAD)
			if math.random(1,120) == 1 then
				sim.partProperty(i,'type', elem.TIMO_PT_TACT)
				sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_POLO)
			end
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_FOG)
			sim.partProperty(r,'ctype', elem.TIMO_PT_RAD)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_WATR then
		sim.partProperty(r,'ctype', elem.DEFAULT_PT_HYGN)
		sim.partProperty(r,'tmp', 5)
		if math.random(1,140) == 1 then
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NITR)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SLTW then
		sim.partProperty(r,'ctype', elem.DEFAULT_PT_HYGN)
		sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_HYGN)
		if math.random(1,26) then
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NBLE)
			sim.partProperty(r,'tmp', 1)
		end
	end
	if math.random(1,60) == 1 then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_NBLE and sim.partProperty(r,'tmp', 0) then
			sim.partProperty(r,'tmp', 1)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BCOL and sim.partProperty(r,'ctype') == elem.TIMO_PT_ACT then
		sim.partProperty(r,'ctype', elem.TIMO_PT_ACT)
		sim.partProperty(r,'type', elem.DEFAULT_PT_SNOW)
		sim.partProperty(i,'temp', 3)
		sim.partProperty(r,'temp', 3)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BCOL and sim.partProperty(r,'ctype') == elem.TIMO_PT_PACT then
		sim.partProperty(r,'ctype', elem.TIMO_PT_PACT)
		sim.partProperty(r,'type', elem.DEFAULT_PT_SNOW)
		sim.partProperty(i,'temp', 3)
		sim.partProperty(r,'temp', 3)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BCOL and sim.partProperty(r,'ctype') == elem.TIMO_PT_TACT then
		sim.partProperty(r,'ctype', elem.TIMO_PT_TACT)
		sim.partProperty(r,'type', elem.DEFAULT_PT_SNOW)
		sim.partProperty(i,'temp', 3)
		sim.partProperty(r,'temp', 3)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
			sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_CFLM)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_HYGN then
		sim.partProperty(r,'ctype', elem.DEFAULT_PT_HYGN)
		sim.partProperty(r,'type', elem.DEFAULT_PT_SPRK)
		sim.partProperty(r,'life', 4)
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_BGLA then
			if math.random(1,120) == 1 then
				if transmuteRDM == 1 then
					sim.partProperty(i,'ctype', elem.DEFAULT_PT_BGLA)
					sim.partProperty(r,'type', elem.DEFAULT_PT_RBDM)
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_BGLA)
					sim.partProperty(i,'type', elem.TIMO_PT_PACT)
				elseif transmuteRDM == 2 then
					sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_POLO)
					sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
					sim.partProperty(r,'tmp', 1)
					sim.partProperty(i,'type', elem.TIMO_PT_ACT)
				elseif transmuteRDM > 2 then
					sim.partProperty(i,'temp', sim.partProperty(i,'temp')+760)
					sim.partProperty(r,'temp', sim.partProperty(r,'temp')+1460)
					sim.partProperty(r,'type', elem.DEFAULT_PT_PQRT)
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_PQRT)
				end
			end
		end
	end
end
end

tpt.element_func(RAD,RADORE)
elem.property(elem.TIMO_PT_RAD, "Update",RADUpdate)
---end radioactive ore
--- transition nuclear metal
local act = elements.allocate("TIMO", "ACT")
elements.element(elements.DEFAULT_PT_PQRT)
elem.property(elem.TIMO_PT_ACT, "Name", "ACT")
elem.property(elem.TIMO_PT_ACT, "Colour", 0x927121)
elem.property(elem.TIMO_PT_ACT, "Description", "Metallic metastable.")
elem.property(elem.TIMO_PT_ACT, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_HOT_GLOW+elem.PROP_NEUTPASS+elem.PROP_RADIOACTIVE)
elem.property(elem.TIMO_PT_ACT, "MenuSection", 10)
elem.property(elem.TIMO_PT_ACT, "MenuVisible", 1)
elem.property(elem.TIMO_PT_ACT, "Weight", 90)
elem.property(elem.TIMO_PT_ACT, "Gravity", 1)
elem.property(elem.TIMO_PT_ACT, "Falldown", 1)
elem.property(elem.TIMO_PT_ACT, "AirLoss", 0.02)
elem.property(elem.TIMO_PT_ACT, "Loss", 0.001)
elem.property(elem.TIMO_PT_ACT, "AirDrag", 0.4)
elem.property(elem.TIMO_PT_ACT, "Advection", 0.13)
elem.property(elem.TIMO_PT_ACT, "Diffusion", 0.01)
elem.property(elem.TIMO_PT_ACT, "HeatConduct", 1)
elem.property(elem.TIMO_PT_ACT, "HighTemperature", 1636.35)
elem.property(elem.TIMO_PT_ACT, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
sim.can_move(elem.DEFAULT_PT_ELEC, elem.TIMO_PT_ACT, 2)
sim.can_move(elem.DEFAULT_PT_PHOT, elem.TIMO_PT_ACT, 2)
tpt.element_func(NU, tpt.element('ACT'))
local function actUpdate(i,x,y,s,n)
local mytemp = sim.partProperty(i,'temp')
local mypres = sim.pressure(x/4,y/4)

r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
if r~= nil then
	local weakforce = sim.partProperty(i,'pavg0')
	local transmuteRDM = math.random(1,6)


-- -- WEAKFORCE INDUCTORS
-- WEAKFORCE 0
if weakforce == 0 then
if sim.partProperty(r,'type') == elem.DEFAULT_PT_FIRE then
	sim.partProperty(i,'pavg0', 5) -- SET TO WEAKFORCE 5
	sim.partProperty(r,'temp', 1073.15)
	sim.partProperty(i,'temp', 823.15)
	sim.partProperty(r,'life', 43)
	sim.partProperty(r,'type', elem.DEFAULT_PT_PLSM)
end
end
-- WEAKFORCE 0 END
-- WEAKFORCE 5
if weakforce == 5 then
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_IRON then
		sim.partProperty(i,'pavg0', 0) -- SET TO WEAKFORCE 0
		if weakforce == 1 and sim.partProperty(r,'type') == elem.DEFAULT_PT_IRON then
			sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+50)
		end
	end
end
-- WEAKFORCE 5 END
-- -- WEAKFORCE INTERACTIONS
-- WEAKFORCE 4 -- GRVT
	if weakforce == 4 then
		if math.random(1,120) == 1 then
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_GRVT)
		end
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_GRVT then
			sim.partProperty(r,'life', math.random(8,12))
			sim.partProperty(r,'vx', 0)
			sim.partProperty(r,'vy', 0)
		end
	end
-- WEAKFORCE 5 
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT and weakforce == 5 and sim.partProperty(r,'life') == 2 and sim.partProperty(r,'tmp') == 2 then -- BASIC EXPLODE

			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
			sim.partProperty(i,'temp', 10000)
			sim.partProperty(r,'temp', 10000)
			sim.pressure(x/4,y/4,255)
			tpt.set_property("vx", math.random(-20,20), r)
			tpt.set_property("vy", math.random(-20,20), r)
			tpt.set_property("vx", math.random(-20,20), i)
			tpt.set_property("vy", math.random(-20,20), i)
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
				sim.partProperty(i,'type', elem.DEFAULT_PT_URAN)
			end
	end
-- WEAKFORCE INTERACTIONS END, WEAKFORCE 0 (DEFAULT) BELOW

-- TRANSMUTEGENERALRATE -- WEAKFORCE 0
if math.random(1,2) == 1 and weakforce == 0 then
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SAWD then
		sim.partProperty(r,'type', elem.DEFAULT_PT_DUST)
		sim.partProperty(r,'ctype', elem.TIMO_PT_ACT)
		sim.partProperty(i,'temp', sim.partProperty(r,'temp')+300)
		sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_BRMT then
			if sim.partProperty(r,'ctype') == elem.DEFAULT_PT_TUNG then
				if transmuteRDM == 1 then
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_POLO)
					sim.partProperty(i,'type', elem.TIMO_PT_TACT)
				end
			elseif sim.partProperty(r,'ctype') == elem.DEFAULT_PT_NONE then
				if transmuteRDM == 1 then
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_TUNG)
					sim.partProperty(i,'type', elem.DEFAULT_PT_PLUT)
				end
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_QRTZ and sim.partProperty(r,'tmp2') < 5 then
		sim.partProperty(r,'dcolor', (sim.partProperty(r,'dcolor')+sim.partProperty(i,'dcolor'))/2)
		if math.random(1,30) == 1 then
			sim.partProperty(r,'tmp', sim.partProperty(r,'tmp')+1)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BCOL and math.random(1,300) then
		sim.partProperty(r,'ctype', elem.TIMO_PT_ACT)
		if transmuteRDM == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_BCOL)
			if math.random(1,30) == 1 then
				sim.partProperty(i,'type', elem.DEFAULT_PT_BRMT)
				sim.partProperty(i,'ctype', elem.DEFAULT_PT_TUNG)
			end
		elseif transmuteRDM == 2 then
			if sim.partProperty(i,'tmp') == 0 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
				sim.partProperty(i,'tmp', sim.partProperty(i,'tmp')+1)
			elseif sim.partProperty(i,'tmp') == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_SAND)
				if math.random(1,45) == 1 then
					sim.partProperty(i,'type', elem.DEFAULT_PT_TUNG)
					sim.partProperty(i,'ctype', elem.TIMO_PT_ACT)
					sim.partProperty(i,'tmp', sim.partProperty(i,'tmp')+1)
				end
			elseif sim.partProperty(i,'tmp') > 2 then
				local polotown = math.random(1,3)
				if polotown == 1 then
					sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
					sim.partProperty(r,'type', elem.DEFAULT_PT_BRMT)
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_PLUT)
				elseif polotown == 2 then
					sim.partProperty(r,'type', elem.DEFAULT_PT_DUST)
					sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
				elseif polotown == 3 then
					sim.partProperty(r,'type', elem.DEFAULT_PT_PQRT)
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_TUNG)
					sim.partProperty(r,'temp', sim.partProperty(r,'temp')+50)
				end
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_WATR or sim.partProperty(r,'type') == elem.DEFAULT_PT_DSTW or sim.partProperty(r,'type') == elem.DEFAULT_PT_WTRV then
		sim.partProperty(r,'pavg0', 0)
		if sim.partProperty(r,'ctype') == elem.DEFAULT_PT_POLO then
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_ISOZ)
			sim.partProperty(r,'tmp', 0)
		elseif sim.partProperty(r,'ctype') == elem.TIMO_PT_TACT then
			if sim.partProperty(r,'tmp') == 2 then
				if transmuteRDM == 1 then
					sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
					sim.partProperty(i,'type', elem.TIMO_PT_TACT)
				elseif transmuteRDM == 2 then
					sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
					sim.partProperty(i,'type', elem.DEFAULT_PT_TACT)
				end
			end
			sim.partProperty(r,'tmp', 1)
			sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-3,3))
			sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-3,3))
		end
	end
--if weakfspark
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_SPRK and math.random(1,35) == 1 or math.random(1,420) == 70 then
			sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-0.01,0.01))
			sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-0.01,0.01))
			sim.partProperty(r,'temp', sim.partProperty(i,'temp')/2+sim.partProperty(i,'temp')+(sim.partProperty(r,'vx')+sim.partProperty(r,'vy')))
			if math.random(1,2) == 1 then
				sim.partProperty(i,'tmp', 1)
				sim.partProperty(i,'type', elem.DEFAULT_PT_PLUT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+2000)
				sim.pressure(x/4,y/4, math.abs(mypres) + 14)
				sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-6,6))
				sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-7,7))
			elseif math.random(1,3) == 1 then 
				if sim.partProperty(r,'type') == elem.DEFAULT_PT_URAN then
					sim.partProperty(r,'type', elem.TIMO_PT_ACT)
				end
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+7000)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.pressure(x/4,y/4, math.abs(mypres) + 24)
				sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-13,13))
				sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-13,17))
				sim.partProperty(i,'type', elem.DEFAULT_PT_PLUT)
				sim.partProperty(r,'tmp', 0)
			end
		end
--end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_URAN then
		if math.random(1,10) == 1 and sim.partProperty(r,'tmp') == 2 and sim.partProperty(r,'life') == 0 then
			sim.partProperty(r,'type', elem.TIMO_PT_ACT)
			sim.partProperty(r,'vx', sim.partProperty(r,'vx')+math.random(-6,6))
			sim.partProperty(r,'vy', sim.partProperty(r,'vy')+math.random(-6,6))
			sim.partProperty(r,'temp', sim.partProperty(r,'temp')+2000)
		end
		if sim.partProperty(r,'life') == 2 and sim.partProperty(r,'tmp') == 2 then
			--SUPER SPECIAL URANIUM
		end
	end
-- DECAY
	if math.random(1,160) == 1 then
		sim.partProperty(i,'temp', sim.partProperty(i,'temp')+165)
		sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
		sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-1,1))
		sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-1,1))
		if math.random(1,30) == 1 then
			sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-6,6))
			sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-7,7))
			sim.partProperty(i,'tmp', math.random(1,2))
			if transmuteRDM == 1 then
				sim.partProperty(i,'type', elem.DEFAULT_PT_PLUT)
			elseif transmuteRDM == 2 and math.random(1,16) == 1 then
				sim.partProperty(i,'pavg0', 5) -- SET TO WEAKFORCE 5 -- NONREACT "WASTE"
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
		--sim.partProperty(i,'life', sim.partProperty(i,'life')+1)
		if math.random(1,10) == 1 then
			if transmuteRDM == 1 then
				sim.partProperty(i,'type', elem.TIMO_PT_PACT)
			end
			if transmuteRDM == 3 and math.random(1,13) == 1 then
				sim.partProperty(i,'pavg0', 5) -- SET TO WEAKFORCE 5 -- NONREACT "WASTE"
			end
		end
	end
-- DECAY END
end--TRANSMUTEGENERALRATE END
end 
end
tpt.element_func(ACT,act)
elem.property(act, "Update",actUpdate)
--- end transition nuclear metal

--- transition nuclear metal 2
local pact = elements.allocate("TIMO", "PACT")
elements.element(elements.DEFAULT_PT_PQRT)
elem.property(elem.TIMO_PT_PACT, "Name", "PACT")
elem.property(elem.TIMO_PT_PACT, "Colour", 0x727323)
elem.property(elem.TIMO_PT_PACT, "Description", "Metallic metastable.")
elem.property(elem.TIMO_PT_PACT, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_HOT_GLOW+elem.PROP_NEUTPASS+elem.PROP_RADIOACTIVE)
elem.property(elem.TIMO_PT_PACT, "MenuSection", 10)
elem.property(elem.TIMO_PT_PACT, "MenuVisible", 1)
elem.property(elem.TIMO_PT_PACT, "Weight", 90)
elem.property(elem.TIMO_PT_PACT, "Gravity", 1)
elem.property(elem.TIMO_PT_PACT, "Falldown", 1)
elem.property(elem.TIMO_PT_PACT, "AirLoss", 0)
elem.property(elem.TIMO_PT_PACT, "Loss", 0)
elem.property(elem.TIMO_PT_PACT, "AirDrag", 0.3)
elem.property(elem.TIMO_PT_PACT, "Advection", 4)
elem.property(elem.TIMO_PT_PACT, "Diffusion", 0.13)
elem.property(elem.TIMO_PT_PACT, "HeatConduct", 2)
elem.property(elem.TIMO_PT_PACT, "HighTemperature", 1376.35)
elem.property(elem.TIMO_PT_PACT, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
sim.can_move(elem.DEFAULT_PT_ELEC, elem.TIMO_PT_PACT, 2)
sim.can_move(elem.DEFAULT_PT_PHOT, elem.TIMO_PT_PACT, 2)
tpt.element_func(NU, tpt.element('PACT'))
local function pactUpdate(i,x,y,s,n)
local mytemp = sim.partProperty(i,'temp')
local mypres = sim.pressure(x/4,y/4)
local weakforce = sim.partProperty(i,'pavg0')
r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
if r~= nil then
	local transmuteRDM = math.random(1,6)
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_WATR or sim.partProperty(r,'type') == elem.DEFAULT_PT_DSTW or sim.partProperty(r,'type') == elem.DEFAULT_PT_WTRV then
		if sim.partProperty(r,'ctype') == elem.TIMO_PT_TACT then
			if sim.partProperty(r,'tmp') == 0 then
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				if transmuteRDM == 1 then
					sim.partProperty(r,'tmp', 2)
				elseif transmuteRDM == 2 then
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_POLO)
				elseif transmuteRDM == 3 then
					sim.partProperty(i,'pavg0', 0) --SET TO REACT
				end
			elseif sim.partProperty(r,'tmp') == 1 then
				sim.partProperty(r,'tmp', 4)
				sim.partProperty(r,'type', elem.DEFAULT_PT_NBLE)
			end
		end
	end
-- WEAKFORCE INTERACTIONS
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_IRON then
		if sim.partProperty(r,'tmp') == 5 then
			sim.partProperty(i,'pavg0', 5) --SET TO NONREACT
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_FIRE then
		sim.partProperty(i,'pavg0', 5) --SET TO NONREACT
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_GOLD then
		if sim.partProperty(r,'tmp') == 0 then
			sim.partProperty(r,'tmp', 5)
			sim.partProperty(i,'pavg0', 0) --SET TO REACT
		end
	end
if weakforce == 0 then 
	if math.random(1,300) == 1 then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT then
			sim.partProperty(r,'type', elem.DEFAULT_PT_TACT)
		end
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_BCOL then
			sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_PLUT then
		if transmuteRDM == 1 then
			sim.partProperty(r,'ctype', elem.TIMO_PT_ACT)
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+5725)	
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_URAN)
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+387)
			sim.partProperty(r,'tmp', 2)
		elseif transmuteRDM == 3 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_BREL)
			if sim.partProperty(r,'type') == elem.DEFAULT_PT_GOLD then
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
			end
		end		
	end	
	if math.random(1,300) == 1 and sim.pressure(x/4,y/4) < -3 then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_NONE then
				sim.partProperty(r,'type', elem.DEFAULT_PT_PROT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
				sim.partCreate(-3, x+math.random(-2,2), y+math.random(-2,2), elem.DEFAULT_PT_PHOT)
		end
	end
	--- DECAY
	if math.random(1,42) == 1 then
		sim.partProperty(i,'temp', sim.partProperty(i,'temp')+625)
		sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT and sim.partProperty(r,'tmp') == 3 then
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+2725)
			sim.partProperty(r,'type', elem.TIMO_PT_TACT)
			sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-6,6))
			sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-6,6))
			sim.partProperty(r,'vx', sim.partProperty(r,'vx')+math.random(-6,6))
			sim.partProperty(r,'vy', sim.partProperty(r,'vy')+math.random(-6,6))
		end
		if math.random(1,46) == 1 then
			if sim.partProperty(r,'type') == elem.DEFAULT_PT_CLST then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
			end
			sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-1,1))
			sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-1,1))
			sim.partProperty(i,'type', elem.TIMO_PT_ACT)
		end
	end
	--- DECAY END
	
	-- NEUTREACT
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
		sim.partProperty(r,'vx', sim.partProperty(r,'vx')+math.random(-0.5,0.5))
		sim.partProperty(r,'vy', sim.partProperty(r,'vy')+math.random(-0.5,0.5))
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_URAN then
			sim.partProperty(r,'type', elem.TIMO_PT_ACT)
		end
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT then
			sim.partProperty(r,'type', elem.TIMO_PT_TACT)
		end
		if math.random(1,10) == 1 then
			sim.partProperty(r,'temp', sim.partProperty(i,'temp')/2+sim.partProperty(i,'temp')+(sim.partProperty(r,'vx')+sim.partProperty(r,'vy')))
			if math.random(1,2) == 1 then
				sim.partProperty(i,'type', elem.TIMO_PT_ACT)
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+2000)
				sim.pressure(x/4,y/4, math.abs(mypres) + 14)
				sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-3,3))
				sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-4,4))
				if math.random(1,3) == 1 then 
					sim.partProperty(i,'temp', sim.partProperty(i,'temp')+7000)
					sim.pressure(x/4,y/4, math.abs(mypres) + 24)
					sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-6,6))
					sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-6,6))
				end 
			end
		end
	end
	-- NEUTREACT END
	
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT then
		if math.random(1,10) == 1 then
			if sim.partProperty(r,'tmp') == 1 then
				sim.partProperty(r,'type', elem.TIMO_PT_PACT)
			elseif sim.partProperty(r,'tmp') == 0 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
				sim.partProperty(r,'tmp', 2)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_URAN then
		if transmuteRDM == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
			sim.partProperty(r,'tmp', 2)
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'type', elem.TIMO_PT_ACT)
			sim.partProperty(r,'tmp', 3)
			sim.partProperty(r,'pavg0', 5)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_SALT and sim.partProperty(r,'tmp') > 0 then
		sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
		sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
		sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
		sim.partProperty(r,'type', elem.DEFAULT_PT_STNE)
		sim.partProperty(r,'ctype', elem.DEFAULT_PT_URAN)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_STNE then
		if math.random(1,40) == 1 then
		if transmuteRDM == 1 then
			if math.random(1,16) == 1 then
				sim.partProperty(r,'vx', sim.partProperty(r,'vx')+math.random(-6,6))
				sim.partProperty(r,'vy', sim.partProperty(r,'vy')+math.random(-6,6))
				sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
			end
		elseif transmuteRDM == 2 then
			if math.random(1,8) == 1 then
				sim.partProperty(r,'vx', sim.partProperty(r,'vx')+math.random(-6,6))
				sim.partProperty(r,'vy', sim.partProperty(r,'vy')+math.random(-6,6))
				sim.partProperty(r,'type', elem.DEFAULT_PT_BRMT)
				sim.pressure(x/4,y/4, math.abs(mypres) + -0.2)
				if math.random(1,32) == 1 then
					sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
					sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
					sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
					sim.partProperty(i,'tmp', transmuteRDM)
					sim.partProperty(i,'type', elem.DEFAULT_PT_IRON)
					sim.partProperty(i,'temp', sim.partProperty(i,'temp')+15)
				end
			end
		end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BRMT then
		if sim.partProperty(r,'tmp') == 5 and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_NONE then
			if transmuteRDM == 1 then
				sim.partProperty(i,'type', elem.TIMO_PT_TACT)
				sim.partProperty(r,'type', elem.TIMO_PT_RAD)
			elseif transmuteRDM == 2 then
				sim.partProperty(i,'type', elem.TIMO_PT_ACT)
				sim.partProperty(r,'type', elem.TIMO_PT_TACT)
			elseif transmuteRDM == 3 then
				sim.partProperty(i,'type', elem.TIMO_PT_TACT)
				sim.partProperty(r,'type', elem.TIMO_PT_TACT)
			elseif transmuteRDM == 1 then
				sim.partProperty(i,'type', elem.DEFAULT_PT_BREL)
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_TUNG)
			end
		end
	end
	end --weakforce end
end
end
--end
tpt.element_func(PACT,pact)
elem.property(pact, "Update",pactUpdate)
--- end transition nuclear metal 2
--- transition nuclear metal 3
local tact = elements.allocate("TIMO", "TACT")
elements.element(elements.DEFAULT_PT_PQRT)
elem.property(elem.TIMO_PT_TACT, "Name", "TACT")
elem.property(elem.TIMO_PT_TACT, "Colour", 0x988888)
elem.property(elem.TIMO_PT_TACT, "Description", "Metallic metastable.")
elem.property(elem.TIMO_PT_TACT, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_HOT_GLOW+elem.PROP_RADIOACTIVE+elem.PROP_NEUTPASS)
elem.property(elem.TIMO_PT_TACT, "MenuSection", 10)
elem.property(elem.TIMO_PT_TACT, "MenuVisible", 1)
elem.property(elem.TIMO_PT_TACT, "Weight", 90)
elem.property(elem.TIMO_PT_TACT, "Gravity", 1)
elem.property(elem.TIMO_PT_TACT, "Falldown", 1)
elem.property(elem.TIMO_PT_TACT, "AirLoss", 0.01)
elem.property(elem.TIMO_PT_TACT, "Loss", 0.02)
elem.property(elem.TIMO_PT_TACT, "AirDrag", 0.31)
elem.property(elem.TIMO_PT_TACT, "Advection", 0.3776)
elem.property(elem.TIMO_PT_TACT, "Diffusion", 0)
elem.property(elem.TIMO_PT_TACT, "HeatConduct", 26)
elem.property(elem.TIMO_PT_TACT, "HighTemperature", 3826.35)
elem.property(elem.TIMO_PT_TACT, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
sim.can_move(elem.DEFAULT_PT_ELEC, elem.TIMO_PT_TACT, 2)
sim.can_move(elem.DEFAULT_PT_PHOT, elem.TIMO_PT_TACT, 2)
sim.can_move(elem.DEFAULT_PT_PROT, elem.TIMO_PT_TACT, 0)
sim.can_move(elem.DEFAULT_PT_NEUT, elem.TIMO_PT_TACT, 1)
sim.can_move(elem.DEFAULT_PT_MERC, elem.TIMO_PT_TACT, 1)
sim.can_move(elem.DEFAULT_PT_LAVA, elem.TIMO_PT_TACT, 1)
sim.can_move(elem.TIMO_PT_ACT, elem.TIMO_PT_TACT, 1)
tpt.element_func(NU, tpt.element('TACT'))
local function tactUpdate(i,x,y,s,n)
local mytemp = sim.partProperty(i,'temp')
local mypres = sim.pressure(x/4,y/4)
local weakforce = sim.partProperty(i,'pavg0')
r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))


if r~= nil then
	local transmuteRDM = math.random(1,6)
-- -- WEAKFORCE INDUCTORS
-- WEAKFORCE 0
if weakforce == 0 then
end
-- WEAKFORCE INTERACTIONS
if sim.partProperty(r,'type') == elem.DEFAULT_PT_FIRE then
	sim.partProperty(i,'pavg0', 5)
	sim.partProperty(i,'dcolor', sim.partProperty(i,'dcolor')+math.random(5,25)) --NONREACT color ?
end
if sim.partProperty(r,'type') == elem.DEFAULT_PT_WATR or sim.partProperty(r,'type') == elem.DEFAULT_PT_DSTW or sim.partProperty(r,'type') == elem.DEFAULT_PT_WTRV then
	sim.partProperty(i,'pavg0', 0)
	sim.partProperty(i,'life', 0)
	sim.partProperty(i,'tmp', 0)
	sim.partProperty(i,'tmp2', 0)
end
-- WEAKFORCE INTERACTIONS END
--TRANSMUTEGENERALRATE -- WEAKFORCE 0
if weakforce == 0 then -- 0WEAKFORCE 1 -- NEUTREACT DECAY
	if sim.partProperty(i,'life') == 0 then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
			sim.partProperty(i,'life', 1)
			sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-5,5))
			sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-4,4))
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+6000)
			---sim.pressure(x/4,y/4, math.abs(mypres) + 14)
			if sim.partProperty(r,'type') == elem.DEFAULT_PT_CRMC then
				sim.partProperty(i,'type', elem.TIMO_PT_ACT)
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+1000)
			end
		end
	elseif sim.partProperty(i,'life') == 1 then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
			if math.random(1,15) == 1 then
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+math.random(2000,9000))
				sim.pressure(x/4,y/4, math.abs(mypres) + 24)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-8,8))
				sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-5,5))
			end
			if transmuteRDM == 1 then
				sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-3,3))
				sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-3,3))
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+7500)
				sim.pressure(x/4,y/4, math.abs(mypres) + 16)
				sim.partProperty(i,'type', elem.TIMO_PT_PACT)
			elseif transmuteRDM == 2 then
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			elseif transmuteRDM == 6 and math.random(1,56) == 1 then
				sim.partProperty(i,'pavg0', 5)
			end
		end
	end
end --- 0WEAKFORCE 1 END
if weakforce == 0 then -- 0WEAKFORCE 2 -- DECAY
	if math.random(1,2360) == 1 then
		sim.partProperty(i,'temp', sim.partProperty(i,'temp')+465)
		sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-1,1))
		sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-1,1))
		if math.random(1,14) == 1 then
			sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-6,6))
			sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-7,7))
			sim.partProperty(i,'tmp', math.random(1,2))
			if transmuteRDM == 1 then
				sim.partProperty(i,'pavg0', 5) --NONREACT
				sim.partProperty(i,'dcolor', sim.partProperty(i,'dcolor')+math.random(5,25)) --NONREACT color ?
			elseif transmuteRDM == 2 then
				sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-6,6))
				sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-7,7))
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+465)
			elseif transmuteRDM == 3 then
				sim.partProperty(i,'type', elem.TIMO_PT_PACT)
				if sim.partProperty(r,'type') == elem.DEFAULT_PT_IRON then
					sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')-1)
				end
			elseif transmuteRDM == 4 then
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+210)
				if math.random(1,3) == 1 then
					sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')-1)
				end
			elseif transmuteRDM == 5 then
				if sim.partProperty(r,'type') == elem.DEFAULT_PT_IRON then
					sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')-1)
				elseif sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_IRON then
					sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+3)
					local pssst = math.random(1,3)
					if pssst == 1 then
						if math.random(1,3) == 1 then
							sim.partProperty(r,'ctype', elem.DEFAULT_PT_METL)
						end
					elseif pssst == 2 then
						sim.partProperty(r,'ctype', elem.DEFAULT_PT_PTCT)
					elseif pssst == 3 then
						sim.partProperty(r,'ctype', elem.DEFAULT_PT_NTCT)
					end
				end
				
				sim.partProperty(i,'type', elem.TIMO_PT_PACT)
			elseif transmuteRDM == 6 then
				local blocal = math.random(1,3)
				if blocal == 1 then
					sim.partProperty(i,'tmp', math.random(1,3)+11)
					sim.partProperty(i,'type', elem.DEFAULT_PT_SALT)
					sim.partProperty(i,'life', 0)
				elseif blocal == 2 then
					if sim.partProperty(r,'type') == elem.DEFAULT_PT_SALT then
						if sim.partProperty(r,'tmp') == 12 then
							sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
						elseif sim.partProperty(r,'tmp') == 13 and math.random(1,10) == 1 then
							sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
						elseif sim.partProperty(r,'tmp') == 14 then
							sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
						end
					end
				elseif blocal == 3 then
					local tlocal = math.random(1,4)
					if tlocal == 1 then
					sim.partProperty(i,'type', elem.DEFAULT_PT_PLUT)
					sim.partProperty(i,'tmp', 2)
					elseif tlocal == 2 then
					sim.partProperty(i,'type', elem.TIMO_PT_PACT)
					elseif tlocal == 3 then
					sim.partProperty(i,'type', elem.TIMO_PT_ACT)
					elseif tlocal == 4 then
					sim.partProperty(i,'pavg0', 5) -- INERT ACT
					sim.partProperty(i,'type', elem.TIMO_PT_ACT)
					end
					
				end
			end
		end
	end
end -- 0WEAKFORCE 2 END
if math.random(1,2) == 1 and weakforce == 0 then
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_QRTZ and sim.partProperty(r,'tmp2') < 15 then
		if transmuteRDM == 1 then
		sim.partProperty(r,'dcolor', (sim.partProperty(r,'dcolor')+sim.partProperty(i,'dcolor'))/sim.partProperty(i,'dcolor'))
		end
		if math.random(1,30) == 1 then
			if transmuteRDM == 1 then
				sim.partProperty(r,'tmp2', sim.partProperty(r,'tmp2')+1)
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'tmp2', sim.partProperty(r,'tmp2')+3)
			elseif transmuteRDM == 3 then
				sim.partProperty(r,'tmp2', sim.partProperty(r,'tmp2')-2)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_PQRT and sim.partProperty(r,'tmp2') < 15 then
		if transmuteRDM == 1 then
		sim.partProperty(r,'dcolor', (sim.partProperty(r,'dcolor')+sim.partProperty(i,'dcolor'))/sim.partProperty(i,'dcolor'))
		end
		if math.random(1,30) == 1 then
			if transmuteRDM == 1 then
				sim.partProperty(r,'tmp2', sim.partProperty(r,'tmp2')+1)
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'tmp2', sim.partProperty(r,'tmp2')+3)
			elseif transmuteRDM == 3 then
				sim.partProperty(r,'tmp2', sim.partProperty(r,'tmp2')-2)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SAWD then
		if sim.partProperty(i,'tmp2') == 0 then
			sim.partProperty(r,'life', 110)
			sim.partProperty(r,'tmp2', math.random(1,500))
			sim.partProperty(r,'type', elem.DEFAULT_PT_BCOL)
			sim.partProperty(r,'ctype', elem.TIMO_PT_TACT)
			sim.partProperty(i,'temp', sim.partProperty(r,'temp')+300)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			sim.partProperty(i,'tmp2', 1)
			if sim.partProperty(r,'type') == elem.DEFAULT_PT_BRMT then
				if sim.partProperty(r,'ctype') == elem.DEFAULT_PT_TUNG then
					sim.partProperty(r,'temp', sim.partProperty(i,'temp')+3333)
					sim.partProperty(i,'type', elem.TIMO_PT_PACT)
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_IRON)
				end
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_WOOD then
		sim.partProperty(r,'life', 110)
		sim.partProperty(r,'tmp', 50)
		sim.partProperty(r,'type', elem.DEFAULT_PT_COAL)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLNT then
		sim.partProperty(r,'life', 110)
		sim.partProperty(r,'tmp', 50)
		sim.partProperty(r,'type', elem.DEFAULT_PT_COAL)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BCOL then
		if sim.partProperty(i,'tmp2') == 1 and math.random(1,46) == 1 then
			if transmuteRDM == 1 then
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partProperty(i,'temp', sim.partProperty(r,'temp')+1300)
				sim.partProperty(r,'vx', sim.partProperty(r,'vx')+math.random(-13,13))
				sim.partProperty(r,'vy', sim.partProperty(r,'vy')+math.random(-13,13))
				sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-6,6))
				sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-6,6))
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'tmp', 2)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-26,26))
				sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-26,26))
				sim.partProperty(i,'type', elem.TIMO_PT_PACT)
				sim.partProperty(i,'temp', sim.partProperty(r,'temp')+8300)
			elseif transmuteRDM == 3 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
				sim.partCreate(-1, x, y, elem.DEFAULT_PT_URAN)
				sim.pressure(x/4,y/4, math.abs(mypres) + 48)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_TUNG then
		if math.random(1,14) == 1 then
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+400)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
		end
		if transmuteRDM == 1 then
			sim.partCreate(-1, x, y, elem.DEFAULT_PT_URAN)
		elseif transmuteRDM == 2 then
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+600)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			if math.random(1,720) == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_IRON)
			end
		end
	end

	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BRMT then
		if math.random(1,48) == 1 then
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+120)
		end
		if math.random(1,290) == 1 then
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'type', elem.TIMO_PT_ACT)
			elseif transmuteRDM == 3 then
				sim.partProperty(r,'type', elem.TIMO_PT_TACT)
			end
		end
		if sim.partProperty(r,'ctype') == elem.DEFAULT_PT_TUNG then
			if math.random(1,14) == 1 then
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+400)
				if transmuteRDM == 1 then
					sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
					sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				elseif transmuteRDM == 2 then
					sim.partProperty(i,'temp', sim.partProperty(i,'temp')+600)
					sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
				end
			end
		end
	end

	--if sim.partProperty(r,'type') == elem.DEFAULT_PT_WATR or sim.partProperty(r,'type') == elem.DEFAULT_PT_DSTW or sim.partProperty(r,'type') == elem.DEFAULT_PT_WTRV then
	--	if sim.partProperty(r,'ctype') == elem.DEFAULT_PT_POLO then
	--		if transmuteRDM == 1 and math.random(1,10) == 1 then
	--			sim.partProperty(r,'ctype', elem.TIMO_PT_TACT)
	--		end
	--	elseif sim.partProperty(r,'ctype') == elem.DEFAULT_PT_ISOZ then
	--		sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-6,6))
	--		sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-7,7))
	--	end
	--end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_POLO then
		--sim.partProperty(i,'dcolor', sim.partProperty(i,'dcolor')-3000)
		if sim.partProperty(r,'tmp') == 0 then
			sim.partProperty(r,'vx', sim.partProperty(r,'vx')+math.random(-13,13))
			sim.partProperty(r,'vy', sim.partProperty(r,'vy')+math.random(-13,13))
			sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-6,6))
			sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-6,6))
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+1300)
			sim.partProperty(r,'temp', sim.partProperty(r,'temp')+600)
			sim.partProperty(r,'type', elem.TIMO_PT_PACT)
		elseif sim.partProperty(r,'tmp') == 1 then
			sim.partProperty(r,'type', elem.TIMO_PT_TACT)
		elseif sim.partProperty(r,'tmp') == 2 then
			local clocal = math.random(1,2)
			if clocal == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
			elseif clocal == 2 then
				sim.partProperty(r,'type', elem.TIMO_PT_ACT)
			end
		elseif sim.partProperty(r,'tmp') > 2 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_CLST then
		if math.random(1,62) == 1 then
			if sim.partProperty(r,'type') == elem.DEFAULT_PT_GLOW then
				if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
					sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
					sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
					sim.partCreate(-3, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_NEUT)
					sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.TIMO_PT_ACT)
					sim.partProperty(r,'vx', math.random(-2,2))
					sim.partProperty(r,'vy', math.random(-2,2))
					sim.partProperty(i,'temp', sim.partProperty(i,'temp')-200)
				end
				if sim.partProperty(r,'type') == elem.DEFAULT_PT_DUST and sim.partProperty(r,'ctype') == elem.TIMO_PT_ACT then
					sim.partProperty(r,'type', elem.TIMO_PT_ACT)
				end
			end
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_STNE)
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_BREL)
			elseif transmuteRDM == 3 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_SAND)
			elseif transmuteRDM == 4 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_BCOL)
			elseif transmuteRDM == 5 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
			elseif transmuteRDM == 6 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BREL then
		sim.partProperty(i,'dcolor', sim.partProperty(i,'dcolor')+12)
		if math.random(1,60) == 1 then
			local colorTactBrellerd = math.random(1,5)
			if colorTactBrellerd == 1 and sim.partProperty(r,'type') == elem.DEFAULT_PT_BREL then
				sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+600)
			elseif colorTactBrellerd == 2 and sim.partProperty(r,'type') == elem.DEFAULT_PT_BREL then
				sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+100)
			end
		end
		if math.random(1,230) == 1 then
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_STNE)
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
			elseif transmuteRDM == 3 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
			elseif transmuteRDM == 4 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
			elseif transmuteRDM == 5 then
				sim.partProperty(r,'type', elem.TIMO_PT_ACT)
			elseif transmuteRDM == 6 then
				sim.partProperty(r,'type', elem.TIMO_PT_TACT)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_SAND then
		if math.random(1,140) == 1 then
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.TIMO_PT_RAD)
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'type', elem.TIMO_PT_RAD)
			elseif transmuteRDM == 3 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_BREL)
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_TUNG)
				if sim.partProperty(r,'type') == elem.DEFAULT_PT_IRON then
					sim.partProperty(r,'type', elem.DEFAULT_PT_CRMC)
				end
			elseif transmuteRDM == 4 then
				sim.partProperty(r,'type', elem.TIMO_PT_TACT)
			elseif transmuteRDM == 5 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
			elseif transmuteRDM == 6 then
				local SANDTOR = math.random(1,3)
				if SANDTOR == 1 then
					sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
					sim.partProperty(r,'vx', sim.partProperty(r,'vx')+math.random(-43,43))
					sim.partProperty(r,'vy', sim.partProperty(r,'vy')+math.random(-43,43))
					sim.partProperty(i,'vx', sim.partProperty(i,'vx')+math.random(-33,33))
					sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-33,33))
				elseif SANDTOR == 2 then
					sim.partProperty(r,'type', elem.TIMO_PT_PACT)
					sim.partProperty(i,'temp', sim.partProperty(i,'temp')+1300)
					sim.partProperty(i,'vy', sim.partProperty(i,'vy')+math.random(-33,33))
				elseif SANDTOR == 3 then
					sim.partProperty(r,'type', elem.TIMO_PT_TACT)
					if sim.partProperty(r,'type') == elem.DEFAULT_PT_IRON then
						sim.partProperty(r,'type', elem.DEFAULT_PT_CRMC)
					end
				end
			end
		end
		if sim.partProperty(r,'ctype') == elem.TIMO_PT_ACT and math.random(1,8) == 1 then
			if sim.partProperty(r,'tmp2') == 0 then
				if transmuteRDM == 1 then
					sim.partProperty(r,'ctype', elem.TIMO_PT_TACT)
					sim.partProperty(r,'tmp2', 1)
					sim.partProperty(r,'pavg0', 5) -- SET TO WEAKFORCE 5. pavg0 is weakforce. 0 = react, 5 = nonreact, other is custom
				elseif transmuteRDM == 2 then
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_PLUT)
					sim.partProperty(r,'tmp2', 1)
				elseif transmuteRDM == 3 then
					sim.partProperty(r,'ctype', elem.DEFAULT_PT_POLO)
					sim.partProperty(r,'tmp2', 1)
					sim.partProperty(r,'tmp', 0)
				end
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_COAL and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_NONE then
		sim.partProperty(r,'ctype', elem.DEFAULT_PT_POLO)
		sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+6)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_BRMT then
		sim.partProperty(i,'temp', sim.partProperty(i,'temp')+60)
		if transmuteRDM == 1 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'type', elem.DEFAULT_PT_BREL)
		end
		if math.random(1,13) == 1 then
			sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_RBDM then
		sim.partProperty(r,'type', elem.TIMO_PT_TACT)
		if sim.partProperty(r,'ctype') == elem.DEFAULT_PT_BMTL then
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_GOLD)
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_RBDM)
				sim.partProperty(r,'tmp', 5)
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_IRON)
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_RBDM)
				sim.partProperty(r,'tmp', 5)
			end
		end
		if sim.partProperty(r,'ctype') == elem.DEFAULT_PT_BRMT then
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_BRMT)
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_TUNG)
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'type', elem.TIMO_PT_RAD)
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_RBDM)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LRBD then
		sim.partProperty(r,'type', elem.TIMO_PT_TACT)
		if sim.partProperty(r,'ctype') == elem.DEFAULT_PT_BMTL then
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_IRON)
				sim.partProperty(r,'tmp', 1)
			elseif transmuteRDM == 2 then
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
			end
		end
		if sim.partProperty(r,'ctype') == elem.DEFAULT_PT_BRMT then
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_BRMT)
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_TUNG)
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'type', elem.TIMO_PT_RADX)
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_LRBD)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_STNE then
		sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')-4)
		if math.random(1,16) == 1 then
			local colorTactStonerd = math.random(1,5)
			if colorTactStonerd == 1 then
				sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+12)
			elseif colorTactStonerd == 2 then
				sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+6)
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_URAN then
		if sim.partProperty(r,'tmp2') == 0 and math.random(1,140) then
			if transmuteRDM == 1 then
				sim.partProperty(r,'type', elem.TIMO_PT_ACT)
				if math.random(1,32) == 1 then
					sim.partProperty(r,'type', elem.DEFAULT_PT_LAVA)
					sim.partProperty(r,'ctype', elem.TIMO_PT_PACT)
				end
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_PLUT)
				sim.partProperty(i,'temp', sim.partProperty(r,'temp')+300)
			elseif transmuteRDM == 3 then
				sim.partProperty(r,'tmp', sim.partProperty(r,'tmp')+1)
				sim.partProperty(i,'temp', sim.partProperty(r,'temp')+400)
			elseif transmuteRDM == 4 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_BREL)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			elseif transmuteRDM == 5 then
				sim.partProperty(i,'temp', sim.partProperty(r,'temp')+150)
			elseif transmuteRDM == 6 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_BREL)
				if math.random(1,3) == 1 then
					sim.partProperty(r,'type', elem.TIMO_PT_ACT)
					sim.partProperty(r,'pavg0', 5)
					if math.random(1,10) == 1 then
						sim.partProperty(i,'pavg0', 5)
					end
				end
			end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_PLUT then
		if sim.partProperty(r,'tmp') == 0 then
			sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')-7)
			if math.random(1,350) then
				if transmuteRDM == 1 then
					sim.partProperty(r,'type', elem.TIMO_PT_ACT)
					if math.random(1,42) == 1 then
						sim.partProperty(r,'type', elem.DEFAULT_PT_LAVA)
						sim.partProperty(r,'ctype', elem.TIMO_PT_ACT)
						sim.partProperty(r,'pavg0', 5)
					end
				elseif transmuteRDM == 2 then
					sim.partProperty(i,'temp', sim.partProperty(r,'temp')+600)
				elseif transmuteRDM == 3 then
					sim.partProperty(r,'tmp', 1)
					sim.partProperty(i,'temp', sim.partProperty(r,'temp')+800)
				elseif transmuteRDM > 3 then
					sim.partProperty(i,'temp', sim.partProperty(r,'temp')+350)
				end
			end
		elseif sim.partProperty(r,'tmp') == 1 then
		elseif sim.partProperty(r,'tmp') == 2 then
			sim.partProperty(i,'temp', sim.partProperty(r,'temp')+200)
			if math.random(1,120) == 1 then
				sim.partProperty(r,'type', elem.DEFAULT_PT_URAN)
				sim.partProperty(r,'dcolor', sim.partProperty(r,'dcolor')+3)
			end
		end
	end
end --TRANSMUTEGENERALRATE END


if math.random(1,10) == 1 then --LAVATRANSMUTERATE
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_POLO then
		if math.random(1,300) == 1 then
		if transmuteRDM == 1 then
			sim.partProperty(r,'ctype', elem.TIMO_PT_ACT)
			sim.partProperty(r,'pavg0', 5) -- NONREACT ACT
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_TUNG)
		elseif transmuteRDM == 3 then
			sim.partProperty(r,'ctype', elem.TIMO_PT_RAD)
		elseif transmuteRDM == 4 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_STNE)
		end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_PLUT then
		sim.partProperty(r,'ctype', elem.TIMO_PT_ACT)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_TACT then
		sim.partProperty(r,'ctype', elem.TIMO_PT_PACT)
		sim.partProperty(i,'temp', sim.partProperty(r,'temp')-350)
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_BRMT then
		if math.random(1,300) == 1 then
		if transmuteRDM == 1 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_TUNG)
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_METL)
		elseif transmuteRDM == 3 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_IRON)
			sim.partProperty(r,'tmp', 5)
		end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_BRCK then
		if math.random(1,300) == 1 then
		if transmuteRDM == 1 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_GOLD)
			sim.partProperty(r,'tmp', 5)
		elseif transmuteRDM == 2 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_QRTZ)
		elseif transmuteRDM == 3 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_POLO)
			sim.partProperty(r,'tmp', 0)
			sim.partProperty(r,'tmp2', 9)
		elseif transmuteRDM == 4 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_STNE)
		end
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_CNCT then
		if math.random(1,300) == 1 then
		if transmuteRDM == 1 then
			sim.partProperty(r,'ctype', elem.DEFAULT_PT_POLO)
			sim.partProperty(r,'tmp', 0)
			sim.partProperty(r,'tmp2', 9)
		end		
		end
	end
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_LAVA and sim.partProperty(r,'ctype') == elem.DEFAULT_PT_SALT then
		if math.random(1,300) == 1 then
		if sim.partProperty(r,'tmp') == 0 then
			if transmuteRDM == 1 then
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_WTRV) --oddity
			elseif transmuteRDM == 2 then
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_TUNG)
			elseif transmuteRDM == 3 then
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_BREL)
			elseif transmuteRDM == 4 then
				sim.partProperty(r,'ctype', elem.DEFAULT_PT_STNE)
			end
		end	
		end
	end
end --LAVATRANSMUTERATE END
end
end
tpt.element_func(TACT,tact)
elem.property(tact, "Update",tactUpdate)
--- end transition nuclear metal 3
--- actinide solid neutpass
local LAMBDA = elements.allocate("TIMO", "LAMD")
elements.element(elements.DEFAULT_PT_IRON)
elem.property(elem.TIMO_PT_LAMD, "Name", "LAMD")
elem.property(elem.TIMO_PT_LAMD, "Colour", 0x555555)
elem.property(elem.TIMO_PT_LAMD, "Description", "Lambda-type allotrope.")
elem.property(elem.TIMO_PT_LAMD, "Properties", elem.TYPE_SOLID+elem.PROP_HOT_GLOW+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_NEUTPASS)
elem.property(elem.TIMO_PT_LAMD, "Gravity", 0)
elem.property(elem.TIMO_PT_LAMD, "Advection", 0)
elem.property(elem.TIMO_PT_LAMD, "Diffusion", 0)
elem.property(elem.TIMO_PT_LAMD, "AirDrag", 0)
elem.property(elem.TIMO_PT_LAMD, "MenuSection", 9)
elem.property(elem.TIMO_PT_LAMD, "MenuVisible", 1)
elem.property(elem.TIMO_PT_LAMD, "AirLoss", 1)
elem.property(elem.TIMO_PT_LAMD, "Loss", 0)
elem.property(elem.TIMO_PT_LAMD, "Weight", 99)
elem.property(elem.TIMO_PT_LAMD, "Falldown", 0)
elem.property(elem.TIMO_PT_LAMD, "HeatConduct", 1)
elem.property(elem.TIMO_PT_LAMD, "HighTemperature", 6626.75)
elem.property(elem.TIMO_PT_LAMD, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
elem.property(elem.TIMO_PT_LAMD, "HighPressure", 63)
elem.property(elem.TIMO_PT_LAMD, "HighPressureTransition", elements.TIMO_PT_TACT)
sim.can_move(elem.DEFAULT_PT_ELEC, elem.TIMO_PT_LAMD, 2)
sim.can_move(elem.DEFAULT_PT_PHOT, elem.TIMO_PT_LAMD, 2)
sim.can_move(elem.DEFAULT_PT_NEUT, elem.TIMO_PT_LAMD, 2)
tpt.element_func(NU, tpt.element('LAMD'))

local function LambdaUpdate(i,x,y,s,n)
	local mytemp = sim.partProperty(i,'temp')
	local mypres = sim.pressure(x/4,y/4)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	nB = sim.partID(x+math.random(-2,2),y+math.random(-2,2))
	if sim.partProperty(i,'temp') > 2200 then
	
	end
	
	
	
if nB~=nil then
	if sim.partProperty(nB,'type') == elem.DEFAULT_PT_URAN then
		sim.partProperty(nB,'type', elem.DEFAULT_PT_PLUT)
	end
end
if r~=nil then
	if sim.partProperty(r,'type') == elem.DEFAULT_PT_URAN then
		sim.partProperty(r,'type', elem.DEFAULT_PT_POLO)
	end
	-- TACT DECAY 
	if math.random(1,3660) == 1 then
		sim.partProperty(i,'temp', sim.partProperty(i,'temp')+715)
		if math.random(1,60) == 1 then
			sim.partProperty(i,'tmp', math.random(1,2))
			if transmuteRDM == 1 then
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+975)
			elseif transmuteRDM == 5 then
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+115)
			elseif transmuteRDM == 6 then
				local tlocal = math.random(1,3)
				if tlocal == 1 then
					sim.partProperty(i,'type', elem.DEFAULT_PT_PLUT)
					sim.partProperty(r,'tmp', 2)
				elseif tlocal == 2 then
					sim.partProperty(i,'type', elem.TIMO_PT_PACT)
				elseif tlocal == 3 then
					sim.partProperty(i,'type', elem.TIMO_PT_ACT)
				end
			end
		end
	end
	-- TACT DECAY END
	-- TACT NEUTREACT
	if sim.partProperty(i,'life') == 0 then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
			sim.partProperty(i,'life', 1)
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+4000)
			---sim.pressure(x/4,y/4, math.abs(mypres) + 14)
			if math.random(1,60) == 1 then
				sim.partProperty(i,'type', elem.TIMO_PT_PACT)
			end
		end
	elseif sim.partProperty(i,'life') == 1 then
		if sim.partProperty(r,'type') == elem.DEFAULT_PT_NEUT then
			sim.partProperty(i,'temp', sim.partProperty(i,'temp')+math.random(2000,9000))
			if math.random(1,15) == 1 then
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+math.random(2000,9000))
				sim.pressure(x/4,y/4, math.abs(mypres) + 24)
				sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT)
			end
			if transmuteRDM == 1 then
				sim.partProperty(i,'temp', sim.partProperty(i,'temp')+7500)
				sim.pressure(x/4,y/4, math.abs(mypres) + 16)
				if math.random(1,30) == 1 then
					sim.partProperty(i,'type', elem.TIMO_PT_PACT)
				end
			end
		end
	end
	-- TACT NEUTREACT END
end
end
tpt.element_func(LAMD,LAMBDA)
elem.property(elem.TIMO_PT_LAMD, "Update",LambdaUpdate)
--- actinide solid end