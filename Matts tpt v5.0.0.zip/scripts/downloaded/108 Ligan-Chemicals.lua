
local cao = elem.allocate("LIG", "CAO")
local caco3 = elem.allocate("LIG", "CACO3")
elem.property(caco3, "Name", "CACB")
elem.property(caco3, "Color", 0xA59D84)
elem.property(caco3, "Description", "Calcium carbonate, decomposes into CaO and CO2.")
elem.property(caco3, "MenuVisible", 1)
elem.property(caco3, "MenuSection", elem.SC_POWDERS)
elem.property(caco3, "Weight", 90)
elem.property(caco3, "Flammable", 0)
elem.property(caco3, "Explosive", 0)
elem.property(caco3, "Meltable", 0)
elem.property(caco3, "Hardness", 60)
elem.property(caco3, "Advection", 0.4)
elem.property(caco3, "AirDrag", 0.04)
elem.property(caco3, "AirLoss", 0.94)
elem.property(caco3, "Loss", 0.95)
elem.property(caco3, "HotAir", 0)
elem.property(caco3, "Collision", 0)
elem.property(caco3, "Gravity", 0.3)
elem.property(caco3, "Falldown", 1)
elem.property(caco3, "Diffusion", 0)
elem.property(caco3, "Temperature", 273.15+sim.R_TEMP)
elem.property(caco3, "HeatConduct", 75)

elem.property(caco3, "Properties", elem.TYPE_PART+elem.PROP_LIFE_DEC+elem.PROP_NEUTPENETRATE)

elem.property(caco3, "HighTemperature", 1113) --Decomposition temperature
elem.property(caco3, "HighTemperatureTransition", ST)

local function caco3Update(i,x,y,s,nt)
	if sim.partProperty(i, "life") <= 4 and sim.partProperty(i, "life") ~= 0 then
		if math.random(0,2) == 0 then
		sim.partChangeType(i, elem.DEFAULT_PT_CO2)
		elseif math.random(0,2) == 1 then
		sim.partChangeType(i, elem.LIG_PT_CAO)
		end
	end
	if sim.partProperty(i, "temp") >= elem.property(caco3, "HighTemperature") then
	sim.partProperty(i, "life", math.max(math.random(4,80)-(sim.partProperty(i, "temp")-elem.property(caco3, "HighTemperature"))*0.25, 4))
	end
	local r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r ~= nil then
	local rt = sim.partProperty(r, "type")
		if (rt == elem.DEFAULT_PT_WATR or rt == elem.DEFAULT_PT_DSTW or rt == elem.DEFAULT_PT_SLTW or rt == elem.DEFAULT_PT_BUBW or rt == elem.DEFAULT_PT_WTRV) then
			if math.random(273,999) < sim.partProperty(i, "temp") then
				if math.random(0,2) == 0 then
				sim.partChangeType(i, elem.DEFAULT_PT_CO2)
				elseif math.random(0,2) == 1 then
				sim.partChangeType(i, elem.LIG_PT_CAO)
				elseif math.random(0,2) == 2 then
				sim.partKill(r)
				end
			end
		end
	end
end

elem.property(caco3, "Update", caco3Update)

elem.property(cao, "Name", "CAOX")
elem.property(cao, "Color", 0xD8D3B8)
elem.property(cao, "Description", "Calcium oxide. Heats up in water and neutralizes acid. High melting point.")
elem.property(cao, "MenuVisible", 1)
elem.property(cao, "MenuSection", elem.SC_POWDERS)
elem.property(cao, "Weight", 90)
elem.property(cao, "Flammable", 0)
elem.property(cao, "Explosive", 0)
elem.property(cao, "Meltable", 0)
elem.property(cao, "Hardness", 4)
elem.property(cao, "Advection", 0.4)
elem.property(cao, "AirDrag", 0.01)
elem.property(cao, "AirLoss", 0.9)
elem.property(cao, "Loss", 0.95)
elem.property(cao, "HotAir", 0)
elem.property(cao, "Collision", -0.1)
elem.property(cao, "Gravity", 0.3)
elem.property(cao, "Falldown", 1)
elem.property(cao, "Diffusion", 0)
elem.property(cao, "Temperature", 273.15+sim.R_TEMP)
elem.property(cao, "HeatConduct", 110)

elem.property(cao, "Properties", elem.TYPE_PART+elem.PROP_HOT_GLOW)

elem.property(cao, "HighTemperature", 2873) --2600° degrees
elem.property(cao, "HighTemperatureTransition", elem.DEFAULT_PT_LAVA)

local function caoUpdate(i,x,y,s,nt)
local r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r ~= nil then
	local rt = sim.partProperty(r, "type")
		if (rt == elem.DEFAULT_PT_WATR or rt == elem.DEFAULT_PT_DSTW or rt == elem.DEFAULT_PT_SLTW or rt == elem.DEFAULT_PT_BUBW) then
		sim.partProperty(r, "temp", math.min(sim.partProperty(i, "temp")*(math.random()+1), 353.15))
			if math.random(0,499) == 0 then
			sim.partChangeType(r, cao)
			sim.partChangeType(i, rt)
			end
		elseif rt == elem.DEFAULT_PT_ACID and math.random(0,59) <= elem.property(cao, "Hardness") then
		sim.partKill(r)
		elseif rt == elem.DEFAULT_PT_LAVA and (sim.partProperty(r, "ctype") == elem.DEFAULT_PT_BRCK or sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSTE) then
		sim.partProperty(r, "ctype", elem.DEFAULT_PT_CNCT)
			if math.random(0,3) ~= 0 then
			sim.partKill(i)
			end
		end
	end
end

elem.property(cao, "Update", caoUpdate)

local function caoGraphics(i,r,g,b)
local limelight = math.max(0, sim.partProperty(i, "temp")-2163) -- 2400-510° degrees
	if sim.partProperty(i, "temp") >= 2163 then
return 0, ren.PMODE_FLAT+ren.FIRE_ADD, 255, r, g, b, limelight*0.5, r, g, b
	else
return 0, ren.PMODE_FLAT, 255, r, g, b, 0, 0, 0, 0
	end
end

elem.property(cao, "Graphics", caoGraphics)

local phos = elements.allocate("PHOS", "PHOS")
elem.property(phos, "Name", "PHOS") --Will maybe rename to SULF
elem.property(phos, "Color", 0xA06050)
elem.property(phos, "Description", "Phosphorus, burns for a long time when ignited.")
elem.property(phos, "MenuVisible", 1)
elem.property(phos, "MenuSection", elem.SC_POWDERS)
elem.property(phos, "Weight", 75)
elem.property(phos, "Flammable", 0)
elem.property(phos, "Explosive", 0)
elem.property(phos, "Meltable", 0)
elem.property(phos, "Hardness", 30)
elem.property(phos, "Advection", 0.4)
elem.property(phos, "AirDrag", 0.04)
elem.property(phos, "AirLoss", 0.9)
elem.property(phos, "Loss", 0.95)
elem.property(phos, "HotAir", 0)
elem.property(phos, "Collision", 0)
elem.property(phos, "Gravity", 0.3)
elem.property(phos, "Falldown", 1)
elem.property(phos, "Diffusion", 0)
elem.property(phos, "Temperature", 295.15)
elem.property(phos, "HeatConduct", 130)

elem.property(phos, "Properties", elem.TYPE_PART)

local function phosUpdate(i,x,y,s,nt)
	local ignite = 160 --how many frames the phos creates fire before burning
	if sim.partProperty(i, "tmp") == 0 then
		sim.partProperty(i, "life", ignite)
		sim.partProperty(i, "tmp", 1)
	end
	if sim.partProperty(i, "tmp") == 1 then
		local r = sim.partID(x+math.random(-1,1), y+math.random(-1,1))
		if r ~= nil then
			local rtype = sim.partProperty(r, "type")
			if rtype == elem.DEFAULT_PT_FIRE then
				sim.partProperty(i, "life", sim.partProperty(i, "life")-1)
			end
			if rtype == elem.DEFAULT_PT_PLSM then
				sim.partProperty(i, "life", 0)
			end
			if rtype == elem.DEFAULT_PT_LAVA and sim.partProperty(r, "ctype") ~= phos then
				sim.partProperty(i, "life", 0)
			end
			if rtype == phos and sim.partProperty(i, "life") ~= ignite and sim.partProperty(i, "life") < sim.partProperty(r, "life") then
				sim.partProperty(i, "life", sim.partProperty(i, "life")+1)
				sim.partProperty(r, "life", sim.partProperty(r, "life")-1)
			end
		end
	end
	if sim.partProperty(i, "life") < ignite and sim.partProperty(i, "tmp") == 1 and sim.partProperty(i, "life") > 0 then
		sim.partProperty(i, "life", sim.partProperty(i, "life")-1)
		local np = sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elem.DEFAULT_PT_FIRE)
		sim.partProperty(np, "life", math.random(110,150))
	end
	if sim.partProperty(i, "life") == 0 then
		sim.partChangeType(i, elem.DEFAULT_PT_FIRE)
		sim.partProperty(i, "life", 140)
		sim.pressure(x/4,y/4,sim.pressure(x/4,y/4)+0.15)
	end
end

elem.property(phos, "Update", phosUpdate)

--Based on TPT_PT's suggestion in the Periodic Table thread

local brom = elements.allocate("HALO", "BROM")
elem.property(brom, "Name", "BROM")
elem.property(brom, "Color", 0x762000)
elem.property(brom, "Description", "Bromine, reacts with plants and metals, explodes into CAUS with water.")
elem.property(brom, "MenuVisible", 1)
elem.property(brom, "MenuSection", elem.SC_LIQUID)
elem.property(brom, "Weight", 40)
elem.property(brom, "Flammable", 0)
elem.property(brom, "Explosive", 0)
elem.property(brom, "Meltable", 0)
elem.property(brom, "Hardness", 0)
elem.property(brom, "Advection", 0.6)
elem.property(brom, "AirDrag", 0.01)
elem.property(brom, "AirLoss", 0.98)
elem.property(brom, "Loss", 0.95)
elem.property(brom, "HotAir", 0)
elem.property(brom, "Collision", 0)
elem.property(brom, "Gravity", 0.1)
elem.property(brom, "Falldown", 2)
elem.property(brom, "Diffusion", 0)
elem.property(brom, "Temperature", 295.15)
elem.property(brom, "HeatConduct", 74)

elem.property(brom, "Properties", elem.TYPE_LIQUID+elem.PROP_DEADLY)

local function bromUpdate(i,x,y,s,nt)
	local r = sim.partID(x+math.random(-2,2), y+math.random(-2,2))
	if r ~= nil then
		local rtype = sim.partProperty(r, "type")
		if (rtype == elem.DEFAULT_PT_PLNT or rtype == elem.DEFAULT_PT_PLNT or rtype == elem.DEFAULT_PT_WOOD or rtype == elem.DEFAULT_PT_VINE) then
			if math.random(0,19) == 0 then
			sim.partKill(r)
			end
		end
		if (rtype == elem.DEFAULT_PT_WATR or rtype == elem.DEFAULT_PT_DSTW or rtype == elem.DEFAULT_PT_SLTW or rtype == elem.DEFAULT_PT_BUBW) then
			sim.partProperty(i, "tmp", 1)
		end
		if (rtype == brom or rtype == elem.DEFAULT_PT_CAUS) and sim.partProperty(r, "tmp") == 1 then
			sim.partProperty(i, "tmp", 1)
		end
		if bit.band(elem.property(rtype, "Properties"), elem.PROP_CONDUCTS+elem.PROP_LIFE_DEC+elem.TYPE_SOLID) == elem.PROP_CONDUCTS+elem.PROP_LIFE_DEC+elem.TYPE_SOLID or (rtype == elem.DEFAULT_PT_MERC or rtype == elem.DEFAULT_PT_BRMT) then
			if math.random(0,49) == 0 then
				sim.partKill(r)
			elseif math.random(0,49) == 1 then
				sim.partChangeType(i, elem.DEFAULT_PT_CAUS)
				sim.partProperty(i, "life", 75)
			end
			sim.partProperty(i, "temp", sim.partProperty(i, "temp")+0.0015*(1+sim.partProperty(i, "tmp2")))
		end
	end
	if sim.partProperty(i, "tmp") == 1 then
		sim.partChangeType(i, elem.DEFAULT_PT_CAUS)
		sim.partProperty(i, "life", 75)
		sim.pressure(x/4,y/4, sim.pressure(x/4,y/4)+0.15)
	end
	if sim.partProperty(i, "temp") >= 303.15 then
		sim.partProperty(i, "tmp2", (sim.partProperty(i, "temp"))/200)
	end
end

elem.property(brom, "Update", bromUpdate)


local h2o2 = elements.allocate("H2O2", "H2O2")
elem.property(h2o2, "Name", "HPXD")
elem.property(h2o2, "Color", 0x3060F0)
elem.property(h2o2, "Description", "Hydrogen peroxide. Decomposes into water and oxygen.")
elem.property(h2o2, "MenuVisible", 1)
elem.property(h2o2, "MenuSection", elem.SC_EXPLOSIVE)
elem.property(h2o2, "Weight", 35)
elem.property(h2o2, "Flammable", 0)
elem.property(h2o2, "Explosive", 0)
elem.property(h2o2, "Meltable", 0)
elem.property(h2o2, "Hardness", 3)
elem.property(h2o2, "Advection", 0.6)
elem.property(h2o2, "AirDrag", 0.01)
elem.property(h2o2, "AirLoss", 0.98)
elem.property(h2o2, "Loss", 0.95)
elem.property(h2o2, "HotAir", 0)
elem.property(h2o2, "Collision", 0)
elem.property(h2o2, "Gravity", 0.1)
elem.property(h2o2, "Falldown", 2)
elem.property(h2o2, "Diffusion", 0)
elem.property(h2o2, "Temperature", 293.15)
elem.property(h2o2, "HeatConduct", 29)

elem.property(h2o2, "Properties", elem.TYPE_LIQUID+elem.PROP_DEADLY+elem.PROP_LIFE_DEC)

local function h2o2Update(i,x,y,s,nt)
	local life = sim.partProperty(i, "life")
	if sim.partProperty(i, "tmp2") == 0 then
		sim.partProperty(i, "life", 9000)
		sim.partProperty(i, "tmp2", 1)
	end
	if math.random(0, 8949) > sim.partProperty(i, "life") and math.random(0,8949) > sim.partProperty(i, "life") and sim.partProperty(i, "tmp2") == 1 then
		if math.random(0,1) == 0 then
			sim.partChangeType(i, elem.DEFAULT_PT_DSTW)
		else
			sim.partChangeType(i, elem.DEFAULT_PT_OXYG)
		end
	end
	local r = sim.partID(x+math.random(-1,1), y+math.random(-1,1))
	if r ~= nil then
		local rtype = sim.partProperty(r, "type")
		if (rtype == elem.DEFAULT_PT_YEST or rtype == elem.DEFAULT_PT_GOLD) and sim.partProperty(i, "life") >= 400 then
			sim.partProperty(i, "life", life-400)
		end
	end
	if sim.partProperty(i, "temp") >= elem.property(h2o2, "HighTemperature") then
		sim.partProperty(i, "life", 0)
		sim.pressure(x/4,y/4, sim.pressure(x/4,y/4)+0.75)
	end
end

elem.property(h2o2, "Update", h2o2Update)

local function h2o2Graphics(i,r,g,b)
	local life = (sim.partProperty(i, "life")/9000)*24
	return 0, 0x00000001, 255, r+life, g+life, b+life, 0, 0, 0, 0
end

elem.property(h2o2, "Graphics", h2o2Graphics)

elem.property(h2o2, "LowTemperature", 272.75)
elem.property(h2o2, "LowTemperatureTransition", elem.DEFAULT_PT_ICEI)
elem.property(h2o2, "HighTemperature", 423.30)