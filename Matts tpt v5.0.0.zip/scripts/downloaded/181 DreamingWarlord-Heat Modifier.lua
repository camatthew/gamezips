
local HEAM = elements.allocate("DreamingWarlord", "HEAM")
elements.property(HEAM, "Description", "Heat Modifier. Modifies heat by TMP")
elements.property(HEAM, "Colour", 0xff9966)
elements.property(HEAM, "MenuSection", elem.SC_SPECIAL)
elements.property(HEAM, "Gravity", 0)
elements.property(HEAM, "Flammable", 0)
elements.property(HEAM, "Explosive", 0)
elements.property(HEAM, "Loss", 0)
elements.property(HEAM, "AirLoss", 0.89)
elements.property(HEAM, "AirDrag", 0)
elements.property(HEAM, "Advection", 0)
elements.property(HEAM, "Weight", 100)
elements.property(HEAM, "Diffusion",0)
elements.property(HEAM, "Falldown", 0)
elements.property(HEAM, "Name", "HEAM")
elements.property(HEAM, "State", 1)
elements.property(HEAM, "HeatConduct", 0)
elements.property(HEAM, "Temperature", 300)
elements.property(HEAM, "MenuVisible", 1)
elements.property(HEAM, "Hardness", 0)
local function WhenTMPisHighOrLowAndYouHaveToModifyHeat(i, x, y, s, n)
	--First code that I used
	--local partNear = sim.partID(x+math.random(1,2), y+math.random(1,2))
	--if partNear then
	--	local tmp = sim.partProperty(i, FIELD_TMP)
	--	sim.partProperty(partNear, FIELD_TEMP, tmp)
	--end

	for fx = -2, 2, 1 do
		for fy = -2, 2, 1 do
			local partNear = sim.partID(x + fx, y + fy)
			local tmp = sim.partProperty(i, "tmp")
			if partNear then
				if sim.partProperty(partNear, "type") == tpt.el.sprk.id then
					if sim.partProperty(partNear, "ctype") == tpt.el.pscn.id then
						sim.partProperty(i, "tmp", tmp+5)
					end
				end
				sim.partProperty(partNear,"temp", tmp)
				sim.partProperty(i ,"temp", tmp)
			end
		end
	end
end

tpt.element_func(WhenTMPisHighOrLowAndYouHaveToModifyHeat, HEAM)