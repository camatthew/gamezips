
local ESMD = elements.allocate("ESMD", "FFGE")
elements.element(elements.ESMD_PT_FFGE, elements.element(tpt.element("INSL")))
elements.property(elements.ESMD_PT_FFGE, "Name", "FFGE")
elements.property(elements.ESMD_PT_FFGE, "Description", "Force field generator.")
elements.property(elements.ESMD_PT_FFGE, "MenuVisible", 1)
elements.property(elements.ESMD_PT_FFGE, "MenuSection", elem.SC_POWERED)
elements.property(elements.ESMD_PT_FFGE, "Advection", 0)
elements.property(elements.ESMD_PT_FFGE, "AirDrag", 0.01)
elements.property(elements.ESMD_PT_FFGE, "AirLoss", 0)
elements.property(elements.ESMD_PT_FFGE, "Loss", 0)
elements.property(elements.ESMD_PT_FFGE, "Collision", 0)
elements.property(elements.ESMD_PT_FFGE, "Gravity", 0)
elements.property(elements.ESMD_PT_FFGE, "Diffusion", 0)
elements.property(elements.ESMD_PT_FFGE, "Falldown", 2)
elements.property(elements.ESMD_PT_FFGE, "Flammable", 0)
elements.property(elements.ESMD_PT_FFGE, "Temperature", -200+273.15)
elements.property(elements.ESMD_PT_FFGE, "Hardness", 0)
elements.property(elements.ESMD_PT_FFGE, "HeatConduct", 0)
elements.property(elements.ESMD_PT_FFGE, "Properties", elem.TYPE_SOLID)
elements.property(elements.ESMD_PT_FFGE, "Colour", 0xFF591B69)
local angle =0
local function ForceFieldGeneratorFunction(i, x, y, s, n)
	local generatortemp= math.floor(tpt.get_property("temp",i))
	local goforce = 1
	if goforce == 1 and tpt.get_property("type", x+(math.random(-3,3)),y+(math.random(-3,3))) == 15 then goforce = 2
	end
	if goforce==2 then goforce = 1
		if angle>=360 then angle=0 end
		local z=360
		for angle=0,z do
			local x2=x+( generatortemp*(math.cos(angle/2)))
			local y2=y+( generatortemp*(math.sin(angle/2)))
			if x2<0 or x>611 or y2<0 or y2>383 then else
				tpt.create(x2, y2,tpt.element("fspw"))
			end
		end
	end
end
tpt.element_func(ForceFieldGeneratorFunction,tpt.element('FFGE'))
local ESMD = elements.allocate("ESMD", "FSPW")
elements.element(elements.ESMD_PT_FSPW, elements.element(tpt.element("QRTZ")))
elements.property(elements.ESMD_PT_FSPW, "Name", "FSPW")
elements.property(elements.ESMD_PT_FSPW, "Description", "Force Field Spawner")
elements.property(elements.ESMD_PT_FSPW, "MenuVisible", 0)
elements.property(elements.ESMD_PT_FSPW, "MenuSection", 0)
elements.property(elements.ESMD_PT_FSPW, "Properties", TYPE_SOLID)
elements.property(elements.ESMD_PT_FSPW, "HighPressure", 999999)
elements.property(elements.ESMD_PT_FSPW, "Colour", 0xFF127BC1)
local ESMD = elements.allocate("ESMD", "FOFI")
elements.element(elements.ESMD_PT_FOFI, elements.element(tpt.element("DMND")))
elements.property(elements.ESMD_PT_FOFI, "Name", "FOFI")
elements.property(elements.ESMD_PT_FOFI, "Description", "Force field")
elements.property(elements.ESMD_PT_FOFI, "MenuVisible", 0)
elements.property(elements.ESMD_PT_FOFI, "MenuSection", 0)
elements.property(elements.ESMD_PT_FOFI, "Properties", elem.TYPE_SOLID)
elements.property(elements.ESMD_PT_FOFI, "HighPressure", 999999)
elements.property(elements.ESMD_PT_FOFI, "Colour", 0xFF127BC1)
local function ForceFieldSpawner(i, x, y, s, n)
	if math.random(1,50000) == 2500 then tpt.delete(x,y) end
	local RX = x+(math.random(-3,3))
	local RY = y+(math.random(-3,3))
	if math.random(1,50) == 1 then sim.createLine(x+math.random(-3,3),y+math.random(-3,3),x+math.random(-3,3),y+math.random(-3,3),0,0,tpt.element('FOFI')) end
	if tpt.get_property("type", RX,RY) == tpt.element('FOFI') then else tpt.delete(RX,RY) end
end
tpt.element_func(ForceFieldSpawner,tpt.element('FSPW'))
local function ForceFieldDelete(i, x, y, s, n)
	if tpt.get_property("type", RX,RY) == tpt.element('FOFI') then else tpt.delete(RX,RY) end
	if math.random(1,20) == 1 then tpt.delete(x,y) end
end
tpt.element_func(ForceFieldDelete,tpt.element('FOFI'))
local function glow(i, colr, colg, colb)
	return 1,0x0000008,255,122,153,181,255,122,153,181
end
tpt.graphics_func(glow,tpt.element('FOFI'))