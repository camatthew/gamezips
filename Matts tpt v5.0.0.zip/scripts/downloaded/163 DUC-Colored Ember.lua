
--Converts everything on screen to EMBR element.
--Deco will become Ctype of EMBR, so that deco will be rendered even when deco layer is off.
--If deco is absent or transparent (<100alpha) EMBR will imitate default element color.

--clearDeco: If true, resets the deco to 0. Defaults to false.
--renderDeco: Whether or not to account for deco color. Defaults to true.
--renderOriginal: Whether or not to keep element's original color. Defaults to true.
--fpsConserve: Removes a particle if it's deco color is black. Defaults to true.
--el: Optional. If set, will only change that element. Give element in number form.
--shenanigans: If made true, will add certain special effects. Defaults to false.
function toEMBR(clearDeco,renderDeco,renderOriginal,fpsConserve,el,shenanigans)
	
	--Default args
	if clearDeco == nil then clearDeco = false end
	if renderDeco == nil then renderDeco = true end
	if renderOriginal == nil then renderOriginal = true end
	if fpsConserve == nil then fpsConserve = true end
	if el == nil then el = 0 end
	
	--Iterate
	for i in sim.parts() do
		local dc = sim.partProperty(i,"dcolour")
		local ct = dc
		local rgb = {gfx.getColors(dc)}
		local al = 100
		if not renderDeco then rgb[4]=0 end
		
		--Interpolate if alpha < 100%
		if rgb[4] < 255 and sim.partProperty(i, "type") then
			local nr, ng, nb, na = 0,0,0,255
			local ec = {gfx.getColors(elem.property(sim.partProperty(i, "type"),"Color"))}
			local alpha = rgb[4]/255
			nr = ec[1]+(rgb[1]-ec[1])*alpha
			ng = ec[2]+(rgb[2]-ec[2])*alpha
			nb = ec[3]+(rgb[3]-ec[3])*alpha
			ct = gfx.getHexColor(nr,ng,nb)
		end
		
		--If color is too dark, lower the life instead
		local nrgb = {gfx.getColors(ct)}
		local maxComponent = math.max(nrgb[1],nrgb[2],nrgb[3])
		if maxComponent < 60 then
			if maxComponent == 0 then maxComponent = 1 end
			local darkness = (maxComponent/60)/(100/60)
			al = 100*darkness
			if nrgb[1] == maxComponent then nrgb[1]=60 end
			if nrgb[2] == maxComponent then nrgb[2]=60 end
			if nrgb[3] == maxComponent then nrgb[3]=60 end
			ct = gfx.getHexColor(nrgb[1],nrgb[2],nrgb[3])
		end
		
		if (sim.partProperty(i,"type")==el) or (el==0) then
			--Set properties
			sim.partProperty(i,"type",tpt.el.embr.id)
			sim.partProperty(i,"ctype", ct)
			sim.partProperty(i,"life",al)
			sim.partProperty(i, "tmp", 0)
			sim.partProperty(i, "tmp2", 0)
			if clearDeco then sim.partProperty(i, "dcolour", 0) end
			
			--Remove if deco is black
			if dc == (-16777216) and fpsConserve then
				sim.partKill(i)
			end
		end
	end
end