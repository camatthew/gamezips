
--Version 1.0
--Author: djy0212
--Email: "moc.liamxof)ta(2120yjd" in reverse


--[[
You can make music in powder toy now!
It requires an external python script as a server, so you will need to install python 3 first!
If someone can write javascript, they are free to port the python script to javascript with webmidi and websocket, thus it can be used without python!
Server script address: https://gist.github.com/djy0212/a26014bd5240e92d4a524eb687d97480
The server script needs a library called "mido", open your command prompt / terminal and type in "pip install mido" or "pip3 install mido"
After the server script successfully runs, create a file named "tptmidi_configs.txt" next to your powder.exe and powder.prefs. Enter "127.0.0.1:25011"(without quotes) and save the file.
After those steps, you can place a MIDI particle, put metal near it and spark the metal. your tpt should make sound now!
Demo save and some tips about the midi element: ID:2455608

Use set_all_midi_props(prop_type, value, modifier) to change all MIDI's property at once.
]]--

local NOTE_NAME = {"C-1","C#-1/Db-1","D-1","D#-1/Eb-1","E-1","F-1","F#-1/Gb-1","G-1","G#-1/Ab-1","A-1","A#-1/Bb-1","B-1","C0","C#0/Db0","D0","D#0/Eb0","E0","F0","F#0/Gb0","G0","G#0/Ab0","A0","A#0/Bb0","B0","C1","C#1/Db1","D1","D#1/Eb1","E1","F1","F#1/Gb1","G1","G#1/Ab1","A1","A#1/Bb1","B1","C2","C#2/Db2","D2","D#2/Eb2","E2","F2","F#2/Gb2","G2","G#2/Ab2","A2","A#2/Bb2","B2","C3","C#3/Db3","D3","D#3/Eb3","E3","F3","F#3/Gb3","G3","G#3/Ab3","A3","A#3/Bb3","B3","C4","C#4/Db4","D4","D#4/Eb4","E4","F4","F#4/Gb4","G4","G#4/Ab4","A4","A#4/Bb4","B4","C5","C#5/Db5","D5","D#5/Eb5","E5","F5","F#5/Gb5","G5","G#5/Ab5","A5","A#5/Bb5","B5","C6","C#6/Db6","D6","D#6/Eb6","E6","F6","F#6/Gb6","G6","G#6/Ab6","A6","A#6/Bb6","B6","C7","C#7/Db7","D7","D#7/Eb7","E7","F7","F#7/Gb7","G7","G#7/Ab7","A7","A#7/Bb7","B7","C8","C#8/Db8","D8","D#8/Eb8","E8","F8","F#8/Gb8","G8","G#8/Ab8","A8","A#8/Bb8","B8","C9","C#9/Db9","D9","D#9/Eb9","E9","F9","F#9/Gb9","G9"}

local CONFIG_FILE_NAME = "tptmidi_configs.txt"

local socket = require("socket")
local sock = nil
local address_port = nil

local unpack = unpack or table.unpack

local midi = elem.allocate("djy","midi")
local midi_id = "DJY_PT_MIDI"
elem.element(midi,elem.element(elem.DEFAULT_PT_DMND))
elem.property(midi,"Name","MIDI")
elem.property(midi,"Description","External MIDI controller. Can be used to make sound.")
elem.property(midi,"MenuSection",elem.SC_ELEC)
elem.property(midi,"Color",0x905E46)
elem.property(midi,"Properties",bit.bor(elem.TYPE_SOLID,elem.PROP_LIFE_DEC))
elem.property(midi,"HeatConduct",0)

--utils
local function split(s, p)
    local rt= {}
    string.gsub(s, '[^'..p..']+', function(w) table.insert(rt, w) end )
    return rt
end

local function clamp(n,minn,maxn)
	return math.min(math.max(n,minn),maxn)
end
--

local function load_server_address()
	local file = io.open(CONFIG_FILE_NAME,"r")
	local address, port = unpack(split(file:read("*a"),":"))
	port = tonumber(port)
	address_port = {address,port}
end

local function connect_to_server()
	if not server_address then
		load_server_address()
	end
	local i,s = pcall(socket.connect,unpack(address_port))
	if i then
		sock = s
	end
end

local function make_sound(data)
	if sock ~= nil then
		sock:send(string.char(unpack(data)))
		local chunk = sock:receive(1)
		if chunk ~= "K" then
			sock:close()
			sock = nil
		end
	else
		connect_to_server()
		if sock == nil then
			tpt.set_pause(1)
			print("[MIDI] Server is not connected! Please specify the server in "..CONFIG_FILE_NAME.." or check its status.")
			if not fs.isFile(CONFIG_FILE_NAME) then
				local file = io.open(CONFIG_FILE_NAME, "a")
				io.close(file)
			end
		else
			make_sound(data)
		end
	end
end

local function unpack_tmp_bytes(tmp)
	local velocity = bit.band(bit.rshift(tmp,24),0xFF)
	local gatemsb = bit.band(bit.rshift(tmp,16),0xFF)
	local gatelsb = bit.band(bit.rshift(tmp,8),0xFF)
	local instrument = bit.band(tmp,0xFF)
	return velocity, gatemsb, gatelsb, instrument
end

local function unpack_tmp(tmp)
	local velocity = bit.band(bit.rshift(tmp,24),0xFF)
	local gate = bit.band(bit.rshift(tmp,8),0xFFFF)
	local instrument = bit.band(tmp,0xFF)
	return velocity, gate, instrument
end

local function pack_tmp(velocity, gate, instrument)
	return bit.bor(bit.lshift(bit.band(velocity,0xFF),24),
	               bit.lshift(bit.band(gate,0xFFFF),8),
	               bit.band(instrument,0xFF))
end

local function decode_note_no(temp)
	return math.floor(clamp(temp-273.15,0,1270)/10+0.001) --0~127
end

local function regulate_props(note_no,velocity,gate,instrument)
	return clamp(note_no,0,127),clamp(velocity,0,127),clamp(gate,1,1023),clamp(instrument,0,128)
end

local function update(i,x,y,s,nt)
	--if sim.partProperty(i,sim.FIELD_LIFE) ~= 0 then
	--	return
	--end
	for r in sim.neighbors(x,y,1,1) do
		local typ = sim.partProperty(r, sim.FIELD_TYPE)
		local lif = sim.partProperty(r, sim.FIELD_LIFE)
		if typ == elem.DEFAULT_PT_SPRK and lif == 3 then
			local note_no = decode_note_no(sim.partProperty(i, sim.FIELD_TEMP)) --0~127
			local tmp = sim.partProperty(i, sim.FIELD_TMP) -- tmp has 4 bytes so can reuse it
			--tmp 0x11223344
			--->velocity=0x11
			--->gate=0x2233
			--->instrument=0x44
			local velocity, gatemsb, gatelsb,instrument = unpack_tmp_bytes(tmp)
			make_sound({note_no,velocity,gatemsb,gatelsb,instrument})
			--sim.partProperty(i,sim.FIELD_LIFE,10)
			return
		elseif typ == elem.DEFAULT_PT_BRAY and lif == 29 then
			local ctyp = sim.partProperty(r, sim.FIELD_CTYPE)
			local velocity, note_no, gatelsb,instrument = unpack_tmp_bytes(ctyp)
			--BRAY's ctype 0x11223344
			--->velocity=0x11
			--->note=0x22
			--->gate=2*0x33
			--->instrument=0x44
			gatelsb = gatelsb*2
			local gatemsb = bit.band(bit.rshift(gatelsb,8),0xFF)
			make_sound({note_no,velocity,gatemsb,gatelsb,instrument})
			return
		end
	end
end
elem.property(midi,"Update", update)

local function check_is_midi_element(x,y)
	if x > 612 or y > 384 then
		return false, nil
	end
	local x,y = sim.adjustCoords(x,y)
	local index = sim.partID(x, y)
	if index == nil then
		return false, nil
	end
	if sim.partProperty(index,sim.FIELD_TYPE) ~= midi then
		return false, index
	end
	return true, index
end

local function get_part_midi_props(index)
	local note_no = decode_note_no(sim.partProperty(index, sim.FIELD_TEMP))
	local tmp = sim.partProperty(index,sim.FIELD_TMP)
	local velocity, gate, instrument = unpack_tmp(tmp)
	return regulate_props(note_no,velocity,gate,instrument)
end

local function set_part_midi_props(index,note_no,velocity,gate,instrument)
	local note_no,velocity,gate,instrument = regulate_props(note_no,velocity,gate,instrument)
	sim.partProperty(index, sim.FIELD_TEMP,note_no*10+273.15+5)
	local tmp = pack_tmp(velocity, gate, instrument)
	sim.partProperty(index,sim.FIELD_TMP,tmp)
end

local aimed_prop = 1
local global_props = {60,100,50,0}
local mousewheel_cooldown = 0 -- make it faster when quickly rolling wheel
local MAX_WHEEL_CD = 3

local function step_hud_display()
	if tpt.selectedl ~= midi_id or tpt.hud() == 0 then
		return
	end
	local x = tpt.mousex
	local y = tpt.mousey
	local _, index = check_is_midi_element(x,y)
	if not _ then
		mousewheel_cooldown = 0
		return
	end
	local note_no,velocity,gate,instrument = get_part_midi_props(index)
	if mousewheel_cooldown > 0 then
		mousewheel_cooldown = mousewheel_cooldown - 1
	end
	
	local notice = "[MIDI] "..(aimed_prop==1 and "*" or "").."Key: "..NOTE_NAME[note_no+1]..", "..(aimed_prop==2 and "*" or "").."Vel: "..velocity..", "..(aimed_prop==3 and "*" or "").."Gate: "..(gate/100).."s, "..(aimed_prop==4 and "*" or "").."Inst: "..instrument.."."
	local backwidth = tpt.textwidth(notice)+8
	local rx
	if x>612-backwidth then
		rx = x - backwidth
	else
		rx = x
	end
	graphics.fillRect(rx, y, backwidth, 12, 0, 0, 0, 128)
	graphics.drawText(rx+3, y+3, notice, 179, 157, 132, 255)
end
evt.register(evt.tick,step_hud_display)

local function mousewheel(x, y, d)
	if tpt.selectedl ~= midi_id then
		return
	end
	local _, index = check_is_midi_element(x,y)
	if not _ then
		return
	end
	d = d*(mousewheel_cooldown+1) -- make it faster when quickly rolling wheel
	mousewheel_cooldown = MAX_WHEEL_CD
	local props = {get_part_midi_props(index)}
	props[aimed_prop] = props[aimed_prop]+d
	if props[4] < 0 then -- to make accessing drum pseudo-instrument easier
		props[4] = 128
	elseif props[4] > 128 then
		props[4] = 0
	end
	set_part_midi_props(index,unpack(props))
	if sock then
		props = {regulate_props(unpack(props))}
		note_no = table.remove(props,1)
		props = {note_no,unpack_tmp_bytes(pack_tmp(unpack(props)))}
		make_sound(props)
	end
	return false
end
evt.register(evt.mousewheel,mousewheel)

local function mousedown(x,y,button) --left click=select aimed,middle click->copy props
	if tpt.selectedl ~= midi_id then
		return
	end
	local _, index = check_is_midi_element(x,y)
	if not _ then
		return
	end
	if button == 1 then
		aimed_prop = aimed_prop +1
		if aimed_prop > 4 then
			aimed_prop = 1
		end
	elseif button == 2 then
		global_props = {get_part_midi_props(index)}
	end
end
evt.register(evt.mousedown,mousedown)

local function gfx(index, colr, colg, colb) -- used to initialize midi particles
	local tmp2 = sim.partProperty(index,sim.FIELD_TMP2)
	if tmp2 == 0 then
		set_part_midi_props(index,unpack(global_props))
		sim.partProperty(index,sim.FIELD_TMP2,1)
	end
end
elem.property(midi,"Graphics", gfx)

-- globals
local name_to_props_table = {["key"]=1,["velocity"]=2,["gate"]=3,["instrument"]=4}
function set_all_midi_props(prop_type, value, modifier)
	if prop_type == nil or value == nil then
		print("arguments: (prop_type, value, [modifier=false]),prop_type=('key'|'velocity'|'gate'|'instrument')")
		return
	end
	if modifier == nil then
		modifier = false
	end
	local prop_to_modify_number = name_to_props_table[prop_type]
	if prop_to_modify_number == nil then
		print("invalid property type")
		return
	end
	for index in sim.parts() do
		if sim.partProperty(index,sim.FIELD_TYPE) == midi then
			local props = {get_part_midi_props(index)}
			if not modifier then
				props[prop_to_modify_number] = value
			else
				props[prop_to_modify_number] = props[prop_to_modify_number]+value
			end
			set_part_midi_props(index,unpack(props))
		end
	end
end