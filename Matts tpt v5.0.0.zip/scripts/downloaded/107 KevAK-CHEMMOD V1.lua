
---Made by: KevAK---
---CHEMMOD V1 Made in December, 2016.---
---This code will have errors, i´m new in this things (Please forgive me xD)---

---------------------------------GRAFITO---------------------------------------

local graphite = elem.allocate("KEV", "Grph")
elem.element(graphite, elem.element(elem.DEFAULT_PT_IRON))
elem.property(graphite, "Name", "GRPH")
elem.property(graphite, "Description", "Graphite. Absorbs neutrons and photons.")
elem.property(graphite, "Color", 0x1E1B1B)
elem.property(graphite, "Flammable", 5)
elem.property(graphite, "Properties", elem.TYPE_PART)
elem.property(graphite, "Weight", 20)
elem.property(graphite, "Meltable",1)

local function grafUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_OXYG then
			sim.partChangeType(r, elem.DEFAULT_PT_CO2)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partProperty(r, "type", carbono)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_OXYG then
			sim.partProperty(r, "type", carbono)
			sim.partProperty(i, "type", elem.DEFAULT_PT_CO2)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PROT then
			sim.partProperty(r, "type", C14)
			sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PHOT then
			sim.partKill(r)
		end
	end
end
elem.property(graphite, "Update", grafUpdate)

-------------------------GRAFITO DERRETIDO------------------------------------

local moltgraphite = elem.allocate("KEV", "Mgrp")
elem.element(moltgraphite, elem.element(elem.DEFAULT_PT_LAVA))
elem.property(moltgraphite, "Name", "MGRP")
elem.property(moltgraphite, "Description", "Molten Graphite. Hidden! Shh!.")
elem.property(moltgraphite, "Color", 0xF9E354)
elem.property(moltgraphite, "Flammable", 0)
elem.property(moltgraphite, "Properties", elem.TYPE_PART)
elem.property(moltgraphite, "Weight", 20)
elem.property(moltgraphite, "MenuVisible", 0)
elements.property(moltgraphite, "LowTemperatureTransition", graphite)
elements.property(moltgraphite, "LowTemperature", 4817.15)

local function molgrafUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_OXYG then
			sim.partChangeType(r, elem.DEFAULT_PT_CO2)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partProperty(i, "type", elem.DEFAULT_PT_PLSM)
		end
	end
end
elem.property(moltgraphite, "Update", molgrafUpdate)

------------------------CARBONO 14 (IN DEVELOPMENT*)---------------------------------------

local carbono14 = elem.allocate("KEV", "C14")
elem.element(carbono14, elem.element(elem.DEFAULT_PT_BCOL))
elem.property(carbono14, "Name", "C14")
elem.property(carbono14, "Description", "Carbono 14. Buggy! In development! Highly radioactive, explodes in contact with neutrons.")
elem.property(carbono14, "Color", 0x636E6E)
elem.property(carbono14, "Flammable", 2)
elem.property(carbono14, "Properties", elem.TYPE_PART)
elem.property(carbono14, "Weight", 90)
elem.property(carbono14, "Meltable",1)
elem.property(moltgraphite, "MenuVisible", 0)

local function carb14Update(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
			sim.partChangeType(i, elem.DEFAULT_PT_PROT)
			sim.partProperty(i, "temp", 400)
			sim.partChangeType(r, elem.DEFAULT_PT_CO2)
		end
	end
end
elem.property(carbono14, "Update", carb14Update)

-------------------------TIERRA--------------------------------------------------------------------------------------------------------------

local dirt = elem.allocate("KEV", "DIRT")
elem.element(dirt, elem.element(elem.DEFAULT_PT_STNE))
elem.property(dirt, "Name", "DIRT")
elem.property(dirt, "Description", "Dirt. Mother of life.")
elem.property(dirt, "Color", 0x6D4D16)
elem.property(dirt, "Flammable", 0)
elem.property(dirt, "Explosive", 0)
elem.property(dirt, "Properties", elem.TYPE_PART)
elem.property(dirt, "Weight", 40)

local function drtUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partChangeType(r, elem.DEFAULT_PT_STNE)
			sim.partChangeType(i, elem.DEFAULT_PT_WTRV)
		end
	end
end

elem.property(dirt, "Update", drtUpdate)

-------------------------FULMINATO DE MERCURIO--------------------------------------------------------------------------------------------------------------

local hgcno = elem.allocate("KEV", "HgNO")
elem.element(hgcno, elem.element(elem.DEFAULT_PT_BCOL))
elem.property(hgcno, "Name", "HgNO")
elem.property(hgcno, "Description", "Mercury Fulminate. Highly Explosive and Flammable.")
elem.property(hgcno, "Color", 0xF8F4E0)
elem.property(hgcno, "Flammable", 650000000)
elem.property(hgcno, "Explosive", 100000000)
elem.property(hgcno, "Properties", elem.TYPE_PART)
elem.property(hgcno, "Weight", 80)

local function mercfulUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partKill(r)
			sim.partChangeType(i, elem.DEFAULT_PT_PLSM)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
			sim.partcreate( elem.DEFAULT_PT_AIR)
		end
		if sim.partProperty(r, "type") == sulfacid then
			sim.partKill(r)
			sim.partProperty(i, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == hno then
			sim.partKill(r)
			sim.partProperty(i, "type", elem.DEFAULT_PT_FIRE)
		end

	end
end

elem.property(hgcno, "Update", mercfulUpdate)

--------------CEMENT---------------------------------------------------------

local cement = elem.allocate("KEV", "CMNT")
elem.element(cement, elem.element(elem.DEFAULT_PT_BCOL))
elem.property(cement, "Name", "CMNT")
elem.property(cement, "Description", "Cement. Strong. Mix with water to have BRCK.")
elem.property(cement, "Color", 0xD9D9D9)
elem.property(cement, "Flammable", 0)
elem.property(cement, "Explosive", 0)
elem.property(cement, "Properties", elem.TYPE_PART)
elem.property(cement, "Weight", 30)

local function cmntUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
			sim.partProperty(i, "type", elem.DEFAULT_PT_BRCK)
			sim.partProperty(r, "type", elem.DEFAULT_PT_PSTE)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_CNCT then
			sim.partProperty(i, "type", elem.DEFAULT_PT_PSTE)
			sim.partProperty(r, "type", cement)
		end

	end
end

elem.property(cement, "Update", cmntUpdate)
-------------POTASIO-------------------------------------------------------

local pot = elem.allocate("KEV", "K")
elem.element(pot, elem.element(elem.DEFAULT_PT_BCOL))
elem.property(pot, "Name", "K")
elem.property(pot, "Description", "Potasium. Explosive and very reactive.")
elem.property(pot, "Color", 0xF0F8FF)
elem.property(pot, "Flammable", 15)
elem.property(pot, "Explosive", 30000)
elem.property(pot, "Properties", elem.TYPE_PART)
elem.property(pot, "Weight", 30)

local function kUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == nitg then
			sim.partKill(r)
			sim.partProperty(i, "type", nitrpot)
		end
		if sim.partProperty(r, "type") == sulf then
			sim.partKill(r)
			sim.partProperty(i, "type", sulfpot)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == carb then
			sim.partKill(r)
			sim.partProperty(i, "type", carbpot)
		end
	end
end

elem.property(pot, "Update", kUpdate)

-----------------------------SODIO--------------------------------------------

local sod = elem.allocate("KEV", "NA")
elem.element(sod, elem.element(elem.DEFAULT_PT_BMTL))
elem.property(sod, "Name", "NA")
elem.property(sod, "Description", "Sodium. Explosive and conductive.")
elem.property(sod, "Color", 0xF0F8FF)
elem.property(sod, "Flammable", 15000)
elem.property(sod, "Explosive", 30000)
elem.property(sod, "Properties", elem.TYPE_SOLID)

local function naUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == nitg then
			sim.partKill(r)
			sim.partProperty(i, "type", nitrsod)
		end
		if sim.partProperty(r, "type") == sulf then
			sim.partKill(r)
			sim.partProperty(i, "type", sulfsod)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_PLSM)
		end
		if sim.partProperty(r, "type") == carb then
			sim.partKill(r)
			sim.partProperty(i, "type", carbpot)
		end
		if sim.partProperty(r, "type") == hydrox then
			sim.partProperty(i, "type", hydroxsod)
			sim.partProperty(r, "type", elem.DEFAUL_PT_WTRV)
		end
	end
end

elem.property(sod, "Update", naUpdate)

-----------------------------CLORO--------------------------------------------

local clor = elem.allocate("KEV", "CL")
elem.element(clor, elem.element(elem.DEFAULT_PT_CAUS))
elem.property(clor, "Name", "CL")
elem.property(clor, "Description", "Chlorine. Toxic and corrosive.")
elem.property(clor, "Color", 0xA0FA9B)
elem.property(clor, "Flammable", 0)
elem.property(clor, "Explosive", 0)
elem.property(clor, "Properties", elem.TYPE_GAS)
elem.property(clor, "Weight", 30)

local function clUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == nitg then
			sim.partKill(r)
			sim.partProperty(i, "type", nitrclor)
		end
		if sim.partProperty(r, "type") == sulf then
			sim.partKill(r)
			sim.partProperty(i, "type", sulfclor)
		end
		if sim.partProperty(r, "type") == sod then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_SALT)
		end
		if sim.partProperty(r, "type") == pot then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_BRMT)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == carb then
			sim.partKill(r)
			sim.partProperty(i, "type", carbclor)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_IRON then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_BMTL then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_METL then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WOOD then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PLNT then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WAX then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_GOO then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_TTAN then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_GOLD then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FILT then
			sim.partKill(r)
			sim.partKill(i)
		end
	end
end

elem.property(clor, "Update", clUpdate)

-----------------------------HIDROXILO--------------------------------------------

local hydrox = elem.allocate("KEV", "HYDX")
elem.element(hydrox, elem.element(elem.DEFAULT_PT_SOAP))
elem.property(hydrox, "Name", "HYDX")
elem.property(hydrox, "Description", "Hydroxil. Functional Group.")
elem.property(hydrox, "Color", 0xFFFFF)
elem.property(hydrox, "Flammable", 0)
elem.property(hydrox, "Explosive", 0)
elem.property(hydrox, "Properties", elem.TYPE_LIQUID)
elem.property(hydrox, "Weight", 1)

local function ohUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
			sim.partProperty(i, "type", elem.DEFAULT_PT_OXYG)
			sim.partProperty(r, "type", elem.DEFAUL_PT_HYGN)
		end
	end
end

elem.property(hydrox, "Update", ohUpdate)

----------------------HIDROXIDO DE SODIO----------------------------------------

local hydroxsod = elem.allocate("KEV", "NAOH")
elem.element(hydroxsod, elem.element(elem.DEFAULT_PT_ACID))
elem.property(hydroxsod, "Name", "NAOH")
elem.property(hydroxsod, "Description", "Sodium Hidroxyde, Neutralizes acid ,flammable and corrosive.")
elem.property(hydroxsod, "Color", 0xF5F5F5)
elem.property(hydroxsod, "Flammable", 65)
elem.property(hydroxsod, "Explosive", 5)
elem.property(hydroxsod, "Properties", elem.TYPE_LIQUID+elem.PROP_DEADLY)
elem.property(hydroxsod, "Weight", 29)

local function naohUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_ACID then
			sim.partType(r, elem.DEFAULT_PT_WTRV)
			sim.partType(i,elem.DEFAULT_PT_SALT)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_BMTL then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_METL then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WOOD then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PLNT then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WAX then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_GOO then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FILT then
			sim.partKill(r)
			sim.partKill(i)
		end

	end
end

elem.property(hydroxsod, "Update", naohUpdate)

---------------------GRUPO NITROGENO-------------------------------------------

local nitg = elem.allocate("KEV", "N")
elem.element(nitg, elem.element(elem.DEFAULT_PT_GAS))
elem.property(nitg, "Name", "N")
elem.property(nitg, "Description", "Nitrogen. Basic element to life.")
elem.property(nitg, "Color", 0x0F8FF)
elem.property(nitg, "Flammable", 0)
elem.property(nitg, "Explosive", 0)
elem.property(nitg, "Properties", elem.TYPE_GAS)
elem.property(nitg, "Weight", 1)
elem.property(nitg, "Diffusion", 10)

local function nUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_OXYGEN then
			sim.partKill(r)
			sim.partProperty(i, "type", nitroxid)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_HYGN then
			sim.partKill(r)
			sim.partProperty(i, "type", nitracid)
		end
		if sim.partProperty(r, "type") == pot then
			sim.partKill(r)
			sim.partProperty(i, "type", nitrpot)
		end
		if sim.partProperty(r, "type") == sod then
			sim.partKill(r)
			sim.partProperty(i, "type", nitrsod)
		end
	end
end

elem.property(pot, "Update", kUpdate)

--------------------OXIDO DE NITROGENO------------------------------------------------------------------------------

local nitroxid = elem.allocate("KEV", "N2O")
elem.element(nitroxid, elem.element(elem.DEFAULT_PT_GAS))
elem.property(nitroxid, "Name", "N2O")
elem.property(nitroxid, "Description", "Nitrogen Oxide. Very Explosive.")
elem.property(nitroxid, "Color", 0x0F8FF)
elem.property(nitroxid, "Flammable", 10000)
elem.property(nitroxid, "Explosive", 6000)
elem.property(nitroxid, "Properties", elem.TYPE_GAS)
elem.property(nitroxid, "Weight", 5)
elem.property(nitroxid, "Diffusion", 5)

local function n2oUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partKill(r)
			sim.partProperty(i, "type", elem.DEFAULT_PT_PLSM)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_HYGN then
			sim.partKill(r)
			sim.partProperty(i, "type", nitracid)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
			sim.partProperty(i, "type", nitracid)
			sim.partProperty(r, "type", elem.DEFAULT_PT_OXYG)
		end
	end
end

elem.property(nitroxid, "Update", n2oUpdate)

-------------------ACIDO NITRICO----------------------------------------------------------

local nitracid = elem.allocate("KEV", "HNO3")
elem.element(nitracid, elem.element(elem.DEFAULT_PT_ACID))
elem.property(nitracid, "Name", "HNO3")
elem.property(nitracid, "Description", "Nitric Acid. Explosive Precursor.")
elem.property(nitracid, "Color", 0xF0E68C)
elem.property(nitracid, "Flammable", 250)
elem.property(nitracid, "Explosive", 5)
elem.property(nitracid, "Properties", elem.TYPE_LIQUID)
elem.property(nitracid, "Weight", 10)
elem.property(nitracid, "Diffusion", 0)

local function hno3Update(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_OIL then
			sim.partProperty(i, "type", elem.DEFAULT_PT_NITR)
			sim.partProperty(r, "type", elem.DEFAULT_PT_TNT)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_GUN then
			sim.partKill(i)
			sim.partProperty(r, "type", blackgun)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_BRMT then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_THRM)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_BCOL then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_GUN)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_IRON then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_BMTL then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_METL then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WOOD then
			sim.partKill(r)
			sim.partProperty(i, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PLNT then
			sim.partKill(r)
			sim.partProperty(i, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WAX then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_GOO then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
			sim.partKill(r)
			sim.partKill(i)
		end
	end
end

elem.property(nitracid, "Update", hno3Update)

----------------------------------- NITRATO DE POTASIO----------------------

local nitrpot = elem.allocate("KEV", "KNO3")
elem.element(nitrpot, elem.element(elem.DEFAULT_PT_BCOL))
elem.property(nitrpot, "Name", "KNO3")
elem.property(nitrpot, "Description", "Potassium Nitrate. Deflagrant Explosive.")
elem.property(nitrpot, "Color", 0x15F5DB)
elem.property(nitrpot, "Flammable", 9.9)
elem.property(nitrpot, "Explosive", 600)
elem.property(nitrpot, "Properties", elem.TYPE_PART)
elem.property(nitrpot, "Weight", 15)
elem.property(nitrpot, "Diffusion", 0)

local function kno3Update(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_OXYG then
			sim.partChangeType(r, nitroxid)
			sim.partChangeType(i, pot)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_HYGN then
			sim.partProperty(r, "type", nitracid)
			sim.partProperty(i, "type", pot)
		end
		if sim.partProperty(r, "type") == sulfacid then
			sim.partKill(i)
			sim.partProperty(r, "type", blackgun)
		end
		if sim.partProperty(r, "type") == dirt then
			sim.partKill(r)
			sim.partProperty(i, "type", elem.DEFAULT_PT_PLNT)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partProperty(i, "type", nitg)
			sim.partProperty(r, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == sulf then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_GUN)
		end
	end
end

elem.property(nitrpot, "Update", kno3Update)

---------------------------------NITRATO DE SODIO-----------------------------------

local nitrsod = elem.allocate("KEV", "NANO3")
elem.element(nitrsod, elem.element(elem.DEFAULT_PT_BCOL))
elem.property(nitrsod, "Name", "NANO")
elem.property(nitrsod, "Description", "Sodium Nitrate. Explosive and Cement Precursor.")
elem.property(nitrsod, "Color", 0xFFFFFF)
elem.property(nitrsod, "Flammable", 50)
elem.property(nitrsod, "Explosive", 200)
elem.property(nitrsod, "Properties", elem.TYPE_PART)
elem.property(nitrsod, "Weight", 1)

local function nano3Update(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == sulfacid then
			sim.partProperty(i, "type", elem.DEFAULT_PT_GUN)
			sim.partProperty(r, "type", sod)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_CNCT then
			sim.partProperty(i, "type", elem.DEFAULT_PT_PSTE)
			sim.partProperty(r, "type", cement)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partProperty(i, "type", elem.DEFAULT_PT_FIRE)
			sim.partProperty(r, "type", elem.DEFAULT_PT_PLSM)
		end
	end
end

elem.property(nitrsod, "Update", nano3Update)

------------GRUPO DEL AZUFRE----------------------------------------------------

local sulfur = elem.allocate("KEV", "S")
elem.element(sulfur, elem.element(elem.DEFAULT_PT_BCOL))
elem.property(sulfur, "Name", "S")
elem.property(sulfur, "Description", "Sulphur. Smells bad.")
elem.property(sulfur, "Color", 0xE6FF1D)
elem.property(sulfur, "Flammable", 600)
elem.property(sulfur, "Explosive", 1600)
elem.property(sulfur, "Properties", elem.TYPE_PART)
elem.property(sulfur, "Weight", 12.5)
elem.property(sulfur, "Diffusion", 0)

local function sUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_OXYGEN then
			sim.partKill(r)
			sim.partProperty(i, "type", sulfoxid)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_HYGN then
			sim.partProperty(r, "type", sulfacid)
			sim.partProperty(i, "type", pot)
		end
		if sim.partProperty(r, "type") == pot then
			sim.partKill(i)
			sim.partProperty(r, "type", sulfpot)
		end
		if sim.partProperty(r, "type") == sod then
			sim.partKill(r)
			sim.partProperty(i, "type", sulfsod)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_IRON then
			sim.partProperty(r, "type", sulfiron)
			sim.partProperty(r, "type", elem.DEFAULT_PT_BRMT)
		end
		if sim.partProperty(r, "type") == sulf then
			sim.partKill(i)
			sim.partProperty(r, "type", elem.DEFAULT_PT_GUN)
		end
	end
end

elem.property(sulfur, "Update", sUpdate)

--------------------OXIDO DE AZUFRE--------------------------------------

local sulfoxid = elem.allocate("KEV", "S2O")
elem.element(sulfoxid, elem.element(elem.DEFAULT_PT_WTRV))
elem.property(sulfoxid, "Name", "S2O")
elem.property(sulfoxid, "Description", "Sulphur Oxide. Very Explosive and toxic.")
elem.property(sulfoxid, "Color", 0xFA8073)
elem.property(sulfoxid, "Flammable", 10550)
elem.property(sulfoxid, "Explosive", 1900)
elem.property(sulfoxid, "Properties", elem.TYPE_GAS)
elem.property(sulfoxid, "Weight", 7.5)
elem.property(sulfoxid, "Diffusion", 6)

local function s2oUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
			sim.partKill(i)
			sim.partProperty(r, "type", sulfacid)
		end
	end
end

elem.property(sulfoxid, "Update", s2oUpdate)

-----------ACIDO SULFURICO-------------------------------------------------------------

local sulfacid = elem.allocate("KEV", "H2SO4")
elem.element(sulfacid, elem.element(elem.DEFAULT_PT_ACID))
elem.property(sulfacid, "Name", "H2SO4")
elem.property(sulfacid, "Description", "Sulfuric Acid. Corrodes all, explosive presursor.")
elem.property(sulfacid, "Color", 0xFFE4E1)
elem.property(sulfacid, "Flammable", 250)
elem.property(sulfacid, "Explosive", 50)
elem.property(sulfacid, "Properties", elem.TYPE_LIQUID)
elem.property(sulfacid, "Weight", 10)
elem.property(sulfacid, "Diffusion", 0)

local function h2so4Update(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == hydroxsod then
			sim.partProperty(r, "type", sulfpot)
			sim.partProperty(i, "type", elem.DEFAULT_PT_WATR)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partProperty(i, "type", sulfoxid)
			sim.partProperty(r, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_IRON then
			sim.partKill(i)
			sim.partProperty(r, "type", sulfoxid)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_BMTL then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_METL then
			sim.partKill(i)
			sim.partKill(r)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WOOD then
			sim.partKill(r)
			sim.partProperty(i, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PLNT then
			sim.partKill(r)
			sim.partProperty(i, "type", elem.DEFAULT_PT_FIRE)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_WAX then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_GOO then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_BCOL then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_TTAN then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_GOLD then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_SHLD then
			sim.partKill(r)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_QRTZ then
			sim.partKill(r)
			sim.partKill(i)
		end
	end
end

elem.property(sulfacid, "Update", h2so4Update)

-------------------VAPOR DE ACIDO SULFURICO-----------------------------

local sulfacidv = elem.allocate("KEV", "H2SO4v")
elem.element(sulfacidv, elem.element(clor))
elem.property(sulfacidv, "Name", "H2SO4v")
elem.property(sulfacidv, "Description", "Sulfuric Acid Vapor. Corrodes all, Condenses into Sulfuric Acid.")
elem.property(sulfacidv, "Color", 0xFFE4E1)
elem.property(sulfacidv, "Flammable", 250)
elem.property(sulfacidv, "Explosive", 50)
elem.property(sulfacidv, "Properties", elem.TYPE_GAS)
elem.property(sulfacidv, "Weight", 10)
elem.property(sulfacidv, "Diffusion", 0)

local function h2so4vUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == hydroxsod then
			sim.partProperty(r, "type", sulfpot)
			sim.partProperty(i, "type", elem.DEFAULT_PT_WATR)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partProperty(i, "type", sulfoxid)
			sim.partProperty(r, "type", elem.DEFAULT_PT_FIRE)
		end
	end
end

elem.property(sulfacidv, "Update", h2so4VUpdate)

------------------SULFATO DE POTASIO-----------------------------------

local sulfpot = elem.allocate("KEV", "KSO3")
elem.element(sulfpot, elem.element(elem.DEFAULT_PT_BCOL))
elem.property(sulfpot, "Name", "KSO3")
elem.property(sulfpot, "Description", "Potassium Sulfate. Fertilizant.")
elem.property(sulfpot, "Color", 0xD2F6F8)
elem.property(sulfpot, "Flammable", 9.9)
elem.property(sulfpot, "Explosive", 600)
elem.property(sulfpot, "Properties", elem.TYPE_PART)
elem.property(sulfpot, "Weight", 15)
elem.property(sulfpot, "Diffusion", 0)

local function kso3Update(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_SAND then
			sim.partChangeType(r, dirt)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == dirt then
			sim.partProperty(i, "type", elem.DEFAULT_PT_PLNT)
			sim.partProperty(r, "type")
		end
	end
end

elem.property(sulfpot, "Update", kso3Update)

------------------------SULFATO DE SODIO-------------------

local sulfsod = elem.allocate("KEV", "NA2SO4")
elem.element(sulfsod, elem.element(elem.DEFAULT_PT_BCOL))
elem.property(sulfsod, "Name", "NASO4")
elem.property(sulfsod, "Description", "Sodium Sulfate. Glass precursor.")
elem.property(sulfsod, "Color", 0xCAD792)
elem.property(sulfsod, "Flammable", 9.9)
elem.property(sulfsod, "Explosive", 600)
elem.property(sulfsod, "Properties", elem.TYPE_PART)
elem.property(sulfsod, "Weight", 15)
elem.property(sulfsod, "Diffusion", 0)

local function na2so4Update(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_SAND then
			sim.partChangeType(r, elem.DEFAULT_PT_BGLA)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPNG then
			sim.partProperty(i, "type", elem.DEFAULT_PT_GEL)
			sim.partProperty(r, "type")
		end
	end
end

elem.property(sulfsod, "Update", na2so4Update)

-----------------GRUPO DEL CARBONO------------------------------------------------------------------------------

local carbono = elem.allocate("KEV", "C")
elem.element(carbono, elem.element(elem.DEFAULT_PT_BMTL))
elem.property(carbono, "Name", "C")
elem.property(carbono, "Description", "Carbono. Highly reactive and Flammable.")
elem.property(carbono, "Color", 0x302525)
elem.property(carbono, "Flammable", 10)
elem.property(carbono, "Properties", elem.TYPE_PART)
elem.property(carbono, "Weight", 60)
elements.property(carbono, "HighTemperature", 4817.15)
elements.property(carbono, "HighTemperatureTransition", moltgraphite)

local function carbUpdate(i, x, y, s, nt)
	r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
	if r~= nil then
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_HYGN then
			sim.partChangeType(r, elem.DEFAULT_PT_GAS)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_OXYG then
			sim.partChangeType(r, elem.DEFAULT_PT_CO2)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == elem.DEFAULT_PT_FIRE then
			sim.partProperty(r, "type", graphite)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == sulfacid then
			sim.partChangeType(r, elem.DEFAULT_PT_BUBW)
			sim.partKill(i)
		end
		if sim.partProperty(r, "type") == hno3 then
			sim.partChangeType(r, elem.DEFAULT_PT_BUBW)
			sim.partChangeType(i, kno)
		end
		if sim.partProperty(r, "type") == pot then
			sim.partChangeType(r, carbpot)
			sim.partKill(i, "type")
		end

	end
end

elem.property(carbono, "Update", carbUpdate)