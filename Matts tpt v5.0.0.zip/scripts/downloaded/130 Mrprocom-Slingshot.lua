
-- Pre-define the variables that will be used in the update function to set the properties of the projectile after collision
local collType, collCtype, collTemp, collLife, collTmp, collTmp2

-- Graphics function of SHOT. Should be invisible, it's only used to specify power and direction to shoot PROJ
local function shotG(i, colr, colg, colb)
  return 1, ren.PMODE_NONE, 0, 0, 0, 0
end

-- Graphics function of PROJ
local function projG(i, colr, colg, colb)
  return 0, ren.PMODE_FLAT + ren.FIRE_BLEND + ren.PMODE_SPARK, 255, 226, 29, 36, 255, 226, 29, 36
end

-- Update function of PROJ
local function projU(i, x, y, s, nt)
  -- Tmp stores the time in game frames since the projectile was launched
  -- pavg0 and pavg1 store the initial vx and vy values, those (along with tmp) are used to calculate the next vx and vy
  sim.partProperty(i, sim.FIELD_TMP, sim.partProperty(i, sim.FIELD_TMP) + 1)
  sim.partProperty(i, sim.FIELD_VX, sim.partProperty(i, sim.FIELD_PAVG0))
  sim.partProperty(i, sim.FIELD_VY, sim.partProperty(i, sim.FIELD_PAVG1) + 0.167 * sim.partProperty(i, sim.FIELD_TMP))
  -- This part checks for future collisions for the next frame only, if there is a collesion, change vx and vy
  local nextd = math.sqrt(sim.partProperty(i, sim.FIELD_VX)^2 + sim.partProperty(i, sim.FIELD_VY)^2)
  for j = 0, 1, 1 / nextd do
    local nextx = x + sim.partProperty(i, sim.FIELD_VX) * j
    local nexty = y + sim.partProperty(i, sim.FIELD_VY) * j
    for r in sim.neighbors(nextx, nexty, 1, 1) do
      -- If a projectile is colliding with another, don't count it as a collision
      if sim.partProperty(r, sim.FIELD_TYPE) ~= sim.partProperty(i, sim.FIELD_TYPE) then
        sim.partProperty(i, sim.FIELD_VX, nextx - x)
        sim.partProperty(i, sim.FIELD_VY, nexty - y)
        break
      end
    end
  end
  -- On impact, convert the projectile to the particle specified by the user in the UI
  for r in sim.neighbors(x, y, 1, 1) do
    if sim.partProperty(r, sim.FIELD_TYPE) ~= sim.partProperty(i, sim.FIELD_TYPE) then
      sim.partChangeType(i, collType)
      sim.partProperty(i, sim.FIELD_CTYPE, collCtype)
      sim.partProperty(i, sim.FIELD_TEMP, collTemp)
      sim.partProperty(i, sim.FIELD_LIFE, collLife)
      sim.partProperty(i, sim.FIELD_TMP, collTmp)
      sim.partProperty(i, sim.FIELD_TMP2, collTmp2)
      break
    end
  end
end

-- Define SHOT (used to specify power and direction) and PROJ (hidden, the projectile that gets launched)
local shot = elem.allocate("PROCOM", "SHOT")
elem.element(shot, elem.element(elem.DEFAULT_PT_DMND))
elem.property(shot, "Name", "SHOT")
elem.property(shot, "Description", "Slingshot. You can specify what it turns into on impact. Drag to control power and direction. Release to launch.")
elem.property(shot, "Color", 0xFFE21D24)
elem.property(shot, "Properties", elem.PROP_LIFE_KILL + elem.PROP_NOCTYPEDRAW)
elem.property(shot, "Graphics", shotG)

local proj = elem.allocate("PROCOM", "PROJ")
elem.element(proj, elem.element(elem.DEFAULT_PT_PHOT))
elem.property(proj, "Name", "PROJ")
elem.property(proj, "Description", "Projectile. Launch it using SHOT.")
elem.property(proj, "Color", 0xFFE21D24)
elem.property(proj, "MenuVisible", 0)
elem.property(proj, "Temperature", sim.R_TEMP + 273.15)
elem.property(proj, "Update", projU)
elem.property(proj, "Graphics", projG)

local shotIdent = elem.property(shot, "Identifier")
local holding = false
local zooming = false
local selectedl = tpt.selectedl
local selectedr = tpt.selectedr
local selecteda = tpt.selecteda
local elemSelector, inputType, inputCtype, inputTemp, inputLife, inputTmp, inputTmp2
local x1, y1, x2, y2

-- This function is called when the Done button is clicked and it checks if all values the users entered are valid
-- If they are, update coll variables. If not, show an error message.
local function validate(sender)
  local inpType = inputType:text()
  local inpCtype = inputCtype:text()
  local inpTemp = inputTemp:text()
  local inpLife = inputLife:text()
  local inpTmp = inputTmp:text()
  local inpTmp2 = inputTmp2:text()
  local unit = "k"
  -- Validate Type
  if pcall(function() tpt.element(inpType) end) then
    inpType = tpt.element(inpType)
  else
    tpt.throw_error("Invalid Type value.")
    return
  end
  -- Validate Ctype
  if pcall(function() tpt.element(inpCtype) end) then
    inpCtype = tpt.element(inpCtype)
  else
    tpt.throw_error("Invalid Ctype value.")
    return
  end
  -- Validate Temp (see what the unit is first, then remove it from inpTemp)
  if inpTemp:sub(-1):lower() == "c" then
    unit = "c"
    inpTemp = tonumber(inpTemp:sub(1, -2))
  elseif inpTemp:sub(-1):lower() == "f" then
    unit = "f"
    inpTemp = tonumber(inpTemp:sub(1, -2))
  elseif inpTemp:sub(-1):lower() == "k" then
    unit = "k"
    inpTemp = tonumber(inpTemp:sub(1, -2))
  end
  if inpTemp then
    if unit == "c" then
      inpTemp = inpTemp + 273.15
    elseif unit == "f" then
      inpTemp = (inpTemp + 459.67) * 5 / 9
    end
  else
    tpt.throw_error("Invalid Temp value.")
    return
  end
  -- Validate Life
  if not tonumber(inpLife) or tonumber(inpLife) < 0 then
    tpt.throw_error("Invalid Life value.")
    return
  end
  -- Validate Tmp
  if not tonumber(inpTmp) or tonumber(inpTmp) < 0 then
    tpt.throw_error("Invalid Tmp value.")
    return
  end
  -- Validate Tmp2
  if not tonumber(inpTmp2) or tonumber(inpTmp2) < 0 then
    tpt.throw_error("Invalid Tmp2 value.")
    return
  end
  -- If all values are valid, update all coll variables
  collType = inpType
  collCtype = inpCtype
  collTemp = inpTemp
  collLife = tonumber(inpLife)
  collTmp = tonumber(inpTmp)
  collTmp2 = tonumber(inpTmp2)
  interface.closeWindow(elemSelector)
end

-- This part creates a UI window that shows up when SHOT is selected
elemSelector = Window:new(-1, -1, 200, 176)
local labelTitle = Label:new(100, 5, 0, 16, "Particle after collision")
local labelType = Label:new(25, 27, 0, 16, "Type:")
local labelCtype = Label:new(23, 48, 0, 16, "Ctype:")
local labelTemp = Label:new(25, 69, 0, 16, "Temp:")
local labelLife = Label:new(26, 90, 0, 16, "Life:")
local labelTmp = Label:new(27, 111, 0, 16, "Tmp:")
local labelTmp2 = Label:new(24, 132, 0, 16, "Tmp2:")
local buttonDone = Button:new(0, 160, 200, 16, "Done")
inputType = Textbox:new(42, 27, 148, 16, "BOMB")
inputCtype = Textbox:new(42, 48, 148, 16, "NONE")
inputTemp = Textbox:new(42, 69, 148, 16, "22C")
inputLife = Textbox:new(42, 90, 148, 16, "0")
inputTmp = Textbox:new(42, 111, 148, 16, "0")
inputTmp2 = Textbox:new(42, 132, 148, 16, "0")
buttonDone:action(validate)
elemSelector:addComponent(labelTitle)
elemSelector:addComponent(labelType)
elemSelector:addComponent(inputType)
elemSelector:addComponent(labelCtype)
elemSelector:addComponent(inputCtype)
elemSelector:addComponent(labelTemp)
elemSelector:addComponent(inputTemp)
elemSelector:addComponent(labelLife)
elemSelector:addComponent(inputLife)
elemSelector:addComponent(labelTmp)
elemSelector:addComponent(inputTmp)
elemSelector:addComponent(labelTmp2)
elemSelector:addComponent(inputTmp2)
elemSelector:addComponent(buttonDone)
-- When the enter key is pressed while the dialog box is up, run validate()
elemSelector:onKeyPress(function(keyCode) if keyCode == 13 then validate() end end)

-- This function checks if mousex and mousey are within workspace
local function inWorkspace(mousex, mousey)
  if mousex >= 4 and mousey >= 4 and mousex <= 607 and mousey <= 379 then return true end
end

-- This function checks if SHOT is selected (left-click element, right-click element, middle-click element, depends on what button is)
local function selected(button)
  if (button == 1 and tpt.selectedl == shotIdent) or (button == 4 and tpt.selectedr == shotIdent) or (button == 2 and tpt.selecteda == shotIdent) then
    return true
  end
end

-- This function draws the power line and the motion path
local function drawPowerMotion()
  local length = math.sqrt((x2 - x1)^2 + (y2 - y1)^2)
  local vx = (x1 - x2) / 17
  local vy = (y1 - y2) / 17
  local r = 0 + length * 1.5
  local g = 255 - length
  -- Draw power line
  graphics.drawLine(x1 + 2, y1, x2, y2, r, g, 0, 25)
  graphics.drawLine(x1 - 2, y1, x2, y2, r, g, 0, 25)
  graphics.drawLine(x1, y1 + 2, x2, y2, r, g, 0, 25)
  graphics.drawLine(x1, y1 - 2, x2, y2, r, g, 0, 25)
  graphics.drawLine(x1 + 1, y1 + 1, x2, y2, r, g, 0, 180)
  graphics.drawLine(x1 + 1, y1 - 1, x2, y2, r, g, 0, 180)
  graphics.drawLine(x1 - 1, y1 + 1, x2, y2, r, g, 0, 180)
  graphics.drawLine(x1 - 1, y1 - 1, x2, y2, r, g, 0, 180)
  graphics.drawLine(x1 + 1, y1, x2, y2, r, g, 0, 230)
  graphics.drawLine(x1 - 1, y1, x2, y2, r, g, 0, 230)
  graphics.drawLine(x1, y1 + 1, x2, y2, r, g, 0, 230)
  graphics.drawLine(x1, y1 - 1, x2, y2, r, g, 0, 230)
  graphics.drawLine(x1, y1, x2, y2, r, g, 0)
  -- Draw motion path (the location of the projectile every 2 frames for 90 frames)
  for i = 1, 90, 2 do
    local x = x1 + vx * i
    local y = y1 + vy * i + 0.0835 * i^2
    if not inWorkspace(x, y) then break end
    local shade = 255 - i * 2.833
    graphics.drawCircle(x + 1, y + 1, 0, 0, shade, shade, shade, 25)
    graphics.drawCircle(x + 1, y - 1, 0, 0, shade, shade, shade, 25)
    graphics.drawCircle(x - 1, y + 1, 0, 0, shade, shade, shade, 25)
    graphics.drawCircle(x - 1, y - 1, 0, 0, shade, shade, shade, 25)
    graphics.drawCircle(x + 1, y, 0, 0, shade, shade, shade, 100)
    graphics.drawCircle(x - 1, y, 0, 0, shade, shade, shade, 100)
    graphics.drawCircle(x, y + 1, 0, 0, shade, shade, shade, 100)
    graphics.drawCircle(x, y - 1, 0, 0, shade, shade, shade, 100)
    graphics.drawCircle(x, y, 0, 0, shade, shade, shade)
  end
end

-- This function creates the projectile with the right vx and vy and stores them in pavg0 and pavg1
local function launch()
  local vx = (x1 - x2) / 17
  local vy = (y1 - y2) / 17
  local projectile = sim.partCreate(-3, x1, y1, proj)
  sim.partProperty(projectile, sim.FIELD_VX, vx)
  sim.partProperty(projectile, sim.FIELD_VY, vy)
  sim.partProperty(projectile, sim.FIELD_PAVG0, vx)
  sim.partProperty(projectile, sim.FIELD_PAVG1, vy)
end

-- This function updates the values of selectedr, selectedl and selecteda and shows the UI window when SHOT is selected
local function checkSelected()
  if (tpt.selectedr == shotIdent and selectedr ~= shotIdent) or
    (tpt.selectedl == shotIdent and selectedl ~= shotIdent) or
    (tpt.selecteda == shotIdent and selecteda ~= shotIdent) then
      selectedr = tpt.selectedr
      selectedl = tpt.selectedl
      selecteda = tpt.selecteda
      interface.showWindow(elemSelector)
  else
    selectedr = tpt.selectedr
    selectedl = tpt.selectedl
    selecteda = tpt.selecteda
  end
end

-- zooming is later used in prelaunch to fix the bug where projectiles are launched when placing a zoom box if they are selected
local function detectZoom(key, keyCode, modifierKeys, event)
  if key == "z" and event == 1 then
    zooming = true
  elseif key == "z" and event == 2 then
    zooming = false
  end
end

-- This is the main function where everything starts
local function prelaunch(mousex, mousey, button, event)
  if selected(button) and not zooming and ((inWorkspace(mousex, mousey) and not holding) or holding) then
    if event == 1 then
      x1, y1 = sim.adjustCoords(mousex, mousey)
      x2, y2 = x1, y1
      holding = true
      tpt.register_step(drawPowerMotion)
    elseif event == 3 then
      x2, y2 = sim.adjustCoords(mousex, mousey)
    else
      tpt.unregister_step(drawPowerMotion)
      holding = false
      launch()
    end
  end
end

tpt.register_step(checkSelected)
tpt.register_keypress(detectZoom)
tpt.register_mouseclick(prelaunch)