
local magic = elem.allocate("LIVINGFOSSIL" , "MAGC") 
elem.element(magic, elem.element(elements.DEFAULT_PT_GLOW))
elem.property(magic, "Name" , "MAGC")
elem.property(magic, "Description", "Magic. Very light glowing liquid. Burns with CFLM.")
elem.property(magic, "Colour", 0xCDFFFF)
elem.property(magic, "MenuVisible", 1)
elem.property(magic, "MenuSection", elem.SC_LIQUID)
elem.property(magic, "Gravity", 0.02) 
elem.property(magic, "Flammable", 0) 
elem.property(magic, "Explosive", 0) 
elem.property(magic, "Loss", 0.95)
elem.property(magic, "AirLoss", 1) 
elem.property(magic, "AirDrag", 0.002) 
elem.property(magic, "Advection", 0.6) 
elem.property(magic, "Weight", 2)
elem.property(magic, "Diffusion", 0) 
elem.property(magic, "Falldown", 2) 
elem.property(magic, "Temperature", 273.15-20)
elem.property(magic, "HeatConduct", 20)
elem.property(magic, "Hardness", 20)

elem.property(magic, "Graphics", function (i, colr, colg, colb)                                   
	return 1, 0x00012012, 255, 185, 254, 247, 150, 185, 254, 247
end)
 
elem.property(magic, "Update", function (i, x, y, s, n)
	 
	local temp = sim.partProperty(i, sim.FIELD_TEMP)
	local tmp = sim.partProperty(i, sim.FIELD_TMP)

	sim.partProperty(i, sim.FIELD_LIFE, 20)
	 
	if tmp == 0 and temp > 273.15-150 then 
		sim.partProperty(i, sim.FIELD_TMP, 5)
	end

	if temp <= 273.15-150 then
		if tmp > 0 then
			for cx = 1, 3, 2 do
				for cy = 1, 3, 2 do
					tpt.create(x + cx, y + cy, 'cflm')
				end
			end
		end
		sim.partProperty(i, sim.FIELD_TMP, tmp - 1)
		if sim.partProperty(i, sim.FIELD_TMP) <= 0 then
			sim.partProperty(i, sim.FIELD_TYPE, 0)
		end
	end	
end)