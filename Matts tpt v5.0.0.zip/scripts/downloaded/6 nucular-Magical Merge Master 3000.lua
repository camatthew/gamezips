
-- nuculars Magical Merge Master 3000
-------------------------------------------
-- Press M to open the interface window.
-- The merged element is named "MRGD" and can be found under the "Special" category.
----
-- Code is under the MIT License, have fun!


local factor = 0.5
local window = Window:new(100, 100, 300, 98)
local elem1 = "NONE"
local elem2 = "NONE"
local merged = nil

-- These are blocked from being merged
local blockedprops = {
    Identifier = 1, MenuVisible = 1, MenuSection = 1, Enabled = 1
}
-- These aren't merged, a weighted random value from both elements is used instead
local randprops = {
    State = 1, Properties = 1,
    LowPressureTransition = 1, HighPressureTransition = 1,
    LowTemperatureTransition = 1, HighTemperatureTransition = 1
}


local factorview = Label:new(10, 10, 280, 16, "0.5")
window:addComponent(factorview)

local function checker(sender)
    local t = sender:text()
    t = string.sub(string.upper(t), 0, 4)
    sender:text(t)
end

local elem1text = Textbox:new(10, 10, 35, 16, "", "NONE")
elem1text:onTextChanged(checker)
window:addComponent(elem1text)

local elem2text = Textbox:new(255, 10, 35, 16, "", "NONE")
elem2text:onTextChanged(checker)
window:addComponent(elem2text)

local factorslider = Slider:new(10, 36, 280, 16, 100)
factorslider:value(50)
factorslider:onValueChanged(function(sender, value)
    factor = value / 100
    factorview:text(factor)
end)
window:addComponent(factorslider)

local mergebutton = Button:new(10, 72, 280, 16, "MERGE!")
mergebutton:action(function(sender)
    local name1 = elem1text:text()
    local name2 = elem2text:text()

    if name1 == "" or name2 == "" then
        tpt.message_box("Come on", "You have to enter an element in\nboth textboxes.")
        return
    end

    if name1 == name2 then
        tpt.message_box("Nah", "You should really select two different\nelements.")
        return
    end

    if tpt.el[string.lower(name1)] == nil then
        tpt.message_box("Well", "I have no idea what element you mean\nwith '" .. name1 .. "' as the first element...")
        return
    end

    if tpt.el[string.lower(name2)] == nil then
        tpt.message_box("Well", "I have no idea what element you mean\nwith '" .. name2 .. "' as the second element...")
        return
    end


    if merged == nil then
        merged = elements.allocate("NUCULAR", "MRGD")
        elements.property(merged, "Name", "MRGD")
        elements.property(merged, "MenuSection", elements.SC_SPECIAL)
        elements.property(merged, "MenuVisible", 1)
    end

    local percent1 = 100 - (factor * 100)
    local percent2 = factor * 100

    
    elements.property(merged, "Description", string.format("Some weird merged stuff, about %s%% of %s and circa %s%% of %s...",
        percent1, name1, percent2, name2))
    
    local id1 = tpt.element(name1)
    local id2 = tpt.element(name2)

    local elem1 = elements.element(id1)
    local elem2 = elements.element(id2)

    for k, v in pairs(elem1) do
        if type(v) == "number" and blockedprops[k] == nil then
            local nv

            if randprops[k] ~= nil then
                if math.random() >= factor then
                    nv = v
                else
                    nv = elem2[k]
                end
            else
                nv = (v * percent1 + elem2[k] * percent2) / 100
            end
            elements.property(merged, k, nv)
        end
    end

    tpt.active_menu(elements.SC_SPECIAL)
    ui.closeWindow(window)
end)
window:addComponent(mergebutton)


window:onTryExit(
    function()
        ui.closeWindow(window)
    end
)


local function keypressed(key, keynum, mod, evt)
    if evt == 2 and key == "m" then
        if elem1text:text() == "" then
            local l = tpt.element(loadstring("return elements." .. tpt.selectedl)())
            if l ~= "NONE" then elem1text:text(l) end
        end
        if elem2text:text() == "" then
            local r = tpt.element(loadstring("return elements." .. tpt.selectedr)())
            if r ~= "NONE" then elem2text:text(r) end
        end

        ui.showWindow(window)
    end
end

tpt.register_keypress(keypressed)