
--tpt.message_box(string title, string message)

tpt.set_console(0)
name=""
local function undeadstkm()

   tpt.start_getPartIndex()
     while tpt.next_getPartIndex() do
        local index = tpt.getPartIndex()
        if tpt.get_property("type", index) == 55 and tpt.get_property("ctype", index) ~= 89 then
           tpt.set_property("life", 10001000,index)
           tpt.set_property("ctype", 89,index)
        elseif tpt.get_property("type", index) == 49 and name ~= "" then
	   tpt.set_property("temp", elements.property(tpt.element(name), "Temperature"),index)
	   tpt.set_property("type", name,index)
	   tpt.set_property("temp", elements.property(tpt.element(name), "Temperature"),index)
	end
     end

return false
end

local function robootsOut(key, code, modifiers, event)
if code == string.byte('j') then
name = tpt.input("element", "element to throw from rocketboots")
return false
end
end
tpt.register_step(undeadstkm)
tpt.register_keypress(robootsOut)