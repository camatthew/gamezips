
local magn = elem.allocate("TPTPL", "MAGN")
local mgnp = elem.allocate("TPTPL", "MGNP")
local mgno = elem.allocate("TPTPL", "MGNO")

-- Magnesium oxide
elem.element(mgno, elem.element(elem.DEFAULT_PT_BREC))
elem.property(mgno, "Name", "MGNO")
elem.property(mgno, "Description", "Magnesium oxide, conductive powder, extinguished MAGN/MGNP.")
elem.property(mgno, "Color", 0x5C5C3D)

local function magnoxide(i, x, y, s, nt)
    local r = sim.partID(math.random(x-1, x+1), math.random(y-1, y+1))
    if r ~= nil then
        local rtype = sim.partProperty(r, "type")
        if rtype == elem.DEFAULT_PT_ACID then
            sim.partChangeType(r, elem.DEFAULT_PT_DSTW)
            sim.partChangeType(i, elem.DEFAULT_PT_SALT)
        elseif rtype == elem.DEFAULT_PT_H2 and sim.pressure(x/4, y/4) >= 2.00 then
            sim.partChangeType(r, elem.DEFAULT_PT_DSTW)
            sim.partChangeType(i, mgnp)
        end
    end
end

elem.property(mgno, "Update", magnoxide)

-- Magnesium
elem.element(magn, elem.element(elem.DEFAULT_PT_SPNG))
elem.property(magn, "Name", "MAGN")
elem.property(magn, "Description", "Magnesium, hard to ignite, burns long with a very hot flame.")
elem.property(magn, "Color", 0xB8B894)
elem.property(magn, "Flammable", 0)
elem.property(magn, "HighPressure", 5)

local function magnesium(i, x, y, s, nt)
    local r = sim.partID(math.random(x-1, x+1), math.random(y-1, y+1))
    if r ~= nil then
        local rtype = sim.partProperty(r, "type")
        if sim.partProperty(i, "tmp") == 0 then
            if sim.partProperty(r, "temp") >= 1773.15 then
                sim.partProperty(i, "tmp", 1)
                sim.partProperty(i, "life", 150)
            elseif rtype == elem.DEFAULT_PT_ACID then
                sim.partChangeType(r, elem.DEFAULT_PT_H2)
                sim.partChangeType(i, elem.DEFAULT_PT_SALT)
            end
        else
            if (rtype == elem.DEFAULT_PT_WATR or rtype == elem.DEFAULT_PT_WTRV or rtype == elem.DEFAULT_PT_DSTW) and sim.partProperty(i, "tmp") == 1 then
                sim.partChangeType(r, elem.DEFAULT_PT_HYGN)
                sim.partChangeType(i, mgno)
            elseif rtype == elem.DEFAULT_PT_O2 and sim.partProperty(i, "tmp") == 1 then
                sim.partChangeType(i, mgno)
            elseif rtype == elem.DEFAULT_PT_CO2 and sim.partProperty(i, "tmp") == 1 then
                sim.partChangeType(r, elem.DEFAULT_PT_BCOL)
                sim.partChangeType(i, mgno)
            end
        end
    end
    if sim.partProperty(i, "tmp") == 1 then
        if sim.partProperty(i, "life") ~= 1 and sim.partProperty(i, "life") > 0 then
            local p1 = sim.partCreate(-1, x, y+1, elem.DEFAULT_PT_FIRE)
            if p1 >= 0 then
                sim.partProperty(p1, "temp", 3775.15)
            end
            local p2 = sim.partCreate(-1, x+1, y, elem.DEFAULT_PT_FIRE)
            if p2 >= 0 then
                sim.partProperty(p2, "temp", 3775.15)
            end
            local p3 = sim.partCreate(-1, x, y-1, elem.DEFAULT_PT_FIRE)
            if p3 >= 0 then
                sim.partProperty(p3, "temp", 3775.15)
            end
            local p4 = sim.partCreate(-1, x-1, y, elem.DEFAULT_PT_FIRE)
            if p4 >= 0 then
                sim.partProperty(p4, "temp", 3775.15)
            end
            sim.partProperty(i, "life", sim.partProperty(i, "life")-1)
        else
            sim.partKill(i)
        end
    end
end

elem.property(magn, "Update", magnesium)

-- Magnesium powder
elem.element(mgnp, elem.element(elem.DEFAULT_PT_DUST))
elem.property(mgnp, "Name", "MGNP")
elem.property(mgnp, "Description", "Magnesium powder, a lot easier to ignite than MAGN and also burns hotter.")
elem.property(mgnp, "Color", 0xE0E0D1)
elem.property(mgnp, "Flammable", 0)
elem.property(magn, "HighPressureTransition", mgnp)

local function mgpowder(i, x, y, s, nt)
    local r = sim.partID(math.random(x-1, x+1), math.random(y-1, y+1))
    if r ~= nil then
        local rtype = sim.partProperty(r, "type")
        if sim.partProperty(i, "tmp") == 0 then
            if sim.partProperty(r, "temp") >= 693.15 then
                sim.partProperty(i, "tmp", 1)
                sim.partProperty(i, "life", 100)
            elseif rtype == elem.DEFAULT_PT_ACID then
                sim.partChangeType(r, elem.DEFAULT_PT_H2)
                sim.partChangeType(i, elem.DEFAULT_PT_SALT)
            end
        else
            if (rtype == elem.DEFAULT_PT_WATR or rtype == elem.DEFAULT_PT_WTRV or rtype == elem.DEFAULT_PT_DSTW) and sim.partProperty(i, "tmp") == 1 then
                sim.partChangeType(r, elem.DEFAULT_PT_HYGN)
                sim.partChangeType(i, mgno)
            elseif rtype == elem.DEFAULT_PT_O2 and sim.partProperty(i, "tmp") == 1 then
                sim.partChangeType(i, mgno)
            elseif rtype == elem.DEFAULT_PT_CO2 and sim.partProperty(i, "tmp") == 1 then
                sim.partChangeType(r, elem.DEFAULT_PT_BCOL)
                sim.partChangeType(i, mgno)
            end
        end
    end
    if sim.partProperty(i, "tmp") == 1 then
        if sim.partProperty(i, "life") ~= 1 and sim.partProperty(i, "life") > 0 then
            local p1 = sim.partCreate(-1, x, y+1, elem.DEFAULT_PT_FIRE)
            if p1 >= 0 then
                sim.partProperty(p1, "temp", 4775.15)
            end
            local p2 = sim.partCreate(-1, x+1, y, elem.DEFAULT_PT_FIRE)
            if p2 >= 0 then
                sim.partProperty(p2, "temp", 4775.15)
            end
            local p3 = sim.partCreate(-1, x, y-1, elem.DEFAULT_PT_FIRE)
            if p3 >= 0 then
                sim.partProperty(p3, "temp", 4775.15)
            end
            local p4 = sim.partCreate(-1, x-1, y, elem.DEFAULT_PT_FIRE)
            if p4 >= 0 then
                sim.partProperty(p4, "temp", 4775.15)
            end
            sim.partProperty(i, "life", sim.partProperty(i, "life")-1)
        else
            sim.partKill(i)
        end
    end
end

elem.property(mgnp, "Update", mgpowder)

-- Iridium
local irdm = elem.allocate("TPTPL", "IRDM")
elem.element(irdm, elem.element(elem.DEFAULT_PT_GOLD))
elem.property(irdm, "Name", "IRDM")
elem.property(irdm, "Description", "Iridium, corroded by OXYG only. Creates FIRE when spark passes through.")
elem.property(irdm, "Color", 0xAFCBCF)
elem.property(irdm, "HighTemperature", 2447 + 273.15)

local function iridium(i, x, y, s, nt)
    local r = sim.partID(math.random(x-1, x+1), math.random(y-1, y+1))
    if r ~= nil then
        local rtype = sim.partProperty(r, "type")
        if rtype == elem.DEFAULT_PT_O2 and math.random(1, 1000) == 1 then
            sim.partKill(i);
            return 1
        end
    end
    if sim.partProperty(i, "life") == 4 then
        local fire = sim.partCreate(-1, math.random(x-1, x+1), math.random(y-1, y+1), elem.DEFAULT_PT_FIRE)
        if fire > -1 then
            sim.partProperty(fire, "temp", sim.partProperty(i, "temp"))
        end
    end
end

elem.property(irdm, "Update", iridium)

-- Radon
local radn = elem.allocate("TPTPL", "RADN")
elem.element(radn, elem.element(elem.DEFAULT_PT_NBLE))
elem.property(radn, "Name", "RADN")
elem.property(radn, "Description", "Radon, radioactive noble gas. Glows, emits NEUT and decays into NBLE when sparked.")
elem.property(radn, "Color", 0x006622)
elem.property(radn, "MenuSection", elem.SC_NUCLEAR)
elem.property(radn, "Properties", elem.TYPE_GAS+elem.PROP_RADIOACTIVE+elem.PROP_CONDUCTS+elem.PROP_LIFE_DEC)

local function radon(i, x, y, s, nt)
    if sim.partProperty(i, "life") == 4 then
        local decay = math.random(1, 10)
        if decay == 1 then
            sim.partKill(i);
            sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT);
            return 1
        elseif decay > 1 and decay <= 4 then
            sim.partProperty(i, "type", elem.DEFAULT_PT_NBLE)
        end
    end
end

local function radonGlow(i, r, g, b)
    if sim.partProperty(i, "life") == 0 then
        return 0, 0x00020000, 255, r, g, b, 20, r, g, b
    else
        return 0, 0x00000041, 255, r, g, b, 20, r, g, b
    end
end

elem.property(radn, "Update", radon)
elem.property(radn, "Graphics", radonGlow)

-- Francium
local fran = elem.allocate("TPTPL", "FRAN")
elem.element(fran, elem.element(elem.DEFAULT_PT_BREL))
elem.property(fran, "Name", "FRAN")
elem.property(fran, "Description", "Francium, decays in just seconds. Don't allow it to contact with water.")
elem.property(fran, "Color", 0xE6F2FF)
elem.property(fran, "MenuSection", elem.SC_NUCLEAR)
elem.property(fran, "Properties", elem.TYPE_SOLID+elem.PROP_RADIOACTIVE)

local function francium(i, x, y, s, nt)
    local r = sim.partID(math.random(x-1, x+1), math.random(y-1, y+1))
    if r ~= nil then
        local rtype = sim.partProperty(r, "type")
        if rtype == elem.DEFAULT_PT_WATR or rtype == elem.DEFAULT_PT_DSTW or rtype == elem.DEFAULT_PT_SLTW or rtype == elem.DEFAULT_PT_CBNW or rtype == elem.DEFAULT_PT_WTRV or rtype == elem.DEFAULT_PT_ICE or rtype == elem.DEFAULT_PT_SNOW then
            sim.partProperty(r, "temp", 1273.15)
            local react = math.random(1, 5)
            if react == 1 then
                sim.partKill(i);
                sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT);
                return 1
            elseif react == 2 then
                sim.partKill(i);
                sim.partCreate(-3, x, y, elem.DEFAULT_PT_PROT);
                return 1
            elseif react == 3 then
                sim.partKill(i);
                sim.partCreate(-3, x, y, elem.DEFAULT_PT_ELEC);
                return 1
            elseif react == 4 then
                sim.partChangeType(i, elem.DEFAULT_PT_H2);
            else
                sim.partChangeType(i, radn);
            end;
            sim.partProperty(i, "temp", 1273.15)
            sim.pressure(x/4, y/4, 50)
        end
    end
    if math.random(1, 100) == 1 then
        local react = math.random(1, 5)
        if react == 1 then
            sim.partKill(i);
            sim.partCreate(-3, x, y, elem.DEFAULT_PT_NEUT);
            return 1
        elseif react == 2 then
            sim.partKill(i);
            sim.partCreate(-3, x, y, elem.DEFAULT_PT_PROT);
            return 1
        elseif react == 3 then
            sim.partKill(i);
            sim.partCreate(-3, x, y, elem.DEFAULT_PT_PHOT);
            return 1
        elseif react == 4 then
            sim.partChangeType(i, elem.DEFAULT_PT_H2);
        else
            sim.partChangeType(i, radn);
        end;
    end
end

elem.property(fran, "Update", francium)