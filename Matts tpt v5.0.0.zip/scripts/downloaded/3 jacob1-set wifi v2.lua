
local channel = -1
local lastindex = 0
local nextchan = 3
local keymode = false
local pageup = false
local pagedown = false

local function keyfunction(key,keycode,modifier,event)
	if keycode == 280 and event == 1 then
		pageup = true
	elseif keycode == 280 and event == 2 then
		pageup = false
	elseif keycode == 281 and event == 1 then
		pagedown = true
	elseif keycode == 281 and event == 2 then
		pagedown = false
	end
	if pageup and pagedown and keymode then
		keymode = false
		tpt.log("Keyboard shortcut mode deactivated")
		return
	elseif pageup and pagedown then
		keymode = true
		tpt.log("Keyboard shortcut mode activated")
		return
	end
	if keymode and keycode == 280 and event == 1 then
		if bit.band(modifier, 0xC0) ~= 0 then
			nextchan = nextchan + 5
		else
			nextchan = nextchan + 1
		end
		if nextchan > 100 then nextchan = 100 end
		tpt.log("Next WIFI channel was set to "..nextchan)
	elseif keymode and keycode == 281 and event == 1 then
		if bit.band(modifier, 0xC0) ~= 0 then
			nextchan = nextchan - 5
		else
			nextchan = nextchan - 1
		end
		if nextchan < 0 then nextchan = 0 end
		tpt.log("Next WIFI channel was set to "..nextchan)
	end
end

local function setwifi(i,x,y,surround_space,nt)
	if i <= lastindex then -- if tpt has looped through every index, this
		channel = -1       -- must be a new frame, so reset entered channel
	end
	local temp = math.floor(tpt.get_property("temp",i)-273.1)
	if temp == 22 and channel == -1 then
		if keymode then
			channel = nextchan
		else
			channel = tonumber(tpt.input("Enter a Channel Number", "Must Be Between 0 and 100"))
		end
		if not channel then
			channel = 3
		end
	end
	if temp == 22 then
		tpt.set_property("temp", channel*100 + 23.15, i)
	end
	lastindex = i
end

tpt.register_keypress(keyfunction)
tpt.element_func(setwifi,tpt.element("WIFI"),0,setwifi)
tpt.element_func(setwifi,tpt.element("PRTI"),0,setwifi)
tpt.element_func(setwifi,tpt.element("PRTO"),0,setwifi)
if tpt.version.jacob1s_mod then
	tpt.element_func(setwifi,tpt.element("PPTI"),0,setwifi)
	tpt.element_func(setwifi,tpt.element("PPTO"),0,setwifi)
end