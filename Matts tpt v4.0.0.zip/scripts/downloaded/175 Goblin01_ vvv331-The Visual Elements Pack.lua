
local COPP = elements.allocate("MODPK", "COPP")

elements.element(elements.MODPK_PT_COPP, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_COPP, "Name", "COPP")
elements.property(elements.MODPK_PT_COPP, "Description", "Copper. Conducts heat and electricity very well.")
elements.property(elements.MODPK_PT_COPP, "Colour", 0xB87333)
elements.property(elements.MODPK_PT_COPP, "MenuSection", 9)

elements.property(elements.MODPK_PT_COPP, "Meltable", 1)
elements.property(elements.MODPK_PT_COPP, "Hardness", 45)

elements.property(elements.MODPK_PT_COPP, "Properties", TYPE_SOLID)
elements.property(elements.MODPK_PT_COPP, "State", ST_SOLID)
elements.property(elements.MODPK_PT_COPP, "Temperature", 295.15)
elements.property(elements.MODPK_PT_COPP, "HeatConduct", 245)
elements.property(elements.MODPK_PT_COPP, "HighTemperature", 1573.15)
elements.property(elements.MODPK_PT_COPP, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)

local STEL = elements.allocate("MODPK", "STEL")

elements.element(elements.MODPK_PT_STEL, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_STEL, "Name", "STEL")
elements.property(
    elements.MODPK_PT_STEL,
    "Description",
    "Steel. Resists corrosions and has a high melting point. Emits sparks when molten."
)
elements.property(elements.MODPK_PT_STEL, "Colour", 0x99a3a3)
elements.property(elements.MODPK_PT_STEL, "MenuSection", 9)

elements.property(elements.MODPK_PT_STEL, "Meltable", 1)
elements.property(elements.MODPK_PT_STEL, "Hardness", 0)

elements.property(elements.MODPK_PT_STEL, "Properties", TYPE_SOLID)
elements.property(elements.MODPK_PT_STEL, "State", ST_SOLID)
elements.property(elements.MODPK_PT_STEL, "Temperature", 295.15)
elements.property(elements.MODPK_PT_STEL, "HeatConduct", 245)
elements.property(elements.MODPK_PT_STEL, "HighTemperature", 2573.15)
elements.property(elements.MODPK_PT_STEL, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local LEAD = elements.allocate("MODPK", "LEAD")

elements.element(elements.MODPK_PT_LEAD, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_LEAD, "Name", "LEAD")
elements.property(elements.MODPK_PT_LEAD, "Description", "Lead. Blocks any radiation.")
elements.property(elements.MODPK_PT_LEAD, "Colour", 0x2d2d2d)
elements.property(elements.MODPK_PT_LEAD, "MenuSection", 9)
elements.property(elements.MODPK_PT_LEAD, "Meltable", 1)
elements.property(elements.MODPK_PT_LEAD, "Hardness", 0)

elements.property(elements.MODPK_PT_LEAD, "Properties", TYPE_SOLID)
elements.property(elements.MODPK_PT_LEAD, "State", ST_SOLID)
elements.property(elements.MODPK_PT_LEAD, "Temperature", 295.15)
elements.property(elements.MODPK_PT_LEAD, "HeatConduct", 50)
elements.property(elements.MODPK_PT_LEAD, "HighTemperature", 1973.15)
elements.property(elements.MODPK_PT_LEAD, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)

local GRPH = elements.allocate("MODPK", "GRPH")

elements.element(elements.MODPK_PT_GRPH, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_GRPH, "Name", "GRPH")
elements.property(
    elements.MODPK_PT_GRPH,
    "Description",
    "Graphite. Similar to lead, but it has a very high melting point."
)
elements.property(elements.MODPK_PT_GRPH, "Colour", 0x111111)
elements.property(elements.MODPK_PT_GRPH, "MenuSection", 9)
elements.property(elements.MODPK_PT_GRPH, "Meltable", 1)
elements.property(elements.MODPK_PT_GRPH, "Hardness", 0)

elements.property(elements.MODPK_PT_GRPH, "Properties", TYPE_SOLID)
elements.property(elements.MODPK_PT_GRPH, "State", ST_SOLID)
elements.property(elements.MODPK_PT_GRPH, "Temperature", 295.15)
elements.property(elements.MODPK_PT_GRPH, "HeatConduct", 50)
elements.property(elements.MODPK_PT_GRPH, "HighTemperature", 6973.15)
elements.property(elements.MODPK_PT_LEAD, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local PB95 = elements.allocate("MODPK", "PB95")

elements.element(elements.MODPK_PT_PB95, elements.element(elements.DEFAULT_PT_DESL))
elements.property(elements.MODPK_PT_PB95, "Name", "PB95")
elements.property(elements.MODPK_PT_PB95, "Description", "Octane 95 fuel.")
elements.property(elements.MODPK_PT_PB95, "Colour", 0xCCCC00)
elements.property(elements.MODPK_PT_PB95, "MenuSection", 7)

--elements.property(elements.MODPK_PT_PB95, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_PB95, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_PB95, "Flammable", 5)
elements.property(elements.MODPK_PT_PB95, "Explosive", 0)
elements.property(elements.MODPK_PT_PB95, "Weight", 5)

elements.property(elements.MODPK_PT_PB95, "Properties", TYPE_LIQUID)
elements.property(elements.MODPK_PT_PB95, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_PB95, "HighTemperatureTransition", NT)
elements.property(elements.MODPK_PT_PB95, "HighPressureTransition", NT)
elements.property(elements.MODPK_PT_PB95, "LowPressureTransition", NT)
elements.property(elements.MODPK_PT_PB95, "HeatConduct", 10)
local PB98 = elements.allocate("MODPK", "PB98")

elements.element(elements.MODPK_PT_PB98, elements.element(elements.DEFAULT_PT_DESL))
elements.property(elements.MODPK_PT_PB98, "Name", "PB98")
elements.property(elements.MODPK_PT_PB98, "Description", "Octane 98 fuel. Slightly more flammable than 95.")
elements.property(elements.MODPK_PT_PB98, "Colour", 0xafba50)
elements.property(elements.MODPK_PT_PB98, "MenuSection", 7)

--elements.property(elements.MODPK_PT_PB98, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_PB98, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_PB98, "Flammable", 10)
elements.property(elements.MODPK_PT_PB98, "Explosive", 0)
elements.property(elements.MODPK_PT_PB98, "Weight", 10)

elements.property(elements.MODPK_PT_PB98, "Properties", TYPE_LIQUID)
elements.property(elements.MODPK_PT_PB98, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_PB98, "HighTemperatureTransition", NT)
elements.property(elements.MODPK_PT_PB98, "HighPressureTransition", NT)
elements.property(elements.MODPK_PT_PB98, "LowPressureTransition", NT)
elements.property(elements.MODPK_PT_PB98, "HeatConduct", 10)
local PB101 = elements.allocate("MODPK", "PB101")

elements.element(elements.MODPK_PT_PB101, elements.element(elements.DEFAULT_PT_DESL))
elements.property(elements.MODPK_PT_PB101, "Name", "PB101")
elements.property(elements.MODPK_PT_PB101, "Description", "Octane 101 fuel.. just more flammable...")
elements.property(elements.MODPK_PT_PB101, "Colour", 0xc9d370)
elements.property(elements.MODPK_PT_PB101, "MenuSection", 7)

--elements.property(elements.MODPK_PT_PB101, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_PB101, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_PB101, "Flammable", 15)
elements.property(elements.MODPK_PT_PB101, "Explosive", 0)
elements.property(elements.MODPK_PT_PB101, "Weight", 15)

elements.property(elements.MODPK_PT_PB101, "Properties", TYPE_LIQUID)
elements.property(elements.MODPK_PT_PB101, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_PB101, "HighTemperatureTransition", NT)
elements.property(elements.MODPK_PT_PB101, "HighPressureTransition", NT)
elements.property(elements.MODPK_PT_PB101, "LowPressureTransition", NT)
elements.property(elements.MODPK_PT_PB101, "HeatConduct", 10)

local MELT = elements.allocate("MODPK", "MELT")
elements.element(elements.MODPK_PT_MELT, elements.element(elements.DEFAULT_PT_STNE))
elements.property(elements.MODPK_PT_MELT, "Name", "MELT")
elements.property(
    elements.MODPK_PT_MELT,
    "Description",
    "Melt powder. Heats up slowly upon contact with other particles."
)
elements.property(elements.MODPK_PT_MELT, "Colour", 0x333333)
elements.property(elements.MODPK_PT_MELT, "MenuSection", 8)

--elements.property(elements.MODPK_PT_MELT, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_MELT, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_MELT, "Weight", 25)

elements.property(elements.MODPK_PT_MELT, "Meltable", 0)
elements.property(elements.MODPK_PT_MELT, "Hardness", 25)

elements.property(elements.MODPK_PT_MELT, "Properties", TYPE_POWDER)
elements.property(elements.MODPK_PT_MELT, "State", ST_POWDER)
elements.property(elements.MODPK_PT_MELT, "HighTemperature", 12000)
elements.property(elements.MODPK_PT_MELT, "HeatConduct", 254)

local PB108 = elements.allocate("MODPK", "PB108")

elements.element(elements.MODPK_PT_PB108, elements.element(elements.DEFAULT_PT_DESL))
elements.property(elements.MODPK_PT_PB108, "Name", "PB108")
elements.property(
    elements.MODPK_PT_PB108,
    "Description",
    "Octane 108 fuel.. and just more flammable. This is an end of that series."
)
elements.property(elements.MODPK_PT_PB108, "Colour", 0xeef7a0)
elements.property(elements.MODPK_PT_PB108, "MenuSection", 7)

--elements.property(elements.MODPK_PT_PB108, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_PB108, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_PB108, "Flammable", 25)
elements.property(elements.MODPK_PT_PB108, "Explosive", 0)
elements.property(elements.MODPK_PT_PB108, "Weight", 25)

elements.property(elements.MODPK_PT_PB108, "Properties", TYPE_LIQUID)
elements.property(elements.MODPK_PT_PB108, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_PB108, "HighTemperatureTransition", NT)
elements.property(elements.MODPK_PT_PB108, "HighPressureTransition", NT)
elements.property(elements.MODPK_PT_PB108, "LowPressureTransition", NT)
local LPG = elements.allocate("MODPK", "LPG")

elements.element(elements.MODPK_PT_LPG, elements.element(elements.DEFAULT_PT_DESL))
elements.property(elements.MODPK_PT_LPG, "Name", "LPG")
elements.property(elements.MODPK_PT_LPG, "Description", "Fuel with a slight combination with gas. Burns very slowly.")
elements.property(elements.MODPK_PT_LPG, "Colour", 0x9ab9ed)
elements.property(elements.MODPK_PT_LPG, "MenuSection", 7)

--elements.property(elements.MODPK_PT_LPG, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_LPG, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_LPG, "Flammable", 1)
elements.property(elements.MODPK_PT_LPG, "Explosive", 0)
elements.property(elements.MODPK_PT_LPG, "Weight", 1)

elements.property(elements.MODPK_PT_LPG, "Properties", TYPE_LIQUID)
elements.property(elements.MODPK_PT_LPG, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_LPG, "HighTemperatureTransition", NT)
elements.property(elements.MODPK_PT_LPG, "HighPressureTransition", NT)
elements.property(elements.MODPK_PT_LPG, "LowPressureTransition", NT)
elements.property(elements.MODPK_PT_LPG, "HeatConduct", 10)
elements.property(elements.MODPK_PT_PB108, "HeatConduct", 10)
local FUEL = elements.allocate("MODPK", "FUEL")

elements.element(elements.MODPK_PT_FUEL, elements.element(elements.DEFAULT_PT_DESL))
elements.property(elements.MODPK_PT_FUEL, "Name", "FUEL")
elements.property(elements.MODPK_PT_FUEL, "Description", "Simple fuel. Burns faster than LPG and slower than PB95.")
elements.property(elements.MODPK_PT_FUEL, "Colour", 0xdb9c1e)
elements.property(elements.MODPK_PT_FUEL, "MenuSection", 7)

--elements.property(elements.MODPK_PT_FUEL, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_FUEL, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_FUEL, "Flammable", 3)
elements.property(elements.MODPK_PT_FUEL, "Explosive", 0)
elements.property(elements.MODPK_PT_FUEL, "Weight", 3)

elements.property(elements.MODPK_PT_FUEL, "Properties", TYPE_LIQUID)
elements.property(elements.MODPK_PT_FUEL, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_FUEL, "HighTemperatureTransition", NT)
elements.property(elements.MODPK_PT_FUEL, "HighPressureTransition", NT)
elements.property(elements.MODPK_PT_FUEL, "LowPressureTransition", NT)
elements.property(elements.MODPK_PT_FUEL, "HeatConduct", 10)
local ALUM = elements.allocate("MODPK", "ALUM")

elements.element(elements.MODPK_PT_ALUM, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_ALUM, "Name", "ALUM")
elements.property(
    elements.MODPK_PT_ALUM,
    "Description",
    "Aluminium, Has capability of storing heat and conducts heat pretty well. Is not resistant to corrosions."
)
elements.property(elements.MODPK_PT_ALUM, "Colour", 0xADB2BD)
elements.property(elements.MODPK_PT_ALUM, "MenuSection", 9)

elements.property(elements.MODPK_PT_ALUM, "Meltable", 1)
elements.property(elements.MODPK_PT_ALUM, "Hardness", 25)

elements.property(elements.MODPK_PT_ALUM, "Properties", TYPE_SOLID)
elements.property(elements.MODPK_PT_ALUM, "State", ST_SOLID)
elements.property(elements.MODPK_PT_ALUM, "Temperature", 295.15)
elements.property(elements.MODPK_PT_ALUM, "HeatConduct", 185)
elements.property(elements.MODPK_PT_ALUM, "HighTemperature", 1373.15)
elements.property(elements.MODPK_PT_ALUM, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local LION = elements.allocate("MODPK", "LION")

elements.element(elements.MODPK_PT_LION, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_LION, "Name", "LION")
elements.property(
    elements.MODPK_PT_LION,
    "Description",
    "Lithium Ion cell. PSCN to charge, NSCN to take. Heats up when used. Charge range is set by tmp."
)
elements.property(elements.MODPK_PT_LION, "Colour", 0x6be58e)
elements.property(elements.MODPK_PT_LION, "MenuSection", 1)

elements.property(elements.MODPK_PT_LION, "Meltable", 10)
elements.property(elements.MODPK_PT_LION, "Hardness", 5)

elements.property(elements.MODPK_PT_LION, "Properties", TYPE_SOLID)
elements.property(elements.MODPK_PT_LION, "State", ST_SOLID)
elements.property(elements.MODPK_PT_LION, "Temperature", 295.15)
elements.property(elements.MODPK_PT_LION, "HeatConduct", 185)

elements.property(elements.MODPK_PT_LION, "HighTemperatureTransition", NT)

local PSTC = elements.allocate("MODPK", "PSTC")
elements.element(elements.MODPK_PT_PSTC, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_PSTC, "Name", "PSTC")
elements.property(elements.MODPK_PT_PSTC, "Description", "Plastic. Resists some of the heat, but melts at a low point.")
elements.property(elements.MODPK_PT_PSTC, "Colour", 0xe5e2e2)
elements.property(elements.MODPK_PT_PSTC, "Weight", 90)

elements.property(elements.MODPK_PT_PSTC, "Meltable", 1)
elements.property(elements.MODPK_PT_PSTC, "Hardness", 30)

elements.property(elements.MODPK_PT_PSTC, "Properties", 0)
elements.property(elements.MODPK_PT_PSTC, "State", ST_SOLID)
elements.property(elements.MODPK_PT_PSTC, "Temperature", 295.15)
elements.property(elements.MODPK_PT_PSTC, "HeatConduct", 70)
elements.property(elements.MODPK_PT_PSTC, "HighTemperature", 550.15)
elements.property(elements.MODPK_PT_PSTC, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local SLCN = elements.allocate("MODPK", "SLCN")
elements.element(elements.MODPK_PT_SLCN, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_SLCN, "Name", "SLCN")
elements.property(elements.MODPK_PT_SLCN, "Description", "Silicon. A material with an intermediate melting point.")
elements.property(elements.MODPK_PT_SLCN, "Colour", 0x111111)
elements.property(elements.MODPK_PT_SLCN, "Weight", 90)

elements.property(elements.MODPK_PT_SLCN, "Meltable", 1)
elements.property(elements.MODPK_PT_SLCN, "Hardness", 30)

elements.property(elements.MODPK_PT_SLCN, "Properties", 0)
elements.property(elements.MODPK_PT_SLCN, "State", ST_SOLID)
elements.property(elements.MODPK_PT_SLCN, "Temperature", 295.15)
elements.property(elements.MODPK_PT_SLCN, "HeatConduct", 70)
local LSCN = elements.allocate("MODPK", "LSCN")
elements.element(elements.MODPK_PT_LSCN, elements.element(elements.DEFAULT_PT_GEL))
elements.property(elements.MODPK_PT_LSCN, "Name", "LSCN")
elements.property(elements.MODPK_PT_LSCN, "Description", "Liquid Silicon.")
elements.property(elements.MODPK_PT_LSCN, "Colour", 0x222222)

elements.property(elements.MODPK_PT_LSCN, "Weight", 99)

elements.property(elements.MODPK_PT_LSCN, "Hardness", 30)

elements.property(elements.MODPK_PT_LSCN, "Properties", TYPE_LIQUID)
elements.property(elements.MODPK_PT_LSCN, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_LSCN, "Temperature", 328.15)
elements.property(elements.MODPK_PT_LSCN, "HeatConduct", 70)
elements.property(elements.MODPK_PT_LSCN, "LowTemperature", 285.15)
elements.property(elements.MODPK_PT_LSCN, "LowTemperatureTransition", elements.MODPK_PT_SLCN)

local PTDP = elements.allocate("MODPK", "PTDP")
elements.element(elements.MODPK_PT_PTDP, elements.element(elements.DEFAULT_PT_GEL))
elements.property(elements.MODPK_PT_PTDP, "Name", "PTDP")
elements.property(
    elements.MODPK_PT_PTDP,
    "Description",
    "P-Type Doping Material. On contact with Silicon will turn it to PSCN."
)
elements.property(elements.MODPK_PT_PTDP, "Colour", 0x892222)
elements.property(elements.MODPK_PT_PTDP, "Weight", 20)

elements.property(elements.MODPK_PT_PTDP, "Properties", 0)
elements.property(elements.MODPK_PT_PTDP, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_PTDP, "Temperature", 295.15)
elements.property(elements.MODPK_PT_PTDP, "HeatConduct", 70)
local NTDP = elements.allocate("MODPK", "NTDP")
elements.element(elements.MODPK_PT_NTDP, elements.element(elements.DEFAULT_PT_GEL))
elements.property(elements.MODPK_PT_NTDP, "Name", "NTDP")
elements.property(
    elements.MODPK_PT_NTDP,
    "Description",
    "N-Type Doping Material. On contact with Silicon will turn it to NSCN."
)
elements.property(elements.MODPK_PT_NTDP, "Weight", 20)
elements.property(elements.MODPK_PT_NTDP, "Colour", 0x23528c)

elements.property(elements.MODPK_PT_NTDP, "Hardness", 30)

elements.property(elements.MODPK_PT_NTDP, "Properties", 0)
elements.property(elements.MODPK_PT_NTDP, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_NTDP, "Temperature", 295.15)
elements.property(elements.MODPK_PT_NTDP, "HeatConduct", 70)
local GLIM = elements.allocate("MODPK", "GLIM")
elements.element(elements.MODPK_PT_GLIM, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_GLIM, "Name", "GLIM")
elements.property(elements.MODPK_PT_GLIM, "Description", "Gallium. A metal with a low melting point.")
elements.property(elements.MODPK_PT_GLIM, "Colour", 0xBFC1C2)

elements.property(elements.MODPK_PT_GLIM, "Weight", 90)

elements.property(elements.MODPK_PT_GLIM, "Meltable", 1)
elements.property(elements.MODPK_PT_GLIM, "Hardness", 30)

elements.property(elements.MODPK_PT_GLIM, "Properties", 0)
elements.property(elements.MODPK_PT_GLIM, "State", ST_SOLID)
elements.property(elements.MODPK_PT_GLIM, "Temperature", 295.15)
elements.property(elements.MODPK_PT_GLIM, "HeatConduct", 70)
elements.property(elements.MODPK_PT_GLIM, "HighTemperature", 305.15)
elements.property(elements.MODPK_PT_GLIM, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local RHDM = elements.allocate("MODPK", "RHDM")
elements.element(elements.MODPK_PT_RHDM, elements.element(elements.DEFAULT_PT_QRTZ))
elements.property(elements.MODPK_PT_RHDM, "Name", "RHDM")
elements.property(
    elements.MODPK_PT_RHDM,
    "Description",
    "Rhodium! The most rare material. Reflects photons and has a high melting point."
)
elements.property(elements.MODPK_PT_RHDM, "Colour", 0xC0C0C0)

elements.property(elements.MODPK_PT_RHDM, "Weight", 60)

elements.property(elements.MODPK_PT_RHDM, "Meltable", 1)
elements.property(elements.MODPK_PT_RHDM, "Hardness", 0)

elements.property(elements.MODPK_PT_RHDM, "Properties", elem.PROP_NEUTPENETRATE)
elements.property(elements.MODPK_PT_RHDM, "State", ST_SOLID)
elements.property(elements.MODPK_PT_RHDM, "Temperature", 295.15)
elements.property(elements.MODPK_PT_RHDM, "HeatConduct", 240)
elements.property(elements.MODPK_PT_RHDM, "HighTemperature", 2237)
elements.property(elements.MODPK_PT_RHDM, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local PLTM = elements.allocate("MODPK", "PLTM")
elements.element(elements.MODPK_PT_PLTM, elements.element(elements.DEFAULT_PT_QRTZ))
elements.property(elements.MODPK_PT_PLTM, "Name", "PLTM")
elements.property(elements.MODPK_PT_PLTM, "Description", "Platinum. Resists corrosions.")
elements.property(elements.MODPK_PT_PLTM, "Colour", 0xE5E4E2)

elements.property(elements.MODPK_PT_PLTM, "Weight", 85)

elements.property(elements.MODPK_PT_PLTM, "Meltable", 1)
elements.property(elements.MODPK_PT_PLTM, "Hardness", 0)

elements.property(elements.MODPK_PT_PLTM, "Properties", elem.PROP_NEUTPENETRATE)
elements.property(elements.MODPK_PT_PLTM, "State", ST_SOLID)
elements.property(elements.MODPK_PT_PLTM, "Temperature", 295.15)
elements.property(elements.MODPK_PT_PLTM, "HeatConduct", 100)
elements.property(elements.MODPK_PT_PLTM, "HighTemperature", 2041.4)
elements.property(elements.MODPK_PT_PLTM, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local RTHM = elements.allocate("MODPK", "RTHM")
elements.element(elements.MODPK_PT_RTHM, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_RTHM, "Name", "RTHM")
elements.property(elements.MODPK_PT_RTHM, "Description", "Ruthenium. A good conductor with a high melting point.")
elements.property(elements.MODPK_PT_RTHM, "Colour", 0xC9CBC8)

elements.property(elements.MODPK_PT_RTHM, "Weight", 90)

elements.property(elements.MODPK_PT_RTHM, "Meltable", 1)
elements.property(elements.MODPK_PT_RTHM, "Hardness", 0)

elements.property(elements.MODPK_PT_RTHM, "State", ST_SOLID)
elements.property(elements.MODPK_PT_RTHM, "Temperature", 295.15)
elements.property(elements.MODPK_PT_RTHM, "HeatConduct", 220)
elements.property(elements.MODPK_PT_RTHM, "HighTemperature", 2607)
elements.property(elements.MODPK_PT_RTHM, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local AND = elements.allocate("MODPK", "AND")
elements.element(elements.MODPK_PT_AND, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_AND, "Name", "AND")
elements.property(
    elements.MODPK_PT_AND,
    "Description",
    "AND gate. PSCN are the 2 inputs, and NSCN is the output. When both inputs are on, the output is on."
)
elements.property(elements.MODPK_PT_AND, "Colour", 0x383838)
elements.property(elements.MODPK_PT_AND, "MenuSection", 2)
elements.property(elements.MODPK_PT_AND, "Weight", 90)

elements.property(elements.MODPK_PT_AND, "Meltable", 1)
elements.property(elements.MODPK_PT_AND, "Hardness", 0)

elements.property(elements.MODPK_PT_AND, "State", ST_SOLID)
elements.property(elements.MODPK_PT_AND, "Temperature", 295.15)
elements.property(elements.MODPK_PT_AND, "HeatConduct", 220)
elements.property(elements.MODPK_PT_AND, "HighTemperature", 99999)
elements.property(elements.MODPK_PT_AND, "HighTemperatureTransition", NT)
local OR = elements.allocate("MODPK", "OR")
elements.element(elements.MODPK_PT_OR, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_OR, "Name", "OR")
elements.property(
    elements.MODPK_PT_OR,
    "Description",
    "OR gate. PSCN are the 2 inputs, and NSCN is the output. When any input is on, the output is on."
)
elements.property(elements.MODPK_PT_OR, "Colour", 0x3D3D3D)
elements.property(elements.MODPK_PT_OR, "MenuSection", 2)
elements.property(elements.MODPK_PT_OR, "Weight", 90)

elements.property(elements.MODPK_PT_OR, "Meltable", 1)
elements.property(elements.MODPK_PT_OR, "Hardness", 0)

elements.property(elements.MODPK_PT_OR, "State", ST_SOLID)
elements.property(elements.MODPK_PT_OR, "Temperature", 295.15)
elements.property(elements.MODPK_PT_OR, "HeatConduct", 220)
elements.property(elements.MODPK_PT_OR, "HighTemperature", 99999)
elements.property(elements.MODPK_PT_OR, "HighTemperatureTransition", NT)
local XOR = elements.allocate("MODPK", "XOR")
elements.element(elements.MODPK_PT_XOR, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_XOR, "Name", "XOR")
elements.property(
    elements.MODPK_PT_XOR,
    "Description",
    "XOR gate. PSCN are the 2 inputs, and NSCN is the output. When only one input is on, the output is on."
)
elements.property(elements.MODPK_PT_XOR, "Colour", 0x444444)
elements.property(elements.MODPK_PT_XOR, "MenuSection", 2)
elements.property(elements.MODPK_PT_XOR, "Weight", 90)

elements.property(elements.MODPK_PT_XOR, "Meltable", 1)
elements.property(elements.MODPK_PT_XOR, "Hardness", 0)

elements.property(elements.MODPK_PT_XOR, "State", ST_SOLID)
elements.property(elements.MODPK_PT_XOR, "Temperature", 295.15)
elements.property(elements.MODPK_PT_XOR, "HeatConduct", 220)
elements.property(elements.MODPK_PT_XOR, "HighTemperature", 99999)
elements.property(elements.MODPK_PT_XOR, "HighTemperatureTransition", NT)
local NAND = elements.allocate("MODPK", "NAND")
elements.element(elements.MODPK_PT_NAND, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_NAND, "Name", "NAND")
elements.property(
    elements.MODPK_PT_NAND,
    "Description",
    "NAND gate. PSCN are the 2 inputs, and NSCN is the output. When both inputs are on, the output is off."
)
elements.property(elements.MODPK_PT_NAND, "Colour", 0x4C4C4C)
elements.property(elements.MODPK_PT_NAND, "MenuSection", 2)
elements.property(elements.MODPK_PT_NAND, "Weight", 90)

elements.property(elements.MODPK_PT_NAND, "Meltable", 1)
elements.property(elements.MODPK_PT_NAND, "Hardness", 0)

elements.property(elements.MODPK_PT_NAND, "State", ST_SOLID)
elements.property(elements.MODPK_PT_NAND, "Temperature", 295.15)
elements.property(elements.MODPK_PT_NAND, "HeatConduct", 220)
elements.property(elements.MODPK_PT_NAND, "HighTemperature", 99999)
elements.property(elements.MODPK_PT_NAND, "HighTemperatureTransition", NT)
local NOR = elements.allocate("MODPK", "NOR")
elements.element(elements.MODPK_PT_NOR, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_NOR, "Name", "NOR")
elements.property(
    elements.MODPK_PT_NOR,
    "Description",
    "NOR gate. PSCN are the 2 inputs, and NSCN is the output. When any input is on, the output is off."
)
elements.property(elements.MODPK_PT_NOR, "Colour", 0x525252)
elements.property(elements.MODPK_PT_NOR, "MenuSection", 2)
elements.property(elements.MODPK_PT_NOR, "Weight", 90)

elements.property(elements.MODPK_PT_NOR, "Meltable", 1)
elements.property(elements.MODPK_PT_NOR, "Hardness", 0)

elements.property(elements.MODPK_PT_NOR, "State", ST_SOLID)
elements.property(elements.MODPK_PT_NOR, "Temperature", 295.15)
elements.property(elements.MODPK_PT_NOR, "HeatConduct", 220)
elements.property(elements.MODPK_PT_NOR, "HighTemperature", 99999)
elements.property(elements.MODPK_PT_NOR, "HighTemperatureTransition", NT)
local XNOR = elements.allocate("MODPK", "XNOR")
elements.element(elements.MODPK_PT_XNOR, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_XNOR, "Name", "XNOR")
elements.property(
    elements.MODPK_PT_XNOR,
    "Description",
    "XNOR gate. PSCN are the 2 inputs, and NSCN is the output. When both or no inputs are on, the output is on."
)
elements.property(elements.MODPK_PT_XNOR, "Colour", 0x505050)
elements.property(elements.MODPK_PT_XNOR, "MenuSection", 2)
elements.property(elements.MODPK_PT_XNOR, "Weight", 90)

elements.property(elements.MODPK_PT_XNOR, "Meltable", 1)
elements.property(elements.MODPK_PT_XNOR, "Hardness", 0)

elements.property(elements.MODPK_PT_XNOR, "State", ST_SOLID)
elements.property(elements.MODPK_PT_XNOR, "Temperature", 295.15)
elements.property(elements.MODPK_PT_XNOR, "HeatConduct", 220)
elements.property(elements.MODPK_PT_XNOR, "HighTemperature", 99999)
elements.property(elements.MODPK_PT_XNOR, "HighTemperatureTransition", NT)
local EFSE = elements.allocate("MODPK", "EFSE")
elements.element(elements.MODPK_PT_EFSE, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.MODPK_PT_EFSE, "Name", "EFSE")
elements.property(
    elements.MODPK_PT_EFSE,
    "Description",
    "E-fuse. Conducts from PSCN to NSCN, but when sparked with METL then it is irreversibly non-conductive."
)
elements.property(elements.MODPK_PT_EFSE, "Colour", 0x383838)
elements.property(elements.MODPK_PT_EFSE, "MenuSection", 2)
elements.property(elements.MODPK_PT_EFSE, "Weight", 90)

elements.property(elements.MODPK_PT_EFSE, "Meltable", 1)
elements.property(elements.MODPK_PT_EFSE, "Hardness", 0)

elements.property(elements.MODPK_PT_EFSE, "State", ST_SOLID)
elements.property(elements.MODPK_PT_EFSE, "Temperature", 295.15)
elements.property(elements.MODPK_PT_EFSE, "HeatConduct", 220)
elements.property(elements.MODPK_PT_EFSE, "HighTemperature", 99999)
elements.property(elements.MODPK_PT_EFSE, "HighTemperatureTransition", NT)
local IRDM = elements.allocate("MODPK", "IRDM")
elements.element(elements.MODPK_PT_IRDM, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_IRDM, "Name", "IRDM")
elements.property(
    elements.MODPK_PT_IRDM,
    "Description",
    "Iridium. Corrosion resistant and has a super high melting point."
)
elements.property(elements.MODPK_PT_IRDM, "Colour", 0xc6ccc6)

elements.property(elements.MODPK_PT_IRDM, "Weight", 80)

elements.property(elements.MODPK_PT_IRDM, "Meltable", 1)
elements.property(elements.MODPK_PT_IRDM, "Hardness", 5)

elements.property(elements.MODPK_PT_IRDM, "State", ST_SOLID)
elements.property(elements.MODPK_PT_IRDM, "Temperature", 295.15)
elements.property(elements.MODPK_PT_IRDM, "HeatConduct", 180)
elements.property(elements.MODPK_PT_IRDM, "HighTemperature", 2719)
elements.property(elements.MODPK_PT_IRDM, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local OSIM = elements.allocate("MODPK", "OSIM")
elements.element(elements.MODPK_PT_OSIM, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_OSIM, "Name", "OSIM")
elements.property(elements.MODPK_PT_OSIM, "Description", "Osmium. A conductor with an extremely high melting point.")
elements.property(elements.MODPK_PT_OSIM, "Colour", 0x9090A3)

elements.property(elements.MODPK_PT_OSIM, "Weight", 95)

elements.property(elements.MODPK_PT_OSIM, "Meltable", 1)
elements.property(elements.MODPK_PT_OSIM, "Hardness", 10)

elements.property(elements.MODPK_PT_OSIM, "State", ST_SOLID)
elements.property(elements.MODPK_PT_OSIM, "Temperature", 295.15)
elements.property(elements.MODPK_PT_OSIM, "HeatConduct", 200)
elements.property(elements.MODPK_PT_OSIM, "HighTemperature", 3306)
elements.property(elements.MODPK_PT_OSIM, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local SILV = elements.allocate("MODPK", "SILV")
elements.element(elements.MODPK_PT_SILV, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_SILV, "Name", "SILV")
elements.property(
    elements.MODPK_PT_SILV,
    "Description",
    "Silver. A thermal and electric conductor with an intermediate melting point."
)
elements.property(elements.MODPK_PT_SILV, "Colour", 0x757575)

elements.property(elements.MODPK_PT_SILV, "Weight", 60)

elements.property(elements.MODPK_PT_SILV, "Meltable", 1)
elements.property(elements.MODPK_PT_SILV, "Hardness", 5)

elements.property(elements.MODPK_PT_SILV, "State", ST_SOLID)
elements.property(elements.MODPK_PT_SILV, "Temperature", 295.15)
elements.property(elements.MODPK_PT_SILV, "HeatConduct", 250)
elements.property(elements.MODPK_PT_SILV, "HighTemperature", 1234.93)
elements.property(elements.MODPK_PT_SILV, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local SPHR = elements.allocate("MODPK", "SPHR")
elements.element(elements.MODPK_PT_SPHR, elements.element(elements.DEFAULT_PT_GLAS))
elements.property(elements.MODPK_PT_SPHR, "Name", "SPHR")
elements.property(
    elements.MODPK_PT_SPHR,
    "Description",
    "Sapphire. A very hard, corrosion resistant crystal with a high melting point."
)
elements.property(elements.MODPK_PT_SPHR, "Colour", 0x0F52BA)

elements.property(elements.MODPK_PT_SPHR, "Weight", 60)

elements.property(elements.MODPK_PT_SPHR, "Meltable", 1)
elements.property(elements.MODPK_PT_SPHR, "Hardness", 0)

elements.property(elements.MODPK_PT_SPHR, "State", ST_SOLID)
elements.property(elements.MODPK_PT_SPHR, "Temperature", 295.15)
elements.property(elements.MODPK_PT_SPHR, "HeatConduct", 100)
elements.property(elements.MODPK_PT_SPHR, "HighTemperature", 2323.15)
elements.property(elements.MODPK_PT_SPHR, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local NEPT = elements.allocate("MODPK", "NEPT")
elements.element(elements.MODPK_PT_NEPT, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.MODPK_PT_NEPT, "Name", "NEPT")
elements.property(elements.MODPK_PT_NEPT, "Description", "Neptunium. Decays into electrons and heats up.")
elements.property(elements.MODPK_PT_NEPT, "Colour", 0x551A8B)

elements.property(elements.MODPK_PT_NEPT, "Weight", 70)
elements.property(elements.MODPK_PT_NEPT, "Properties", elem.PROP_CONDUCTS)
elements.property(elements.MODPK_PT_NEPT, "Meltable", 1)
elements.property(elements.MODPK_PT_NEPT, "Hardness", 5)
elements.property(elements.MODPK_PT_NEPT, "MenuSection", 10)
elements.property(elements.MODPK_PT_NEPT, "State", ST_SOLID)
elements.property(elements.MODPK_PT_NEPT, "Temperature", 295.15)
elements.property(elements.MODPK_PT_NEPT, "HeatConduct", 250)
elements.property(elements.MODPK_PT_NEPT, "HighTemperature", 917)
elements.property(elements.MODPK_PT_NEPT, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local PWRN = elements.allocate("MODPK", "PWRN")
elements.element(elements.MODPK_PT_PWRN, elements.element(elements.DEFAULT_PT_POLO))
elements.property(elements.MODPK_PT_PWRN, "Name", "PWRN")
elements.property(elements.MODPK_PT_PWRN, "Description", "Powdered Neptunium.")
elements.property(elements.MODPK_PT_PWRN, "Colour", 0x752AAB)

elements.property(elements.MODPK_PT_PWRN, "Weight", 30)
elements.property(elements.MODPK_PT_PWRN, "Properties", elem.PROP_CONDUCTS)
elements.property(elements.MODPK_PT_PWRN, "Meltable", 1)
elements.property(elements.MODPK_PT_PWRN, "Hardness", 5)
elements.property(elements.MODPK_PT_PWRN, "MenuSection", 10)
elements.property(elements.MODPK_PT_PWRN, "State", ST_POWDER)
elements.property(elements.MODPK_PT_PWRN, "Temperature", 295.15)
elements.property(elements.MODPK_PT_PWRN, "HeatConduct", 250)
elements.property(elements.MODPK_PT_PWRN, "HighTemperature", 917)
elements.property(elements.MODPK_PT_PWRN, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
local SODA = elements.allocate("MODPK", "SODA")

elements.element(elements.MODPK_PT_SODA, elements.element(elements.DEFAULT_PT_DUST))
elements.property(elements.MODPK_PT_SODA, "Name", "SODA")
elements.property(
    elements.MODPK_PT_SODA,
    "Description",
    "Soda. When mixed with vinegar under high temperature, will produce acidic powder."
)
elements.property(elements.MODPK_PT_SODA, "Colour", 0xFDFDFD)
elements.property(elements.MODPK_PT_SODA, "MenuSection", 8)

--elements.property(elements.MODPK_PT_SODA, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_SODA, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_SODA, "Weight", 15)

elements.property(elements.MODPK_PT_SODA, "Meltable", 0)
elements.property(elements.MODPK_PT_SODA, "Hardness", 25)

elements.property(elements.MODPK_PT_SODA, "Properties", TYPE_POWDER)
elements.property(elements.MODPK_PT_SODA, "State", ST_POWDER)
elements.property(elements.MODPK_PT_SODA, "HeatConduct", 254)

local HYPX = elements.allocate("MODPK", "HYPX")

elements.element(elements.MODPK_PT_HYPX, elements.element(elements.DEFAULT_PT_WATR))
elements.property(elements.MODPK_PT_HYPX, "Name", "HYPX")
elements.property(
    elements.MODPK_PT_HYPX,
    "Description",
    "Hydrogen peroxide. Made out of water and oxygen infusion. Reacts with plants."
)
elements.property(elements.MODPK_PT_HYPX, "Colour", 0xbfe7ff)
elements.property(elements.MODPK_PT_HYPX, "MenuSection", 7)

--elements.property(elements.MODPK_PT_HYPX, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_HYPX, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_HYPX, "Weight", 10)

elements.property(elements.MODPK_PT_HYPX, "Meltable", 0)
elements.property(elements.MODPK_PT_HYPX, "Hardness", 15)

elements.property(elements.MODPK_PT_HYPX, "Properties", TYPE_LIQUID)
elements.property(elements.MODPK_PT_HYPX, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_HYPX, "HeatConduct", 70)

local DTRG = elements.allocate("MODPK", "DTRG")

elements.element(elements.MODPK_PT_DTRG, elements.element(elements.DEFAULT_PT_STNE))
elements.property(elements.MODPK_PT_DTRG, "Name", "DTRG")
elements.property(elements.MODPK_PT_DTRG, "Description", "Detergent. Cures virus. Good for making pools.")
elements.property(elements.MODPK_PT_DTRG, "Colour", 0xFAFAFA)
elements.property(elements.MODPK_PT_DTRG, "MenuSection", 8)

--elements.property(elements.MODPK_PT_DTRG, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_DTRG, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_DTRG, "Meltable", 0)

elements.property(elements.MODPK_PT_DTRG, "Properties", TYPE_POWDER)
elements.property(elements.MODPK_PT_DTRG, "State", ST_POWDER)
elements.property(elements.MODPK_PT_DTRG, "HeatConduct", 100)

local DTRW = elements.allocate("MODPK", "DTRW")

elements.element(elements.MODPK_PT_DTRW, elements.element(elements.DEFAULT_PT_WATR))
elements.property(elements.MODPK_PT_DTRW, "Name", "DTRW")
elements.property(elements.MODPK_PT_DTRW, "Description", "Water with detergent dissolved in it.")
elements.property(elements.MODPK_PT_DTRW, "Colour", 0x71a6c6)
elements.property(elements.MODPK_PT_DTRW, "MenuSection", 7)

--elements.property(elements.MODPK_PT_DTRW, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_DTRW, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_DTRW, "Weight", 5)

elements.property(elements.MODPK_PT_DTRW, "Properties", TYPE_LIQUID)
elements.property(elements.MODPK_PT_DTRW, "State", ST_LIQUID)
elements.property(elements.MODPK_PT_DTRW, "HeatConduct", 100)
local VNGR = elements.allocate("MODPK", "VNGR")

elements.element(elements.MODPK_PT_VNGR, elements.element(elements.DEFAULT_PT_DUST))
elements.property(elements.MODPK_PT_VNGR, "Name", "VNGR")
elements.property(
    elements.MODPK_PT_VNGR,
    "Description",
    "Vinegar. When mixed with soda under high temperature, will produce acidic powder."
)
elements.property(elements.MODPK_PT_VNGR, "Colour", 0xFDFDFD)
elements.property(elements.MODPK_PT_VNGR, "MenuSection", 8)

--elements.property(elements.MODPK_PT_VNGR, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_VNGR, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_VNGR, "Weight", 15)

elements.property(elements.MODPK_PT_VNGR, "Meltable", 0)
elements.property(elements.MODPK_PT_VNGR, "Hardness", 25)

elements.property(elements.MODPK_PT_VNGR, "Properties", TYPE_POWDER)
elements.property(elements.MODPK_PT_VNGR, "State", ST_POWDER)
elements.property(elements.MODPK_PT_VNGR, "HeatConduct", 254)

local ADPR = elements.allocate("MODPK", "ADPR")

elements.element(elements.MODPK_PT_ADPR, elements.element(elements.DEFAULT_PT_DUST))
elements.property(elements.MODPK_PT_ADPR, "Name", "ADPR")
elements.property(elements.MODPK_PT_ADPR, "Description", "Acidic powder, with distilled water will turn into acid.")
elements.property(elements.MODPK_PT_ADPR, "Colour", 0xf9b6dd)
elements.property(elements.MODPK_PT_ADPR, "MenuSection", 8)

--elements.property(elements.MODPK_PT_ADPR, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_ADPR, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_ADPR, "Weight", 15)

elements.property(elements.MODPK_PT_ADPR, "Meltable", 0)
elements.property(elements.MODPK_PT_ADPR, "Hardness", 0)

elements.property(elements.MODPK_PT_ADPR, "Properties", TYPE_POWDER)
elements.property(elements.MODPK_PT_ADPR, "State", ST_POWDER)
elements.property(elements.MODPK_PT_ADPR, "HeatConduct", 254)

local HYGO2 = elements.allocate("MODPK", "HYGO2")

elements.element(elements.MODPK_PT_HYGO2, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.MODPK_PT_HYGO2, "Name", "HYGO2")
elements.property(elements.MODPK_PT_HYGO2, "Description", "Hydrogen and oxygen mix. Used to make hydrogen peroxide.")
elements.property(elements.MODPK_PT_HYGO2, "Colour", 0x2387c4)
elements.property(elements.MODPK_PT_HYGO2, "MenuSection", 6)

--elements.property(elements.MODPK_PT_HYGO2, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_HYGO2, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_HYGO2, "Hardness", 10)

elements.property(elements.MODPK_PT_HYGO2, "Properties", elem.TYPE_GAS)
elements.property(elements.MODPK_PT_HYGO2, "State", ST_GAS)
elements.property(elements.MODPK_PT_HYGO2, "HeatConduct", 50)
local GHSE = elements.allocate("MODPK", "GHSE")

elements.element(elements.MODPK_PT_GHSE, elements.element(elements.DEFAULT_PT_CO2))
elements.property(elements.MODPK_PT_GHSE, "Name", "GHSE")
elements.property(
    elements.MODPK_PT_GHSE,
    "Description",
    "Greenhouse gas. Captures ambient heat and immediately conducts. Has a small chance to trap energy particles."
)
elements.property(elements.MODPK_PT_GHSE, "Colour", 0x64FE7173)
elements.property(elements.MODPK_PT_GHSE, "MenuSection", 6)

--elements.property(elements.MODPK_PT_GHSE, "AirLoss", 0.3)
--elements.property(elements.MODPK_PT_GHSE, "AirDrag", 0.003)
elements.property(elements.MODPK_PT_GHSE, "Hardness", 0)

elements.property(elements.MODPK_PT_GHSE, "Properties", elem.TYPE_GAS)
elements.property(elements.MODPK_PT_GHSE, "State", ST_GAS)
elements.property(elements.MODPK_PT_GHSE, "HeatConduct", 255)
local RS5 = elements.allocate("MODPK", "RS-5")
elements.element(RS5, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(RS5, "Name", "RS-5")
elements.property(RS5, "Description", "Resistor (value 5). Counducts 0.25x less sparks. Follows some of the GOL rules.")
elements.property(RS5, "Colour", 0xf7eeb7)
elements.property(RS5, "MenuSection", 1)
elements.property(RS5, "Hardness", 0)

elements.property(RS5, "Properties", TYPE_SOLID)
elements.property(RS5, "State", ST_SOLID)
elements.property(RS5, "HeatConduct", 225)
local RS6 = elements.allocate("MODPK", "RS-6")
elements.element(RS6, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(RS6, "Name", "RS-6")
elements.property(RS6, "Description", "Resistor (value 6). Counducts 0.5x less sparks. Follows some of the GOL rules.")
elements.property(RS6, "Colour", 0xf7eeb7)
elements.property(RS6, "MenuSection", 1)
elements.property(RS6, "Hardness", 0)

elements.property(RS6, "Properties", TYPE_SOLID)
elements.property(RS6, "State", ST_SOLID)
elements.property(RS6, "HeatConduct", 225)
local RS7 = elements.allocate("MODPK", "RS-7")
elements.element(RS7, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(RS7, "Name", "RS-7")
elements.property(RS7, "Description", "Resistor (value 7). Counducts 0.75x less sparks. Follows some of the GOL rules.")
elements.property(RS7, "Colour", 0xf7eeb7)
elements.property(RS7, "MenuSection", 1)
elements.property(RS7, "Hardness", 0)

elements.property(RS7, "Properties", TYPE_SOLID)
elements.property(RS7, "State", ST_SOLID)
elements.property(RS7, "HeatConduct", 225)
local RS8 = elements.allocate("MODPK", "RS-8")
elements.element(RS8, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(RS8, "Name", "RS-8")
elements.property(RS8, "Description", "Resistor (value 8). Counducts 1x less sparks. Follows some of the GOL rules.")
elements.property(RS8, "Colour", 0xf7eeb7)
elements.property(RS8, "MenuSection", 1)
elements.property(RS8, "Hardness", 0)

elements.property(RS8, "Properties", TYPE_SOLID)
elements.property(RS8, "State", ST_SOLID)
elements.property(RS8, "HeatConduct", 225)
local RSCT = elements.allocate("MODPK", "RSCT")
elements.element(RSCT, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(RSCT, "Name", "RSCT")
elements.property(RSCT, "Description", "Custom resistor. Set it's resistance by tmp2. Follows some of the GOL rules.")
elements.property(RSCT, "Colour", 0xf7eeb7)
elements.property(RSCT, "MenuSection", 1)
elements.property(RSCT, "Hardness", 0)

elements.property(RSCT, "Properties", TYPE_SOLID)
elements.property(RSCT, "State", ST_SOLID)
elements.property(RSCT, "HeatConduct", 225)
local CP4 = elements.allocate("MODPK", "CP-4")
elements.element(CP4, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(CP4, "Name", "CP-4")
elements.property(CP4, "Description", "Capacitor (value 4). Stores energy when sparked, and releases it to NSCN.")
elements.property(CP4, "Colour", 0xb7b7b7)
elements.property(CP4, "MenuSection", 1)
elements.property(CP4, "Hardness", 0)

elements.property(CP4, "Properties", TYPE_SOLID)
elements.property(CP4, "State", ST_SOLID)
elements.property(CP4, "HeatConduct", 225)
local CP5 = elements.allocate("MODPK", "CP-5")
elements.element(CP5, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(CP5, "Name", "CP-5")
elements.property(CP5, "Description", "Capacitor (value 5). Stores energy when sparked, and releases it to NSCN.")
elements.property(CP5, "Colour", 0xb7b7b7)
elements.property(CP5, "MenuSection", 1)
elements.property(CP5, "Hardness", 0)

elements.property(CP5, "Properties", TYPE_SOLID)
elements.property(CP5, "State", ST_SOLID)
elements.property(CP5, "HeatConduct", 225)
local CP6 = elements.allocate("MODPK", "CP-6")
elements.element(CP6, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(CP6, "Name", "CP-6")
elements.property(CP6, "Description", "Capacitor (value 6). Stores energy when sparked, and releases it to NSCN.")
elements.property(CP6, "Colour", 0xb7b7b7)
elements.property(CP6, "MenuSection", 1)
elements.property(CP6, "Hardness", 0)

elements.property(CP6, "Properties", TYPE_SOLID)
elements.property(CP6, "State", ST_SOLID)
elements.property(CP6, "HeatConduct", 225)
local CP7 = elements.allocate("MODPK", "CP-7")
elements.element(CP7, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(CP7, "Name", "CP-7")
elements.property(CP7, "Description", "Capacitor (value 7). Stores energy when sparked, and releases it to NSCN.")
elements.property(CP7, "Colour", 0xb7b7b7)
elements.property(CP7, "MenuSection", 1)
elements.property(CP7, "Hardness", 0)

elements.property(CP7, "Properties", TYPE_SOLID)
elements.property(CP7, "State", ST_SOLID)
elements.property(CP7, "HeatConduct", 225)
local CP8 = elements.allocate("MODPK", "CP-8")
elements.element(CP8, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(CP8, "Name", "CP-8")
elements.property(CP8, "Description", "Capacitor (value 8). Stores energy when sparked, and releases it to NSCN.")
elements.property(CP8, "Colour", 0xb7b7b7)
elements.property(CP8, "MenuSection", 1)
elements.property(CP8, "Hardness", 0)

elements.property(CP8, "Properties", TYPE_SOLID)
elements.property(CP8, "State", ST_SOLID)
elements.property(CP8, "HeatConduct", 225)
local CPCT = elements.allocate("MODPK", "CPCT")
elements.element(CPCT, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(CPCT, "Name", "CPCT")
elements.property(
    CPCT,
    "Description",
    "Custom value capacitor. Stores energy when sparked, and releases it to NSCN. Set the capacitance by tmp."
)
elements.property(CPCT, "Colour", 0xb7b7b7)
elements.property(CPCT, "MenuSection", 1)
elements.property(CPCT, "Hardness", 0)

elements.property(CPCT, "Properties", TYPE_SOLID)
elements.property(CPCT, "State", ST_SOLID)
elements.property(CPCT, "HeatConduct", 225)
local IN4 = elements.allocate("MODPK", "IN-4")
elements.element(IN4, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(IN4, "Name", "IN-4")
elements.property(IN4, "Description", "Inductor (value 4). Will not transfer to NSCN when not fully charged.")
elements.property(IN4, "Colour", 0x565656)
elements.property(IN4, "MenuSection", 1)
elements.property(IN4, "Hardness", 0)

elements.property(IN4, "Properties", TYPE_SOLID)
elements.property(IN4, "State", ST_SOLID)
elements.property(IN4, "HeatConduct", 225)
local IN5 = elements.allocate("MODPK", "IN-5")
elements.element(IN5, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(IN5, "Name", "IN-5")
elements.property(IN5, "Description", "Inductor (value 5). Will not transfer to NSCN when not fully charged.")
elements.property(IN5, "Colour", 0x565656)
elements.property(IN5, "MenuSection", 1)
elements.property(IN5, "Hardness", 0)

elements.property(IN5, "Properties", TYPE_SOLID)
elements.property(IN5, "State", ST_SOLID)
elements.property(IN5, "HeatConduct", 225)
local IN6 = elements.allocate("MODPK", "IN-6")
elements.element(IN6, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(IN6, "Name", "IN-6")
elements.property(IN6, "Description", "Inductor (value 6). Will not transfer to NSCN when not fully charged.")
elements.property(IN6, "Colour", 0x565656)
elements.property(IN6, "MenuSection", 1)
elements.property(IN6, "Hardness", 0)

elements.property(IN6, "Properties", TYPE_SOLID)
elements.property(IN6, "State", ST_SOLID)
elements.property(IN6, "HeatConduct", 225)
local IN7 = elements.allocate("MODPK", "IN-7")
elements.element(IN7, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(IN7, "Name", "IN-7")
elements.property(IN7, "Description", "Inductor (value 7). Will not transfer to NSCN when not fully charged.")
elements.property(IN7, "Colour", 0x565656)
elements.property(IN7, "MenuSection", 1)
elements.property(IN7, "Hardness", 0)

elements.property(IN7, "Properties", TYPE_SOLID)
elements.property(IN7, "State", ST_SOLID)
elements.property(IN7, "HeatConduct", 225)
local IN8 = elements.allocate("MODPK", "IN-8")
elements.element(IN8, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(IN8, "Name", "IN-8")
elements.property(IN8, "Description", "Inductor (value 8). Will not transfer to NSCN when not fully charged.")
elements.property(IN8, "Colour", 0x565656)
elements.property(IN8, "MenuSection", 1)
elements.property(IN8, "Hardness", 0)

elements.property(IN8, "Properties", TYPE_SOLID)
elements.property(IN8, "State", ST_SOLID)
elements.property(IN8, "HeatConduct", 225)
local INCT = elements.allocate("MODPK", "INCT")
elements.element(INCT, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(INCT, "Name", "INCT")
elements.property(
    INCT,
    "Description",
    "Custom value inductor. Will not transfer to NSCN when not fully charged. Set charge range by tmp2."
)
elements.property(INCT, "Colour", 0x565656)
elements.property(INCT, "MenuSection", 1)
elements.property(INCT, "Hardness", 0)

elements.property(INCT, "Properties", TYPE_SOLID)
elements.property(INCT, "State", ST_SOLID)
elements.property(INCT, "HeatConduct", 225)
local NPNT = elements.allocate("MODPK", "NPNT")
elements.element(NPNT, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(NPNT, "Name", "NPNT")
elements.property(
    NPNT,
    "Description",
    "NPN transistor. Use INST for base, PSCN for collector and NSCN for emitter. Transfer current when there is current in the base."
)
elements.property(NPNT, "Colour", 0x552F72)
elements.property(NPNT, "MenuSection", 2)
elements.property(NPNT, "Hardness", 0)

elements.property(NPNT, "Properties", TYPE_SOLID)
elements.property(NPNT, "State", ST_SOLID)
elements.property(NPNT, "HeatConduct", 225)
local PNPT = elements.allocate("MODPK", "PNPT")
elements.element(PNPT, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(PNPT, "Name", "PNPT")
elements.property(
    PNPT,
    "Description",
    "PNP transistor. Use INST for base, PSCN for collector and NSCN for emitter. Transfer current when there is no current in the base."
)
elements.property(PNPT, "Colour", 0xAA1839)
elements.property(PNPT, "MenuSection", 2)
elements.property(PNPT, "Hardness", 0)

elements.property(PNPT, "Properties", TYPE_SOLID)
elements.property(PNPT, "State", ST_SOLID)
elements.property(PNPT, "HeatConduct", 225)
local SCRT = elements.allocate("MODPK", "SCRT")
elements.element(SCRT, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(SCRT, "Name", "SCRT")
elements.property(
    SCRT,
    "Description",
    "Thyristor. PSCN and NSCN are the two main terminals, and INST is the gate. Conducts when the current in the gate was pulsed. Not bidirectional."
)
elements.property(SCRT, "Colour", 0x802456)
elements.property(SCRT, "MenuSection", 2)
elements.property(SCRT, "Hardness", 0)

elements.property(SCRT, "Properties", TYPE_SOLID)
elements.property(SCRT, "State", ST_SOLID)
elements.property(SCRT, "HeatConduct", 225)
local HETR = elements.allocate("MODPK", "HETR")
elements.element(elements.MODPK_PT_HETR, elements.element(elements.DEFAULT_PT_DMND))
elements.property(elements.MODPK_PT_HETR, "Name", "HETR")
elements.property(elements.MODPK_PT_HETR, "Description", "Heater, sets the temperature by its tmp.")
elements.property(elements.MODPK_PT_HETR, "Colour", 0xe17c00)
elements.property(elements.MODPK_PT_HETR, "MenuSection", 11)
elements.property(elements.MODPK_PT_HETR, "Hardness", 0)

elements.property(elements.MODPK_PT_HETR, "Properties", TYPE_SOLID)
elements.property(elements.MODPK_PT_HETR, "State", ST_SOLID)
elements.property(elements.MODPK_PT_HETR, "HeatConduct", 225)

function SPRKfunc(i, x, y, s, n)
    if sim.partProperty(i, "ctype") == RS5 then
        if sim.partProperty(i, "tmp") == 0 then
            tpt.set_property("tmp", 1, i)
            tpt.set_property("life", 10, i)
            sim.partChangeType(i, RS5)
        --   tpt.set_property("ctype", nil, i)
        end
    end
    if sim.partProperty(i, "ctype") == RS6 then
        if sim.partProperty(i, "tmp") == 0 then
            tpt.set_property("tmp", 1, i)
            tpt.set_property("life", 12, i)

            sim.partChangeType(i, RS6)
        --   tpt.set_property("ctype", nil, i)
        end
    end
    if sim.partProperty(i, "ctype") == RS7 then
        if sim.partProperty(i, "tmp") == 0 then
            tpt.set_property("tmp", 1, i)
            tpt.set_property("life", 14, i)
            sim.partChangeType(i, RS7)
        --  tpt.set_property("ctype", nil, i)
        end
    end
    if sim.partProperty(i, "ctype") == RS8 then
        if sim.partProperty(i, "tmp") == 0 then
            tpt.set_property("tmp", 1, i)
            tpt.set_property("life", 16, i)
            sim.partChangeType(i, RS8)
        --  tpt.set_property("ctype", nil, i)
        end
    end
    if sim.partProperty(i, "ctype") == RSCT then
        if sim.partProperty(i, "tmp") == 0 then
            tpt.set_property("tmp", 1, i)
            tpt.set_property("life", sim.partProperty(i, "tmp2"), i)
            sim.partChangeType(i, RSCT)
        --tpt.set_property("ctype", nil, i)
        end
    end
end
function resetResistortmp2(i, x, y, s, n)
    if sim.partProperty(i, "life") <= 0 then
        if sim.partProperty(i, "tmp") == 1 then
            tpt.set_property("tmp", 0, i)
        end
    end
end
function SODAfunc(i, x, y, s, n)
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == elem.MODPK_PT_VNGR then
            if sim.pressure(x / 4, y / 4) >= 8 then
                sim.partChangeType(r, elem.MODPK_PT_ADPR)
                sim.partChangeType(i, elem.MODPK_PT_ADPR)
            end
        end
    end
end
function ADPRfunc(i, x, y, s, n)
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_DSTW then
            sim.partKill(n)
            sim.partKill(r)
            tpt.create(x + math.random(-1, 1), y + math.random(-1, 1), "acid")
        end
    end
end
function DTRGfunc(i, x, y, s, n)
    if math.random(1, 30) == 1 then
        for r in sim.neighbors(x, y, 1, 1) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
                sim.partKill(i)

                sim.partChangeType(r, elem.MODPK_PT_DTRW)
                tpt.create(x + math.random(-1, 1), y + math.random(-1, 1), "dtrw")
                break
            end
        end
    end
end

function HYPXfunc(i, x, y, s, n)
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_PLNT then
            tpt.create(x + math.random(-1, 1), y + math.random(-1, 1), "oxyg")
            sim.partKill(i)
        else
            if sim.partProperty(r, "type") == elem.MODPK_PT_SODA then
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "fire")
                sim.partKill(i)
                sim.partChangeType(r, elem.DEFAULT_PT_SMKE)
            end
        end
    end
end
function DTRWfunc(i, x, y, s, n)
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_VRSS then
            tpt.set_property("pavg0", 1, r)
        end
    end
end
function HYGO2func(i, x, y, s, n)
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
            sim.partChangeType(r, elem.MODPK_PT_HYPX)
            sim.partKill(i)
        end
    end
end
function MELTfunc(i, x, y, s, n)
    for r in sim.neighbors(x, y, 3, 3) do
        if sim.partProperty(r, "type") == elem.MODPK_PT_MELT then
            break
        else
            tpt.set_property("temp", tpt.get_property("temp", i) + 0.6, i)
        end
    end
end
function LAVAfunc2(i, x, y, s, n)
    if sim.partProperty(i, "type") == elem.DEFAULT_PT_LAVA then
        if sim.partProperty(i, "ctype") == elem.MODPK_PT_STEL then
            tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "embr")
            tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "embr")
            tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "embr")
            tpt.create(x + math.random(-2, 2), y + math.random(-2, 2), "embr")
        end
    end
    if sim.partProperty(i, "ctype") == elem.MODPK_PT_PNPT then
        sim.partChangeType(i, elem.MODPK_PT_NEPT)
    end
end
function DopeSilicons(i, x, y, s, n)
    if sim.partProperty(i, "type") == elem.MODPK_PT_PTDP then
        found = false
        for r in sim.neighbors(x, y, 3, 3) do
            if sim.partProperty(r, "type") == elem.MODPK_PT_SLCN then
                found = true
                sim.partChangeType(r, elem.DEFAULT_PT_PSCN)
            end
        end
        if found == true then
            sim.partKill(i)
        end
    end
    if sim.partProperty(i, "type") == elem.MODPK_PT_NTDP then
        found = false
        for r in sim.neighbors(x, y, 3, 3) do
            if sim.partProperty(r, "type") == elem.MODPK_PT_SLCN then
                found = true
                sim.partChangeType(r, elem.DEFAULT_PT_NSCN)
            end
        end
        if found == true then
            sim.partKill(i)
        end
    end
end
function HETRfunc(i, x, y, s, n)
    tpt.set_property("temp", tpt.get_property("tmp", i) + 273.15, i)
end
function SCNDfunc(i, x, y, s, n)
    if tpt.get_property("life", i) then
        tpt.set_property("life", 1)
    end
end
function LIONfunc(i, x, y, s, n)
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                if sim.partProperty(i, "life") >= sim.partProperty(i, "tmp") then
                else
                    tpt.set_property("life", tpt.get_property("life", i) + 5, i)
                    tpt.set_property("temp", tpt.get_property("temp", i) + 0.3, i)
                end
            end
        end
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
            if sim.partProperty(i, "life") > 0 then
                if sim.partProperty(r, "life") == 0 then
                    tpt.set_property("life", tpt.get_property("life", i) - 3, i)
                    tpt.set_property("temp", tpt.get_property("temp", i) + 0.2, i)
                    tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                    tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                    tpt.set_property("life", "4", r)
                end
            end
        end
        if sim.partProperty(r, "type") == elem.MODPK_PT_LION then
            if (sim.partProperty(i, "life") < sim.partProperty(r, "life")) then
                tpt.set_property("life", tpt.get_property("life", i) + 1, i)
                tpt.set_property("life", tpt.get_property("life", r) - 1, r)
            end
        end
    end
end
function Capacitorfunc(i, x, y, s, n)
    if sim.partProperty(i, "type") == CP5 then
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "tmp") >= 15 then
                    else
                        tpt.set_property("tmp", tpt.get_property("tmp", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") > 0 then
                    if sim.partProperty(r, "life") == 0 then
                        tpt.set_property("tmp", tpt.get_property("tmp", i) - 3, i)
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == CP4 then
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "tmp") >= 10 then
                    else
                        tpt.set_property("tmp", tpt.get_property("tmp", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") > 0 then
                    if sim.partProperty(r, "life") == 0 then
                        tpt.set_property("tmp", tpt.get_property("tmp", i) - 3, i)
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == CP6 then
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "tmp") >= 20 then
                    else
                        tpt.set_property("tmp", tpt.get_property("tmp", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") > 0 then
                    if sim.partProperty(r, "life") == 0 then
                        tpt.set_property("tmp", tpt.get_property("tmp", i) - 3, i)
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == CP7 then
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "tmp") >= 25 then
                    else
                        tpt.set_property("tmp", tpt.get_property("tmp", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") > 0 then
                    if sim.partProperty(r, "life") == 0 then
                        tpt.set_property("tmp", tpt.get_property("tmp", i) - 3, i)
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == CP8 then
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "tmp") >= 25 then
                    else
                        tpt.set_property("tmp", tpt.get_property("tmp", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") > 0 then
                    if sim.partProperty(r, "life") == 0 then
                        tpt.set_property("tmp", tpt.get_property("tmp", i) - 3, i)
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == CPCT then
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "tmp") >= sim.partProperty(i, "tmp2") then
                    else
                        tpt.set_property("tmp", tpt.get_property("tmp", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") > 0 then
                    if sim.partProperty(r, "life") == 0 then
                        tpt.set_property("tmp", tpt.get_property("tmp", i) - 3, i)
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
end
function Inductorfunc(i, x, y, s, n)
    if sim.partProperty(i, "type") == IN4 then
        if sim.partProperty(i, "life") >= 35 then
            tpt.set_property("tmp", 1, i)
        else
            if sim.partProperty(i, "life") <= 0 then
                tpt.set_property("tmp", 0, i)
            end
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "life") < 35 then
                        tpt.set_property("life", tpt.get_property("life", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") >= 1 then
                    if sim.partProperty(i, "life") > 0 then
                        if sim.partProperty(r, "life") <= 0 then
                            tpt.set_property("life", tpt.get_property("life", i) - 8, i)
                            tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                            tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                            tpt.set_property("life", "4", r)
                        end
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == IN5 then
        if sim.partProperty(i, "life") >= 40 then
            tpt.set_property("tmp", 1, i)
        else
            if sim.partProperty(i, "life") <= 0 then
                tpt.set_property("tmp", 0, i)
            end
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "life") < 40 then
                        tpt.set_property("life", tpt.get_property("life", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") >= 1 then
                    if sim.partProperty(i, "life") > 0 then
                        if sim.partProperty(r, "life") <= 0 then
                            tpt.set_property("life", tpt.get_property("life", i) - 8, i)
                            tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                            tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                            tpt.set_property("life", "4", r)
                        end
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == IN6 then
        if sim.partProperty(i, "life") >= 45 then
            tpt.set_property("tmp", 1, i)
        else
            if sim.partProperty(i, "life") <= 0 then
                tpt.set_property("tmp", 0, i)
            end
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "life") < 45 then
                        tpt.set_property("life", tpt.get_property("life", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") >= 1 then
                    if sim.partProperty(i, "life") > 0 then
                        if sim.partProperty(r, "life") <= 0 then
                            tpt.set_property("life", tpt.get_property("life", i) - 8, i)
                            tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                            tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                            tpt.set_property("life", "4", r)
                        end
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == IN7 then
        if sim.partProperty(i, "life") >= 50 then
            tpt.set_property("tmp", 1, i)
        else
            if sim.partProperty(i, "life") <= 0 then
                tpt.set_property("tmp", 0, i)
            end
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "life") < 50 then
                        tpt.set_property("life", tpt.get_property("life", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") >= 1 then
                    if sim.partProperty(i, "life") > 0 then
                        if sim.partProperty(r, "life") <= 0 then
                            tpt.set_property("life", tpt.get_property("life", i) - 8, i)
                            tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                            tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                            tpt.set_property("life", "4", r)
                        end
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == IN8 then
        if sim.partProperty(i, "life") >= 55 then
            tpt.set_property("tmp", 1, i)
        else
            if sim.partProperty(i, "life") <= 0 then
                tpt.set_property("tmp", 0, i)
            end
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "life") < 55 then
                        tpt.set_property("life", tpt.get_property("life", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") >= 1 then
                    if sim.partProperty(i, "life") > 0 then
                        if sim.partProperty(r, "life") <= 0 then
                            tpt.set_property("life", tpt.get_property("life", i) - 8, i)
                            tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                            tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                            tpt.set_property("life", "4", r)
                        end
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == INCT then
        if sim.partProperty(i, "life") >= sim.partProperty(i, "tmp2") then
            tpt.set_property("tmp", 1, i)
        else
            if sim.partProperty(i, "life") <= 0 then
                tpt.set_property("tmp", 0, i)
            end
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    if sim.partProperty(i, "life") < sim.partProperty(i, "tmp2") then
                        tpt.set_property("life", tpt.get_property("life", i) + 5, i)
                    end
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(i, "tmp") >= 1 then
                    if sim.partProperty(i, "life") > 0 then
                        if sim.partProperty(r, "life") <= 0 then
                            tpt.set_property("life", tpt.get_property("life", i) - 8, i)
                            tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                            tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                            tpt.set_property("life", "4", r)
                        end
                    end
                end
            end
        end
    end
end
function NEPTfunc(i, x, y, s, n)
    if math.random(0, 10) > 8 then
        tpt.create(x + math.random(-3, 3), y + math.random(-3, 3), "elec")
        tpt.set_property("temp", tpt.get_property("temp", i) + 20, i)
    end
end

function Logicfunc(i, x, y, s, n)
    if sim.partProperty(i, "type") == elem.MODPK_PT_AND then
        input = 0

        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
                if sim.partProperty(r, "life") > 0 then
                    input = input + 1
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                    input = input + 1
                end
            end
        end
        if input >= 2 then
            for r in sim.neighbors(x, y, 2, 2) do
                if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                    if sim.partProperty(r, "life") <= 0 then
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == elem.MODPK_PT_OR then
        input = 0

        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
                if sim.partProperty(r, "life") > 0 then
                    input = input + 1
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                    input = input + 1
                end
            end
        end
        if input >= 1 then
            for r in sim.neighbors(x, y, 2, 2) do
                if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                    if sim.partProperty(r, "life") <= 0 then
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == elem.MODPK_PT_XOR then
        input = 0
        if sim.partProperty(i, "tmp") > 0 then
            tpt.set_property("tmp", sim.partProperty(i, "tmp") - 1, i)
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
                if sim.partProperty(r, "life") > 0 then
                    input = input + 1
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                    input = input + 1
                end
            end
        end
        if input >= 2 then
            tpt.set_property("tmp", 4, i)
        end
        if input == 1 and sim.partProperty(i, "tmp") <= 0 then
            for r in sim.neighbors(x, y, 2, 2) do
                if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                    if sim.partProperty(r, "life") <= 0 then
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == elem.MODPK_PT_NAND then
        input = 0
        if sim.partProperty(i, "tmp") > 0 then
            tpt.set_property("tmp", sim.partProperty(i, "tmp") - 1, i)
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
                if sim.partProperty(r, "life") > 0 then
                    input = input + 1
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                    input = input + 1
                end
            end
        end
        if input >= 2 then
            tpt.set_property("tmp", 4, i)
        end

        if input < 2 and sim.partProperty(i, "tmp") <= 0 then
            for r in sim.neighbors(x, y, 2, 2) do
                if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                    if sim.partProperty(r, "life") <= 0 then
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == elem.MODPK_PT_NOR then
        input = 0
        if sim.partProperty(i, "tmp") > 0 then
            tpt.set_property("tmp", sim.partProperty(i, "tmp") - 1, i)
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
                if sim.partProperty(r, "life") > 0 then
                    input = input + 1
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                    input = input + 1
                end
            end
        end
        if input > 0 then
            tpt.set_property("tmp", 8, i)
        end

        if input == 0 and sim.partProperty(i, "tmp") <= 0 then
            for r in sim.neighbors(x, y, 2, 2) do
                if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                    if sim.partProperty(r, "life") <= 0 then
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
    if sim.partProperty(i, "type") == elem.MODPK_PT_XNOR then
        input = 0
        if sim.partProperty(i, "tmp") > 0 then
            tpt.set_property("tmp", sim.partProperty(i, "tmp") - 1, i)
        end
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
                if sim.partProperty(r, "life") > 0 then
                    input = input + 1
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                    input = input + 1
                end
            end
        end
        if input == 1 then
            tpt.set_property("tmp", 4, i)
        end

        if (input == 0 or input == 2) and sim.partProperty(i, "tmp") <= 0 then
            for r in sim.neighbors(x, y, 2, 2) do
                if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                    if sim.partProperty(r, "life") <= 0 then
                        tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                        tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                        tpt.set_property("life", "4", r)
                    end
                end
            end
        end
    end
end
function EFSEfunc(i, x, y, s, n)
    if sim.partProperty(i, "tmp") == 0 then
        pscn_in = 0
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
                if sim.partProperty(r, "life") > 0 then
                    pscn_in = pscn_in + 1
                end
            end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                    pscn_in = pscn_in + 1
                end
                if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_METL then
                    tpt.set_property("tmp", 1, i)
                end
            end
        end
        if pscn_in > 0 then
            for r in sim.neighbors(x, y, 2, 2) do
                if sim.partProperty(r, "life") <= 0 and sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                    tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                    tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                    tpt.set_property("life", "4", r)
                end
            end
        end
    end
end
function GHSEfunc(i, x, y, s, n)
    for r in sim.neighbors(x, y, 1, 1) do
        if math.random(0, 100) > 99 then
            if not sim.photons(sim.partPosition(r)) == 0 then
                tpt.set_property("temp", (sim.partProperty(r, "temp") / 10) + sim.partProperty(i, "temp"), i)
                sim.partKill(r)
            end
        end
    end
end
function NPNTransistorFunc(i, x, y, s, n)
    pscn_in = 0
    gate = 0
     --
    --[[for r in sim.neighbors(x, y, 2, 2) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
            if sim.partProperty(r, "life") > 0 then
                pscn_in = 1
            end
        else
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                pscn_in = 1
            end
        else 
            pscn_in = 0
        end
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_INST then
                gate = 1
            else
                gate = 0
            end
        else 
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_INST then
            if sim.partProperty(r, "life") > 0 then
                pscn_in = 1
            end
        end
        end
    end
    end]] input =
        0
    gate = 0
    for r in sim.neighbors(x, y, 2, 2) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
            if sim.partProperty(r, "life") > 0 then
                input = input + 1
            end
        end
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                input = input + 1
            end
        end
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_INST then
            if sim.partProperty(r, "life") > 0 then
                gate = gate + 1
            end
        end
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_INST then
                gate = gate + 1
            end
        end
    end
    if (gate >= 1 and input >= 1) then
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(r, "life") <= 0 then
                    tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                    tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                    tpt.set_property("life", "4", r)
                end
            end
        end
    end
    --[[if (gate == 1 and pscn_in == 1)then
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(r, "life") <= 0 then
                    tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                    tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                    tpt.set_property("life", "4", r)
                end
            end
        end
    end ]]
 --
end
function PNPTransistorFunc(i, x, y, s, n)
    pscn_in = 0
    gate = 0
     --
    --[[for r in sim.neighbors(x, y, 2, 2) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
            if sim.partProperty(r, "life") > 0 then
                pscn_in = 1
            end
        else
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                pscn_in = 1
            end
        else 
            pscn_in = 0
        end
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_INST then
                gate = 1
            else
                gate = 0
            end
        else 
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_INST then
            if sim.partProperty(r, "life") > 0 then
                pscn_in = 1
            end
        end
        end
    end
    end]] input =
        0
    gate = 0
    for r in sim.neighbors(x, y, 2, 2) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
            if sim.partProperty(r, "life") > 0 then
                input = input + 1
            end
        end
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
                input = input + 1
            end
        end
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_INST then
            if sim.partProperty(r, "life") > 0 then
                gate = gate + 2
            else
                if sim.partProperty(i, "tmp") > 0 then
                    gate = gate + 2
                    tpt.set_property("tmp", sim.partProperty(i, "tmp") - 1, i)
                end
            end
        end
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_INST then
                gate = gate + 2
                tpt.set_property("tmp", "4", i)
            end
        end
    end
    if (gate <= 0 and input >= 1) then
        for r in sim.neighbors(x, y, 2, 2) do
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
                if sim.partProperty(r, "life") <= 0 then
                    tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                    tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                    tpt.set_property("life", "4", r)
                end
            end
        end
    end
end
function ThyristorFunc(i,x,y,s,n)
 -- use tmp for switch delay
 -- use tmp2 for on/off state
 pscn_in = 0
 gate = 0
  --
 --[[for r in sim.neighbors(x, y, 2, 2) do
     if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
         if sim.partProperty(r, "life") > 0 then
             pscn_in = 1
         end
     else
     if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
         if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
             pscn_in = 1
         end
     else 
         pscn_in = 0
     end
     if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
         if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_INST then
             gate = 1
         else
             gate = 0
         end
     else 
         if sim.partProperty(r, "type") == elem.DEFAULT_PT_INST then
         if sim.partProperty(r, "life") > 0 then
             pscn_in = 1
         end
     end
     end
 end
 end]] input =
     0
 gate = 0
 for r in sim.neighbors(x, y, 2, 2) do
     if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
         if sim.partProperty(r, "life") > 0 then
             input = input + 1
             tpt.set_property("life", "4", i)
         end
     end
     if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
         if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_PSCN then
             input = input + 1
             tpt.set_property("life", "4", i)
         end

     end
     if sim.partProperty(r, "type") == elem.DEFAULT_PT_INST then
         if sim.partProperty(r, "life") > 0 then
             gate = gate + 2
             tpt.set_property("tmp2", "2", i)
         else
             if sim.partProperty(i, "tmp") > 0 then
                 gate = gate + 2
                 tpt.set_property("tmp", sim.partProperty(i, "tmp") - 1, i)
                 tpt.set_property("tmp2", "2", i)
             end
         end
     end
     if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
         if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_INST then
             gate = gate + 2
             tpt.set_property("tmp", "4", i)
         end
     end
 end
 if sim.partProperty(i, "life") > 0 then
    input = input + 1
    tpt.set_property("life", sim.partProperty(i, "life") - 1, i)
end

 if (gate >= 1 and input >= 1) or (sim.partProperty(i, "tmp2") >= 2 and input >= 1)then
     for r in sim.neighbors(x, y, 2, 2) do
         if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
             if sim.partProperty(r, "life") <= 0 then
                 tpt.set_property("type", elem.DEFAULT_PT_SPRK, r)
                 tpt.set_property("ctype", elem.DEFAULT_PT_NSCN, r)
                 tpt.set_property("life", "4", r)
             end
         end
     end
 end
 if input <= 0 and sim.partProperty(i, "life") == 0  then
    tpt.set_property("tmp2", "0", i)
 end
end
elements.property(elements.DEFAULT_PT_EMBR, "Temperature", 2572.15)
tpt.element_func(SODAfunc, SODA)
tpt.element_func(ADPRfunc, ADPR)
tpt.element_func(DTRGfunc, DTRG)
tpt.element_func(HYPXfunc, HYPX)
tpt.element_func(HYGO2func, HYGO2)
tpt.element_func(DTRWfunc, DTRW)
tpt.element_func(MELTfunc, MELT)
tpt.element_func(LAVAfunc2, tpt.element("lava"))
tpt.element_func(DopeSilicons, NTDP)
tpt.element_func(DopeSilicons, PTDP)
tpt.element_func(HETRfunc, HETR)
tpt.element_func(LIONfunc, LION)
tpt.element_func(SPRKfunc, elements.DEFAULT_PT_SPRK)
tpt.element_func(resetResistortmp2, RS5)
tpt.element_func(resetResistortmp2, RS6)
tpt.element_func(resetResistortmp2, RS7)
tpt.element_func(resetResistortmp2, RS8)
tpt.element_func(resetResistortmp2, RSCT)
tpt.element_func(Capacitorfunc, CP4)
tpt.element_func(Capacitorfunc, CP5)
tpt.element_func(Capacitorfunc, CP6)
tpt.element_func(Capacitorfunc, CP7)
tpt.element_func(Capacitorfunc, CP8)
tpt.element_func(Capacitorfunc, CPCT)
tpt.element_func(Inductorfunc, IN4)
tpt.element_func(Inductorfunc, IN5)
tpt.element_func(Inductorfunc, IN6)
tpt.element_func(Inductorfunc, IN7)
tpt.element_func(Inductorfunc, IN8)
tpt.element_func(Inductorfunc, INCT)
tpt.element_func(NEPTfunc, NEPT)
tpt.element_func(NEPTfunc, PWRN)
tpt.element_func(Logicfunc, AND)
tpt.element_func(Logicfunc, OR)
tpt.element_func(Logicfunc, XOR)
tpt.element_func(Logicfunc, NAND)
tpt.element_func(Logicfunc, NOR)
tpt.element_func(Logicfunc, XNOR)
tpt.element_func(EFSEfunc, EFSE)
tpt.element_func(GHSEfunc, GHSE)
tpt.element_func(NPNTransistorFunc, NPNT)
tpt.element_func(PNPTransistorFunc, PNPT)
tpt.element_func(ThyristorFunc, SCRT)