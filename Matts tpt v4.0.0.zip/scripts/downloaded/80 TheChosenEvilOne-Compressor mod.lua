
local COMP = elements.allocate('TCEO','COMP')
local UCMP = elements.allocate('TCEO','UCMP')
local CMPR = elements.allocate('TCEO','CMPR')

elements.property(COMP, 'Gravity', '0')
elements.property(UCMP, 'Gravity', '0')
elements.property(CMPR, 'Gravity', '1')

elements.property(COMP, "Name" , "COMP")
elements.property(CMPR, "Name" , "CMPR")
elements.property(UCMP, "Name" , "UCMP")

elements.property(COMP, 'Falldown', '0')
elements.property(UCMP, 'Falldown', '0')
elements.property(CMPR, 'Falldown', '1')

elements.property(COMP, 'Weight', '100')
elements.property(UCMP, 'Weight', '100')
elements.property(CMPR, 'Weight', '10')

elements.property(COMP, 'Color', '0x8C8C8C')
elements.property(UCMP, 'Color', '0x8C8C8C')
elements.property(CMPR, 'Color', '0x8C8C8C')

elements.property(COMP, 'MenuSection', elem.SC_SPECIAL)
elements.property(UCMP, 'MenuSection', elem.SC_SPECIAL)

elements.property(COMP, 'MenuVisible', 1)
elements.property(UCMP, 'MenuVisible', 1)

elements.property(COMP, "Description" , "Compressor: Compresses two elements on both sides of itself into one")
elements.property(UCMP, "Description" , "Uncompressor: decompresses compressed particles and places them below itself to either side")

elements.property(CMPR,"Properties", elem.TYPE_PART)

blacklistedEl = {elements.DEFAULT_PT_DMND,COMP,UCMP,CMPR}
isBlacklisted = false

function compress(i,x,y,s,n)
	if sim.partID(x+1,y) ~= nil and sim.partID(x-1,y) ~= nil then
		elnoI = sim.partID(x+1,y)
		elnoII = sim.partID(x-1,y)
		eltypeI = sim.partProperty(elnoI,sim.FIELD_TYPE)
		eltypeII = sim.partProperty(elnoII,sim.FIELD_TYPE)
		for i, blackEl in ipairs(blacklistedEl) do
			if blackEl == eltypeI or blackEl == eltypeII then
				isBlacklisted = true
				break
			end
		end
		if isBlacklisted ~= true then
			for yap=0,3,1 do
				if(sim.partID(x,y+yap) == nil) then
					createdEl = sim.partCreate(-1,x,y+yap,CMPR)
					sim.partProperty(createdEl, sim.FIELD_TMP, eltypeI)
					sim.partProperty(createdEl, sim.FIELD_TMP2, eltypeII)
					sim.partKill(elnoI)
					sim.partKill(elnoII)
					break
				end
			end
		end
	end
	isBlacklisted = false
end

function uncompress(i,x,y,s,n)
	elementty = sim.partID(x,y-1) --save element index to variable
	if elementty ~= nil then --if there is element get type
		elemID = sim.partProperty(elementty,sim.FIELD_TYPE)
	end
	if elemID == CMPR then --check if elemID is CMPR (element)
		cmprtmp = sim.partProperty(elementty,sim.FIELD_TMP) --get info from TMP
		cmprtmp2 = sim.partProperty(elementty,sim.FIELD_TMP2) --get info from TMP2
		if cmprtmp ~= 0 and cmprtmp2 ~= 0 or cmprtmp ~= nil and cmprtmp2 ~= nil then --checking if nil/0
			sim.partCreate(-1,x-1,y+1,cmprtmp) --create element with id cmprtmp
			sim.partCreate(-1,x+1,y+1,cmprtmp2) --create element with id cmprtmp2
			sim.partKill(elementty) --kill element (elementty)
		end
	end
	elemID = nil
end

tpt.element_func(compress, COMP)
tpt.element_func(uncompress, UCMP)