
local muon = elem.allocate("BIGDIG", "MUON")
local tau = elem.allocate("BIGDIG", "TAU")

elem.element(muon, elem.element(elem.DEFAULT_PT_ELEC))
elem.property(muon, "Name", "MUON")
elem.property(muon, "Description", "Muon, a heavy unstable elementary particle. Catalyzes fusion of hydrogen.")
elem.property(muon, "Color", 0x00ff00)


local function particleGraphics(i, colr, colg, colb)
    return 1, 0x00010001, 255, colr, colg, colb, 255, colr, colg, colb
end

local function muonUpdate(i, x, y, s, nt)
    if tpt.get_property("tmp2", i) == 0 then
        local a = (math.random(360)-1) * 0.01745329;
        tpt.set_property("life",680,i);
        tpt.set_property("vx",2*math.cos(a),i);
        tpt.set_property("vy",2*math.sin(a),i);
        tpt.set_property("tmp2",1,i)
    end;
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_HYGN then
            local rx = sim.partProperty(r, "x");
            local ry = sim.partProperty(r, "y");
            tpt.set_pressure((rx/4)-4, (ry/4)-4, 7, 7, 255);
            sim.partProperty(r, "temp", 10000.00);
        end
    end
end

elem.property(muon, "Update", muonUpdate)
elem.property(muon, "Graphics", particleGraphics)

elem.element(tau, elem.element(elem.DEFAULT_PT_ELEC))
elem.property(tau, "Name", "TAU")
elem.property(tau, "Description", "Tau, the heaviest lepton found. Catalyzes fission of plutonium.")
elem.property(tau, "Color", 0x336600)

local function tauUpdate(i, x, y, s, nt)
    if tpt.get_property("tmp2", i) == 0 then
        local a = (math.random(360)-1) * 0.01745329;
        tpt.set_property("life",680,i)
        tpt.set_property("vx",2*math.cos(a),i)
        tpt.set_property("vy",2*math.sin(a),i)
        tpt.set_property("tmp2",1,i)
    end
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == elem.DEFAULT_PT_PLUT then
            local rx = sim.partProperty(r, "x");
            local ry = sim.partProperty(r, "y");
            tpt.set_pressure((rx/4)-4, (ry/4)-4, 7, 7, 255);
        end
    end
end

elem.property(tau, "Update", tauUpdate)
elem.property(tau, "Graphics", particleGraphics)

local uqrk = elem.allocate("BIGDIG", "UQRK")
local dqrk = elem.allocate("BIGDIG", "DQRK")

elem.element(uqrk, elem.element(elem.DEFAULT_PT_ELEC))
elem.property(uqrk, "Name", "UQRK")
elem.property(uqrk, "Description", "Up quark, an elementary particle. Will create NEUT with two down quarks.")
elem.property(uqrk, "Color", 0x0000ff)

local function uqrkUpdate(i, x, y, s, nt)
    if tpt.get_property("tmp2", i) == 0 then
        local a = (math.random(360)-1) * 0.01745329;
        tpt.set_property("life",680,i)
        tpt.set_property("vx",2*math.cos(a),i)
        tpt.set_property("vy",2*math.sin(a),i)
        tpt.set_property("tmp2",1,i)
    end
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == dqrk then
               for r2 in sim.neighbors(x, y, 1, 1) do
                   if sim.partProperty(r2, "type") == dqrk then
                       sim.partKill(r)
                       sim.partKill(r2)
                       sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                   end
               end
        end
    end
end

elem.property(uqrk, "Update", uqrkUpdate)
elem.property(uqrk, "Graphics", particleGraphics)

elem.element(dqrk, elem.element(elem.DEFAULT_PT_ELEC))
elem.property(dqrk, "Name", "DQRK")
elem.property(dqrk, "Description", "Down quark, an elementary particle. Will create PROT with two up quarks.")
elem.property(dqrk, "Color", 0xff0000)

local function dqrkUpdate(i, x, y, s, nt)
    if tpt.get_property("tmp2", i) == 0 then
        local a = (math.random(360)-1) * 0.01745329;
        tpt.set_property("life",680,i)
        tpt.set_property("vx",2*math.cos(a),i)
        tpt.set_property("vy",2*math.sin(a),i)
        tpt.set_property("tmp2",1,i)
    end
    for r in sim.neighbors(x, y, 1, 1) do
        if sim.partProperty(r, "type") == uqrk then
               for r2 in sim.neighbors(x, y, 1, 1) do
                   if sim.partProperty(r2, "type") == uqrk then
                       sim.partKill(r)
                       sim.partKill(r2)
                       sim.partProperty(i, "type", elem.DEFAULT_PT_PROT)
                   end
               end
        end
    end
end

elem.property(dqrk, "Update", dqrkUpdate)
elem.property(dqrk, "Graphics", particleGraphics)