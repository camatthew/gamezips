
------------------- Configuration -------------------
local rquiredAPIVersion = 2.42
-----------------------------------------------------
pcall(dofile,"scripts/ssccssccAPI.lua")
if not interface_s or interface_s.Version < rquiredAPIVersion then
  if tpt.confirm("Download and install file", "Interface API (scripts/ssccssccAPI.lua) is required to run script 'WIFI Tuner'. Download it now?") then
    fs.makeDirectory("scripts")
    tpt.getscript(172, "scripts/ssccssccAPI.lua", 1, 0)
  else
    tpt.log("'WIFI Tuner' script is unavailable due to lack of required files.")
    return
  end
end
local DefaultTheme = interface_s.DefaultTheme
--=================================================================--
--                    CODE IS BELOW THIS LINE                      --
--=================================================================--

local PopupWindow = interface_s.Components.Window:new(40, 40, 38, 11,false, DefaultTheme.Window)

PopupWindow.AllowResize = false
PopupWindow.AlwaysFocused = true
PopupWindow.IsShowing = false

local ChannelLabel = interface_s.Components.Label:new(2,2,"Ch:",DefaultTheme.Label)
local ChannelValueLabel = interface_s.Components.Label:new(20,2,"-100",DefaultTheme.Label)

local block = false

local lasti = -1

interface_s.AddOnStepAction(function(x,y)
  if (tpt.selectedl=="DEFAULT_PT_WIFI" or tpt.selectedr=="DEFAULT_PT_WIFI" or tpt.selectedl=="DEFAULT_PT_PRTI" or tpt.selectedr=="DEFAULT_PT_PRTI" or tpt.selectedl=="DEFAULT_PT_PRTO" or tpt.selectedr=="DEFAULT_PT_PRTO") and not block then
    local i = sim.partID(sim.adjustCoords(x,y))
    if i and (sim.partProperty(i, "type")==124 or sim.partProperty(i, "type")==109 or sim.partProperty(i, "type")==110) then
      PopupWindow.X,PopupWindow.Y = sim.adjustCoords(x,y)
      PopupWindow.X=PopupWindow.X+6
      ChannelValueLabel.Text=math.ceil(sim.partProperty(i, "temp")/100)
      PopupWindow.IsShowing = true
      lasti = i
    else
      PopupWindow.IsShowing = false
      lasti = -1
    end
  elseif block then
    block = false
  end
end)

interface_s.AddOnClickAction(function(mousex, mousey, event, button, wheel)
  if PopupWindow.IsShowing == false then
    block = true
  end
  if PopupWindow.IsShowing == true then
    if button==0 and event==0 then
      local i = sim.partID(sim.adjustCoords(mousex,mousey))
      if i then
        if ChannelValueLabel.Text < 100 and wheel==1 then
          ChannelValueLabel.Text = ChannelValueLabel.Text + 1
        elseif ChannelValueLabel.Text > 0 and wheel==-1 then
          ChannelValueLabel.Text = ChannelValueLabel.Text - 1
        end
        sim.partProperty(i, "temp",ChannelValueLabel.Text*100)
        return true
      end
    else
      if (button==4 or button==3)  and event == 2 then
        if lasti ~= -1 then
           sim.partKill(lasti)
        end
      end
    end
  end
end)

PopupWindow:AddComponent(ChannelLabel)
PopupWindow:AddComponent(ChannelValueLabel)

interface_s.addComponent(PopupWindow)
--=================================================================--
--                    CODE IS ABOVE THIS LINE                      --
--=================================================================--