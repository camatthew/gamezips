------------------- Configuration -------------------
local InterfaceAPIVersion = 2.43
-----------------------------------------------------
local mouseEvents = {
  Down = 1,
  Up = 2
}
local mouseButtons = {
    Left = 1,
    Middle = 2,
    Right = 3
}
local function DefineInterfaceComponents()
  function interface_s.Components.Window:new(x, y, Width, Height, Movable, theme)
    local obj= {}
    obj.Type = "Window"

    obj.AllowResize = true
    obj.AlwaysFocused = false
    obj.IsMovable = Movable
    obj.MinWidth = 16
    obj.MinHeight = 16
    obj.Theme = theme
    obj.X = x
    obj.Y = y
    obj.Width = Width
    obj.Height = Height

    obj.OnShow = nil
    obj.OnHide = nil
    obj.OnDraw = nil
    obj.OnEndDraw = nil
    obj.OnMove = nil
    obj.OnClick = nil

    obj.Focused=false
    obj.Items = {}
    obj.MoveStartX = -1
    obj.MoveStartY = -1
    obj.IsMoving = false
    obj.IsShowing = true
    obj.IsResizing = false
    obj.ResizeStartX = 1
    obj.ResizeStartY = 1
    obj.ResizeStartWidth = 1
    obj.ResizeStartHeight = 1
    obj.ResizeLastWidth =0
    obj.ResizeLastHeight=0  
    obj.SizeOfHeader = 8  
    function obj:Draw(IsFocused,mx,my)
      self.Focused=IsFocused or self.AlwaysFocused
      if self.OnDraw ~= nil then
        if self.OnDraw(IsFocused,mx,my) == true then
          return
        end
      end
      if self.Focused == true then
        gfx.fillRect(self.X, self.Y, self.Width,self.Height, gfx.getColors(self.Theme.BackColor))
        gfx.drawRect(self.X, self.Y, self.Width,self.Height, gfx.getColors(self.Theme.BorderColor))
        if self.IsMovable then
          gfx.fillRect(self.X, self.Y, self.Width,self.SizeOfHeader, gfx.getColors(self.Theme.HeaderColor))
        end
        if self.AllowResize==true then
          gfx.fillRect(self.X+self.Width-6, self.Y+self.Height-6, 6,6, gfx.getColors(self.Theme.BorderColor))
        end
      else
        gfx.fillRect(self.X, self.Y, self.Width,self.Height, gfx.getColors(self.Theme.UnfocusedBackColor))
        gfx.drawRect(self.X, self.Y, self.Width,self.Height, gfx.getColors(self.Theme.UnfocusedBorderColor))
        if self.AllowResize==true then
          gfx.fillRect(self.X+self.Width-6, self.Y+self.Height-6, 6,6, gfx.getColors(self.Theme.UnfocusedBorderColor))
        end
        if self.IsMovable then
          gfx.fillRect(self.X, self.Y, self.Width,self.SizeOfHeader, gfx.getColors(self.Theme.UnfocusedHeaderColor))
        end
      end
      for i=#self.Items,0,-1 do
        if (self.Items[i]~=nil) and (self.Items[i].IsShowing==true) then
          self.Items[i]:Draw(self.Focused,self.X,self.Y,mx-self.X,my-self.Y)
        end
      end
      if self.OnEndDraw ~= nil then
        if self.OnEndDraw(IsFocused,mx,my) == true then
          return
        end
      end
    end 
    function obj:Show()
      self.IsShowing = true
      if self.OnShow ~= nil then
         self.OnShow(self)
      end
    end
    function obj:Hide()
      self.IsShowing = false
      if self.OnHide ~= nil then
         self.OnHide(self)
      end
    end
    function obj:Resize(ws,hs)
      if ws < self.MinWidth then
        ws=self.MinWidth
      end
      if hs < self.MinHeight then
        hs=self.MinHeight
      end
      self.ResizeLastHeight = self.Height
      self.ResizeLastWidth = self.Width
      self.Height = hs
      self.Width = ws
      hs = self.Height-self.ResizeLastHeight
      ws = self.Width-self.ResizeLastWidth
      for i=0,#self.Items do
        if self.Items[i]~=nil then
          if self.Items[i].Anchor.Top==true and self.Items[i].Anchor.Bottom==true then
            self.Items[i].Height = self.Items[i].Height + hs
          end
          if self.Items[i].Anchor.Top==false and self.Items[i].Anchor.Bottom==true then
            self.Items[i].Y = self.Items[i].Y + hs
          end
          if self.Items[i].Anchor.Left==true and self.Items[i].Anchor.Right==true then
            self.Items[i].Width = self.Items[i].Width + ws
          end
          if self.Items[i].Anchor.Left==false and self.Items[i].Anchor.Right==true then
            self.Items[i].X = self.Items[i].X + ws
          end
        end
      end
    end
    function obj:AddComponent(component)
      self.Items[#self.Items+1] = component
      component.Base = self
    end
    function obj:GetComponentIndex(obj2)
      for i=0, #self.Items do
        if self.Items[i] == obj2 then
          return i
        end
      end
      return -1
    end
    function obj:focusComponent(obj2)
      local index = self:GetComponentIndex(obj2)
      for i=index, 1,-1 do
        self.Items[i] = self.Items[i-1] 
      end
      self.Items[0] = obj2
    end
    function obj:KeyPress(key, scan, r, ctrl, shift, alt)
      for i=0,#self.Items do
        if (self.Items[i]~=nil) and (self.Items[i].IsShowing==true) and (self.Items[i].KeyPress~=nil) then
          if self.Items[i]:KeyPress(key, scan, r, ctrl, shift, alt) then
            return true
          end
        end
      end
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
      if (self.IsMovable) and (e==mouseEvents.Up) and (self.IsMoving) then
        self.IsMoving = false
      end
      if self.IsResizing== false then
        for i=0,#self.Items do
          if (self.Items[i]~=nil) and (self.Items[i].IsShowing==true) then
            if self.Items[i]:Click(x-self.X,y-self.Y,e,b,w) then
              return true
            end
          end
        end
      end
      if (x>self.X) and (x<self.X+self.Width) and (y>self.Y) and (y<self.Y+self.Height) then
        if self.Focused then
          if self.AllowResize==true and self.IsResizing==false and e==mouseEvents.Down and x>self.X+self.Width-8 and x<self.X+self.Width and y>self.Y+self.Height-self.SizeOfHeader and y<self.Y+self.Height then
            self.IsResizing=true
            self.ResizeStartX = x
            self.ResizeStartY = y
            self.ResizeStartWidth = self.Width
            self.ResizeStartHeight = self.Height
            return true
          end
          if (self.IsMovable) and (y>self.Y) and (y<self.Y+self.SizeOfHeader) and (e==mouseEvents.Down) then
            self.MoveStartX = x - self.X
            self.MoveStartY = y - self.Y
            self.IsMoving = true
          end
          if self.IsResizing==false then
            return true
          end
        else
          if e==mouseEvents.Down then
            return true
          end
        end
      else
        if IsResizing==false then
          return false
        end
      end

      if self.IsResizing==true and e==mouseEvents.Up then
        self.IsResizing = false
        return true
      end

    end
    function obj:Move(x,y,dx,dy)
      if (self.IsMovable) and (self.IsMoving) then
        self.X = x-self.MoveStartX
        self.Y = y-self.MoveStartY
        if self.OnMove~=nil then
          self.OnMove(self.X,self.Y)
        end
      else
        if self.IsResizing==true then
          self:Resize(self.ResizeStartWidth-self.ResizeStartX+x,self.ResizeStartHeight-self.ResizeStartY+y)
          return true
        end
      end
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end
  function interface_s.Components.Button:new(x, y, Width, Height, text, theme)
    local obj= {}
    obj.Type = "Button"

    obj.X = x
    obj.Y = y
    obj.Width = Width
    obj.Height = Height
    obj.Theme = theme
    obj.IsShowing = true
    obj.Text = text
    obj.Enabled = true
    obj.HintText = ""
    obj.Anchor = {Top = false,Bottom=false,Left=false,Right=false}

    obj.OnPressed = nil
    obj.OnDraw = nil
    obj.OnEndDraw = nil
    obj.OnClick = nil
    
    obj.Base = nil
    obj.Focused=false
    obj.ClickHelper = interface_s.ComponentsHelpers.Click:new()
    obj.HintHelper = nil
    function obj:Draw(IsFocused, baseX, baseY,x,y)
      if not self.IsShowing then return end
      self.Focused=IsFocused
      if self.OnDraw ~= nil then
        if self.OnDraw(IsFocused,self.X+baseX,self.Y+baseY,x,y) == true then
          return
        end
      end
      local tw, th = gfx.textSize(self.Text)
      if IsFocused == true and self.Enabled then
        if (x>self.X) and (x<self.X+self.Width) and (y>self.Y) and (y<self.Y+self.Height) then
          if self.ClickHelper.IsFirstClick then
            gfx.fillRect(self.X+baseX, self.Y+baseY, self.Width,self.Height, gfx.getColors(self.Theme.PressedBackColor))
            gfx.drawText(self.X+baseX+(self.Width-tw)/2, self.Y+baseY + (self.Height-th)/2+1, self.Text, gfx.getColors(self.Theme.PressedTextColor))
          else
            gfx.fillRect(self.X+baseX, self.Y+baseY, self.Width,self.Height, gfx.getColors(self.Theme.MouseOverColor))
            gfx.drawText(self.X+baseX+(self.Width-tw)/2, self.Y+baseY + (self.Height-th)/2+1, self.Text, gfx.getColors(self.Theme.TextColor))
            if self.HintHelper~=nil then
              self.HintHelper:MouseOver(x+baseX,y+baseY,self.HintText)
            end
          end
        else
          if self.HintHelper~=nil then
            self.HintHelper:Reset()
          end
          gfx.fillRect(self.X+baseX, self.Y+baseY, self.Width,self.Height, gfx.getColors(self.Theme.BackColor))
          gfx.drawText(self.X+baseX+(self.Width-tw)/2, self.Y+baseY + (self.Height-th)/2+1, self.Text, gfx.getColors(self.Theme.TextColor))
        end
        gfx.drawRect(self.X+baseX, self.Y+baseY, self.Width,self.Height, gfx.getColors(self.Theme.BorderColor))
      else
        if self.HintHelper~=nil then
          self.HintHelper:Reset()
        end
        if (x>self.X) and (x<self.X+self.Width) and (y>self.Y) and (y<self.Y+self.Height) then
          if self.ClickHelper.IsFirstClick then
            gfx.fillRect(self.X+baseX, self.Y+baseY, self.Width,self.Height, gfx.getColors(self.Theme.PressedBackColor))
            gfx.drawText(self.X+baseX+(self.Width-tw)/2, self.Y+baseY + (self.Height-th)/2+1, self.Text, gfx.getColors(self.Theme.PressedTextColor))
          else
            gfx.fillRect(self.X+baseX, self.Y+baseY, self.Width,self.Height, gfx.getColors(self.Theme.UnfocusedMouseOverColor))
            gfx.drawText(self.X+baseX+(self.Width-tw)/2, self.Y+baseY + (self.Height-th)/2+1, self.Text, gfx.getColors(self.Theme.UnfocusedTextColor))
          end
        else
          gfx.fillRect(self.X+baseX, self.Y+baseY, self.Width,self.Height, gfx.getColors(self.Theme.UnfocusedBackColor))
          gfx.drawText(self.X+baseX+(self.Width-tw)/2, self.Y+baseY + (self.Height-th)/2+1, self.Text, gfx.getColors(self.Theme.UnfocusedTextColor))
        end
        gfx.drawRect(self.X+baseX, self.Y+baseY, self.Width,self.Height, gfx.getColors(self.Theme.UnfocusedBorderColor))
      end
      if self.OnEndDraw ~= nil then
        if self.OnEndDraw(IsFocused,self.X+baseX,self.Y+baseY,x,y) == true then
          return
        end
      end
    end 
    function obj:Show()
      self.IsShowing = true
    end
    function obj:Hide()
      self.IsShowing = false
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
      if self.Enabled then
        self.ClickHelper.OnPress = self.OnPressed
        self.ClickHelper:ProcessClick(self.Width,self.Height,self.X,self.Y,x,y,e,b)
      end
    end
    function obj:AddHint(text)
      self.HintText = text
      self.HintHelper = interface_s.ComponentsHelpers.Hint:new()
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end

  function interface_s.Components.Combobox:new(x, y,w,h,i, theme)
    local obj= {}
    obj.Type = "Combobox"

    obj.X = x
    obj.Y = y

    obj.Theme = theme
    obj.IsShowing = true
    obj.Width = w
    obj.Height = h
    obj.Enabled = true
    obj.Anchor = {Top = false,Bottom=false,Left=false,Right=false}
    obj.Items = i
    obj.IsItemsShown = false
    
    obj.SelectedIndex=0
    obj.OnItemSelected = nil
    obj.OnClick = nil

    obj.Base = nil
    obj.Focused=false
    obj.DropClickHelper = interface_s.ComponentsHelpers.Click:new()
      obj.DropClickHelper.OnPress = function()
          if obj.IsItemsShown==false then
            obj.Base:focusComponent(obj)
            obj.IsItemsShown = true
          end
        end
    obj.ItemClickHelper = interface_s.ComponentsHelpers.Click:new()
      obj.ItemClickHelper.OnFirstClick = function() return true end
      obj.ItemClickHelper.OnPress = function(x,y)
          local i = y-obj.Y-obj.Height
          obj.SelectedIndex=math.floor(i/14)
          if obj.OnItemSelected~= nil then
            obj.OnItemSelected(obj.SelectedIndex,obj.Items[obj.SelectedIndex+1])
          end
          obj.IsItemsShown = false
          interface_s.RemoveOnClickAction(obj)
          return true
        end
      obj.ItemClickHelper.OnMissClick = function(x,y)
        obj.IsItemsShown = false
        interface_s.RemoveOnClickAction(obj)
        return true
      end
    function obj:Draw(IsFocused, baseX, baseY,x,y)
      if not self.IsShowing then return end
      self.Focused = IsFocused
      if IsFocused and self.Enabled then
        gfx.drawRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.BorderColor))
        if self.SelectedIndex>=0 then
          gfx.drawText(self.X+baseX+5,self.Y+baseY+3, self.Items[self.SelectedIndex+1], gfx.getColors(self.Theme.TextColor))
        end
        if self.IsItemsShown==true then
          gfx.fillRect(self.X+self.Width-self.Height+baseX, self.Y+baseY, self.Height,self.Height, gfx.getColors(self.Theme.ButtonPressedBackColor))
        else
          if x>self.X+self.Width-self.Height and x<self.X+self.Width and y>self.Y and y<self.Y+self.Height then
            gfx.fillRect(self.X+self.Width-self.Height+baseX, self.Y+baseY, self.Height,self.Height, gfx.getColors(self.Theme.ButtonMouseOverBackColor))
          else
            gfx.fillRect(self.X+self.Width-self.Height+baseX, self.Y+baseY, self.Height,self.Height, gfx.getColors(self.Theme.ButtonBackColor))
          end
        end
        gfx.drawRect(self.X+self.Width-self.Height+baseX, self.Y+baseY, self.Height,self.Height, gfx.getColors(self.Theme.BorderColor))
        if self.IsItemsShown==true then
          gfx.fillRect(self.X+baseX,self.Y+baseY+self. Height,self.Width,#self.Items*14,gfx.getColors(self.Theme.BackColor))
          for i=0,#self.Items-1 do
            if x>self.X and x<self.X+self.Width and y>self.Y+i*14+self.Height and y<self.Y+i*14+self.Height+15 then
              gfx.fillRect(self.X+baseX,self.Y+baseY+i*14+self.Height,self.Width,14+1,gfx.getColors(self.Theme.ButtonMouseOverBackColor))
            end
            gfx.drawRect(self.X+baseX,self.Y+baseY+i*14+self.Height,self.Width,14+1,gfx.getColors(self.Theme.BorderColor))
            gfx.drawText(self.X+baseX+5,self.Y+baseY+i*14+3+self.Height, self.Items[i+1],gfx.getColors(self.Theme.TextColor))
          end
        end
      else
        obj.IsItemsShown = false
        gfx.drawRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.UnfocusedBorderColor))
        if self.SelectedIndex>=0 then
          gfx.drawText(self.X+baseX+5,self.Y+baseY+3, self.Items[self.SelectedIndex+1],gfx.getColors(self.Theme.UnfocusedTextColor))
        end
        if x>self.X+self.Width-self.Height and x<self.X+self.Width and y>self.Y and y<self.Y+self.Height then
          gfx.fillRect(self.X+self.Width-self.Height+baseX, self.Y+baseY, self.Height,self.Height, gfx.getColors(self.Theme.UnfocusedButtonMouseOverBackColor))
        else
          gfx.fillRect(self.X+self.Width-self.Height+baseX, self.Y+baseY, self.Height,self.Height,gfx.getColors(self.Theme.UnfocusedButtonBackColor))
        end
        gfx.drawRect(self.X+self.Width-self.Height+baseX, self.Y+baseY, self.Height,self.Height, gfx.getColors(self.Theme.UnfocusedBorderColor))
      end
    end 
    function obj:Show()
      self.IsShowing = true
    end
    function obj:Hide()
      self.IsShowing = false
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
      if self.Enabled then
        if self.IsItemsShown==true then
          return self.ItemClickHelper:ProcessClick(self.Width,#self.Items*14,self.X,self.Y+self.Height,x,y,e,b)
        end
        return self.DropClickHelper:ProcessClick(self.Height,self.Height,self.X+self.Width-self.Height,self.Y,x,y,e,b)
      end
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end

  function interface_s.Components.Graph:new(x, y,w,h, theme)
    local obj= {}
    obj.Type = "Graph"

    obj.X = x
    obj.Y = y
    obj.Theme = theme
    obj.IsShowing = true
    obj.Width = w
    obj.Height = h
    obj.UpdateSpeed = 20
    obj.Anchor = {Top = false,Bottom=false,Left=false,Right=false}

    obj.GetValue = nil
    obj.OnClick = nil

    obj.Focused=false
    obj.ZeroHeight = 0
    obj.MaxValue = 0
    obj.NewMaxValue = 0
    obj.MinValue = 0
    obj.NewMinValue = 0
    obj.UpdateCounter = 0
    obj.PointX = {} 
    obj.PointY = {} 
    obj.Base = nil
    function obj:Draw(IsFocused, baseX, baseY,x,y)
      if not self.IsShowing then return end
      if self.UpdateCounter>self.UpdateSpeed then
        if self.GetValue ~= nil then
          self:AddPoint(self.GetValue())
        end
        self.UpdateCounter=0
      end
      self.UpdateCounter=self.UpdateCounter+1
      self.Focused = IsFocused
      if IsFocused==true then
        gfx.fillRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.BackColor))
        gfx.drawRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.BorderColor))
        gfx.drawText(self.X+baseX,self.Y+baseY-10,"Max: "..self.MaxValue,gfx.getColors(self.Theme.TextColor))
        gfx.drawText(self.X+baseX+100,self.Y+baseY-10,"Min: "..self.MinValue,gfx.getColors(self.Theme.TextColor))
      else
        gfx.fillRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.UnfocusedBackColor))
        gfx.drawRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.UnfocusedBorderColor))
        gfx.drawText(self.X+baseX,self.Y+baseY-10,"Max: "..self.MaxValue,gfx.getColors(self.Theme.UnfocusedTextColor))
        gfx.drawText(self.X+baseX+100,self.Y+baseY-10,"Min: "..self.MinValue,gfx.getColors(self.Theme.UnfocusedTextColor))
      end
      self.NewMaxValue = 0
      self.NewMinValue = 0
      if self.PointX[#self.PointX] ~= nil then
        local v = self.PointX[#self.PointX]-self.Width+1
        if v>0 then
          for i=v,#self.PointY do
            self.PointY[i-v]=self.PointY[i]
            self.PointX[i-v]=self.PointX[i]-v
          end
          for i=#self.PointY-v,#self.PointY do
            self.PointY[i]=nil
            self.PointX[i]=nil
          end
        end
      end
      for i=2, #self.PointX do
        if self.PointX[i]<self.Width-1 then
          if self.NewMaxValue < self.PointY[i] then
            self.NewMaxValue = self.PointY[i]
          else
            if self.NewMinValue>self.PointY[i] then
              self.NewMinValue = self.PointY[i]
            end
          end
          if self.MaxValue < self.PointY[i] then
            self.MaxValue = self.PointY[i]
          else
            if self.MinValue>self.PointY[i] then
              self.MinValue = self.PointY[i]
            end
          end
          local x1 = self.PointX[i]+self.X+baseX
          local y1 = (self.Height-((self.PointY[i]+math.abs( self.MinValue ))/(self.MaxValue+math.abs( self.MinValue )))*(self.Height-3))+self.Y+baseY-2
          local x2 = self.PointX[i-1]+self.X+baseX
          local y2 = (self.Height-((self.PointY[i-1]+math.abs( self.MinValue ))/(self.MaxValue+math.abs( self.MinValue )))*(self.Height-3))+self.Y+baseY-2
          if y1==y1 and y2==y2 then
            if IsFocused==true then    
              gfx.drawLine(x1,y1,x2,y2,gfx.getColors(self.Theme.GraphColor))
            else
              gfx.drawLine(x1,y1,x2,y2,gfx.getColors(self.Theme.UnfocusedGraphColor))
            end
          end
        end
      end
      if self.PointY[1]~=nil then
        if self.NewMaxValue < self.PointY[1] then
          self.NewMaxValue = self.PointY[1]
        else
          if self.NewMinValue>self.PointY[1] then
            self.NewMinValue = self.PointY[1]
          end
        end
        if self.MaxValue < self.PointY[1] then
          self.MaxValue = self.PointY[1]
        else
          if self.MinValue>self.PointY[1] then
            self.MinValue = self.PointY[1]
          end
        end
        self.ZeroHeight = (self.Height-((math.abs( self.MinValue ))/(self.MaxValue+math.abs( self.MinValue )))*(self.Height-3))+self.Y+baseY-2
        if self.ZeroHeight == self.ZeroHeight then
          if IsFocused== true then
            gfx.drawLine(self.X+baseX,self.ZeroHeight,self.X+baseX+self.Width-1,self.ZeroHeight,gfx.getColors(self.Theme.ZeroLine))
          else
            gfx.drawLine(self.X+baseX,self.ZeroHeight,self.X+baseX+self.Width-1,self.ZeroHeight,gfx.getColors(self.Theme.UnfocusedZeroLine))
          end
        end
      end
      self.MaxValue = self.NewMaxValue
      self.MinValue = self.NewMinValue
    end 
    function obj:Show()
      self.IsShowing = true
    end
    function obj:Hide()
      self.IsShowing = false
    end
    function obj:AddPoint(v) 
      if v~= nil then
      if #self.PointY==0 then
        self.PointY[1]=v
        self.PointX[1]=1
      else
        if #self.PointY+1 < self.Width-1 then
        self.PointY[#self.PointY+1]=v
        self.PointX[#self.PointX+1]=self.PointX[#self.PointX]+1
        else
          for i=2,#self.PointY do
            self.PointY[i-1]=self.PointY[i]
            self.PointX[i-1]=self.PointX[i]-1
          end
          self.PointY[#self.PointY]=v
          self.PointX[#self.PointX]=self.PointX[#self.PointX]
        end
      end
      end
    end
    function obj:ClearPoints() 
        self.PointY = {}
        self.PointX = {}
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
      if (x>self.X+self.Width-self.Height) and (x<self.X+self.Width) and (y>self.Y) and (y<self.Y+self.Height) then
        return true
      end
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end

  function interface_s.Components.Label:new(x, y, t, theme)
    local obj= {}
    obj.Type = "Label"

    obj.X = x
    obj.Y = y
    obj.Anchor = {Top = false,Bottom=false,Left=false,Right=false}
    obj.Theme = theme
    obj.HintText = ""
    obj.IsShowing = true
    obj.Text = t
    
    obj.OnClick = nil

    obj.Base = nil
    obj.Focused=false
    obj.HintHelper = nil
    function obj:Draw(IsFocused, baseX, baseY,x,y)
      if not self.IsShowing then return end
      self.Focused = IsFocused
      if IsFocused==true then
        gfx.drawText(self.X+baseX,self.Y+baseY,self.Text,gfx.getColors(self.Theme.TextColor))
        local tw, th = gfx.textSize(self.Text)
        if (x>self.X) and (x<self.X+tw) and (y>self.Y) and (y<self.Y+th) then
          if self.HintHelper~=nil then
            self.HintHelper:MouseOver(x+baseX,y+baseY,self.HintText)
          end
        else
          if self.HintHelper~=nil then
            self.HintHelper:Reset()
          end
        end
      else
        if self.HintHelper~=nil then
          self.HintHelper:Reset()
        end
        gfx.drawText(self.X+baseX,self.Y+baseY,self.Text,gfx.getColors(self.Theme.UnfocusedTextColor))
      end
    end 
    function obj:Show()
      self.IsShowing = true
    end
    function obj:Hide()
      self.IsShowing = false
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
    end
    function obj:AddHint(text)
      self.HintText = text
      self.HintHelper = interface_s.ComponentsHelpers.Hint:new()
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end

  function interface_s.Components.Textbox:new(x, y, w, h, theme)
    local obj= {}
    obj.Type = "Textbox"

    obj.X = x
    obj.Y = y
    obj.Theme = theme
    obj.IsShowing = true
    obj.Width = w
    obj.Height = h
    obj.Text = ""
    obj.Enabled = true
    obj.Anchor = {Top = false,Bottom=false,Left=false,Right=false}
    obj.MaxTextLength = 10
    obj.PointerIndex = 0

    obj.OnTextChanged = nil
    obj.OnClick = nil

    obj.Focused=false
    obj.Base = nil
    obj.IsActive = false
    obj.PointerBlinkStep =0
    obj.ClickHelper = interface_s.ComponentsHelpers.Click:new()
    obj.ClickHelper.OnPress = function()
        obj.IsActive = true
      end
    obj.ClickHelper.OnMissClick = function()
        obj.IsActive = false
      end
    function obj:Draw(IsFocused, baseX, baseY,x,y)
      if not self.IsShowing then return end
      self.Focused = IsFocused
      gfx.fillRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.BackColor))
      if self.IsActive==true and self.Enabled then
        gfx.drawRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.BorderColor))
        self.PointerBlinkStep = self.PointerBlinkStep + 1
        if self.PointerBlinkStep > 30 then
          self.PointerBlinkStep=0
        end
        if self.PointerBlinkStep > 15 then
          local x = gfx.textSize(string.sub(self.Text, 0,self.PointerIndex) )
          gfx.drawLine(x+self.X+baseX+1,self.Y+baseY+4, x+self.X+baseX+1, self.Y+baseY+self.Height-4,gfx.getColors(self.Theme.PointerColor)) 
        end
      else
        gfx.drawRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.UnfocusedBorderColor))
      end
      local x, y = gfx.textSize(string.sub(self.Text, 0,self.PointerIndex) )
      if IsFocused==true and self.Enabled then
        gfx.drawText(self.X+baseX+2,self.Y+baseY+(self.Height-y+3)/2,self.Text,gfx.getColors(self.Theme.TextColor))
      else
        gfx.drawText(self.X+baseX+2,self.Y+baseY+(self.Height-y+3)/2,self.Text,gfx.getColors(self.Theme.UnfocusedTextColor))
      end
    end 
    function obj:Show()
      self.IsShowing = true
    end
    function obj:Hide()
      self.IsShowing = false
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
      if self.Enabled then
        self.ClickHelper:ProcessClick(self.Width,self.Height,self.X,self.Y,x,y,e,b)
      end
    end
    function obj:KeyPress(code, scan, r, ctrl, shift, alt)
      if self.IsActive==true and self.Enabled then
        if scan~=nil then
          if code==8 and self.PointerIndex>0 then
            self.PointerIndex=self.PointerIndex-1
            self.Text=string.sub(self.Text,0,self.PointerIndex)..string.sub(self.Text,self.PointerIndex+2)
            if self.OnTextChanged~=nil then
              self.OnTextChanged(self.Text)
            end
          elseif code==127 and self.PointerIndex~=string.len(self.Text) then
            self.PointerIndex=self.PointerIndex
            self.Text=string.sub(self.Text,0,self.PointerIndex)..string.sub(self.Text,self.PointerIndex+2)
            if self.OnTextChanged~=nil then
              self.OnTextChanged(self.Text)
            end
          elseif code==1073741903 and string.len(self.Text)>=self.PointerIndex+1 then
            self.PointerIndex=self.PointerIndex+1
          elseif code==1073741904 and self.PointerIndex>0 then
            self.PointerIndex=self.PointerIndex-1
          end
        else
          if string.len(self.Text)<=self.MaxTextLength then
            self.PointerIndex=self.PointerIndex+1
            self.Text=string.sub(self.Text,0,self.PointerIndex-1)..code..string.sub(self.Text,self.PointerIndex)
            if self.OnTextChanged~=nil then
              self.OnTextChanged(self.Text)
            end
          end
        end
        return true
      end
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end

  function interface_s.Components.Checkbox:new(x, y, s, t, theme)
    local obj= {}
    obj.Type = "Checkbox"

    obj.X = x
    obj.Y = y
    obj.Theme = theme
    obj.IsShowing = true
    obj.Size = s
    obj.Text = t
    obj.Enabled = true
    obj.Checked = false
    obj.Anchor = {Top = false,Bottom=false,Left=false,Right=false}

    obj.OnStateChanged = nil
    obj.OnClick = nil

    obj.Focused=false
    obj.Base = nil
    obj.ClickHelper = interface_s.ComponentsHelpers.Click:new()
    obj.ClickHelper.OnPress = function()
        if obj.Checked==true then
          obj.Checked = false
        else
          obj.Checked = true
        end
        if obj.OnStateChanged~=nil then
          obj.OnStateChanged(obj.Checked)
        end
      end
    function obj:Draw(IsFocused, baseX, baseY,x,y)
      if not self.IsShowing then return end
      self.Focused = IsFocused
      local x, y = gfx.textSize(self.Text)
      if IsFocused==true and self.Enabled then
        gfx.drawRect(self.X+baseX,self.Y+baseY,self.Size,self.Size,gfx.getColors(self.Theme.BorderColor))
        if self.Checked==true then
          gfx.fillRect(self.X+baseX+3,self.Y+baseY+3,self.Size-6,self.Size-6,gfx.getColors(self.Theme.CheckColor))
        end
        gfx.drawText(self.X+baseX+self.Size+4,self.Y+baseY+(self.Size-y)/2+1,self.Text,gfx.getColors(self.Theme.TextColor))
      else
        gfx.drawRect(self.X+baseX,self.Y+baseY,self.Size,self.Size,gfx.getColors(self.Theme.UnfocusedBorderColor))
        if self.Checked==true then
          gfx.fillRect(self.X+baseX+3,self.Y+baseY+3,self.Size-6,self.Size-6,gfx.getColors(self.Theme.UnfocusedCheckColor))
        end
        gfx.drawText(self.X+baseX+self.Size+4,self.Y+baseY+(self.Size-y)/2+1,self.Text,gfx.getColors(self.Theme.UnfocusedCheckColor))
      end
    end 
    function obj:Show()
      self.IsShowing = true
    end
    function obj:Hide()
      self.IsShowing = false
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
      if self.Enabled then
        return self.ClickHelper:ProcessClick(self.Size,self.Size,self.X,self.Y,x,y,e,b)
      end
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end

  function interface_s.Components.Selection:new(x, y, theme)
    local obj= {}
    obj.X = x
    obj.Y = y
    obj.Focused=false
    obj.Theme = theme
    obj.IsShowing = true
    obj.IsPointSet = false
    obj.FirstPointX = -1
    obj.FirstPointY = -1
    obj.IsFinished = false
    obj.EndPointX = -1
    obj.EndPointY = -1
    obj.OnSelectionStart = nil
    obj.OnSelected = nil
    obj.OnSelectionAborted = nil
    obj.V2EndWidth = -1
    obj.V2EndHeight = -1
    obj.V2StartX = -1
    obj.V2StartY = -1
    obj.OnClick = nil
    obj.OnDraw = nil
    function obj:Draw(IsFocused,x,y)
      if self.OnDraw~=nil then
        IsFocused,x,y = self.OnDraw(IsFocused,x,y)
        if IsFocused == nil then return end
      end
      self.Focused = IsFocused
      if IsFocused then
        if (self.IsPointSet) and (self.IsFinished==false) then
          local arg11 = -1
          local arg12 = -1
          local arg21 = -1
          local arg22 = -1
          if self.FirstPointX-x>=0 then
            arg11 = x
            arg12 = self.FirstPointX-x
          else
            arg11 = self.FirstPointX
            arg12 = x-self.FirstPointX
          end
          if self.FirstPointY - y>=0 then
            arg21 = y
            arg22 = self.FirstPointY - y
          else
            arg21 = self.FirstPointY
            arg22 = y-self.FirstPointY
          end
          if (self.IsFinished==false) and (self.IsPointSet==true)  then
            self.V2EndWidth = arg12
            self.V2EndHeight = arg22
            self.V2StartX = arg11
            self.V2StartY = arg21
          end
          gfx.fillRect(arg11, arg21, arg12,arg22, gfx.getColors(self.Theme.BackColor))
        end
      else
        self.IsPointSet = false
      end
    end 
    function obj:Show()
      self.IsShowing = true
    end
    function obj:Hide()
      self.IsShowing = false
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
      if (e==mouseEvents.Down) and (self.IsPointSet==false) and (b==mouseButtons.Left) then
        self.IsPointSet = true
        self.FirstPointX = x
        self.FirstPointY = y
        if self.OnSelectionStart ~= nil then
          self.OnSelectionStart(self.FirstPointX,self.FirstPointY)
        end
        return true
      else 
        if (e==mouseEvents.Up) and (self.IsPointSet==true) and (b==mouseButtons.Left) and (self.IsFinished == false) then
          self.IsFinished = true
          self.EndPointX = x
          self.EndPointY = y
          if self.OnSelected ~= nil then
            self.OnSelected(self.FirstPointX,self.FirstPointY,self.EndPointX,self.EndPointY, self.V2StartX, self.V2StartY, self.V2EndWidth,self.V2EndHeight)
          end
          return true
        end
        if (self.IsPointSet==true) and (b~=mouseButtons.Left) and (self.IsFinished==false) then
          self.IsPointSet=false
          if self.OnSelectionAborted ~= nil then
            self.OnSelectionAborted()
          end
        end
      end
    end
    function obj:Move()
    end
    function obj:KeyPress(key, scan, r, ctrl, shift, alt)
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end

  function interface_s.Components.SelectionMover:new(x, y,w,h, theme)
    local obj= {}
    obj.X = x
    obj.Y = y
    obj.Focused=false
    obj.Theme = theme
    obj.IsShowing = true
    obj.Width = w
    obj.Height = h
    obj.OnMovement = nil
    obj.OnAbort = nil
    obj.OnDone = nil
    obj.MoveStartX = -1
    obj.MoveStartY = -1
    obj.NewPosX = -1
    obj.NewPosY = -1
    obj.IsMoving = false
    obj.SumDX = 0
    obj.SumDY = 0
    obj.IsMoved = false
    obj.OnDraw = nil
    obj.OnClick = nil
    obj.OnMove = nil
    function obj:Draw(IsFocused,x,y)
      if self.OnDraw~=nil then
        self.OnDraw(IsFocused,x,y)
      end
      self.Focused = IsFocused
      gfx.fillRect(self.X, self.Y, self.Width,self.Height, gfx.getColors(self.Theme.BackColor))
    end 
    function obj:Show()
      self.IsShowing = true
    end
    function obj:Hide()
      self.IsShowing = false
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
      if (e==3) and (self.IsMoving) then  --For old versions
        if self.OnMovement ~= nil then
          self.OnMovement(-self.MoveStartX + x,- self.MoveStartY + y)
        end
        if (-self.MoveStartX + x ~= 0) and (- self.MoveStartY + y ~= 0) then
          self.IsMoved = true
        end
        self.SumDX = self.SumDX - self.MoveStartX + x
        self.SumDY = self.SumDY - self.MoveStartY + y
        self.X = self.X - self.MoveStartX + x
        self.Y = self.Y - self.MoveStartY + y
        self.MoveStartX = x
        self.MoveStartY = y
      else
        if (e==mouseEvents.Up) and (self.IsMoving) then
          if self.IsMoved == false then
            if self.OnDone ~= nil then
              self.OnDone(self.SumDX,self.SumDY)
            end
          end
          self.IsMoving = false
        end
      end
      if (x>self.X) and (x<self.X+self.Width) and (y>self.Y) and (y<self.Y+self.Height) then
        if (e==mouseEvents.Down) and (b==mouseButtons.Right or b==4) then
          if self.OnAbort ~= nil then
            self.OnAbort(self.SumDX,self.SumDY)
          end
        end
        if (y>self.Y) and (y<self.Y+self.Height) and (e==mouseEvents.Down) then
          self.MoveStartX = x
          self.MoveStartY = y
          self.IsMoving = true
        end
        if (e==mouseEvents.Down) and (b==mouseButtons.Left) then
          self.IsMoved = false
        end
        return true
      end
    end
    function obj:Move(x,y,dx,dy)
      if self.OnMove~=nil then
        x,y,dx,dy = self.OnMove(x,y,dx,dy)
        if x==nil then
          return
        end
      end
      if self.IsMoving then
        if self.OnMovement ~= nil then
          self.OnMovement(-self.MoveStartX + x,- self.MoveStartY + y)
        end
        if (-self.MoveStartX + x ~= 0) and (- self.MoveStartY + y ~= 0) then
          self.IsMoved = true
        end
        self.SumDX = self.SumDX - self.MoveStartX + x
        self.SumDY = self.SumDY - self.MoveStartY + y
        self.X = self.X - self.MoveStartX + x
        self.Y = self.Y - self.MoveStartY + y
        self.MoveStartX = x
        self.MoveStartY = y
      end
    end
    function obj:KeyPress(key, scan, r, ctrl, shift, alt)
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end

  function interface_s.Components.Listbox:new(x, y, w, h, theme)
    local obj= {}
    obj.Type = "Listbox"
    obj.X = x
    obj.Y = y
    obj.Focused=false
    obj.Theme = theme
    obj.IsShowing = true
    obj.Width = w
    obj.Height = h
    obj.Anchor = {Top = false,Bottom=false,Left=false,Right=false}
    obj.SelectedIndex = 1
    obj.Items = {}
    obj.ItemsColsCount = 1
    obj.ItemsColsPadding = {0}

    obj.OnItemSelected = nil
    obj.OnClick = nil

    obj.Base = nil
    obj.IsActive = false
    obj.ScrollStartItemIndex = 1
    obj.ItemClickHelper = interface_s.ComponentsHelpers.Click:new()
    obj.ItemClickHelper.OnPress = function(x,y)
        obj.SelectedIndex=math.floor((y-obj.Y)/11)+obj.ScrollStartItemIndex-1
        if obj.OnItemSelected~= nil then
          obj.OnItemSelected(obj.SelectedIndex,obj.Items[obj.SelectedIndex])
        end
        return true
    end
    function obj:Draw(IsFocused, baseX, baseY,x,y)
      if not self.IsShowing then return end
      self.Focused = IsFocused
      gfx.fillRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.BackColor))
      gfx.drawRect(self.X+baseX,self.Y+baseY,self.Width,self.Height,gfx.getColors(self.Theme.BorderColor))
      local endindex = math.floor(self.Height/11)+self.ScrollStartItemIndex-1
      if table.getn(self.Items)<math.floor(self.Height/11) then
        endindex = table.getn(self.Items)
      end
      for i=self.ScrollStartItemIndex, endindex do
        if IsFocused then
          if self.SelectedIndex==i-1 then
            gfx.fillRect(self.X+baseX+2,self.Y+baseY+(i-self.ScrollStartItemIndex)*11+2,self.Width-4,10,gfx.getColors(self.Theme.SelectionColor))
            if self.ItemsColsCount==1 then
              gfx.drawText(self.X+baseX+3,self.Y+baseY+3+(i-self.ScrollStartItemIndex)*11,self.Items[i],gfx.getColors(self.Theme.SelectionTextColor))
            else
              for j=1, self.ItemsColsCount do
                gfx.drawText(self.X+baseX+3+self.ItemsColsPadding[j],self.Y+baseY+3+(i-self.ScrollStartItemIndex)*11,self.Items[i][j],gfx.getColors(self.Theme.SelectionTextColor))
              end
            end
          else
            if self.ItemsColsCount==1 then
              gfx.drawText(self.X+baseX+3,self.Y+baseY+3+(i-self.ScrollStartItemIndex)*11,self.Items[i],gfx.getColors(self.Theme.TextColor))
            else
              for j=1, self.ItemsColsCount do
                gfx.drawText(self.X+baseX+3+self.ItemsColsPadding[j],self.Y+baseY+3+(i-self.ScrollStartItemIndex)*11,self.Items[i][j],gfx.getColors(self.Theme.TextColor))
              end
            end
          end
          if x>self.X+3 and x<self.X+self.Width and y>self.Y+(i-self.ScrollStartItemIndex)*11 and y<self.Y+(i-self.ScrollStartItemIndex)*11+11 then
            gfx.fillRect(self.X+baseX+1,self.Y+baseY+(i-self.ScrollStartItemIndex)*11,self.Width-2,12,gfx.getColors(self.Theme.MouseOverColor))
          end
      else -- unfocused
        if self.SelectedIndex==i-1 then
          gfx.fillRect(self.X+baseX+2,self.Y+baseY+(i-self.ScrollStartItemIndex)*11+2,self.Width-4,10,gfx.getColors(self.Theme.UnfocusedSelectionColor))
          if self.ItemsColsCount==1 then
            gfx.drawText(self.X+baseX+3,self.Y+baseY+3+(i-self.ScrollStartItemIndex)*11,self.Items[i],gfx.getColors(self.Theme.UnfocusedSelectionTextColor))
          else
            for j=1, self.ItemsColsCount do
              gfx.drawText(self.X+baseX+3+self.ItemsColsPadding[j],self.Y+baseY+3+(i-self.ScrollStartItemIndex)*11,self.Items[i][j],gfx.getColors(self.Theme.UnfocusedSelectionTextColor))
            end
          end
        else
          if self.ItemsColsCount==1 then
            gfx.drawText(self.X+baseX+3,self.Y+baseY+3+(i-self.ScrollStartItemIndex)*11,self.Items[i],gfx.getColors(self.Theme.UnfocusedTextColor))
          else
            for j=1, self.ItemsColsCount do
              gfx.drawText(self.X+baseX+3+self.ItemsColsPadding[j],self.Y+baseY+3+(i-self.ScrollStartItemIndex)*11,self.Items[i][j],gfx.getColors(self.Theme.UnfocusedTextColor))
            end
          end
        end
        if x>self.X+3 and x<self.X+self.Width and y>self.Y+(i-self.ScrollStartItemIndex)*11 and y<self.Y+(i-self.ScrollStartItemIndex)*11+11 then
          gfx.fillRect(self.X+baseX+1,self.Y+baseY+(i-self.ScrollStartItemIndex)*11,self.Width-2,12,gfx.getColors(self.Theme.UnfocusedMouseOverColor))
        end
      end
    end
    end 
    function obj:Show()
      self.IsShowing = true
    end
    function obj:Hide()
      self.IsShowing = false
    end
    function obj:Click(x,y,e,b,w)
      if self.OnClick~=nil then
        x,y,e,b,w = self.OnClick(x,y,e,b,w)
        if x==nil then
          return
        end
      end
      if w==1 and self.ScrollStartItemIndex<table.getn(self.Items)-math.floor( self.Height/11 )+1 then
        self.ScrollStartItemIndex=self.ScrollStartItemIndex+1
        return true
      elseif w==-1 and self.ScrollStartItemIndex>1 then
        self.ScrollStartItemIndex=self.ScrollStartItemIndex-1
        return true
      end
      return self.ItemClickHelper:ProcessClick(self.Width,(#self.Items-self.ScrollStartItemIndex+1)*11,self.X,self.Y,x,y,e,b)
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end

  function interface_s.ComponentsHelpers.Click:new(x, y)
    local obj= {}
    obj.IsFirstClick = false
    obj.OnPress = nil
    obj.OnFirstClick = nil
    obj.OnMissClick = nil
    function obj:ProcessClick(width,height,x,y,clickX,clickY,e,b)
      if (clickX>x) and (clickX<x+width) and (clickY>y) and (clickY<y+height) and (self.IsFirstClick==false) and (e==mouseEvents.Down) and (b==mouseButtons.Left) then
        self.IsFirstClick=true
        if self.OnFirstClick ~= nil then
          return self.OnFirstClick(clickX,clickY)
        else
          return true
        end
      else
        if (clickX>x) and (clickX<x+width) and (clickY>y) and (clickY<y+height) and (self.IsFirstClick==true) and (e==mouseEvents.Up) and (b==mouseButtons.Left) then
          self.IsFirstClick = false   
          if self.OnPress~= nil then
            return self.OnPress(clickX,clickY)
          else
            return true
          end
        else
          self.IsFirstClick = false
          if self.OnMissClick~= nil then
            return self.OnMissClick(clickX,clickY)
          end
        end
      end 
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end
  function interface_s.ComponentsHelpers.Hint:new()
    local obj= {}
    obj.HintFrames = 0
    obj.Window = interface_s.Components.Window:new(0, 0, 0, 12,false, interface_s.DefaultTheme.Window)
    obj.Label = interface_s.Components.Label:new(5,2,"",interface_s.DefaultTheme.Label)
    obj.Window:AddComponent(obj.Label)
    obj.Window.AllowResize = false
    obj.Window.AlwaysFocused = true
    function obj:MouseOver(x,y,text)
      if text~="" then
        self.HintFrames = self.HintFrames + 1
        if self.HintFrames>40 then
          local w,h = gfx.textSize(text)
          self.Window.X = x
          self.Window.Y = y+12
          self.Window.Width = w+10
          self.Label.Text = text
          self.Window:Draw(true,x,y)
        end
      end
    end
    function obj:Reset()
      self.HintFrames = 0
    end
    setmetatable(obj, self)
    self.__index = self;
    return obj
  end
end
local function DefineAPI()
  interface_s.Components.Window = {}
  interface_s.Components.Button = {}
  interface_s.Components.Combobox = {}
  interface_s.Components.Graph = {}
  interface_s.Components.Label = {}
  interface_s.Components.Textbox = {}
  interface_s.Components.Checkbox = {}
  interface_s.Components.Listbox = {}
  interface_s.Components.Selection = {}
  interface_s.Components.SelectionMover = {}
  interface_s.ComponentsHelpers.Click = {}
  interface_s.ComponentsHelpers.Hint = {}
  
  interface_s.AddOnClickAction = function(func)
    for i=#interface_s.OnClick+1,2,-1 do
      interface_s.OnClick[i]=interface_s.OnClick[i-1]
    end
    if type(func) == "function" then
      interface_s.OnClick[1]={}
      interface_s.OnClick[1].Click = func
    else
      interface_s.OnClick[1] = func
    end
  end

  interface_s.RemoveOnClickAction = function(func)
    local index = interface_s.GetOnClickActionIndex(func)
    if index~=-1 then
      interface_s.OnClick[index] = 0
    end
  end

  interface_s.GetOnClickActionIndex=function(obj)
    if type(obj) == "function" then
      for i=1, #interface_s.OnClick do
        if interface_s.OnClick[i]~=0 then
          if interface_s.OnClick[i].Click == obj then
            return i
          end
        end
      end
    else
      for i=1, #interface_s.OnClick do
        if interface_s.OnClick[i] == obj then
          return i
        end
      end
    end
    return -1
  end

  interface_s.AddOnStepAction = function(func)
    for i=#interface_s.OnStep+1,2,-1 do
      interface_s.OnStep[i]=interface_s.OnStep[i-1]
    end
    interface_s.OnStep[1] = func
  end

  interface_s.RemoveOnStepAction = function(func)
    local index = interface_s.GetOnStepActionIndex(func)
    if index~=-1 then
      interface_s.OnStep[index]=0
    end
  end

  interface_s.GetOnStepActionIndex=function(obj)
    for i=1, #interface_s.OnStep do
      if interface_s.OnStep[i] == obj then
        return i
      end
    end
    return -1
  end

  interface_s.AddKeyPressAction = function(func)
    for i=#interface_s.OnKeyPress+1,2,-1 do
      interface_s.OnKeyPress[i]=interface_s.OnKeyPress[i-1]
    end
    if type(func) == "function" then
      interface_s.OnKeyPress[1]={}
      interface_s.OnKeyPress[1].KeyPress = func
    else
      interface_s.OnKeyPress[1] = func
    end
  end

  interface_s.RemoveKeyPressAction = function(func)
    local index = interface_s.GetOnKeyPressActionIndex(func)
    if index~=-1 then
      interface_s.OnKeyPress[index]=0
    end
  end

  interface_s.GetOnKeyPressActionIndex=function(obj)
    if type(obj) == "function" then
      for i=1, #interface_s.OnKeyPress do
        if interface_s.OnKeyPress[i].KeyPress == obj then
          return i
        end
      end
    else
      for i=1, #interface_s.OnKeyPress do
        if interface_s.OnKeyPress[i] == obj then
          return i
        end
      end
    end
    return -1
  end
  interface_s.AddLeftWindow=function(obj) 
    for i=#interface_s.windows+1,2,-1 do
      interface_s.windows[i]=interface_s.windows[i-1]
    end
    interface_s.windows[1]=obj
  end
  
  interface_s.addComponent=function(obj) 
    interface_s.AddLeftWindow(obj) 
  end
  
  interface_s.GetComponentIndex=function(obj)
    for i=1, #interface_s.windows do
      if interface_s.windows[i] == obj then
        return i
      end
    end
    return -1
  end
  
  interface_s.RemoveComponent=function(obj) 
    local index = interface_s.GetComponentIndex(obj)
    if index~=-1 then
      for i=index, #interface_s.windows-1 do
        interface_s.windows[i]=interface_s.windows[i+1]
      end
      interface_s.windows[#interface_s.windows] = nil
    end
  end
  
  interface_s.focusComponent = function(index)
    local temp= interface_s.windows[index] 
    for i=index, 2,-1 do
      interface_s.windows[i] = interface_s.windows[i-1] 
    end
    interface_s.windows[1] = temp
  end

  interface_s.deleteFromArray = function(ar,index)
    for i=index, #ar-1 do
      ar[i]=ar[i+1]
    end
    ar[#ar] = nil
  end

  interface_s.step = function()
    local deletedFound = false
    for i=1,#interface_s.OnStep do
      if interface_s.OnStep[i]~=0 then
        interface_s.OnStep[i](tpt.mousex,tpt.mousey)
      else
        deletedFound = true
      end
    end
    if deletedFound then
      for i=1,#interface_s.OnStep do
        if interface_s.OnStep[i]==0 then
          interface_s.deleteFromArray(interface_s.OnStep,i)
          i=i-1
        end
      end
    end
    for i=#interface_s.windows, 1,-1 do
      if (interface_s.windows[i] ~= nil) and (interface_s.windows[i].IsShowing==true) then
        if i==1 then
          interface_s.windows[i]:Draw(true,tpt.mousex,tpt.mousey)
        else
          interface_s.windows[i]:Draw(false,tpt.mousex,tpt.mousey)
        end
      end
    end
  end

  interface_s.click = function(mousex, mousey, button, event,wheel)
    if event==3 then
      interface_s.mousemove(mousex,mousey,-1,-1)
      return true
    end
    local deletedFound = false
    local f = false
    for i=1,#interface_s.OnClick do
      if interface_s.OnClick[i]~=0 then
        if interface_s.OnClick[i].Base~=nil then
          if interface_s.OnClick[i]:Click(mousex-interface_s.OnClick[i].Base.X , mousey-interface_s.OnClick[i].Base.Y , event, button,wheel) then
            f=true
          end
        else
          if interface_s.OnClick[i].Click(mousex, mousey, event, button,wheel) then
            f=true
          end
        end
      else
        deletedFound = true
      end
    end
    if deletedFound then
      for i=1,#interface_s.OnClick do
        if interface_s.OnClick[i]==0 then
          interface_s.deleteFromArray(interface_s.OnClick,i)
          i=i-1
        end
      end
    end
    for i=1,#interface_s.windows do
      if interface_s.windows[i] == nil then
        interface_s.RemoveComponent(interface_s.windows[i])
        break
      end
      if (interface_s.windows ~= nil) then
        if interface_s.windows[i]:Click(mousex , mousey , event, button,wheel) then
          if (interface_s.windows[i]~=nil) and (interface_s.windows[i].IsShowing~=nil) and (interface_s.windows[i].IsShowing==true) then
            interface_s.focusComponent(i) 
            return false
          end
        end 
      end
    end
    if f==true then
      return false
    end
  end

  interface_s.key = function(char, code, mod, evt)
    local f = false
    if interface_s.windows[1] ~= nil then
      if interface_s.windows[1]:KeyPress(char, code, mod, evt) then
        f = true
      end
    end
    local deletedFound = false
    for i=1,#interface_s.OnKeyPress do
      if interface_s.OnKeyPress[i]~=0 then
        if interface_s.OnKeyPress[i].Base~=nil then
          if interface_s.OnKeyPress[i]:KeyPress(char, code, mod, evt) then
            f=true
          end
        else
          if interface_s.OnKeyPress[i].KeyPress(char, code, mod, evt) then
            f=true
          end
        end
      else
        deletedFound = true
      end
    end
    if deletedFound then
      for i=1,#interface_s.OnKeyPress do
        if interface_s.OnKeyPress[i]==0 then
          interface_s.deleteFromArray(interface_s.OnKeyPress,i)
          i=i-1
        end
      end
    end
    if interface_s.BlockKeyboard == true or f==true then
      return false
    end
  end

  interface_s.mousemove = function(x, y, dx, dy)
    for i=1,#interface_s.windows do
      if interface_s.windows[i] == nil then
        interface_s.RemoveComponent(interface_s.windows[i])
        break
      end
      if (interface_s.windows ~= nil) then
        if interface_s.windows[i]:Move(x , y , dx, dy) then
          if (interface_s.windows[i]~=nil) and (interface_s.windows[i].IsShowing~=nil) and (interface_s.windows[i].IsShowing==true) then
            interface_s.focusComponent(i) 
            return false
          end
        end 
      end
    end
  end

  interface_s.mouseUpToClick = function(x, y, b)
    return interface_s.click(x,y,b,mouseEvents.Up)
  end
  
  interface_s.mouseDownToClick = function(x, y, b)
    return interface_s.click(x,y,b,mouseEvents.Down)
  end
  
  interface_s.mouseWheelToClick = function(x, y, d)
    return interface_s.click(x,y,0,0,d)
  end

  if tpt.version.major<=93 and tpt.version.jacob1s_mod==nil or tpt.version.jacob1s_mod~=nil and tpt.version.jacob1s_mod<42 then
    tpt.register_step(interface_s.step)
    tpt.register_mouseclick(interface_s.click)
    tpt.register_keypress(interface_s.key)
  else
    event.register(event.tick, interface_s.step)  
    event.register(event.mousedown, interface_s.mouseDownToClick)
    event.register(event.mouseup, interface_s.mouseUpToClick)
    event.register(event.mousemove, interface_s.mousemove)
    event.register(event.mousewheel, interface_s.mouseWheelToClick)
    event.register(event.keypress, interface_s.key)
    event.register(event.textinput, interface_s.key)
  end
end
local function unregisterOldVerionEvents()
  pcall(tpt.unregister_step,interface_s.step)
  pcall(tpt.unregister_mouseclick,interface_s.click)
  pcall(tpt.unregister_keypress,interface_s.key)
  if event~=nil then
    pcall(event.unregister,event.mousedown,interface_s.mouseDownToClick)
    pcall(event.unregister,event.mouseup,interface_s.mouseUpToClick)
    pcall(event.unregister,event.mousemove,interface_s.mousemove)
    pcall(event.unregister,event.mousewheel,interface_s.mouseWheelToClick)
    pcall(event.unregister,event.keypress,interface_s.key)
    pcall(event.unregister,event.textinput,interface_s.key)
  end
end
local function InitIntefaceAPI()
  if interface_s == nil then
    interface_s = {
      Version = InterfaceAPIVersion,
      Components = {},
      ComponentsHelpers = {},
      windows = {},
      step = nil,
      click = nil,
      mouseUpToClick = nil,
      mouseDownToClick = nil,
      mouseWheelToClick = nil,
      mousemove = nil,
      key = nil,
      addLeft = nil,
      addComponent = nil,
      GetComponentIndex = nil,
      RemoveComponent = nil,
      focusComponent = nil,
      BlockKeyboard = false,
      OnClick = {},
      OnKeyPress = {},
      OnStep = {},
      DefaultTheme = {},
      mouseEvents = mouseEvents,
      mouseButtons = mouseButtons
    }
    DefineAPI()
    DefineInterfaceComponents()
  else
    if interface_s.Version<InterfaceAPIVersion then
      unregisterOldVerionEvents()
      interface_s = {
        Version = InterfaceAPIVersion,
        Components = {},
        ComponentsHelpers = {},
        windows = interface_s.windows,
        step = nil,
        click = nil,
        mouseUpToClick = nil,
        mouseDownToClick = nil,
        mouseWheelToClick = nil,
        mousemove = nil,
        key = nil,
        addLeft = nil,
        addComponent = nil,
        GetComponentIndex = nil,
        RemoveComponent = nil,
        focusComponent = nil,
        BlockKeyboard = interface_s.BlockKeyboard,
        OnClick = interface_s.OnClick or {},
        OnKeyPress = interface_s.OnKeyPress or {},
        OnStep = interface_s.OnStep or {},
        DefaultTheme = interface_s.DefaultTheme or {},
        mouseEvents = mouseEvents,
        mouseButtons = mouseButtons
      }
      DefineAPI()
      DefineInterfaceComponents()
    end
  end
end
InitIntefaceAPI()
--=================================================================--
--                       THEME START                               --
--=================================================================--
interface_s.DefaultTheme = {
  Window = {},
  Button = {},
  Combobox = {},
  Graph = {},
  Label = {},
  Textbox = {},
  Checkbox = {},
  Listbox = {},
  Selection = {}
}

interface_s.DefaultTheme.Window.BackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Window.UnfocusedBackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Window.BorderColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Window.UnfocusedBorderColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Window.HeaderColor = gfx.getHexColor(150,150,255,255)
interface_s.DefaultTheme.Window.UnfocusedHeaderColor = gfx.getHexColor(32,32,55,255)

interface_s.DefaultTheme.Button.BackColor = gfx.getHexColor(0,0,0,0)
interface_s.DefaultTheme.Button.UnfocusedBackColor = gfx.getHexColor(0,0,0,0)
interface_s.DefaultTheme.Button.PressedBackColor = gfx.getHexColor(240,240,240,255)
interface_s.DefaultTheme.Button.BorderColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Button.UnfocusedBorderColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Button.MouseOverColor = gfx.getHexColor(255,255,255,128)
interface_s.DefaultTheme.Button.UnfocusedMouseOverColor = gfx.getHexColor(150,150,150,128)
interface_s.DefaultTheme.Button.TextColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Button.UnfocusedTextColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Button.PressedTextColor = gfx.getHexColor(0,0,0,255)

interface_s.DefaultTheme.Combobox.BackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Combobox.UnfocusedBackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Combobox.BorderColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Combobox.UnfocusedBorderColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Combobox.TextColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Combobox.UnfocusedTextColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Combobox.ButtonBackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Combobox.ButtonPressedBackColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Combobox.ButtonMouseOverBackColor = gfx.getHexColor(150,150,150,128)
interface_s.DefaultTheme.Combobox.UnfocusedButtonBackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Combobox.UnfocusedButtonMouseOverBackColor = gfx.getHexColor(150,150,150,128)

interface_s.DefaultTheme.Graph.BackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Graph.BorderColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Graph.UnfocusedBackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Graph.UnfocusedBorderColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Graph.TextColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Graph.UnfocusedTextColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Graph.GraphColor = gfx.getHexColor(255,100,100,255)
interface_s.DefaultTheme.Graph.UnfocusedGraphColor = gfx.getHexColor(100,30,30,255)
interface_s.DefaultTheme.Graph.ZeroLine = gfx.getHexColor(255,200,200,255)
interface_s.DefaultTheme.Graph.UnfocusedZeroLine = gfx.getHexColor(100,80,80,255)

interface_s.DefaultTheme.Label.TextColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Label.UnfocusedTextColor = gfx.getHexColor(150,150,150,255)

interface_s.DefaultTheme.Textbox.BackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Textbox.BorderColor = gfx.getHexColor(255,200,200,255)
interface_s.DefaultTheme.Textbox.TextColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Textbox.UnfocusedTextColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Textbox.PointerColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Textbox.UnfocusedBorderColor = gfx.getHexColor(200,200,200,255)

interface_s.DefaultTheme.Checkbox.BorderColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Checkbox.UnfocusedBorderColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Checkbox.CheckColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Checkbox.UnfocusedCheckColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Checkbox.TextColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Checkbox.UnfocusedTextColor = gfx.getHexColor(150,150,150,255)

interface_s.DefaultTheme.Listbox.BackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Listbox.BorderColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Listbox.SelectionColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Listbox.SelectionTextColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Listbox.TextColor = gfx.getHexColor(255,255,255,255)
interface_s.DefaultTheme.Listbox.MouseOverColor = gfx.getHexColor(255,255,255,50)
interface_s.DefaultTheme.Listbox.UnfocusedBackColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Listbox.UnfocusedBorderColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Listbox.UnfocusedSelectionColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Listbox.UnfocusedSelectionTextColor = gfx.getHexColor(0,0,0,255)
interface_s.DefaultTheme.Listbox.UnfocusedTextColor = gfx.getHexColor(150,150,150,255)
interface_s.DefaultTheme.Listbox.UnfocusedMouseOverColor = gfx.getHexColor(150,150,150,50)

interface_s.DefaultTheme.Selection.BackColor = gfx.getHexColor(140,140,200,70)
--=================================================================--
--                         THEME END                               --
--=================================================================--
