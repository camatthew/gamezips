
elements.allocate("ME","RCNT")
elements.element(elements.ME_PT_RCNT,elements.element(elements.DEFAULT_PT_CNCT))
elements.property(elements.ME_PT_RCNT,"Name","RCNT")
elements.property(elements.ME_PT_RCNT,"Description","Reinforced Concrete")
elements.property(elements.ME_PT_RCNT,"Colour",0xBEACAC)


local function noFall(i,x,y)
    if tpt.get_property("type",x,y+1)~=0 or (tpt.get_property("type",x+1,y+1)~=0 and tpt.get_property("type",x+1,y)~=0) or (tpt.get_property("type",x-1,y+1)~=0 and tpt.get_property("type",x-1,y)~=0) then 
    --| R | or | #R | will not fall
    --| # |    | #  |
        tpt.set_property("vx",tpt.get_property("vx",i)/10,i) 
        tpt.set_property("vy",0,i)
    end
end

tpt.element_func(noFall,elements.ME_PT_RCNT)