
--RCA's HUD XV.I
--Please use cracker64's script manager
--VER 13 UPDATE {Not Available At Current Time}
 
--Version 15
 
print("RCA's HUD")
print("Version XV.I")
print("Have Fun!")

local rclr, gclr, bclr = 0, 255, 165
local rSlider, gSlider, bSlider, rtext, btext, gtext
local defaultc, purplec, turquoisec, realisticCheck, saveCheck
local coloruw
local openCheck
local tOn
local t
local frameCount,colourRED,colourGRN,colourBLU = 0,0,0,0
local time, FC = 0, 0
local counter = 0

if not tpt.version.jacob1s_mod then --support jacob1's mod (jacob1 edit)
--Windows
local window1 = Window:new(-1, -1, 611, 383)
local creditw = Window:new(-1, -1, 611, 383)
local infow = Window:new(-1, -1, 611, 383)
colourw = Window:new(-1, -1, 611, 383)
local messagew = Window:new(-1, -1, 611, 383)
local realisticw = Window:new(-1, -1, 611, 383)

--Texts
local creditsttl = Label:new(270, 1, 50, 15, "CREDITS")
local creditstxt = Label:new(1, 20, 611, 15, "Jacob1, Cracker 64, jward212 (NameColour, SaveLoader), and the knowledge gained from all Lua programmers in TPT.")
local infotxt = Label:new(1, 20, 611, 15, "How to use RCA's HUD (XV V.1):")
local instructions = Label:new(1, 40, 611, 15, "To turn the HUD on or off, use the H key on your keyboard.")
local instructions2 = Label:new(1, 60, 611, 15, "To turn on or off the extra level of the HUD (TMP2, VX, VY) use the D key.") 
local instructions3 = Label:new(1, 80, 611, 15, "Pressing the M key will engage Realistic Mode. Every five frames WTRV is turned into DSTW")
local instructions4 = Label:new(1, 90, 611, 15, "and all pixels are reset to normal temp. Press M again to turn off.")
local rca = Label:new(500, 5, 100, 15, "RCA Production (2015)")
local realisticmode = Label:new(10, 30, 150, 15, "Useful when using MultiPlayer")
rtext = Label:new(275, 10, 50, 15)
rtext:text("0")
gtext = Label:new(275, 40, 50, 15)
gtext:text("255")
btext = Label:new(275, 70, 50, 15)
btext:text("165")
rtext2 = Label:new(275, 130, 50, 15)
rtext2:text("0")
gtext2 = Label:new(275, 160, 50, 15)
gtext2:text("0")
btext2 = Label:new(275, 190, 50, 15)
btext2:text("0")
local redl = Label:new(325, 10, 50, 15, "Red")
local greenl = Label:new(325, 40, 50, 15, "Green")
local bluel = Label:new(325, 70, 50, 15, "Blue")
local redl2 = Label:new(325, 130, 50, 15, "Red")
local greenl2 = Label:new(325, 160, 50, 15, "Green")
local bluel2 = Label:new(325, 190, 50, 15, "Blue")
local messageText = Label:new(5, 5, 611, 15, "Hallo Sam. Jeg elsker deg... Du er veldig vakker... Jeg er forelsket.")
local messageQuote1 = Label:new(5, 25, 611, 15, "Never get tired of doin' little things for others. Sometimes those little things occupy")
local messageQuote2 = Label:new(5, 40, 611, 15, "the biggest part of their hearts. -lostfox")

--Red Slider
rSlider = Slider:new(10, 10, 255, 15, 255)
rSlider:value(0)
--Green Slider
gSlider = Slider:new(10, 40, 255, 15, 255)
gSlider:value(255)
--Blue Slider
bSlider = Slider:new(10, 70, 255, 15, 255)
bSlider:value(165)
    
if MANAGER then
rSlider:onValueChanged(function() r = rSlider:value() MANAGER.savesetting("RCA", "redColour", r) rclr = rSlider:value() rtext:text(rclr) end)
if MANAGER.getsetting("RCA", "redColour", r) == nil then rSlider:value(0) else
rSlider:value(MANAGER.getsetting("RCA", "redColour", r))
end
rclr = rSlider:value() 
rtext:text(rclr)
gSlider:onValueChanged(function() g = gSlider:value() MANAGER.savesetting("RCA", "greenColour", g) gclr = gSlider:value() gtext:text(gclr) end)
if MANAGER.getsetting("RCA", "greenColour", g) == nil then gSlider:value(255) else
gSlider:value(MANAGER.getsetting("RCA", "greenColour"))
end
gclr = gSlider:value()
gtext:text(gclr)
bSlider:onValueChanged(function() b = bSlider:value() MANAGER.savesetting("RCA", "blueColour", b) bclr = bSlider:value() btext:text(bclr) end)
if MANAGER.getsetting("RCA", "blueColour", b) == nil then bSlider:value(165) else
bSlider:value(MANAGER.getsetting("RCA", "blueColour"))
end
bclr = bSlider:value()
btext:text(bclr)
else
rSlider:onValueChanged(function() rclr = rSlider:value() rtext:text(rclr) end)
gSlider:onValueChanged(function() gclr = gSlider:value() gtext:text(gclr) end)
bSlider:onValueChanged(function() bclr = bSlider:value() btext:text(bclr) end)
end
    
--SLIDERS FOR NAME

--Red Slider
rSlider2 = Slider:new(10, 130, 255, 15, 255)
rSlider2:value(0)
--Green Slider
gSlider2 = Slider:new(10, 160, 255, 15, 255)
gSlider2:value(255)
--Blue Slider
bSlider2 = Slider:new(10, 190, 255, 15, 255)
bSlider2:value(165)

if MANAGER then
rSlider2:onValueChanged(function() r2 = rSlider2:value() MANAGER.savesetting("RCA", "redColour2", r2) rclr2 = rSlider2:value() rtext2:text(rclr2) end)
if MANAGER.getsetting("RCA", "redColour2", r2) == nil then rSlider2:value(0) else
rSlider2:value(MANAGER.getsetting("RCA", "redColour2", r2))
end
rclr2 = rSlider2:value() 
rtext2:text(rclr2)
gSlider2:onValueChanged(function() g2 = gSlider2:value() MANAGER.savesetting("RCA", "greenColour2", g2) gclr2 = gSlider2:value() gtext2:text(gclr2) end)
if MANAGER.getsetting("RCA", "greenColour2", g2) == nil then gSlider2:value(0) else
gSlider2:value(MANAGER.getsetting("RCA", "greenColour2"))
end
gclr2 = gSlider2:value()
gtext2:text(gclr2)
bSlider2:onValueChanged(function() b2 = bSlider2:value() MANAGER.savesetting("RCA", "blueColour2", b2) bclr2 = bSlider2:value() btext2:text(bclr2) end)
if MANAGER.getsetting("RCA", "blueColour2", b2) == nil then bSlider:value(0) else
bSlider2:value(MANAGER.getsetting("RCA", "blueColour2"))
end
bclr2 = bSlider:value()
btext:text(bclr2)
else
rSlider2:onValueChanged(function() rclr2 = rSlider2:value() rtext2:text(rclr2) end)
gSlider2:onValueChanged(function() gclr2 = gSlider2:value() gtext2:text(gclr2) end)
bSlider2:onValueChanged(function() bclr2 = bSlider2:value() btext2:text(bclr2) end)
end
    
--Checkbox Border
bordercheck = Checkbox:new(10, 100, 10, 10, "Colorful Border")
if MANAGER then
	bordercheck:action(function(sender, checked) MANAGER.savesetting("RCA", "border", checked and 1 or 0) end)
	bordercheck:checked(MANAGER.getsetting("RCA", "border") == "1" and true or false)
end
    
--Random Save Generator by jward212
local frameCount,beforeid,afterid = 0,0,1900000
local Tuner = Label:new(65,88,50,15, "Generate save between")
local errorbar = Label:new(100,120,50,15, "")
local input = Textbox:new(55, 105, 60, 15 , 0)
local input2 = Textbox:new(135, 105, 60, 15 , 1900000)
local idlabel = Label:new(30,105,30,16, "ID:")
local idlabel2 = Label:new(110,105,30,16, "ID:")
local Main = Window:new(150,80,300,300)
local CloseButton = Button:new(10, 274, 60, 16, "Close")
local PlayButton = Button:new(220, 274, 60, 16, "Load")
local Title = Label:new(9,5,120,16, "Save Loader")
local Author = Label:new(14,20,200,16, "by jward212 (Functionality Edits by RCA)")
CloseButton:action(function() interface.closeWindow(Main) end)

input:onTextChanged(function(sender) 
beforeid = input:text() 
end)
input2:onTextChanged(function(sender) 
afterid = input2:text() 
end)
PlayButton:action(function()
    if  beforeid > afterid then
        print("Error: First ID greater than second ID")
        errorbar:text("Error: First ID greater than second ID")
        else
        loadid = math.random(beforeid, afterid)
        sim.loadSave(loadid, 0) 
        interface.closeWindow(Main)
    end
end)
Main:onTryExit(function() interface.closeWindow(Main) end)
Main:addComponent(Author);
Main:addComponent(Title);
Main:addComponent(Tuner);
Main:addComponent(input);
Main:addComponent(input2);
Main:addComponent(idlabel);
Main:addComponent(idlabel2);
Main:addComponent(errorbar);
Main:addComponent(CloseButton);
Main:addComponent(PlayButton);
    
--Credits Button
local credits = Button:new(5, 5, 50, 15, "Credits")
credits:action(function() ui.showWindow(creditw) end)
--Close Credits Button
local close2 = Button:new(508, 365, 100, 15, "Close Credits")
close2:action(function() ui.closeWindow(creditw) end)
--Info Button
local info = Button:new(5, 25, 50, 15, "Info")
info:action(function() ui.showWindow(infow) end)
--Close Info Button
local close3 = Button:new(508, 365, 100, 15, "Close Info")
close3:action(function() ui.closeWindow(infow) end)
--Colour Button
local colourButton = Button:new(5, 45, 50, 15, "Colours")
colourButton:action(function() ui.showWindow(colourw) end)
--Close Colour Window
local closeColour = Button:new(508, 365, 100, 15, "Close Colours")
closeColour:action(function() ui.closeWindow(colourw) end)
--Realistic Mode
local realisticb = Button:new(5, 65, 50, 15, "Realistic")
realisticb:action(function() ui.showWindow(realisticw) end)
--Close Realistic
local realisticc = Button:new(508, 365, 100, 15, "Close Realistic")
realisticc:action(function() ui.closeWindow(realisticw) end)
--Message
local message = Button:new(5, 85, 50, 15, "Message")
message:action(function() ui.showWindow(messagew) end)
--Close Message
local messagec = Button:new(508, 365, 100, 15, "Close Message")
messagec:action(function() ui.closeWindow(messagew) end)

--I Button
local infoButton = Button:new(597, 1, 15, 15, "I", "Info about RCA's HUD - Extras")
infoButton:visible(false)
infoButton:action(function() ui.showWindow(window1) end)
--S Button
local saveLoader = Button:new(597, 17, 15, 15, "S", "Load Random Saves -- By jward212")
saveLoader:visible(false)
saveLoader:action(function() ui.showWindow(Main) end)
--Exit Button
local enterButton = Button:new(558, 365, 50, 15, "Exit")
enterButton:action(function() ui.closeWindow(window1) end)
--C Button
local closeButton = Button:new(597, 97, 15, 15, "C", "Close")
closeButton:visible(false)
closeButton:action(function() infoButton:visible(false) saveLoader:visible(false) closeButton:visible(false) end)

--E Button
local extraButton = Button:new(613, 97, 15, 15, "E", "Extra Menu - Elements - Info")
extraButton:action(function() infoButton:visible(true) saveLoader:visible(true) closeButton:visible(true) end)
    
--Checkbox Default
defaultc = Checkbox:new(470, 10, 10, 10, "Default")
if MANAGER then
	defaultc:action(function(sender, checked) MANAGER.savesetting("RCA", "defaultOn", checked and 1 or 0) end)
	defaultc:checked(MANAGER.getsetting("RCA", "defaultOn") == "1" and true or false)
end
--Checkbox Purple
purplec = Checkbox:new(470, 30, 10, 10, "Purple")
if MANAGER then
	purplec:action(function(sender, checked) MANAGER.savesetting("RCA", "purpleOn", checked and 1 or 0) end)
	purplec:checked(MANAGER.getsetting("RCA", "purpleOn") == "1" and true or false)
end
--Checkbox Turquoise
turquoisec = Checkbox:new(470, 50, 10, 10, "Turquoise")
if MANAGER then
	turquoisec:action(function(sender, checked) MANAGER.savesetting("RCA", "turqoiseOn", checked and 1 or 0) end)
	turquoisec:checked(MANAGER.getsetting("RCA", "turqoiseOn") == "1" and true or false)
end
    
--Checkbox Name
namecolor = Checkbox:new(10, 220, 10, 10, "Name Colours by jward212")
if MANAGER then
	namecolor:action(function(sender, checked) MANAGER.savesetting("RCA", "namecolor", checked and 1 or 0) end)
	namecolor:checked(MANAGER.getsetting("RCA", "namecolor") == "1" and true or false)
end
    
--Realistic Checkbox (Turns realistic ability off)
realisticCheck = Checkbox:new(10, 10, 10, 10, "Disable Realistic Mode")
if MANAGER then
	realisticCheck:action(function(sender, checked) MANAGER.savesetting("RCA", "realistic", checked and 1 or 0) end)
	realisticCheck:checked(MANAGER.getsetting("RCA", "realistic") == "1" and true or false)
	realisticCheck:checked(MANAGER.getsetting("RCA", "realistic") == "1" and true or false)
end
    
window1:addComponent(rca)
window1:addComponent(enterButton)
window1:addComponent(credits)
window1:addComponent(info)
window1:addComponent(colourButton)
window1:addComponent(message)
window1:addComponent(realisticb)

creditw:addComponent(close2)
creditw:addComponent(creditsttl)
creditw:addComponent(creditstxt)

infow:addComponent(infotxt)
infow:addComponent(close3)
infow:addComponent(instructions)
infow:addComponent(instructions2)
infow:addComponent(instructions3)
infow:addComponent(instructions4)

colourw:addComponent(rSlider)
colourw:addComponent(rtext)
colourw:addComponent(closeColour)
colourw:addComponent(gSlider)
colourw:addComponent(bSlider)
colourw:addComponent(gtext)
colourw:addComponent(btext)
colourw:addComponent(redl)
colourw:addComponent(greenl)
colourw:addComponent(bluel)
colourw:addComponent(purplec)
colourw:addComponent(defaultc)
colourw:addComponent(turquoisec)
colourw:addComponent(bordercheck)
colourw:addComponent(rSlider2)
colourw:addComponent(gSlider2)
colourw:addComponent(bSlider2)
colourw:addComponent(rtext2)
colourw:addComponent(gtext2)
colourw:addComponent(btext2)
colourw:addComponent(redl2)
colourw:addComponent(greenl2)
colourw:addComponent(bluel2)
colourw:addComponent(namecolor)

realisticw:addComponent(realisticc)
realisticw:addComponent(realisticCheck)
realisticw:addComponent(realisticmode)

messagew:addComponent(messagec)
messagew:addComponent(messageText)
messagew:addComponent(messageQuote1)
messagew:addComponent(messageQuote2)

ui.addComponent(extraButton)
ui.addComponent(infoButton)
ui.addComponent(saveLoader)
ui.addComponent(closeButton)
end

hudon = true
hudon2 = false
hudonv = true
vis2 = 0
bvis2 = 0
zoomEnabled = false
tempZoomEnabled = false
setZoom = false

function keyclicky(key, nkey, modifier, event)
    if (key == "h" and event == 1) then 
        hudon = not hudon
        hudonv = not hudonv
    end
    if (key == "d" and event == 1) then
        hudon2 = not hudon2
    end
    if (key == "m" and event == 1) then 
        realistic = not realistic
    end
    if (key == "z" and event == 1) then
        tempZoomEnabled = true
        zoomEnabled = false
        setZoom = false
        else
        tempZoomEnabled = false
    end
end

tpt.register_keypress(keyclicky) 

function mouseclicky(mousex, mousey, button, event)
    if (button == 1 and event == 1) and tempZoomEnabled == true then
        zoomEnabled = true
    end
end

tpt.register_mouseclick(mouseclicky) 

function DrawHUD()
    
    if hudon == true then
        vis1 = 255
        bvis1 = 200
        else
        vis1 = 0
        bvis1 = 0
        end
    if hudon2 == true then
        if hudonv == true then
            vis2 = 255
            bvis2 = 200
            else
            vis2 = 0
            bvis2 = 0
            end
        else
        vis2 = 0
        bvis2 = 0
        end
    if tpt.mousex >= 611 then 
        x2 = 611
        else
        x2 = tpt.mousex
        end
    
    if tpt.mousey >= 383 then
        y2 = 383
        else
        y2 = tpt.mousey
        end
    
    local x, y = sim.adjustCoords(x2, y2)
    
    if tpt.get_property("type", x, y) >= 1 then
        ptype = tpt.element(tpt.get_property("type", x, y))
        else
        ptype = "Empty,"
        end
    
    if tpt.get_property("type", x, y) == 6 and tpt.get_property("ctype", x, y) >= 1 then
        ptype = "Molten"
        end
    
    if tpt.get_property("type", x, y) >= 1 then
        var1 = tpt.get_property("temp", x, y)-273.15
        else
        var1 = 293.15
        end
    
    local var2 = var1*100
    local var3 = math.floor(var2)/100 
    
    if tpt.get_property("type", x, y) >= 1 then
        temp = var3
        else
        temp = "()"
        end
    
    if tpt.get_property("type", x, y) >= 1 then
        tempb = var3
        else
        tempb = 21.99
        end
    
    if tpt.get_property("type", x, y) >= 1 then
        temp2 = math.floor(tpt.get_property("temp", x, y)*10)/10
        else
        temp2 = "()"
        end
    
    if tpt.get_property("type", x, y) >= 1 then 
        var12312389 = tpt.get_property("ctype", x, y) 
        end
    
    if tpt.get_property("type", x, y) >= 1 and var12312389 >= 0 and var12312389 < sim.PT_NUM then 
        ctype = tpt.element(tpt.get_property("ctype", x, y))
        end
    
    if tpt.get_property("type", x, y) == 0 or tpt.get_property("ctype", x, y) < 1 then 
        ctype = "()"
        end
    
    if x >= 609 then 
        x1 = 609/4
        else
        x1 = x/4
        end
    
    if y >= 381 then 
        y1 = 381/4
        else
        y1 = y/4
        end
    
    local var4 = sim.pressure(x1, y1)*100
    local var14 = math.floor(var4)/100
    
    if var14 == "nan" then
        pressure = "Infinite"
        else
        pressure = var14
        end

    local parts = tpt.get_numOfParts()
    if tpt.get_property("type", x, y) >= 1 then 
        tmp = tpt.get_property("tmp", x, y)
        else
        tmp = "0"
        end
    
    if tpt.get_property("type", x, y) >= 1 then 
        life = tpt.get_property("life", x, y)
        else
        life = "0"
        end
    
    if tpt.get_property("type", x, y) >= 1 then 
        tmp2 = tpt.get_property("tmp2", x, y)
        else
        tmp2 = "0"
        end
    
    if tpt.get_property("type", x, y) >= 1 then
        var11 = tpt.get_property("vy", x, y)*1000
        else
        var11 = 0
        end
    if var11 <= 9999 or var11 <= -9999 then 
        vy = math.floor(var11)/1000
        else
        vy = "Err(2)"
        end
    
    if tpt.get_property("type", x, y) >= 1 then
        var12 = tpt.get_property("vx", x, y)*1000
        else
        var12 = 0
        end
    if var12 <= 9999 or var12 <= -9999 then 
        vx = math.floor(var12)/1000
        else
        vx = "Err(1)"
        end
    
    FC = FC + 1
    if FC == 2 then
    time2 = socket.gettime() - time
    FPS = math.floor((2/time2)*100)/100
    time = socket.gettime()
    FC = 0
    end
    
    if not tpt.version.jacob1s_mod then --jacob1 edit
        
    if purplec:checked() == true then
        rclr, gclr, bclr = 164, 95, 255
        end
    
    if defaultc:checked() == true then
        rclr, gclr, bclr = 0, 255, 165
        end
    
    if turquoisec:checked() == true then
        rclr, gclr, bclr = 0, 255, 255
        end
    
    if bordercheck:checked() == true then
        graphics.fillRect(0, 0, 4, 383, rclr2, gclr2, bclr2, 200)
        graphics.fillRect(0, 379, 611, 4, rclr2, gclr2, bclr2, 200)
        graphics.fillRect(0, 0, 611, 4, rclr2, gclr2, bclr2, 200)
        graphics.fillRect(608, 0, 4, 383, rclr2, gclr2, bclr2, 200)
    end    
        
    colourw:onDraw(function() graphics.fillRect(385, 10, 76, 76, rclr, gclr, bclr) graphics.fillRect(385, 130, 76, 76, rclr2, gclr2, bclr2) end)
       
        if namecolor:checked() == true then
                colourRGB = {colourRED,colourGRN,colourBLU}
                if frameCount > 1529 then frameCount = 0 else frameCount = frameCount + 1 end
                if frameCount > 0 and frameCount < 255 then
                    colourRED = 255
                    if colourGRN > 254 then else colourGRN = colourGRN + 1 end
                end
                if frameCount > 254 and frameCount < 510 then
                    colourGRN = 255
                    if colourRED == 0 then else colourRED = colourRED - 1 end
                end
                if frameCount > 510 and frameCount < 765 then
                    colourGRN = 255
                    if colourBLU > 254 then else colourBLU = colourBLU + 1 end
                end
                if frameCount > 764 and frameCount < 1020 then
                    colourBLU = 255
                    if colourGRN == 0 then else colourGRN = colourGRN - 1 end
                end
                if frameCount > 1020 and frameCount < 1275 then
                    colourBLU = 255
                    if colourRED > 254 then else colourRED = colourRED + 1 end
                end
                if frameCount > 1274 and frameCount < 1530 then
                    colourRED = 255
                    if colourBLU == 0 then else colourBLU = colourBLU - 1 end
                end
                tpt.fillrect(510 + (tpt.version.jacob1s_mod and 15 or 0),410,50,10, 0, 0, 0, 255)
                tpt.drawtext(510 + (tpt.version.jacob1s_mod and 15 or 0),412,tpt.get_name(), colourRED, colourGRN, colourBLU, 255)
        end
    
    end
    
    counter = (counter + 1)%5
    if counter == 0 and realistic == true and (tpt.version.jacob1s_mod or realisticCheck:checked() == false) then
        sim.resetTemp()
        tpt.set_property("temp", 293.15, "wtrv")
        infoOn = true
    end  
    if realistic == false or (not tpt.version.jacob1s_mod and realisticCheck:checked() == true) then
        infoOn = false
    end
    
    if zoomEnabled == true or tempZoomEnabled == true then
        if (x > 305) and setZoom == false then 
            xadd = 365
            xadj = 365
        end
        if (x < 306) and setZoom == false then 
            xadd = 20
            xadj = 0
        end
        if zoomEnabled == true then
            setZoom = true
        end
        yadd = 246
        else
        xadd = 0
        yadd = 0
        xadj = 0
    end
    
    if infoOn == true and hudon == true then
        graphics.fillRect(77, 27, 134,12, 55, 55, 55, 200)
        graphics.drawText(78+xadj, 29, "Realistic Mode Enabled (M)", 255, 0, 0, 255)
        elseif infoOn == true and hudon == false then
        graphics.fillRect(4, 4, 134,12, 55, 55, 55, 200)
        graphics.drawText(5, 6, "Realistic Mode Enabled (M)", 255, 0, 0, 255)
    end

    local draw = graphics.drawText
    local rect = graphics.fillRect
 
    rect(398-xadd, 13+yadd, 187, 12, 55, 55, 55, bvis1)
    rect(398-xadd, 27+yadd, 200, 12, 55, 55, 55, bvis1)
    rect(14+xadj, 13, 210, 12, 55, 55, 55, bvis1)
    rect(398-xadd, 41+yadd, 180, 12, 55, 55, 55, bvis2)
    rect(14+xadj, 27, 61, 12, 55, 55, 55, bvis1)
 
    draw(16+xadj, 15, os.date(), rclr, gclr, bclr, vis1)
    draw(550-xadd, 30+yadd, x, rclr, gclr, bclr, vis1)
    draw(578-xadd, 30+yadd, y, rclr, gclr, bclr, vis1)
    draw(541-xadd, 30+yadd, "X:", rclr, gclr, bclr, vis1)
    draw(570-xadd, 30+yadd, "Y:", rclr, gclr, bclr, vis1)
    draw(435-xadd, 15+yadd, ctype, rclr, gclr, bclr, vis1)
    draw(400-xadd, 15+yadd, ptype, rclr, gclr, bclr, vis1)
    draw(558-xadd, 15+yadd, pressure, rclr, gclr, bclr, vis1)
    draw(465-xadd, 15+yadd, "Temp:", rclr, gclr, bclr, vis1)
    draw(465-xadd, 30+yadd, "Tmp:", rclr, gclr, bclr, vis1)
    draw(400-xadd, 30+yadd, "Life:", rclr, gclr, bclr, vis1)
    draw(535-xadd, 15+yadd, "Pres:", rclr, gclr, bclr, vis1)
    draw(160+xadj, 15, "Parts:", rclr, gclr, bclr, vis1)
    draw(490-xadd, 15+yadd, temp, rclr, gclr, bclr, vis1)
    draw(485-xadd, 30+yadd, tmp, rclr, gclr, bclr, vis1)
    draw(422-xadd, 30+yadd, life, rclr, gclr, bclr, vis1)
    draw(187+xadj, 15, parts, rclr, gclr, bclr, vis1)
    
    draw(400-xadd, 44+yadd, "Tmp2:", rclr, gclr, bclr, vis2)
    draw(426-xadd, 44+yadd, tmp2, rclr, gclr, bclr, vis2)
    draw(465-xadd, 44+yadd, "VX:", rclr, gclr, bclr, vis2)
    draw(535-xadd, 44+yadd, "VY:", rclr, gclr, bclr, vis2)
    draw(480-xadd, 44+yadd, vx, rclr, gclr, bclr, vis2)
    draw(550-xadd, 44+yadd, vy, rclr, gclr, bclr, vis2)
    draw(16+xadj, 29, "FPS:", rclr, gclr, bclr, vis2)
    draw(38+xadj, 29, FPS, rclr, gclr, bclr, vis2)
    --Useful for programming, shows an element's number (Not name) at mouse X, Y. By default is commented out.
    --draw(550, 54, tpt.get_property("type", x, y), 0, gclr, bclr, 200)
    
    --Temperature Colour Graph
if zoomEnabled == false and tempZoomEnabled == false then
    local dx = ((tempb-1550)/50)
    if dx >= 39 then
        ddx = 565
        visb = 255
        dddx = (dx-39)+490
        else
        ddx = dx+526
        visb = 0
        dddx = 1
        end

    if dddx >= 565 then
        ddddx = dddx-75
        dddx = 565
        visbb = 255
        else
        ddddx = 1
        visbb = 0
        end
    if tempb >=-290 then
        tpt.drawpixel(490, 25, 80, 54, 254, vis1)
        end
    if tempb >= -250 then
        tpt.drawpixel(491, 25, 60, 54, 254, vis1)
        end
    if tempb >= -200 then
        tpt.drawpixel(492, 25, 60, 74, 254, vis1)
        end
    if tempb >= -150 then
        tpt.drawpixel(493, 25, 60, 94, 254, vis1)
        end
    if tempb >= -100 then
        tpt.drawpixel(494, 25, 60, 114, 254, vis1)
        end
    if tempb >= -50 then
        tpt.drawpixel(495, 25, 60, 134, 254, vis1)
        end
    if tempb >= 0 then
        tpt.drawpixel(496, 25, 60, 153, 254, vis1)
        end
    if tempb >= 50 then
        tpt.drawpixel(497, 25, 60, 154, 234, vis1)
        end
    if tempb >= 100 then
        tpt.drawpixel(498, 25, 60, 174, 234, vis1)
        end
    if tempb >= 150 then
        tpt.drawpixel(499, 25, 60, 194, 234, vis1)
        end
    if tempb >= 200 then
        tpt.drawpixel(500, 25, 60, 214, 234, vis1)
        end
    if tempb >= 250 then
        tpt.drawpixel(501, 25, 60, 234, 234, vis1)
        end
    if tempb >= 300 then
        tpt.drawpixel(502, 25, 60, 254, 234, vis1)
        end
    if tempb >= 350 then
        tpt.drawpixel(503, 25, 60, 254, 214, vis1)
        end
    if tempb >= 400 then
        tpt.drawpixel(504, 25, 60, 254, 94, vis1)
        end
    if tempb >= 450 then
        tpt.drawpixel(505, 25, 60, 254, 74, vis1)
        end
    if tempb >= 500 then
        tpt.drawpixel(506, 25, 60, 254, 54, vis1)
        end
    if tempb >= 550 then
        tpt.drawpixel(507, 25, 80, 254, 54, vis1)
        end
    if tempb >= 600 then
        tpt.drawpixel(508, 25, 100, 254, 54, vis1)
        end
    if tempb >= 650 then
        tpt.drawpixel(508, 25, 120, 254, 54, vis1)
        end
    if tempb >= 750 then
        tpt.drawpixel(509, 25, 140, 254, 54, vis1)
        end
    if tempb >= 800 then
        tpt.drawpixel(510, 25, 160, 254, 54, vis1)
        end
    if tempb >= 850 then
        tpt.drawpixel(511, 25, 180, 254, 54, vis1)
        end
    if tempb >= 900 then
        tpt.drawpixel(512, 25, 200, 254, 54, vis1)
        end
    if tempb >= 950 then
        tpt.drawpixel(513, 25, 220, 254, 54, vis1)
        end
    if tempb >= 1000 then
        tpt.drawpixel(514, 25, 240, 254, 54, vis1)
        end
    if tempb >= 1050 then
        tpt.drawpixel(515, 25, 254, 254, 54, vis1)
        end
    if tempb >= 1100 then
        tpt.drawpixel(516, 25, 254, 254, 54, vis1)
        end
    if tempb >= 1150 then
        tpt.drawpixel(517, 25, 254, 214, 54, vis1)
        end
    if tempb >= 1200 then
        tpt.drawpixel(518, 25, 254, 194, 54, vis1)
        end
    if tempb >= 1250 then
        tpt.drawpixel(519, 25, 254, 174, 54, vis1)
        end
    if tempb >= 1300 then
        tpt.drawpixel(520, 25, 254, 154, 54, vis1)
        end
    if tempb >= 1350 then
        tpt.drawpixel(521, 25, 254, 134, 54, vis1)
        end
    if tempb >= 1400 then
        tpt.drawpixel(522, 25, 254, 114, 54, vis1)
        end
    if tempb >= 1450 then
        tpt.drawpixel(523, 25, 254, 94, 54, vis1)
        end
    if tempb >= 1500 then
        tpt.drawpixel(524, 25, 254, 74, 54, vis1)
        end
    if tempb >= 1550 then
        tpt.drawpixel(525, 25, 254, 54, 54, vis1)
        end
    if tempb >= 1600 then
        graphics.drawLine(526, 25, ddx, 25, 255, 0, 0, vis1)
        end
    graphics.drawLine(490, 26, dddx, 26, 255, 0, 0, visb)
    graphics.drawLine(490, 27, ddddx, 27, 255, 0, 0, visbb)
end
    
--Keeps normal HUD off
tpt.hud(0)
end
 
tpt.register_step(DrawHUD)