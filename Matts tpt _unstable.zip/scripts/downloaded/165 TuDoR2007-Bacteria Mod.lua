
local algae = elements.allocate("TPT", "ALGAE")
elements.element(algae, elements.element(elements.DEFAULT_PT_SOAP))
elements.property(algae, "Name" , "ALGE")
elements.property(algae, "Description" , "Algae, spreads in water.")
elements.property(algae, "Color", 0x407010)
elements.property(algae, "Diffusion", 0.3)
elements.property(algae, "Weight", 31)
elements.property(algae, "MenuSection", 16)
elements.property(elem.TPT_PT_ALGAE, "Update", --*1
function(i,x,y,s,nt) --1
if nt == 8 then --2
for r in sim.neighbors(x,y,1,1) do --3
if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --4
if math.random(1,1000) > 1 then --4
sim.partProperty(i, "vy", -0.05)
end --5
if math.random(1,1000) > 1 then --5
sim.partProperty(i, "vx", math.random(-0.01,0.01))
end --6
end --4
if math.random(1,250) < 4 then --7
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
end --7
if math.random(1,400) < 2 then --8
sim.partKill(i)
end --8
if sim.partProperty(r, "type") == elements.DEFAULT_PT_CO2 then --9
if math.random(1,200) == 1 then --10
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_ALGAE)
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.DEFAULT_PT_OXYG)
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.DEFAULT_PT_OXYG)
end --10
end --9
end --3
end --2
if math.random(1,400) < 2 then --11
sim.partKill(i)
end --11
end --1
) --*1

local bctr = elements.allocate("TPT", "BACT")
elements.element(bctr, elements.element(elements.DEFAULT_PT_SOAP))
elements.property(bctr, "Name" , "BCTR")
elements.property(bctr, "Description" , "Bacteria, spreads and sticks.")
elements.property(bctr, "Color", 0xE0F0A1)
elements.property(bctr, "Diffusion", 0.3)
elements.property(bctr, "Weight", 30)
elements.property(bctr, "MenuSection", 11)

local bctrb = elements.allocate("TPT", "BCTR")
elements.element(bctrb, elements.element(elements.DEFAULT_PT_SOAP))
elements.property(bctrb, "Name" , "BCTD")
elements.property(bctrb, "Description" , "Decomposer bacteria, decomposes plant matter.")
elements.property(bctrb, "Color", 0xFFE990)
elements.property(bctrb, "Diffusion", 0.3)
elements.property(bctrb, "Weight", 30)
elements.property(bctrb, "MenuSection", 16)

local bctra = elements.allocate("TPT", "BCTRA")
elements.element(bctra, elements.element(elements.DEFAULT_PT_SOAP))
elements.property(bctra, "Name" , "ABCT")
elements.property(bctra, "Description" , "Airbourne bacteria.")
elements.property(bctra, "Color", 0xC9E9FF)
elements.property(bctra, "Diffusion", 0.2)
elements.property(bctra, "Weight", 29)
elements.property(bctra, "MenuSection", 16)
elements.property(bctra, "Gravity", -0.025)

local bctrc = elements.allocate("TPT", "BCTRC")
elements.element(bctrc, elements.element(elements.DEFAULT_PT_SOAP))
elements.property(bctrc, "Name" , "BCTW")
elements.property(bctrc, "Description" , "Bacterial wall, solid but still flows")
elements.property(bctrc, "Color", 0xC9FF90)
elements.property(bctrc, "Diffusion", 0.1)
elements.property(bctrc, "Weight", 31)
elements.property(bctrc, "MenuSection", 16)

local bctrp = elements.allocate("TPT", "BCTRP")
elements.element(bctrp, elements.element(elements.DEFAULT_PT_SOAP))
elements.property(bctrp, "Name" , "AQBC")
elements.property(bctrp, "Description" , "Aquatic Bacteria. Floats and spreads through water slowly.")
elements.property(bctrp, "Color", 0xFFF0FF)
elements.property(bctrp, "Diffusion", 0.3)
elements.property(bctrp, "Weight", 31)
elements.property(bctrp, "MenuSection", 16)
elements.property(elem.TPT_PT_BCTRP, "Update", --*1
function(i,x,y,s,nt) --1
if nt == 8 then --2
for r in sim.neighbors(x,y,1,1) do --3
if math.random(1,1000) > 1 then --4
sim.partProperty(i, "vy", -0.05)
end --4
if math.random(1,1000) > 1 then --5
sim.partProperty(i, "vx", math.random(-0.01,0.01))
end --5
if math.random(1,2000) < 4 then --6
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
end --6
if math.random(1,40000) < 2 then --7
sim.partKill(i)
end --7
if sim.partProperty(r, "type") == elements.DEFAULT_PT_CO2 then --8
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRP)
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTR)
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRC)
end --8
end --3
end --2
end --1
) --*1

elements.property(elem.TPT_PT_BCTRC, "Update", --*1
function(i,x,y,s,nt) --1
if s ~=8 and nt ~=0 and s > 0 then --2
for r in sim.neighbors(x,y,1,1) do --3
if math.random(1,1000) > 1 then --4
sim.partProperty(i, "vy", 0)
end --4
if math.random(1,1000) > 1 then --5
sim.partProperty(i, "vx", 0)
end --5
if math.random(1,200000) < 4 then --6
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
end --6
if math.random(1,200000) == 1 then --7
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
end --7
if math.random(1,200000) == 1 then --8
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
end --8
if math.random(1,4000) < 2 then --9
sim.partKill(i)
end --9
if sim.partProperty(r, "type") == elements.DEFAULT_PT_CO2 then --10
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRC)
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRC)
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRC)
end --10
if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --11
if math.random(1,20) == 1 then --12
if math.random(1,50) == 1 then --13
sim.partProperty(i, "type", elements.TPT_PT_BCTRP)
end --13
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRP)
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRP)
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRP)
sim.partKill(i)
end --12
end --11
if sim.partProperty(r, "type") == elements.TPT_PT_BCTRP then --11
if math.random(1,200) == 1 then --12
sim.partKill(i)
end --12
end --11
end --3
end --2
end --1
) --*1

elements.property(elem.TPT_PT_BCTR, "Update", --*1
function(i,x,y,s,nt) --1
if s ~=8 and nt ~=0 and nt - s > 0 then --2
for r in sim.neighbors(x,y,1,1) do --3
if math.random(1,10) > 1 then --4
sim.partProperty(i, "vy", 0)
end --4
if math.random(1,10) > 1 then --5
sim.partProperty(i, "vx", 0)
end --5
if math.random(1,200) < 4 then --6
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
end --6
if math.random(1,4000) < 2 then --7
sim.partKill(i)
end --7
if sim.partProperty(r, "type") == elements.DEFAULT_PT_WOOD then --8
if math.random(1,20) < 2 then --9
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ASH)
sim.partKill(r)
end --9
end --8
if sim.partProperty(r, "type") == elements.DEFAULT_PT_PLNT then --10
if math.random(1,20) < 2 then --11
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ASH)
sim.partKill(r)
end --11
end --10
if sim.partProperty(r, "type") == elements.TPT_PT_ALGAE then --12
if math.random(1,20) < 2 then --13
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRP)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ASH)
sim.partKill(r)
end --13
end --12
if math.random(1,1000) == 1 then --14
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-3,y+3),elements.TPT_PT_BCTRC)
sim.partCreate(-1, math.random(x-3,x+3),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
end --14
if math.random(1,10000) == 1 then --15
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
end --15
if math.random(1,1000) == 1 then --16
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRP)
end --16
end --3
end --2
end --1
) --*1

elements.property(elem.TPT_PT_BCTRA, "Update", --*1
function(i,x,y,s,nt) --1
if s ~=8 and nt ~=0 and nt - s > 0 then --2
for r in sim.neighbors(x,y,1,1) do --3
if math.random(1,20) > 1 then --4
sim.partProperty(i, "vy", -0.01)
end --4
if math.random(1,20) > 1 then --5
sim.partProperty(i, "vx", 0)
end --5
if math.random(1,400) < 4 then --6
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
end --6
if math.random(1,1600) < 2 then --7
sim.partKill(i)
end --7
if sim.partProperty(r, "type") == elements.TPT_PT_ASH then --8
if math.random(1,20) < 2 then --9
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.DEFAULT_PT_CO2)
sim.partKill(r)
end --9
end --8
if sim.partProperty(r, "type") == elements.DEFAULT_PT_OXYG then --10
if math.random(1,20) < 2 then --11
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.DEFAULT_PT_CO2)
sim.partKill(r)
end --11
end --10
if math.random(1,125) == 1 then --12
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-3,y+1),elements.TPT_PT_BCTRC)
end --12
if math.random(1,10000) == 1 then --12
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
end --12
end --3
end --2
end --1
) --*1

elements.property(elem.TPT_PT_BACT, "Update", --*1
function(i,x,y,s,nt) --1
if s ~=8 and nt ~=0 and nt - s > 0 then --2
for r in sim.neighbors(x,y,1,1) do --3
if math.random(1,20) > 1 then --4
sim.partProperty(i, "vy", -0.01)
end --4
if math.random(1,20) > 1 then --5
sim.partProperty(i, "vx", 0)
end --5
if math.random(1,20) < 2 then --6
sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
sim.partKill(i)
end --6
end --3
end --2
end --1
) --*1

local co2s = elements.allocate("TPT", "CSNW")
elements.element(co2s, elements.element(elements.DEFAULT_PT_SNOW))
elements.property(co2s, "Name" , "CSNW")
elements.property(co2s, "Description" , "CO2 Snow.")
elements.property(co2s, "Color", 0xC2C2C2)
elements.property(co2s, "Diffusion", 0.1)
elements.property(co2s, "HighTemperature", 10001)
elements.property(co2s, "Temperature", 186.65)
elements.property(co2s, "Weight", 31)
elements.property(co2s, "MenuSection", 16)
elements.property(elements.TPT_PT_CSNW, "Update", --*1
function(i,x,y) --1
if sim.partProperty(i, "temp") > 194.65 then --2
if math.random(1,450) == 1 then --3
sim.partChangeType(i, elements.DEFAULT_PT_CO2)
end --3
end --2
end --1
) --*1

elements.property(elements.DEFAULT_PT_DRIC, "HighPressure", 1.2)
elements.property(elements.DEFAULT_PT_DRIC, "HighPressureTransition", elements.TPT_PT_CSNW)