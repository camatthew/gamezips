
local function GRAVmass(i,x,y,s,n)
        --Searching for other masses
	for i2 in sim.parts() do
		if sim.partProperty(i2, 'type') == elements.TEST_PT_GMAS and i2 ~= i then
                        local myMass = sim.partProperty(i, 'tmp')        --Mass of this object
                        local otherMass = sim.partProperty(i2, 'tmp')    --Mass of other object
                        local myRadius = sim.partProperty(i, 'tmp2')     --Radius of this object
                        local otherRadius = sim.partProperty(i2, 'tmp2') --Radius of other object
			local vx = sim.partProperty(i, 'vx')             --Velocity on x axis of this object
			local vy = sim.partProperty(i, 'vy')             --Velocity on y axis of this object
			local vx2 = sim.partProperty(i2, 'vx')           --Velocity on x axis
			local vy2 = sim.partProperty(i2, 'vy')           --Velocity on y axis of other object
			local x2 = sim.partProperty(i2, 'x')             --x of other object
			local y2 = sim.partProperty(i2, 'y')             --y of other object
                        local d = math.sqrt((x2-x)*(x2-x)+(y2-y)*(y2-y)) --Distance between 2 objects

                        ----------Calculating force----------

                        local f = myMass/d^2 --Acceleration for another object

                        ----------Calculating force----------

                        local sRadius = myMass/60
                        local sRadius2 = otherMass/60
                        --Applying force to other mass
			sim.partProperty(i2, 'vx',vx2+(x-x2)*f/d)
			sim.partProperty(i2, 'vy',vy2+(y-y2)*f/d)
                        --Merging 2 masses if they are too close
                        if (d < (myRadius + otherRadius)/1.5 or d < sRadius+sRadius2) and myMass >= otherMass then
			        local vx = sim.partProperty(i, 'vx')
			        local vy = sim.partProperty(i, 'vy')
			        local vx2 = sim.partProperty(i2, 'vx')
		                local vy2 = sim.partProperty(i2, 'vy')
                                massRatio = myMass/otherMass
                                sim.partProperty(i, 'tmp', myMass+otherMass)
                                sim.partProperty(i, 'vx', vx + (vx2-vx)/massRatio/(1+1/massRatio))
                                sim.partProperty(i, 'vy', vy + (vy2-vy)/massRatio/(1+1/massRatio))
                                sim.partProperty(i, 'x', x+(x2 - x)/massRatio/2)
                                sim.partProperty(i, 'y', y+(y2 - y)/massRatio/2)
                                sim.partKill(i2)
                        end
		end
	end
end

local function funcGraphics(i, colr, colg, colb)
        --Drawing circles with radius and schwarzschild radius
        local x,y=sim.partPosition(i)
        local mass = sim.partProperty(i, 'tmp')
        local sRadius = mass/60
        local aRadius = (math.sqrt(mass)+(mass/8)^2-(mass/20)^3+(math.abs(mass-124)/3.7+(mass-124)/3.7)^1.56)*2.5
        if aRadius > sRadius then
        sim.partProperty(i, 'tmp2', aRadius)
        else
        sim.partProperty(i, 'tmp2', sRadius)
        end
        local r = sim.partProperty(i, 'tmp2')
        if aRadius > sRadius then
                graphics.drawCircle(x, y, r, r, 255, mass*1.5, mass*1.5, 255)
                graphics.fillCircle(x, y, r, r, 255, mass*1.5, mass*1.5, 200)
                graphics.drawCircle(x, y, sRadius, sRadius, 63, 63, 63, 127)
                graphics.fillCircle(x, y, sRadius, sRadius, 63, 63, 63, 127)
        blackhole = true
        end
        if aRadius <= sRadius then
                graphics.drawCircle(x, y, r, r, 63, 63, 63, 255)
                graphics.fillCircle(x, y, r, r, 63, 63, 63, 225)
        end
end

--Launching mass

function inWorkspace()
        if ((x1 >= 4 and x1 <= 607) and (y1 >= 4 and y1 <= 379)) and ((x2 >= 4 and x2 <= 607) and (y2 >= 4 and y2 <= 379)) then
                return true
        end
end

local function zoom(key)
        if key == 122 then
                zooming = true
        end
end

local function notzoom(key)
        if key == 122 then
                zooming = false
        end
end

local function setCoords1(x,y,button)
        if button == 1 and not zooming then 
                x1,y1=sim.adjustCoords(x,y)
                holding=true
        end
end

local function setCoords2(x,y,dx,dy)
        x2,y2=sim.adjustCoords(x,y)
end

local function drawLine()
        if tpt.selectedl == elements.property(elements.TEST_PT_LMAS, "Identifier") and holding and inWorkspace() and not zooming then
                graphics.drawLine(x1, y1, x2, y2)
                graphics.drawLine(x1+1, y1, x2, y2)
                graphics.drawLine(x1-1, y1, x2, y2)
                graphics.drawLine(x1, y1+1, x2, y2)
                graphics.drawLine(x1, y1-1, x2, y2)
        end
end

local function launch(x,y,button)
        if tpt.selectedl == elements.property(elements.TEST_PT_LMAS, "Identifier") and button == 1 and holding and (inWorkspace() and not zooming) then
                i = sim.partCreate(-3,x1,y1,elem.TEST_PT_GMAS)
                sim.partProperty(i,"vx",(x1-x2)/64)
                sim.partProperty(i,"vy",(y1-y2)/64)
                sim.partProperty(i,"tmp",(tpt.brushx+tpt.brushy)/2+1)
        end
        holding = false
end


event.register(event.mousedown, setCoords1)
event.register(event.mousemove, setCoords2)
event.register(event.tick, drawLine)
event.register(event.mouseup, launch)
event.register(event.keypress, zoom)
event.register(event.keyrelease, notzoom)

--Making white LMAS black
local function funcGraphics2(i, colr, colg, colb)
  return 1, ren.PMODE_NONE, 0, 0, 0, 0
end

local gmas = elements.allocate("TEST", "GMAS")
elements.element(elements.TEST_PT_GMAS, elements.element(elements.DEFAULT_PT_DMND))
elements.property(elements.TEST_PT_GMAS, "Name", "GMAS")
elements.property(elements.TEST_PT_GMAS, "Description", "Hey, how did you get here? Anyway, it's gravitational mass. Launch it with LMAS.")
elements.property(elements.TEST_PT_GMAS, "Colour", 0xFFFFFFFF)
elements.property(elements.TEST_PT_GMAS, "MenuVisible", 0)
elements.property(elements.TEST_PT_GMAS, "Update", GRAVmass)
elements.property(elements.TEST_PT_GMAS, "Graphics", funcGraphics)
elements.property(elements.TEST_PT_GMAS, "Loss", 1)

local lmas = elements.allocate("TEST", "LMAS")
elements.element(elements.TEST_PT_LMAS, elements.element(elements.DEFAULT_PT_PHOT))
elements.property(elements.TEST_PT_LMAS, "Name", "LMAS")
elements.property(elements.TEST_PT_LMAS, "Description", "Gravitational mass launcher. Click and drag to place GMAS with some velocity")
elements.property(elements.TEST_PT_LMAS, "Colour", 0xFFFFFFFF)
elements.property(elements.TEST_PT_LMAS, "MenuSection", 11)
elements.property(elements.TEST_PT_LMAS, "Properties", elem.PROP_LIFE_KILL+elem.PROP_NOCTYPEDRAW)
elements.property(elements.TEST_PT_LMAS, "Graphics", funcGraphics2)