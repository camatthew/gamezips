
function cross(x, y)
    local l = {sim.partID(x+1, y), sim.partID(x-1, y), sim.partID(x, y+1), sim.partID(x, y-1)}
    return l
end

local function woody(i, x, y, s, nt)
    for r=0,3 do
        if cross(x, y)[r] ~= nil and sim.partProperty(cross(x, y)[r], "type") == tpt.el.plnt.id then
            if math.random(1, 100) == 100 then
                sim.partChangeType(cross(x, y)[r], tpt.el.wood.id);
                sim.partChangeType(i, tpt.el.spng.id)
            end
        end
    end
    if math.random(1, 1000) == 1 then
        local bc = 0
        for b in sim.neighbors(x, y, 1, 1) do
            if sim.partProperty(b, "type") == tpt.el.spng.id or sim.partProperty(b, "type") == tpt.el.wood.id or sim.partProperty(b, "type") == tpt.el.filt.id then
                bc = bc + 1
            end
        end
        if bc == 8 then
            sim.partChangeType(i, tpt.el.iron.id)
        end
    end
end

tpt.element_func(woody, tpt.el.wood.id)

local function spongy(i, x, y, s, nt)
    for r=0,3 do
        if cross(x, y)[r] ~= nil and sim.partProperty(cross(x, y)[r], "type") == tpt.el.plnt.id then
            if math.random(1, 100) == 100 then
                sim.partChangeType(cross(x, y)[r], tpt.el.wood.id);
            end
        end
    end
end

tpt.element_func(spongy, tpt.el.spng.id)

local function irony(i, x, y, s, nt)
    for r=0,3 do
        if cross(x, y)[r] ~= nil then
            if sim.partProperty(cross(x, y)[r], "type") == tpt.el.spng.id then
                if math.random(1, 100) == 100 then
                    sim.partChangeType(cross(x, y)[r], tpt.el.iron.id);
                    sim.partChangeType(i, tpt.el.spng.id)
                end
            elseif sim.partProperty(cross(x, y)[r], "type") == tpt.el.iron.id and math.random(1, 10) == 10 then
                sim.partChangeType(cross(x, y)[r], tpt.el.spng.id);
                sim.partChangeType(i, tpt.el.wax.id)
            end
        end
    end
end

tpt.element_func(irony, tpt.el.iron.id)

local function waxy(i, x, y, s, nt)
    for r=0,3 do
        if cross(x, y)[r] ~= nil then
            if math.random(1, 10) == 10 then
                if sim.partProperty(cross(x, y)[r], "type") == tpt.el.wood.id and sim.partProperty(i, "ctype") == 0 then
                    sim.partChangeType(cross(x, y)[r], tpt.el.iron.id);
                    sim.partChangeType(i, tpt.el.iron.id)
                    return 1
               end
            end
            if math.random(1, 100) == 100 then
                if sim.partProperty(cross(x, y)[r], "type") == tpt.el.spng.id and sim.partProperty(i, "ctype") == 0 then
                    sim.partChangeType(cross(x, y)[r], tpt.el.wax.id);
                    sim.partChangeType(i, tpt.el.spng.id)
                elseif sim.partProperty(cross(x, y)[r], "type") == tpt.el.filt.id and sim.partProperty(i, "ctype") == 0 then
                    sim.partChangeType(cross(x, y)[r], tpt.el.wax.id);
                    if sim.partProperty(i, "ctype") == 0 then
                        sim.partChangeType(i, tpt.el.filt.id)
                    else
                        sim.partChangeType(i, tpt.el.spng.id)
                    end
                    sim.partProperty(i, "ctype", tpt.el.filt.id)
                elseif sim.partProperty(cross(x, y)[r], "type") == tpt.el.plnt.id and sim.partProperty(i, "ctype") == tpt.el.filt.id then
                    sim.partChangeType(cross(x, y)[r], tpt.el.wood.id);
                    sim.partChangeType(i, tpt.el.filt.id)
                    sim.partProperty(i, "ctype", 0)
                end
            end
        end
    end
end

tpt.element_func(waxy, tpt.el.wax.id)