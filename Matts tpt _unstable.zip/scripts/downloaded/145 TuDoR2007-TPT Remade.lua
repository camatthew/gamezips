
local function velocity(i,v,n) --*1
 local angle = math.random(1,n)*(2*math.pi/n)
 tpt.set_property("vx", v*math.cos(angle), i)
 tpt.set_property("vy", v*math.sin(angle), i)
 tpt.set_property("tmp", -1, i)
 end --*1

local function attract(i,x,y,a) --*1
 sim.gravMap(x/4,y/4,a)
end --*1

local nept = elements.allocate("TPT" , "NEPT")
 elements.element(nept, elements.element(elements.DEFAULT_PT_PLUT))
 elements.property(nept, "Name" , "NEPT")
 elements.property(nept, "Description" , "Neptunium, radioactive. Quickly heats up when bombarded with neutrons.")
 elements.property(nept, "Color", 0x557020)
 elements.property(nept, "PhotonReflectWavelengths", 0x002FF200)
 elements.property(nept, "MenuSection", 10)

local vsns = elements.allocate("TPT" , "VSNS")
 elements.element(vsns, elements.element(elements.DEFAULT_PT_DMND))
 elements.property(vsns, "Name" , "VSNS")
 elements.property(vsns, "Description" , "Velocity sensor, creates power when something's velocity is higher than its temperature.")
 elements.property(vsns, "Color", 0x3D3125)
 elements.property(vsns, "MenuSection", 3)
 elements.property(vsns, "HeatConduct", 0)
 elements.property(elem.TPT_PT_VSNS, "Update", 
 function(i,x,y,s,nt) --1
  for r in sim.neighbors(x,y,1,1) do --2
   if math.sqrt(math.pow(sim.partProperty(r, "vx"),2)+math.pow(sim.partProperty(r, "vy"),2)) > sim.partProperty(i, "temp")-273.15 then --3
    sim.partCreate(-1, x, y+1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x+1, y+1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x-1, y+1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x, y-1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x+1, y-1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x-1, y-1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x+1, y, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x-1, y, elements.DEFAULT_PT_SPRK)
    end --3
   end --2
  end --1
) --*1

local mrcv = elements.allocate("TPT", "MRCV")
 elements.element(mrcv,elem.element(elem.DEFAULT_PT_WTRV))
 elements.property(mrcv, "Name" , "MRCV")
 elements.property(mrcv, "Description" , "Mercury Vapor.")
 elements.property(mrcv, "Color", 0x6D6567)
 elements.property(mrcv, "Temperature", 637.85)
 elements.property(mrcv, "AirDrag", 0.01)
 elements.property(mrcv, "Loss", 0.5)
 elements.property(mrcv, "LowTemperature", 618.32)
 elements.property(mrcv, "LowTemperatureTransition", elements.DEFAULT_PT_MERC)

 elements.property(elements.DEFAULT_PT_MERC, "Update", --*1
 function(i,x,y) --1
  if sim.partProperty(i, "temp") > 628.91 then --2
   if math.random(1,450) == 1 then --3
    sim.partChangeType(i, elements.TPT_PT_MRCV)
    end --3
   end --2
  end --1
 ) --*1

local anti = elements.allocate("TPT" , "ANTI")
 elements.element(anti, elements.element(elements.DEFAULT_PT_SING))
 elements.property(anti, "Name" , "ANTI")
 elements.property(anti, "Description" , "Anti Singularity, incredibly destructive. Slowly increases in size")
 elements.property(anti, "Color", 0xDBDBDB)
 elements.property(anti, "HotAir", 0.15)
 elements.property(anti, "MenuSection", 16)
 elements.property(elements.TPT_PT_ANTI, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,-0.75)
  if math.random(1,50) == 1 then --2
   sim.partCreate(-1, x+math.random(-1,1),y+math.random(-1,1),elements.TPT_PT_ANTI)
   sim.partProperty(i, "temp", sim.partProperty(i, "temp")-200)
   end --2
  end --1
 ) --*1

 elements.property(elements.DEFAULT_PT_SING, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.75)
  end --1
 ) --*1

local ash = elements.allocate("TPT", "ASH")
 elements.element(ash, elements.element(elements.DEFAULT_PT_DUST))
 elements.property(ash, "Name" , "ASH")
 elements.property(ash, "Description" , "Ash, light powder. Turns into oil under pressure.")
 elements.property(ash, "Color", 0x393224)
 elements.property(ash, "Gravity", 0.056)
 elements.property(ash, "Advection", 0.2)
 elements.property(ash, "Weight", 2)
 elements.property(ash, "AirDrag", 0.05)
 elements.property(ash, "Flammable", 25.56)

local lhyg = elements.allocate("TPT", "LHYG")
 elements.element(lhyg, elements.element(elements.DEFAULT_PT_LOXY))
 elements.property(lhyg, "Name" , "LHYG")
 elements.property(lhyg, "Description" , "Liquid Hydrogen, very cold. Incredibly flammable")
 elements.property(lhyg, "Flammable", 5000.65)
 elements.property(lhyg, "Explosive", 1)
 elements.property(lhyg, "Color", 0x3D68CD)
 elements.property(lhyg, "Temperature", 14.15)
 elements.property(lhyg, "MenuSection", 7)
 elements.property(lhyg, "HighTemperature", 18.15)
 elements.property(lhyg, "HighTemperatureTransition", elements.DEFAULT_PT_HYGN)

 elements.property(elements.DEFAULT_PT_HYGN, "LowTemperature", 15.24)
 elements.property(elements.DEFAULT_PT_HYGN, "LowTemperatureTransition", elements.TPT_PT_LHYG)

local pb = elements.allocate("TPT" , "LEAD")
 elements.element(pb, elements.element(elements.DEFAULT_PT_IRON))
 elements.property(pb, "Name" , "LEAD")
 elements.property(pb, "Description" , "Lead, absorbs neutrons. Conducts electricity.")
 elements.property(pb, "Color", 0x686868)
 elements.property(pb, "Hardness", 0)
 elements.property(pb, "HighTemperature", 601.25)
 elements.property(pb, "Properties", elements.PROP_NEUTABSORB+elements.PROP_CONDUCTS+elements.PROP_LIFE_DEC+elements.TYPE_SOLID+elements.PROP_DEADLY)

local mnpr = elements.allocate("TPT", "MNPR")
 elements.element(mnpr, elements.element(elements.DEFAULT_PT_BOYL))
 elements.property(mnpr, "Name" , "MONO")
 elements.property(mnpr, "Description" , "Monopropellant. Disperses quickly.")
 elements.property(mnpr, "Color", 0xB0B0B0)
 elements.property(mnpr, "Advection", 0.2)
 elements.property(mnpr, "AirDrag", 0.05)
 elements.property(mnpr, "HotAir", 0.01)
 elements.property(mnpr, "MenuSection", 16)
 elements.property(elements.TPT_PT_MNPR, "Update", --*1
function(i,x,y) --1
 if math.random(1,30) == 1 then --2
  sim.partKill(i)
  end --2
 end --1
 ) --*1

local mnpl = elements.allocate("TPT", "MNPL")
 elements.element(mnpl, elements.element(elements.DEFAULT_PT_LOXY))
 elements.property(mnpl, "Name" , "MNPL")
 elements.property(mnpl, "Description" , "Liquid Monopropellant. Releases lots of pressure and heat when boiled")
 elements.property(mnpl, "Flammable", 0)
 elements.property(mnpl, "Color", 0xA0A0A0)
 elements.property(mnpl, "Temperature", 180.15)
 elements.property(mnpl, "MenuSection", 5)
 elements.property(mnpl, "Diffusion", 0.1)
 elements.property(mnpl, "HighTemperature", 200.15)
 elements.property(mnpl, "HighTemperatureTransition", elements.TPT_PT_MNPR)
 elements.property(elements.TPT_PT_MNPL, "Update", --*1
 function(i,x,y,s,nt) --1
  for r in sim.neighbors(x,y,1,1) do --2
   if sim.partProperty(r, "type") == elements.TPT_PT_MNPR then --3
    if math.random(1,45) == 1 then --4
     sim.partProperty(i, "temp", sim.partProperty(i, "temp")+75)
     sim.pressure(x/4,y/4,10)
     end --4
    end --3
   end --2
  end --1
 ) --*1

 elements.property(mnpr, "LowTemperature", 190.15)
 elements.property(mnpr, "LowTemperatureTransition", elements.TPT_PT_MNPL)

local tchn = elements.allocate("TPT" , "TCHN")
 elements.element(tchn, elements.element(elements.DEFAULT_PT_URAN))
 elements.property(tchn, "Name" , "TCHN")
 elements.property(tchn, "Description" , "Technetium, decays over time and leaves heat.")
 elements.property(tchn, "Color", 0x205570)
 elements.property(tchn, "MenuSection", 11)
elements.property(elements.TPT_PT_TCHN, "Update", --*1
 function(i,x,y) --1
  if math.random(1,11520) == 1 then --2
   sim.partProperty(i, "temp", sim.partProperty(i, "temp")+400)
   sim.pressure(x/4,y/4,8)
   sim.partProperty(i, "type", elements.DEFAULT_PT_STNE)
   end --2
  end --1
 ) --*1
 elements.property(tchn, "HighTemperatureTransition", elements.TPT_PT_TCHN)

local psac = elements.allocate("TPT", "PSAC")
 elements.element(psac, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(psac, "Name" , "PSAC")
 elements.property(psac, "Description" , "Positronic acid, reacts violently with matter, weak acid.")
 elements.property(psac, "Color", 0xFF20BB)
 elements.property(psac, "Advection", 0.01)
 elements.property(psac, "Hardness", 0)
 elements.property(psac, "Properties", elements.TYPE_LIQUID+elements.PROP_NEUTPENETRATE+elements.PROP_RADIOACTIVE)
 elements.property(elem.TPT_PT_PSAC, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   if math.random(1,100) == 10 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_DMND then --5
      if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_VACU then --6
       if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_VOID then --7
        if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_CLNE then --8
         if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_PCLN then --9
          if math.random(1,3) == 1 then --10
           sim.partKill(r)
           sim.partProperty(i, "temp", sim.partProperty(i, "temp")+3200)
           if math.random(1,13) == 1 then --11
            sim.pressure(x/4,y/4,16)
            sim.partKill(i)
            return
            end --11
           end --10
          end --9
         end --8
        end --7
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local si = elements.allocate("TPT" , "SILC")
 elements.element(si, elements.element(elements.DEFAULT_PT_IRON))
 elements.property(si, "Name" , "SILC")
 elements.property(si, "Description" , "Silicon, conducts electricity. Lets air pass through")
 elements.property(si, "Color", 0x686E76)
 elements.property(si, "AirLoss", 1)
 elements.property(si, "HighTemperature", 1687.01)
 elements.property(si, "Properties", elements.PROP_CONDUCTS+elements.PROP_LIFE_DEC+elements.TYPE_SOLID+elements.PROP_HOT_GLOW)

local torn = elements.allocate("TPT" , "TORN")
 elements.element(torn, elements.element(elements.DEFAULT_PT_BOYL))
 elements.property(torn, "Name" , "TORN")
 elements.property(torn, "Description" , "Tornado, self explanatory.")
 elements.property(torn, "Color", 0x8A9098)
 elements.property(torn, "AirDrag", 0.05)
 elements.property(torn, "AirDrag", 0.05)
 elements.property(torn, "HotAir", -0.001)
 elements.property(torn, "MenuSection", 16)

local lhlm = elements.allocate("TPT", "LHE")
 elements.element(lhlm, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(lhlm, "Name" , "LHE")
 elements.property(lhlm, "Description" , "Liquid helium, incredibly cold.")
 elements.property(lhlm, "Temperature", 4.01)
 elements.property(lhlm, "Color", 0x5000FF)
 elements.property(lhlm, "MenuSection", 11)
 elements.property(elem.TPT_PT_LHE, "Update", --*1
function(i,x,y,s) --1
  if math.random(1,200) == 1 then --2
   if sim.partProperty(i, "temp") > 4.21 then --3
    if math.random(1,100) > 1 then --4
     sim.partKill(i)
     else
     sim.partProperty(i, "type", elements.TPT_PT_HE)
     end --4
    end --3
   end --2
  end --1
  ) --*1

local he = elements.allocate("TPT", "HE")
 elements.element(he, elements.element(elements.DEFAULT_PT_HYGN))
 elements.property(he, "Name" , "HE")
 elements.property(he, "Description", "Helium, floats.")
 elements.property(he, "Color", 0x6111FF)
 elements.property(he, "Diffusion", 1.5)
 elements.property(he, "Gravity", -0.3)
 elements.property(he, "Flammable", 0)
 elements.property(he, "LowTemperature", -1)
 elements.property(he, "LowTemperatureTransition", -1)
 elements.property(he, "MenuSection", 16)

local n237 = elements.allocate("TPT" , "N237")
 elements.element(n237, elements.element(elements.DEFAULT_PT_POLO))
 elements.property(n237, "Name" , "N237")
 elements.property(n237, "Description" , "Neptunium 237, decays very quickly. Radioactive waste.")
 elements.property(n237, "Color", 0x668131)
 elements.property(n237, "HighTemperature", 1644)
 elements.property(n237, "PhotonReflectWavelengths", 0x002FF200)
 elements.property(n237, "MenuSection", 16)
 function nept237(i,x,y,s,n)
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   if math.random(1,2) == 1 then --2
    tpt.parts[i].type = elements.DEFAULT_PT_PLUT
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    else if math.random(1,6) == 1 then --3
     tpt.parts[i].type = elements.DEFAULT_PT_HE
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     end --3
    end --2
   end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,125) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    tpt.set_property("temp", math.huge, x ,y)
    end --4
   end --3
  if math.random(1,100) == 10 then --5
   sim.pressure(x/4,y/4,0.2)
   end --5
  end --*1
 tpt.element_func(nept237,elements.TPT_PT_N237)

 function neptunium(i,x,y,s,n)
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   if math.random(1,2) == 1 then --2
    tpt.parts[i].type = elements.DEFAULT_PT_URAN
    else if math.random(1,6) == 1 then --3
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), elements.TPT_PT_N237)
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), elements.TPT_PT_N237)
     tpt.parts[i].type = elements.DEFAULT_PT_NBLE
     end --3
    end --2
   end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    tpt.set_property("temp", math.huge, x ,y)
    end --4
   end --3
  if math.random(1,10000) == 10 then --5
   sim.pressure(x/4,y/4,0.1)
   end --5
  end --*1
 tpt.element_func(neptunium,nept)
  function neutron(i,x,y,s,n) --*2
   if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == nept then --1
    if math.random(1,25) == 10 then --2 
     tpt.create(x, y, 'neut')
     tpt.set_property("temp", tpt.get_property("temp", x, y)+7000, x ,y)
     sim.pressure(x/4,y/4,8)
     end --2
    end --1
   end --*2
 tpt.element_func(neutron,tpt.el.neut.id)

local he3 = elements.allocate("TPT", "HE3")
 elements.element(he3, elements.element(elements.DEFAULT_PT_HYGN))
 elements.property(he3, "Name" , "HE3")
 elements.property(he3, "Description", "Helium 3, fuses with tritium.")
 elements.property(he3, "Color", 0xD6EE00)
 elements.property(he3, "Diffusion", 1.7)
 elements.property(he3, "Gravity", -1.0)
 elements.property(he3, "Flammable", 0)
 elements.property(he3, "LowTemperature", -1)
 elements.property(he3, "LowTemperatureTransition", -1)
 elements.property(he3, "MenuSection", 16)

local shake = elements.allocate("TPT", "SHAKE")
 elements.element(shake, elements.element(elements.DEFAULT_PT_DMND))
 elements.property(shake, "Name" , "SHAK")
 elements.property(shake, "Description", "Shakes particles.")
 elements.property(shake, "Color", 0xFFCCCC)
 elements.property(shake, "Weight", 0)
 elements.property(shake, "MenuSection", 13)
 elements.property(elem.TPT_PT_SHAKE, "Update", --*1
function(i,x,y,s) --1
  for r in sim.neighbors(x,y,1,1) do --2
   velocity(r,6,360)
   end --2
  sim.partKill(i)
  end --1
 ) --*1

local normal = elements.allocate("TPT", "NORMAL")
 elements.element(normal, elements.element(elements.DEFAULT_PT_DMND))
 elements.property(normal, "Name" , "NORM")
 elements.property(normal, "Description", "Normalizes temperature and pressure in the selected area.")
 elements.property(normal, "Color", 0xCCFFCC)
 elements.property(normal, "Weight", 0)
 elements.property(normal, "MenuSection", 13)
 elements.property(elem.TPT_PT_NORMAL, "Update", --*1
function(i,x,y,s) --1
  sim.pressure(x/4,y/4,0)
  for r in sim.neighbors(x,y,1,1) do --2
   if sim.partProperty(r, "temp") > 295.15 then --3
    sim.partProperty(r, "temp", sim.partProperty(r, "temp")-5)
    end --3
   if sim.partProperty(r, "temp") < 295.15 then --4
    sim.partProperty(r, "temp", sim.partProperty(r, "temp")+5)
    end --4
   end --2
  sim.partKill(i)
  end --1
 ) --*1

local os = elements.allocate("TPT" , "OSMM")
 elements.element(os, elements.element(elements.DEFAULT_PT_BRMT))
 elements.property(os, "Name" , "OSMM")
 elements.property(os, "Description" , "Osmium, heavy metal. Mostly the norwegian kind")
 elements.property(os, "Color", 0x4D5763)
 elements.property(os, "Gravity", 0.5)
 elements.property(os, "AirDrag", 0.08)
 elements.property(os, "Weight", 97)
 elements.property(os, "Meltable", 1)
 elements.property(os, "HighTemperature", 3306)
 elements.property(os, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
 elements.property(elements.TPT_PT_OSMM, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.0025)
  end --1
 ) --*1

local anco = elements.allocate("TPT", "ACOL")
 elements.element(anco, elements.element(elements.DEFAULT_PT_COAL))
 elements.property(anco, "Name" , "ACOL")
 elements.property(anco, "Description" , "Anti-Coal, burns slowly and very... surprisingly cold.")
 elements.property(anco, "MenuSection", 16)
 elements.property(anco, "Color", 0xDDDDDD)
 elements.property(elem.TPT_PT_ACOL, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 2 then --2
   if s ~=8 and nt ~=0 and nt - s > 0 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(i, "tmp") == 0 then --5
      if sim.partProperty(r, "type") == elements.DEFAULT_PT_CFLM then --6
       sim.partProperty(i, "tmp", -1)
       end --6
      end --5
     if sim.partProperty(i, "tmp") == -1 then --7
      if math.random(1,9) == 1 then --8
       sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.DEFAULT_PT_CFLM)
       sim.partProperty(i, "temp", sim.partProperty(i, "temp")-200)
       if math.random(1,900) == 1 then --9
        sim.partKill(i)
        return
        end --9
       end --8
      end --7
     end --4
    end --3
   end --2
  end --1
  ) --*1

 elements.property(elements.DEFAULT_PT_PLSM, "HeatConduct", 255)
 elements.property(elements.DEFAULT_PT_GLOW, "HeatConduct", 255)

 elements.property(elements.DEFAULT_PT_IRON, "Update", --*1
 function(i,x,y,s,nt) --1
   if s ~=8 and nt ~=0 and nt - s > 0 then --2
    for r in sim.neighbors(x,y,1,1) do --3
     if sim.pressure(x/4,y/4) > 2.51 then --4
      if sim.partProperty(r, "type") == elements.DEFAULT_PT_FIRE then --5
       sim.partProperty(i, "tmp", -1)
       end --5
      if sim.partProperty(i, "tmp") == -1 then --6
       if math.random(1,9) == 1 then --7
        sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.DEFAULT_PT_FIRE)
         if math.random(1,25) == 1 then --8
          sim.partProperty(i, "temp", sim.partProperty(i, "temp")+10000)
          sim.partProperty(i, "temp", sim.partProperty(i, "temp")+10000)
          sim.partProperty(i, "temp", sim.partProperty(i, "temp")+10000)
          sim.partProperty(i, "tmp", 0)
          end --8
         end --7
        end --6
       end --5
      end --4
     end --3
    end --2
 ) --*1

local bhut = elements.allocate("TPT" , "BHUT")
 elements.element(bhut, elements.element(elements.DEFAULT_PT_BOYL))
 elements.property(bhut, "Name" , "BHUT")
 elements.property(bhut, "HeatConduct", 255)
 elements.property(bhut, "HotAir", 0.001)
 elements.property(bhut, "Color", 0x706050)
 elements.property(bhut, "AirDrag", 0.001)
 elements.property(bhut, "AirLoss", 1)
 elements.property(bhut, "Diffusion", 1.25)
 elements.property(bhut, "MenuSection", 5)
 elements.property(bhut, "Description" , "Bhutane, explosive gas")
 elements.property(elem.TPT_PT_BHUT, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 2 then --2
   if s ~=8 and nt ~=0 and nt - s > 0 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(i, "tmp") == 0 then --5
      if sim.partProperty(r, "type") == elements.DEFAULT_PT_FIRE then --6
       sim.partProperty(i, "tmp", -1)
       end --6
      end --5
     if sim.partProperty(i, "tmp") == -1 then --7
      if math.random(1,3) > 1 then --8
       sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.DEFAULT_PT_FIRE)
       sim.partProperty(i, "temp", sim.partProperty(i, "temp")+400)
       sim.pressure(x/4,y/4,5)
       if math.random(1,6) == 1 then --9
        sim.partKill(i)
        return
        end --9
       end --8
      end --7
     end --4
    end --3
   end --2
  end --1
  ) --*1

 elements.property(elements.TPT_PT_ASH, "Update", --*1
function(i,x,y,s) --1
  if sim.pressure(x/4,y/4) > 5.9 then --2
   if math.random(1,950) == 1 then --3
    sim.partProperty(i, "type", elements.DEFAULT_PT_OIL)
    else if math.random (1,3000) == 1 then --4
     sim.partProperty(i, "type", elements.TPT_PT_BHUT)
     else if math.random (1,3000) == 1 then --4
      sim.partProperty(i, "type", elements.DEFAULT_PT_SAWD)
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local gr = elements.allocate("TPT" , "GRPH")
 elements.element(gr, elements.element(elements.DEFAULT_PT_COAL))
 elements.property(gr, "Name" , "GRPH")
 elements.property(gr, "Description" , "Graphite, melts at an incredibly high temperature.")
 elements.property(gr, "Color", 0x111113)
 elements.property(gr, "HeatConduct", 7)
 elements.property(gr, "HighTemperature", 4003.15)
 elements.property(gr, "Meltable", 1)
 elements.property(gr, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
 elements.property(gr, "Properties", elements.PROP_CONDUCTS+elements.TYPE_SOLID+elements.PROP_HOT_GLOW)
 elements.property(elements.TPT_PT_GRPH, "Update", --*1
 function(i,x,y,s,nt) --1
   if sim.partProperty(i, "life") > 0 then --2
    if math.random(1,65) == 1 then --3
     sim.partProperty(i, "life", 0)
     end --3
    end --2
   if sim.pressure(x/4,y/4) > 11.8 then --4
    if math.random(1,950) == 1 then --5
     sim.partProperty(i, "type", elements.DEFAULT_PT_DMND)
     end --5
    end --4
   end --1
  ) --*1

local thor = elements.allocate("TPT" , "THOR")
 elements.element(thor, elements.element(elements.DEFAULT_PT_PLUT))
 elements.property(thor, "Name" , "THOR")
 elements.property(thor, "Description" , "Thorium, not radioactive on its own, needs help from another radioactive material to function.")
 elements.property(thor, "Color", 0x404043)
 elements.property(thor, "PhotonReflectWavelengths", 0x8FFFFFFF)
 elements.property(thor, "MenuSection", 10)
  function neutron2(i,x,y,s,n) --*2
   if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == thor then --1
    if math.random(1,70) == 1 then --2
     tpt.set_property("temp", tpt.get_property("temp", x, y)+4500, x ,y)
     end --2
    end --1
   end --*2
 tpt.element_func(neutron2,tpt.el.neut.id)

local para = elements.allocate("TPT" , "PARA")
 elements.element(para, elements.element(elements.DEFAULT_PT_WAX))
 elements.property(para, "Name" , "FZOL")
 elements.property(para, "HeatConduct", 5)
 elements.property(para, "Color", 0x474530)
 elements.property(para, "Flammable", 1)
 elements.property(para, "Description" , "Frozen oil, flammable")
 elements.property(para, "HighTemperature", 277.14)
 elements.property(para, "Temperature", 274.14)
 elements.property(para, "HighTemperatureTransition", elements.DEFAULT_PT_OIL)

 elements.property(elements.DEFAULT_PT_OIL, "LowTemperature", 278.14)
 elements.property(elements.DEFAULT_PT_OIL, "LowTemperatureTransition", elements.TPT_PT_PARA)

local plwd = elements.allocate("TPT" , "PLWD")
 elements.element(plwd, elements.element(elements.DEFAULT_PT_WOOD))
 elements.property(plwd, "Name" , "PLWD")
 elements.property(plwd, "HeatConduct", 2)
 elements.property(plwd, "Color", 0x808445)
 elements.property(plwd, "Flammable", 1)
 elements.property(plwd, "Description" , "Plywood. Durable material.")
 elements.property(plwd, "AirLoss", 0.2)
 elements.property(plwd, "Hardness", 1)

local lbl = elements.allocate("TPT" , "LBYL")
 elements.element(lbl, elements.element(elements.DEFAULT_PT_GLOW))
 elements.property(lbl, "Name" , "LBYL")
 elements.property(lbl, "HeatConduct", 25)
 elements.property(lbl, "Color", 0x001F00)
 elements.property(lbl, "Flammable", 5)
 elements.property(lbl, "HotAir", -0.0001)
 elements.property(lbl, "Description" , "Liquid Boyle gas. Explosive.")
 elements.property(lbl, "HighTemperature", 220.14)
 elements.property(lbl, "Temperature", 213.14)
 elements.property(lbl, "HighTemperatureTransition", elements.DEFAULT_PT_BOYL)
 elements.property(lbl, "MenuSection", 16)

 elements.property(elements.DEFAULT_PT_BOYL, "LowTemperature", 219.14)
 elements.property(elements.DEFAULT_PT_BOYL, "HighTemperatureTransition", elements.TPT_PT_LBYL)

local mgns = elements.allocate("TPT", "CAVE")
 elements.element(mgns, elements.element(elements.DEFAULT_PT_BRMT))
 elements.property(mgns, "Name" , "CAVE")
 elements.property(mgns, "Description" , "Burn life's house down! With the lemons!")
 elements.property(mgns, "Color", 0xA5A515)
 elements.property(mgns, "Weight", 49)
 elements.property(mgns, "Gravity", 0.3)
 elements.property(mgns, "MenuSection", 16)
 elements.property(elem.TPT_PT_CAVE, "Update", --*1
 function(i,x,y,s) --1
  if s > 6 then --2
   if math.random(1,20) == 20 then --3
    sim.partCreate(-1, x+math.random(-2,2), y+math.random(-2,2), elements.DEFAULT_PT_FIRE)
    sim.partCreate(-1, x+math.random(-2,2), y+math.random(-2,2), elements.DEFAULT_PT_FIRE)
    sim.partCreate(-1, x+math.random(-2,2), y+math.random(-2,2), elements.DEFAULT_PT_FIRE)
    sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
    sim.pressure(x/4,y/4,16)
    if math.random(1,5) == 5 then --4
     sim.partKill(i)
     end --4
    end --3
   end --2
  end --1
  ) --*1

local tmpsns = elements.allocate("TPT" , "TMPS")
elements.element(tmpsns, elements.element(elements.DEFAULT_PT_DMND))
elements.property(tmpsns, "Name" , "TMPS")
elements.property(tmpsns, "Description" , "Temporary value sensor, creates power when something's tmp or tmp2 is higher than its temperature.")
elements.property(tmpsns, "Color", 0x22713D)
elements.property(tmpsns, "MenuSection", 3)
elements.property(tmpsns, "HeatConduct", 0)
elements.property(elem.TPT_PT_TMPS, "Update", 
 function(i,x,y,s,nt) --1
  for r in sim.neighbors(x,y,1,1) do --2
   if sim.partProperty(r, "tmp") > sim.partProperty(i, "temp")-273.15 then --3
    sim.partCreate(-1, x, y+1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x+1, y+1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x-1, y+1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x, y-1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x+1, y-1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x-1, y-1, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x+1, y, elements.DEFAULT_PT_SPRK)
    sim.partCreate(-1, x-1, y, elements.DEFAULT_PT_SPRK)
    end --3
   end --2
  end --1
) --*1

local erode = elements.allocate("TPT", "ERODE")
 elements.element(erode, elements.element(elements.DEFAULT_PT_DMND))
 elements.property(erode, "Name" , "EROD")
 elements.property(erode, "Description", "Erodes.")
 elements.property(erode, "Color", 0xCCCCCC)
 elements.property(erode, "Weight", 0)
 elements.property(erode, "MenuSection", 13)
 elements.property(elem.TPT_PT_ERODE, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   if math.random(1,25) == 10 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if math.random(1,6) == 3 then --5
      sim.partKill(r)
      end --5
     end --4
    end --3
   end --2
  sim.partKill(i)
  end --1
  ) --*1

local storm = elements.allocate("TPT", "STORM")
 elements.element(storm, elements.element(elements.DEFAULT_PT_DMND))
 elements.property(storm, "Name" , "STRM")
 elements.property(storm, "Description", "Storms.")
 elements.property(storm, "Color", 0x889F9F)
 elements.property(storm, "Weight", 0)
 elements.property(storm, "MenuSection", 11)
 elements.property(elem.TPT_PT_STORM, "Update", --*1
 function(i,x,y,s) --1
  sim.pressure(x/4,y/4,math.random(-112,112))
  if math.random(1,1000) == 1 then --2
   sim.partProperty(i, "type", elements.DEFAULT_PT_WATR)
   else if math.random(1,100) == 1 then --3
    sim.partProperty(i, "type", elements.DEFAULT_PT_FOG)
    else if math.random(1,50000) == 1 then --4
     sim.partProperty(i, "tmp2", 4)
     sim.partProperty(i, "tmp", math.random(0,359))
     sim.partProperty(i, "life", math.random(15,25))
     sim.partProperty(i, "type", elements.DEFAULT_PT_LIGH)
     else
     sim.partKill(i)
     end --4
    end --3
   end --2
  end --1
 ) --*1

local aliq = elements.allocate("TPT", "ANLIQ")
 elements.element(aliq, elements.element(elements.DEFAULT_PT_GLOW))
 elements.property(aliq, "Name" , "ALIQ")
 elements.property(aliq, "Description", "Anti-liquid. Flows upwards.")
 elements.property(aliq, "Color", 0xEFEFFF)
 elements.property(aliq, "Gravity", -0.1)
 elements.property(aliq, "Advection", -0.6)
 elements.property(aliq, "AirDrag", -0.01)
 elements.property(aliq, "HeatConduct", 2)
 elements.property(aliq, "MenuSection", 16)
 elements.property(elem.TPT_PT_ANLIQ, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 2 then --2
   if s ~=8 and nt ~=0 and nt - s > 0 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(i, "tmp") == 0 then --5
      if sim.partProperty(r, "type") == elements.DEFAULT_PT_CFLM then --6
       sim.partProperty(i, "tmp", -1)
       end --6
      end --5
     if sim.partProperty(i, "tmp") == -1 then --7
      if math.random(1,2) == 1 then --8
       sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.DEFAULT_PT_CFLM)
       sim.partProperty(i, "temp", sim.partProperty(i, "temp")-200)
       sim.pressure(x/4,y/4,5)
       if math.random(1,50) == 1 then --9
        sim.partKill(i)
        return
        end --9
       end --8
      end --7
     end --4
    end --3
   end --2
  end --1
  ) --*1

local neutr = elements.allocate("TPT" , "NETR")
 elements.element(neutr, elements.element(elements.DEFAULT_PT_DMND))
 elements.property(neutr, "Name" , "NETR")
 elements.property(neutr, "Description" , "Neutronium. Dense, Radioactive solid. Slowly implodes and decays after time. Rarely grows")
 elements.property(neutr, "Color", 0x0606FF)
 elements.property(neutr, "Properties", elements.TYPE_SOLID+elements.PROP_CONDUCTS+elements.PROP_LIFE_DEC+elements.PROP_RADIOACTIVE+elements.PROP_NEUTPASS)
 elements.property(neutr, "PhotonReflectWavelengths", 0x00000001)
 elements.property(neutr, "MenuSection", 10)
elements.property(elements.TPT_PT_NETR, "Update", --*1
 function(i,x,y) --1
  attract(i,x,y,0.1)
   if math.random(1,(sim.pressure(x/4,y/4)+256)/100) == 1 then --2
    if math.random(1,50) == 1 then --3
     sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.TPT_PT_NETR)
     if math.random(1,500) == 1 then --4
      sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.TPT_PT_NETR)
      end --4
     end --3
    end --2
  if math.random(1,(sim.pressure(x/4,y/4)+256)*100) == 1 then --5
   sim.partProperty(i, "temp", sim.partProperty(i, "temp")+400)
   sim.pressure(x/4,y/4,32)
   sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.DEFAULT_PT_NEUT)
   sim.pressure(x/4,y/4,-32)
   sim.partProperty(i, "life", 90)
   repeat --6
    attract(i,x,y,-10)
    if math.random(1,2) == 1 then --7
     sim.partProperty(i, "life", sim.partProperty(i, "life")-1)
     end --7
    until sim.partProperty(i, "life") < 0 --6
   sim.partKill(i)
   end --5
  end --1
 ) --*1

local brcryst = elements.allocate("TPT" , "BCRY")
 elements.element(brcryst, elements.element(elements.DEFAULT_PT_PQRT))
 elements.property(brcryst, "Name" , "BCRY")
 elements.property(brcryst, "Description" , "Broken Crystal. Light powder, may shred lungs of organisms.")
 elements.property(brcryst, "Properties", elements.TYPE_PART+elements.PROP_DEADLY)
 elements.property(brcryst, "Color", 0xE9E9EF)
 elements.property(brcryst, "PhotonReflectWavelengths", 0xEFEFEFF6)
 elements.property(brcryst, "MenuSection", 8)
 elements.property(brcryst, "Gravity", 0.056)
 elements.property(brcryst, "Advection", 0.2)
 elements.property(brcryst, "Weight", 2)
 elements.property(brcryst, "AirDrag", 0.05)
 elements.property(brcryst, "Diffusion", 0.1)

local cryst = elements.allocate("TPT" , "CRYT")
 elements.element(cryst, elements.element(elements.DEFAULT_PT_QRTZ))
 elements.property(cryst, "Name" , "CRYS")
 elements.property(cryst, "Description" , "Crystal. Durable, grows")
 elements.property(cryst, "Color", 0xEEEEF3)
 elements.property(cryst, "PhotonReflectWavelengths", 0xF8F8F8FF)
 elements.property(cryst, "MenuSection", 9)
 elements.property(cryst, "HighPressure", 20.14)
 elements.property(cryst, "HighPressureTransition", elements.TPT_PT_BCRY)
elements.property(elements.TPT_PT_CRYT, "Update", --*1
 function(i,x,y) --1
  if math.random(1,100) == 1 then --2
   sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.TPT_PT_CRYT)
   if math.random(1,20) == 1 then --3
    sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.TPT_PT_CRYT)
    end --3
   end --2
  end --1
) --*1


 elements.property(brcryst, "HighTemperatureTransition", elements.TPT_PT_CRYT)

local gasl = elements.allocate("TPT" , "GASL")
 elements.element(gasl, elements.element(elements.DEFAULT_PT_GLOW))
 elements.property(gasl, "Name" , "GASL")
 elements.property(gasl, "HeatConduct", 255)
 elements.property(gasl, "Color", 0xF0C020)
 elements.property(gasl, "Flammable", 0)
 elements.property(gasl, "MenuSection", 5)
 elements.property(gasl, "Description" , "Gasoline, highly flammable.")
 elements.property(elem.TPT_PT_GASL, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 2 then --2
   if s ~=8 and nt ~=0 and nt - s > 0 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(i, "tmp") == 0 then --5
      if sim.partProperty(r, "type") == elements.DEFAULT_PT_FIRE then --6
       sim.partProperty(i, "tmp", -1)
       end --6
      end --5
     if sim.partProperty(i, "tmp") == -1 then --7
      if math.random(1,3) > 1 then --8
       sim.partCreate(-1, x+math.random(-2,2), y+math.random(-2,2), elements.DEFAULT_PT_FIRE)
       sim.partProperty(i, "temp", sim.partProperty(i, "temp")+100)
       sim.pressure(x/4,y/4,2)
       if math.random(1,60) == 1 then --9
        sim.partKill(i)
        return
        end --9
       end --8
      end --7
     end --4
    end --3
   end --2
  end --1
  ) --*1

local logan = elements.allocate("TPT" , "XMEN")
 elements.element(logan, elements.element(elements.DEFAULT_PT_IRON))
 elements.property(logan, "Name" , "ADMT")
 elements.property(logan, "Description" , "Adamantium, incredibly durable material. Almost virtually indestructible. An alloy of steel and vibranium")
 elements.property(logan, "Color", 0xC8C8D0)
 elements.property(logan, "HighTemperature", 9500.50)
 elements.property(logan, "Weight", 1010)
 elements.property(logan, "Hardness", 0)

local dmdd = elements.allocate("TPT" , "DMDD")
 elements.element(dmdd, elements.element(elements.DEFAULT_PT_DMND))
 elements.property(dmdd, "Name" , "DMDD")
 elements.property(dmdd, "Description" , "Diamond dust. Yeah.")
 elements.property(dmdd, "Color", 0xC6F6F6)
 elements.property(dmdd, "MenuSection", 8)
 elements.property(dmdd, "Properties", elements.TYPE_PART)
 elements.property(dmdd, "Gravity", 0.112)
 elements.property(dmdd, "Advection", 1)
 elements.property(dmdd, "Weight", 100)
 elements.property(dmdd, "AirDrag", 0.1)
 elements.property(dmdd, "Falldown", 1)
 elements.property(dmdd, "HighTemperature", 9999)
 elements.property(dmdd, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA)
 elements.property(dmdd, "Falldown", 1)

local anih = elements.allocate("TPT" , "ANIH")
 elements.element(anih, elements.element(elements.DEFAULT_PT_DEST))
 elements.property(anih, "Name" , "ANIH")
 elements.property(anih, "Description" , "Annihilation.")
 elements.property(anih, "Color", 0x603090)
 elements.property(anih, "HotAir", 0.1)
 elements.property(anih, "MenuSection", 11)
 elements.property(elements.TPT_PT_ANIH, "Update", --*1
  function(i,x,y,s,nt) --1
  attract(i,x,y,0.1)
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   if math.random(1,1) == 1 then --3
    for r in sim.neighbors(x,y,2,2) do --4
     if math.random(1,6) == 3 then --5
      sim.partProperty(i, "temp", sim.partProperty(i, "temp")+10000)
      if math.random(1,2) == 1 then --6
       if sim.partProperty(r, "type") == elements.DEFAULT_PT_DMND then --7
        sim.partProperty(r, "type", elements.TPT_PT_DMDD)
        else if sim.partProperty(r, "type") ~= elements.TPT_PT_DMDD then --8
         sim.pressure(x/4,y/4,255)
         sim.partKill(r)
         return
         end --8
        end --7
       end --6
      end --5
     end --4
    end --3
   end --2
  if math.random(1,8) == 1 then --9
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.TPT_PT_ANTI)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.TPT_PT_ANTI)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.TPT_PT_ANTI)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.DEFAULT_PT_SING)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.DEFAULT_PT_PROT)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.DEFAULT_PT_HYGN)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.DEFAULT_PT_PROT)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.DEFAULT_PT_HYGN)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.DEFAULT_PT_PROT)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.DEFAULT_PT_HYGN)
   sim.partCreate(-1, x+math.random(-10,10),y+math.random(-10,10),elements.DEFAULT_PT_DEST)
   sim.partProperty(i, "temp", sim.partProperty(i, "temp")+10000)
   end --9
  end --1
 ) --*1

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.PMODE_LFLARE,30,colr,colg,colb,255,96,48,144
  end --*1
 elements.property(anih, "Graphics", funcGraphics)

local bullet = elements.allocate("TPT" , "BULT")
 elements.element(bullet, elements.element(elements.DEFAULT_PT_BREL))
 elements.property(bullet, "Name" , "BLLT")
 elements.property(bullet, "Description" , "Bullet, travels with minimum decceleration and creates winds.")
 elements.property(bullet, "Color", 0x433141)
 elements.property(bullet, "MenuSection", 16)
 elements.property(bullet, "Flammable", 0)
 elements.property(bullet, "Loss", 1)
 elements.property(bullet, "AirDrag", 0.35)
 elements.property(bullet, "Weight", 101)
 elements.property(bullet, "Gravity", 0.002)
 elements.property(elem.TPT_PT_BULT, "Update", 
 function(i,x,y,s,nt) --1
  if math.sqrt(math.pow(sim.partProperty(i, "vx"),2)+math.pow(sim.partProperty(i, "vy"),2)) > 50 then --2
   sim.partCreate(-1, x, y+1, elements.DEFAULT_PT_FIRE)
   sim.partCreate(-1, x+1, y+1, elements.DEFAULT_PT_FIRE)
   sim.partCreate(-1, x-1, y+1, elements.DEFAULT_PT_FIRE)
   sim.partCreate(-1, x, y-1, elements.DEFAULT_PT_FIRE)
   sim.partCreate(-1, x+1, y-1, elements.DEFAULT_PT_FIRE)
   sim.partCreate(-1, x-1, y-1, elements.DEFAULT_PT_FIRE)
   sim.partCreate(-1, x+1, y, elements.DEFAULT_PT_FIRE)
   sim.partCreate(-1, x-1, y, elements.DEFAULT_PT_FIRE)
   end --2
  end --1
) --*1

local anmt = elements.allocate("TPT" , "AMTL")
 elements.element(anmt, elements.element(elements.DEFAULT_PT_METL))
 elements.property(anmt, "Name" , "AMTL")
 elements.property(anmt, "Description" , "Anti-Metal, violently heats surrounding materials when sparked. Melts at cold temperatures.")
 elements.property(anmt, "Color", 0x899469)
 elements.property(anmt, "LowTemperature", 10)
 elements.property(anmt, "LowTemperatureTransition", elements.DEFAULT_PT_LAVA)
 elements.property(anmt, "HighTemperature", 10001)
 elements.property(elem.TPT_PT_AMTL, "Update", 
 function(i,x,y,s,nt) --1
  for r in sim.neighbors(x,y,2,2) do --2
   if sim.partProperty(r, "type") == elements.DEFAULT_PT_SPRK then --3
    sim.partProperty(i, "temp", sim.partProperty(i, "temp")+500)
    end --3
   end --2
  end --1
) --*1

local agas = elements.allocate("TPT" , "AGAS")
 elements.element(agas, elements.element(elements.DEFAULT_PT_BOYL))
 elements.property(agas, "Name" , "AGAS")
 elements.property(agas, "HeatConduct", 255)
 elements.property(agas, "HotAir", 0.001)
 elements.property(agas, "Color", 0xFDFDB7)
 elements.property(agas, "AirDrag", 0.001)
 elements.property(agas, "AirLoss", 1)
 elements.property(agas, "Diffusion", 1.25)
 elements.property(agas, "MenuSection", 16)
 elements.property(agas, "LowPressure",  -5)
 elements.property(agas, "LowPressureTransition", elements.TPT_PT_ANLIQ)
 elements.property(agas, "Description" , "Anti-Gas. Opposite of gas")
 elements.property(elem.TPT_PT_AGAS, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 2 then --2
   if s ~=8 and nt ~=0 and nt - s > 0 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(i, "tmp") == 0 then --5
      if sim.partProperty(r, "type") == elements.DEFAULT_PT_CFLM then --6
       sim.partProperty(i, "tmp", -1)
       end --6
      end --5
     if sim.partProperty(i, "tmp") == -1 then --7
      if math.random(1,2) == 1 then --8
       sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.DEFAULT_PT_CFLM)
       sim.partProperty(i, "temp", sim.partProperty(i, "temp")-200)
       sim.pressure(x/4,y/4,10)
       if math.random(1,50) == 1 then --9
        sim.partKill(i)
        return
        end --9
       end --8
      end --7
     end --4
    end --3
   end --2
  end --1
  ) --*1

 elements.property(aliq, "LowTemperature",  5)
 elements.property(aliq, "LowTemperatureTransition", elements.TPT_PT_AGAS)

local qtfm = elements.allocate("TPT", "RADI")
 elements.element(qtfm, elements.element(elements.DEFAULT_PT_PROT))
 elements.property(qtfm, "Name" , "RADI")
 elements.property(qtfm, "Description" , "Radio Waves. Spreads.")
 elements.property(qtfm, "Color", 0x888888)
 elements.property(qtfm, "Diffusion", 1)
 elements.property(qtfm, "Update", --*1
 function (i,x,y,s,n) --1
  if math.random(1,8) == 1 then --2
   sim.partKill(i)
   end --2
  end --1
  ) --*1

 local function funcGraphics(i, colr, colg, colb) --*1
  return 1,ren.PMODE_SPARK,255,colr,colg,colb,192,184,200,223
  end --*1
 elements.property(qtfm, "Graphics", funcGraphics)

 elements.property(elements.DEFAULT_PT_CO2, "Color", 0xBBBBBB)

 elements.property(elements.DEFAULT_PT_METL, "Name" , "STEL")
 elements.property(elements.DEFAULT_PT_METL, "Description" , "Steel, basic metal. Conducts")
 elements.property(elements.DEFAULT_PT_METL, "Color", 0x54545D)
 elements.property(elements.DEFAULT_PT_METL, "HighTemperature", 1643.15)

local argi = elements.allocate("TPT" , "ARGI")
 elements.element(argi, elements.element(elements.DEFAULT_PT_GOLD))
 elements.property(argi, "Name" , "SLVR")
 elements.property(argi, "Description" , "Silver, resistant to corrosion. Conducts at a faster pulse")
 elements.property(argi, "Color", 0xA0A5B0)
 elements.property(argi, "HighTemperature", 1235.46)
 elements.property(elem.TPT_PT_ARGI, "Update", 
 function(i,x,y,s,nt) --1
  if sim.partProperty(i, "life") > 0 then --2
   sim.partProperty(i, "life", sim.partProperty(i, "life")-1)
   end --2
  end --1
) --*1

 elements.property(elements.DEFAULT_PT_SPRK, "Color", 0xDCECFF)

local trit = elements.allocate("TPT" , "TRIT")
 elements.element(trit, elements.element(elements.DEFAULT_PT_HYGN))
 elements.property(trit, "Name" , "TRIT")
 elements.property(trit, "Description" , "Tritium, decays into lighter components when struck with neutrons.")
 elements.property(trit, "Color", 0x11161D)
 elements.property(trit, "Gravity", 0.2)
 elements.property(trit, "PhotonReflectWavelengths", 0x00000001)
 elements.property(trit, "MenuSection", 10)
 function tritium(i,x,y,s,n)
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   if math.random(1,2) == 1 then --2
    tpt.parts[i].type = elements.DEFAULT_PT_DEUT
    tpt.set_property("temp", tpt.get_property("temp", x, y)+7000, x ,y)
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    sim.pressure(x/4,y/4,5)
    else if math.random(1,6) == 1 then --3
     tpt.parts[i].type = elements.DEFAULT_PT_HYGN
     tpt.set_property("temp", tpt.get_property("temp", x, y)+7000, x ,y)
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     sim.pressure(x/4,y/4,5)
     else if math.random(1,6) == 1 then --4
      tpt.parts[i].type = elements.TPT_PT_HE
      sim.pressure(x/4,y/4,5)
      tpt.set_property("temp", tpt.get_property("temp", x, y)+7000, x ,y)
      tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'elec')
      end --4
     end --3
    end --2
   end --1
  if sim.pressure(x/4,y/4) > 1 then --3
   if math.random(1,250) == 10 then --4
    tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
    tpt.set_property("temp", math.huge, x ,y)
    end --4
   end --3
  if math.random(1,10000) == 10 then --5
   sim.pressure(x/4,y/4,2)
   end --5
  end --*1

 elements.property(elem.TPT_PT_TRIT, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 2 then --2
   if s ~=8 and nt ~=0 and nt - s > 0 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(i, "tmp") == 0 then --5
      if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --6
       sim.partProperty(i, "tmp", -1)
       end --6
      end --5
     if sim.partProperty(i, "tmp") == -1 then --7
      if math.random(1,2) == 1 then --8
       sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.DEFAULT_PT_ACID)
       sim.partProperty(i, "temp", sim.partProperty(i, "temp")+20)
       if math.random(1,2) == 1 then --9
        sim.partKill(i)
        return
        end --9
       end --8
      end --7
     end --4
    end --3
   end --2
   tritium(i,x,y,s,n)
  end --1
  ) --*1

local ltrt = elements.allocate("TPT" , "LTRT")
 elements.element(ltrt, elements.element(elements.TPT_PT_LHYG))
 elements.property(ltrt, "Name" , "LTRT")
 elements.property(ltrt, "Description" , "Liquid Tritium, dangerous.")
 elements.property(ltrt, "Color", 0x13161C)
 elements.property(ltrt, "HighTemperatureTransition", elements.TPT_PT_TRIT)
 elements.property(ltrt, "PhotonReflectWavelengths", 0x00000001)
 elements.property(ltrt, "MenuSection", 16)
 elements.property(elem.TPT_PT_LTRT, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 2 then --2
   if s ~=8 and nt ~=0 and nt - s > 0 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(i, "tmp") == 0 then --5
      if sim.partProperty(r, "type") == elements.DEFAULT_PT_DEUT then --6
       sim.partProperty(i, "tmp", -2)
       end --6
      end --5
     if sim.partProperty(i, "tmp") == -2 then --7
      if math.random(1,500) == 1 then --8
       sim.partCreate(-1, x+math.random(-1,1), y+math.random(-1,1), elements.TPT_PT_LHE)
       sim.partProperty(i, "temp", sim.partProperty(i, "temp")+200)
       if math.random(1,2) == 1 then --9
        sim.partKill(i)
        return
        end --9
       end --8
      end --7
     end --4
    end --3
   end --2
  end --1
  ) --*1

elements.property(trit, "LowTemperatureTransition", elements.TPT_PT_LTRT)

local pkic = elements.allocate("TPT" , "PKIC")
 elements.element(pkic, elements.element(elements.DEFAULT_PT_DMND))
 elements.property(pkic, "Name" , "PKIC")
 elements.property(pkic, "Description" , "Packed Ice.")
 elements.property(pkic, "Color", 0x6F94F4)
 elements.property(pkic, "MenuSection", 9)
 elements.property(pkic, "Temperature", 210.32)
 elements.property(pkic, "HeatConduct", 5)
 elements.property(elem.TPT_PT_PKIC, "Update", 
 function(i,x,y,s,nt) --1
  if math.random(1,20) == 1 then --2
   if sim.partProperty(i, "temp") > 220.35 then --3
    sim.partProperty(i, "type", elements.DEFAULT_PT_ICE)
    end --3
   end --2
  end --1
) --*1

 elements.property(elem.DEFAULT_PT_ICE, "Update", 
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 1 then --2
   if sim.partProperty(i, "temp") < 220.30 then --3
    sim.partProperty(i, "type", elements.TPT_PT_PKIC)
    end --3
   end --2
  end --1
) --*1


local pala = elements.allocate("TPT" , "PALA")
 elements.element(pala, elements.element(elements.DEFAULT_PT_GOLD))
 elements.property(pala, "Name" , "PALA")
 elements.property(pala, "Description" , "Paladium, desintegrates over time with neutrons.")
 elements.property(pala, "Color", 0xCCC7BD)
 elements.property(pala, "PhotonReflectWavelengths", 0x2FF20000)
 elements.property(pala, "MenuSection", 10)
 elements.property(pala, "HighTemperature", 1828)
 function paladium(i,x,y,s,n)
  if tpt.get_property("type", x + math.random(-2,2), y + math.random(-2,2)) == tpt.el.neut.id then --1
   if math.random(1,2) == 1 then --2
    tpt.parts[i].type = elements.TPT_PT_ARGI
    if math.random(1,2) == 1 then --3
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'slvr')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'slvr')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'slvr')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'slvr')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'lead')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     tpt.create(x + math.random(-2,2), y + math.random(-2,2), 'neut')
     tpt.set_property("temp", tpt.get_property("temp", x ,y)+5000, x ,y)
     end --3
    end --2
   end --1
  if math.random(1,10000) == 10 then --4
   sim.pressure(x/4,y/4,5)
   end --4
  end --*1
 tpt.element_func(paladium,pala)

local algae = elements.allocate("TPT", "ALGAE")
 elements.element(algae, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(algae, "Name" , "ALGE")
 elements.property(algae, "Description" , "Algae, spreads in water.")
 elements.property(algae, "Color", 0x407010)
 elements.property(algae, "Diffusion", 0.3)
 elements.property(algae, "Weight", 31)
 elements.property(algae, "MenuSection", 16)
 elements.property(elem.TPT_PT_ALGAE, "Update", --*1
 function(i,x,y,s,nt) --1
  if nt == 8 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --4
     if math.random(1,1000) > 1 then --4
      sim.partProperty(i, "vy", -0.05)
      end --5
     if math.random(1,1000) > 1 then --5
      sim.partProperty(i, "vx", math.random(-0.01,0.01))
      end --6
     end --4
    if math.random(1,250) < 4 then --7
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ALGAE)
     end --7
    if math.random(1,400) < 2 then --8
     sim.partKill(i)
     end --8
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_CO2 then --9
     if math.random(1,200) == 1 then --10
      sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_ALGAE)
      sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.DEFAULT_PT_OXYG)
      sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.DEFAULT_PT_OXYG)
      end --10
     end --9
    end --3
   end --2
  if math.random(1,400) < 2 then --11
   sim.partKill(i)
   end --11
  end --1
) --*1

local ltac = elements.allocate("TPT", "LTAC")
 elements.element(ltac, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(ltac, "Name" , "LTAC")
 elements.property(ltac, "Description" , "Lactic acid, helps to decompose organic matter.")
 elements.property(ltac, "Color", 0xD7BCCD)
 elements.property(ltac, "Hardness", 1)
 elements.property(elem.TPT_PT_LTAC, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   if math.random(1,100) == 10 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(r, "type") == elements.DEFAULT_PT_PLNT or sim.partProperty(r, "type") == elements.DEFAULT_PT_WOOD then --5
      if math.random(1,3) == 1 then --6
       sim.partProperty(r, "type", elements.TPT_PT_ASH)
       sim.partProperty(i, "temp", sim.partProperty(i, "temp")+10)
       if math.random(1,13) == 1 then --7
        sim.pressure(x/4,y/4,0.1)
        sim.partKill(i)
        return
        end --7
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local bctr = elements.allocate("TPT", "BACT")
 elements.element(bctr, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(bctr, "Name" , "BCTR")
 elements.property(bctr, "Description" , "Bacteria, spreads and sticks.")
 elements.property(bctr, "Color", 0xE0F0A1)
 elements.property(bctr, "Diffusion", 0.3)
 elements.property(bctr, "Weight", 30)
 elements.property(bctr, "MenuSection", 11)

local bctrb = elements.allocate("TPT", "BCTR")
 elements.element(bctrb, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(bctrb, "Name" , "BCTD")
 elements.property(bctrb, "Description" , "Decomposer bacteria, decomposes plant matter.")
 elements.property(bctrb, "Color", 0xFFE990)
 elements.property(bctrb, "Diffusion", 0.3)
 elements.property(bctrb, "Weight", 30)
 elements.property(bctrb, "MenuSection", 16)

local bctra = elements.allocate("TPT", "BCTRA")
 elements.element(bctra, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(bctra, "Name" , "ABCT")
 elements.property(bctra, "Description" , "Airbourne bacteria.")
 elements.property(bctra, "Color", 0xC9E9FF)
 elements.property(bctra, "Diffusion", 0.2)
 elements.property(bctra, "Weight", 29)
 elements.property(bctra, "MenuSection", 16)
 elements.property(bctra, "Gravity", -0.025)

local bctrc = elements.allocate("TPT", "BCTRC")
 elements.element(bctrc, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(bctrc, "Name" , "BCTW")
 elements.property(bctrc, "Description" , "Bacterial wall, solid but still flows")
 elements.property(bctrc, "Color", 0xC9FF90)
 elements.property(bctrc, "Diffusion", 0.1)
 elements.property(bctrc, "Weight", 31)
 elements.property(bctrc, "MenuSection", 16)

local bctrp = elements.allocate("TPT", "BCTRP")
 elements.element(bctrp, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(bctrp, "Name" , "AQBC")
 elements.property(bctrp, "Description" , "Aquatic Bacteria. Floats and spreads through water slowly.")
 elements.property(bctrp, "Color", 0xFFF0FF)
 elements.property(bctrp, "Diffusion", 0.3)
 elements.property(bctrp, "Weight", 31)
 elements.property(bctrp, "MenuSection", 16)
 elements.property(elem.TPT_PT_BCTRP, "Update", --*1
 function(i,x,y,s,nt) --1
  if nt == 8 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if math.random(1,1000) > 1 then --4
     sim.partProperty(i, "vy", -0.05)
     end --4
    if math.random(1,1000) > 1 then --5
     sim.partProperty(i, "vx", math.random(-0.01,0.01))
     end --5
    if math.random(1,2000) < 4 then --6
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
     end --6
    if math.random(1,40000) < 2 then --7
     sim.partKill(i)
     end --7
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_CO2 then --8
     sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRP)
     sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTR)
     sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRC)
     end --8
    end --3
   end --2
  end --1
) --*1

 elements.property(elem.TPT_PT_BCTRC, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if math.random(1,1000) > 1 then --4
     sim.partProperty(i, "vy", 0)
     end --4
    if math.random(1,1000) > 1 then --5
     sim.partProperty(i, "vx", 0)
     end --5
    if math.random(1,200000) < 4 then --6
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
     sim.partProperty(i, "temp", 338)
     end --6
    if math.random(1,200000) == 1 then --7
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
     end --7
    if math.random(1,200000) == 1 then --8
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
     sim.partProperty(i, "temp", 338)
     end --8
    if math.random(1,4000) < 2 then --9
     sim.partKill(i)
     end --9
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_CO2 then --10
     if math.random(1,40) then --11
      sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRC)
      sim.partProperty(i, "temp", 338)
      sim.partKill(4)
      end --11
     end --10
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WATR then --12
     if math.random(1,20) == 1 then --13
      if math.random(1,50) == 1 then --14
       sim.partProperty(i, "type", elements.TPT_PT_BCTRP)
       end --14
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRP)
      sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRP)
      sim.partCreate(-1, math.random(x-3,x+3),math.random(y-3,y+3),elements.TPT_PT_BCTRP)
     sim.partProperty(i, "temp", 338)
      sim.partKill(i)
      end --13
     end --12
    if sim.partProperty(r, "type") == elements.TPT_PT_BCTRP then --15
     if math.random(1,200) == 1 then --16
      sim.partKill(i)
      end --16
     end --15
    end --3
   end --2
  end --1
) --*1

 elements.property(elem.TPT_PT_BCTR, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if math.random(1,10) > 1 then --4
     sim.partProperty(i, "vy", 0)
     end --4
    if math.random(1,10) > 1 then --5
     sim.partProperty(i, "vx", 0)
     end --5
    if math.random(1,200) < 4 then --6
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
     sim.partProperty(i, "temp", 338)
     end --6
    if math.random(1,4000) < 2 then --7
     sim.partKill(i)
     end --7
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_WOOD then --8
     if math.random(1,20) < 2 then --9
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_LTAC)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_LTAC)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ASH)
     sim.partProperty(i, "temp", 338)
      sim.partKill(r)
      end --9
     end --8
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_PLNT then --10
     if math.random(1,20) < 2 then --11
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ASH)
      sim.partKill(r)
      end --11
     end --10
    if sim.partProperty(r, "type") == elements.TPT_PT_ALGAE then --12
     if math.random(1,20) < 2 then --13
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTR)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRP)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_ASH)
      sim.partKill(r)
      end --13
     end --12
    if math.random(1,1000) == 1 then --14
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-3,y+3),elements.TPT_PT_BCTRC)
     sim.partCreate(-1, math.random(x-3,x+3),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
     sim.partProperty(i, "temp", 338)
     end --14
    if math.random(1,10000) == 1 then --15
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
     end --15
    if math.random(1,1000) == 1 then --16
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRP)
     end --16
    end --3
   end --2
  end --1
  ) --*1

 elements.property(elem.TPT_PT_BCTRA, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if math.random(1,20) > 1 then --4
     sim.partProperty(i, "vy", -0.01)
     end --4
    if math.random(1,20) > 1 then --5
     sim.partProperty(i, "vx", 0)
     end --5
    if math.random(1,400) < 4 then --6
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
     end --6
    if math.random(1,1600) < 2 then --7
     sim.partKill(i)
     end --7
    if sim.partProperty(r, "type") == elements.TPT_PT_ASH then --8
     if math.random(1,20) < 2 then --9
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.DEFAULT_PT_CO2)
      sim.partKill(r)
      end --9
     end --8
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_OXYG then --10
     if math.random(1,20) < 2 then --11
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
      sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.DEFAULT_PT_CO2)
      sim.partKill(r)
      end --11
     end --10
    if math.random(1,125) == 1 then --12
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-3,y+1),elements.TPT_PT_BCTRC)
     end --12
    if math.random(1,10000) == 1 then --12
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRA)
     end --12
    end --3
   end --2
  end --1
  ) --*1

 elements.property(elem.TPT_PT_BACT, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if math.random(1,20) > 1 then --4
     sim.partProperty(i, "vy", -0.01)
     end --4
    if math.random(1,20) > 1 then --5
     sim.partProperty(i, "vx", 0)
     end --5
    if math.random(1,20) < 2 then --6
     sim.partCreate(-1, math.random(x-1,x+1),math.random(y-1,y+1),elements.TPT_PT_BCTRC)
     sim.partKill(i)
     end --6
    end --3
   end --2
  end --1
  ) --*1

local sdpr = elements.allocate("TPT" , "SPPR")
 elements.element(sdpr, elements.element(elements.DEFAULT_PT_DMND))
 elements.property(sdpr, "Name" , "SPPR")
 elements.property(sdpr, "Description" , "Sandpaper, Gritty.")
 elements.property(sdpr, "Color", 0x6F6245)
 elements.property(sdpr, "HeatConduct", 4)
 elements.property(elem.TPT_PT_SPPR, "Update", 
 function(i,x,y,s,nt) --1
  for r in sim.neighbors(x,y,1,1) do --2
   if sim.partProperty(r, "type") > 0 then --3
    sim.partProperty(i, "temp", sim.partProperty(i, "temp")+math.sqrt(math.pow(sim.partProperty(r, "vx"),2)+math.pow(sim.partProperty(r, "vy"),2))*4)
    sim.partProperty(r, "vy", 0)
    sim.partProperty(r, "vx", 0)
    end --3
   end --2
  end --1
) --*1
 
local jean = elements.allocate("TPT", "DISA")
 elements.element(jean, elements.element(elements.DEFAULT_PT_THDR))
 elements.property(jean, "Name" , "DISA")
 elements.property(jean, "Description" , "\"Cause Havok.\"")
 elements.property(jean, "Weight", -1)
 elements.property(jean, "Loss", -1.01)
 elements.property(jean, "MenuSection", 16)
 elements.property(jean, "Diffusion", 0)
 elements.property(elem.TPT_PT_DISA, "Update", --*1
 function(i,x,y,s) --1
  if s > 6 then --2
   if math.random(1,20) == 20 then --3
    sim.partCreate(-1, x+math.random(-9,9), y+math.random(-9,9), elements.DEFAULT_PT_THDR)
    sim.partCreate(-1, x+math.random(-9,9), y+math.random(-9,9), elements.TPT_PT_TORN)
    sim.partCreate(-1, x+math.random(-9,9), y+math.random(-9,9), elements.TPT_PT_STRM)
    sim.partCreate(-1, x+math.random(-9,9), y+math.random(-9,9), elements.TPT_PT_CAVE)
    sim.pressure(x/4,y/4,16)
    if math.random(1,5) == 5 then --4
     sim.partKill(i)
     end --4
    end --3
   end --2
  end --1
  ) --*1

local co2s = elements.allocate("TPT", "CSNW")
 elements.element(co2s, elements.element(elements.DEFAULT_PT_SNOW))
 elements.property(co2s, "Name" , "CSNW")
 elements.property(co2s, "Description" , "CO2 Snow.")
 elements.property(co2s, "Color", 0xC2C2C2)
 elements.property(co2s, "Diffusion", 0.1)
 elements.property(co2s, "HighTemperature", 10001)
 elements.property(co2s, "Temperature", 186.65)
 elements.property(co2s, "Weight", 31)
 elements.property(co2s, "MenuSection", 16)
 elements.property(elements.TPT_PT_CSNW, "Update", --*1
 function(i,x,y) --1
  if sim.partProperty(i, "temp") > 194.65 then --2
   if math.random(1,450) == 1 then --3
    sim.partChangeType(i, elements.DEFAULT_PT_CO2)
    end --3
   end --2
  end --1
 ) --*1

 elements.property(elements.DEFAULT_PT_DRIC, "HighPressure", 1.2)
 elements.property(elements.DEFAULT_PT_DRIC, "HighPressureTransition", elements.TPT_PT_CSNW)

 elements.property(elements.DEFAULT_PT_COAL, "Update", --*1
 function(i,x,y,s,nt) --1
  if sim.pressure(x/4,y/4) < -9.5 then --2
   if math.random(1,950) == 1 then --3
    sim.partProperty(i, "type", elements.TPT_PT_GRPH)
    sim.partCreate(-1, x+math.random(-9,9), y+math.random(-9,9), elements.DEFAULT_PT_SMKE)
    sim.partCreate(-1, x+math.random(-2,2), y+math.random(-2,2), elements.TPT_PT_ASH)
    end --3
   end --2
  end --1
  ) --*1

local ground = elements.allocate("TPT" , "GRND")
 elements.element(ground, elements.element(elements.DEFAULT_PT_STNE))
 elements.property(ground, "Name" , "GRND")
 elements.property(ground, "Description" , "Ground.")
 elements.property(ground, "Color", 0xA2A29A)
 elements.property(ground, "HighTemperature", 10001)
 elements.property(ground, "MenuSection", 16)
 elements.property(ground, "Flammable", 0)
 elements.property(elem.TPT_PT_GRND, "Update", 
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 1 then --2
  sim.partCreate(-1, x+math.random(-2,2), y+math.random(-2,2), elements.DEFAULT_PT_SAND)
  sim.partCreate(-1, x+math.random(-2,2), y+math.random(-2,2), elements.DEFAULT_PT_STNE)
  sim.partCreate(-1, x+math.random(-2,2), y+math.random(-2,2), elements.DEFAULT_PT_DUST)
  end --2
 end --1
) --*1

local brwf = elements.allocate("TPT" , "BRWF")
 elements.element(brwf, elements.element(elements.DEFAULT_PT_EQVE))
 elements.property(brwf, "Name" , "BRWF")
 elements.property(brwf, "Description" , "Broken Tungsten.")
 elements.property(brwf, "Color", 0x5E575B)
 elements.property(brwf, "HighTemperature", 3595.0)
 elements.property(brwf, "HighTemperatureTransition", elements.DEFAULT_PT_TUNG)
 elements.property(brwf, "MenuSection", 16)
 elements.property(brwf, "Flammable", 0)
 elements.property(elem.DEFAULT_PT_BRMT, "Update", 
 function(i,x,y,s,nt) --1
  if sim.partProperty(i, "ctype") == elements.DEFAULT_PT_TUNG then --2
  sim.partProperty(i, "type", elements.TPT_PT_BRWF)
  end --2
 end --1
) --*1

 elements.property(elements.DEFAULT_PT_CFLM, "Falldown", 2)
 elements.property(elements.DEFAULT_PT_CFLM, "Gravity", 0.1)

local lo3 = elements.allocate("TPT", "LO3")
 elements.element(lo3, elements.element(elements.DEFAULT_PT_LOXY))
 elements.property(lo3, "Name" , "LO3")
 elements.property(lo3, "Description" , "Liquid Ozone, very cold. Horrifying")
 elements.property(lo3, "Flammable", 5.65)
 elements.property(lo3, "Explosive", 0)
 elements.property(lo3, "Color", 0x4F68AC)
 elements.property(lo3, "Temperature", 145.15)
 elements.property(lo3, "MenuSection", 7)

local o3 = elements.allocate("TPT", "O3")
 elements.element(o3, elements.element(elements.DEFAULT_PT_HYGN))
 elements.property(o3, "Name" , "O3")
 elements.property(o3, "Description" , "Ozone, strong oxidizer.")
 elements.property(o3, "Color", 0x6079BD)
 elements.property(o3, "LowTemperature", 159.1)
 elements.property(o3, "LowTemperatureTransition", elements.TPT_PT_LO3)
 elements.property(elem.TPT_PT_O3, "Update", 
 function(i,x,y,s,nt) --1
  for r in sim.neighbors(x,y,1,1) do --2
   if sim.partProperty(r, "type") == elements.DEFAULT_PT_FIRE then --3
    sim.partProperty(r, "life", 1000)
    sim.partProperty(r, "vy", sim.partProperty(r, "vy")*1.05)
    sim.partProperty(r, "vx", sim.partProperty(r, "vx")*1.05)
    sim.partProperty(r, "temp", sim.partProperty(r, "temp")+100)
    sim.pressure(x/4,y/4,0.1)
    if math.random(1,500) == 1 then --4
     sim.partKill(i)
     end --4
    end --3
   if sim.partProperty(r, "type") == elements.DEFAULT_PT_PLSM then --5
    sim.partProperty(r, "life", math.random(125,500))
    sim.partProperty(r, "vy", sim.partProperty(r, "vy")*1.1)
    sim.partProperty(r, "vx", sim.partProperty(r, "vx")*1.1)
    sim.partProperty(r, "temp", sim.partProperty(r, "temp")+200)
    sim.pressure(x/4,y/4,0.1)
    if math.random(1,500) == 1 then --6
     sim.partKill(i)
     end --6
    end --5
   end --2
  end --1
) --*1

 elements.property(lo3, "HighTemperature", 161.1)
 elements.property(lo3, "HighTemperatureTransition", elements.TPT_PT_O3)

 elements.property(elements.DEFAULT_PT_PLSM, "Falldown", 2)
 elements.property(elements.DEFAULT_PT_PLSM, "Gravity", 0)

 elements.property(elem.TPT_PT_HE, "Update", --*1
function(i,x,y,s) --1
  if sim.partProperty(i, "temp") < 4.15 then --2
   if math.random(1,800) == 1 then --3
    sim.partProperty(i, "type", elements.TPT_PT_LHE)
    end --3
   end --2
  if sim.partProperty(i, "temp") > 4000 then --4
   if sim.pressure(x/4,y/4) > 100 then --5
    sim.partCreate(-1, x, y+1, elements.DEFAULT_PT_PHOT)
    sim.partCreate(-1, x+1, y+1, elements.DEFAULT_PT_PHOT)
    sim.partCreate(-1, x, y-1, elements.DEFAULT_PT_CO2)
    sim.partCreate(-1, x+1, y-1, elements.DEFAULT_PT_OXYG)
    sim.partCreate(-1, x-1, y-1, elements.DEFAULT_PT_NBLE)
    sim.partCreate(-1, x+1, y, elements.TPT_PT_HE3)
    sim.partCreate(-1, x-1, y, elements.TPT_PT_NEUT)
    if math.random(1,25) == 1 then --6
     sim.partCreate(-1, x-1, y, elements.TPT_PT_O3)
     sim.partProperty(i, "tmp2", 4)
     sim.partProperty(i, "tmp", math.random(0,359))
     sim.partProperty(i, "life", math.random(1,4))
     sim.pressure(x/4,y/4,150)
     sim.partProperty(i, "type", elements.DEFAULT_PT_LIGH)
     return
     end --6
    end --5
   end --4
  end --1
  ) --*1

 elements.property(elem.DEFAULT_PT_OXYG, "Update", 
 function(i,x,y,s,nt) --1
  for r in sim.neighbors(x,y,1,1) do --2
   if sim.partProperty(r, "type") == elements.DEFAULT_PT_LIGH then --3
    sim.partProperty(i, "type", elements.TPT_PT_O3)
    end --3
   end --2
  end --1
) --*1

local magm = elements.allocate("TPT" , "MAGM")
 elements.element(magm, elements.element(elements.DEFAULT_PT_LAVA))
 elements.property(magm, "Name" , "MAGM")
 elements.property(magm, "Description" , "Magma.")
 elements.property(magm, "Color", 0xFA7E3B)
 elements.property(magm, "Weight", 99)
 elements.property(magm, "Temperature", 1950.32)
 elements.property(magm, "HeatConduct", 10)
 elements.property(magm, "HotAir", 0.01)
 elements.property(magm, "Advection", 0.05)
 elements.property(elem.TPT_PT_MAGM, "Update", 
 function(i,x,y,s,nt) --1
  if math.random(1,20) == 1 then --2
   sim.partProperty(i, "type", elements.DEFAULT_PT_LAVA)
   end --2
  end --1
) --*1

 elements.property(elem.DEFAULT_PT_LAVA, "Update", --*1
 function(i,x,y,s,nt) --1
  if math.random(1,2) == 2 then --2
   for r in sim.neighbors(x,y,1,1) do --3
    if sim.partProperty(r, "type") == elements.DEFAULT_PT_LAVA then --4
     if sim.partProperty(r, "ctype") == elements.DEFAULT_PT_METL then --5
      if sim.partProperty(i, "ctype") == elements.DEFAULT_PT_VIBR then --6
       sim.partProperty(r, "type", elements.TPT_PT_XMEN)
       sim.partProperty(i, "type", elements.TPT_PT_XMEN)
       end --6
      end --5
     end --4
    end --3
   end --2
  if math.random(1,2) == 2 then --7
   if sim.partProperty(i, "ctype") == elements.TPT_PT_DMDD then --9
    sim.partProperty(i, "ctype", elements.DEFAULT_PT_DMND)
    end --8
   end --7
  if math.random(1,100) == 1 then --9
   if sim.partProperty(i, "temp") > 1920.30 then --10
    sim.partProperty(i, "type", elements.TPT_PT_MAGM)
    end --10
   end --9
  end --1
  ) --*1

local h2o2 = elements.allocate("TPT", "H2O2")
 elements.element(h2o2, elements.element(elements.DEFAULT_PT_SOAP))
 elements.property(h2o2, "Name" , "H2O2")
 elements.property(h2o2, "Description" , "Hydrogen Peroxide, corrosive, decomposes into oxygen and water, rarely ozone.")
 elements.property(h2o2, "Color", 0x1E41CF)
 elements.property(h2o2, "Hardness", 0)
 elements.property(h2o2, "Weight", 30)
 elements.property(elem.TPT_PT_H2O2, "Update", --*1
 function(i,x,y,s,nt) --1
  if s ~=8 and nt ~=0 and nt - s > 0 then --2
   if math.random(1,100) == 10 then --3
    for r in sim.neighbors(x,y,1,1) do --4
     if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_DMND then --5
      if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_VACU then --6
       if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_VOID then --7
        if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_CLNE then --8
         if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_PCLN then --9
          if sim.partProperty(r, "type") ~= elements.DEFAULT_PT_OXYG then --10
           if sim.partProperty(r, "type") ~= elements.TPT_PT_O3 then --11
            if math.random(1,20) == 1 then --12
             sim.partProperty(r, "type", elements.DEFAULT_PT_O2)
             sim.partProperty(i, "temp", sim.partProperty(i, "temp")+300)
             if math.random(1,10) == 1 then --13
              sim.pressure(x/4,y/4,2)
              sim.partProperty(r, "type", elements.DEFAULT_PT_WATR)
              if math.random(1,10) == 1 then --14
               sim.partProperty(i, "type", elements.TPT_PT_O3)
               return
               end --14
              end --13
             end --12
            end --11
           end --10
          end --9
         end --8
        end --7
       end --6
      end --5
     end --4
    end --3
   end --2
  end --1
  ) --*1

local cmnt = elements.allocate("TPT" , "CMNT")
 elements.element(cmnt, elements.element(elements.DEFAULT_PT_WATR))
 elements.property(cmnt, "Name" , "CMNT")
 elements.property(cmnt, "Description" , "Cement, hardens over time.")
 elements.property(cmnt, "HighTemperature", 10001)
 elements.property(cmnt, "Color", 0x5E5E5E)
 elements.property(elem.TPT_PT_CMNT, "Update", 
 function(i,x,y,s,nt) --1
  if math.random(1,12) == 1 then --2
   if math.sqrt(math.pow(sim.partProperty(i, "vx"),2)+math.pow(sim.partProperty(i, "vy"),2)) < 0.1 then --3
    if math.random(1,10) == 1 then --4
     sim.partProperty(i, "type", elements.DEFAULT_PT_BRCK)
     else if math.random(1,100) == 1 then --5
      sim.partProperty(i, "type", elements.DEFAULT_PT_CNCT)
      else if math.random(1,500) == 1 then --6
      sim.partProperty(i, "type", elements.DEFAULT_PT_STNE)
      end --6
     end --5
    end --4
   end --3
  end --2
 end --1
) --*1