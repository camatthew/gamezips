
gunmod = {["version"] = 1.1}
opengun,mousex,mousey,shoot,topressl,run,rise,gy,gx,frameCount = 0,0,0,0,0,0,0,0,0,1
--global value for colour effects from other mods
colourRGB = {255,255,255}
--bullet types
local btype = {1,0,0,0,0}
if frameCount > 10 then else frameCount = frameCount + 1 end
if frameCount == 2 then 
	LEAD = elements.allocate("JWARD", "LEAD")
	elements.element(elements.JWARD_PT_LEAD, elements.element(elements.DEFAULT_PT_GRAV))
	elements.property(elements.JWARD_PT_LEAD, "Name", "LEAD")
	elements.property(elements.JWARD_PT_LEAD, "Description", "LEAD, good for radiation shielding")
	elements.property(elements.JWARD_PT_LEAD, "Colour", 0x5D5D5C)
	elements.property(elements.JWARD_PT_LEAD, "MenuVisible", 0)
	elements.property(elements.JWARD_PT_LEAD, "Gravity", 0)
	elements.property(elements.JWARD_PT_LEAD, "Flammable", 0)
	elements.property(elements.JWARD_PT_LEAD, "Explosive", 0)
	elements.property(elements.JWARD_PT_LEAD, "Advection", 0)
	elements.property(elements.JWARD_PT_LEAD, "Falldown", 0)
	elements.property(elements.JWARD_PT_LEAD, "HeatConduct", 87)
	elements.property(elements.JWARD_PT_LEAD, "Properties", elem.PROP_DEADLY+elem.PROP_LIFE_DEC+elem.PROP_NEUTABSORB+elem.PROP_CONDUCTS)
	elements.property(elements.JWARD_PT_LEAD, "Hardness", 19)
	elements.property(elements.JWARD_PT_LEAD, "Weight", 100)
	--stick man side of things
	function stkmyx(i, x, y, s, nt)
		gx,gy = x,y
		if shoot == 1 then
			if mousex < gx then
				tpt.create(x - (math.cos(math.atan(rise/run)) * 5),y - (math.sin(math.atan(rise/run)) * 5),tpt.element("LEAD"))
				tpt.set_property('tmp', 2, x - (math.cos(math.atan(rise/run)) * 5), y - (math.sin(math.atan(rise/run)) * 5))
			else 
				tpt.create(x + (math.cos(math.atan(rise/run)) * 5),y + (math.sin(math.atan(rise/run)) * 5),tpt.element("LEAD"))
				tpt.set_property('tmp', 2, x+(math.cos(math.atan(rise/run)) * 5), y + (math.sin(math.atan(rise/run)) * 5))
			end
		end
	end
	tpt.element_func(stkmyx,tpt.element("STKM"))
	function spwn(s)
		gs = s
	end
	function bulletfunc(i,x,y,s,n)
		tmp = tpt.get_property("tmp",i)
		reaction = tpt.get_property("type",x+math.random(-1,1),y+math.random(-1,1))
		--impact
		if tpt.get_property("vx",i) == 0 and tpt.get_property("vx",i) == 0 and shoot == 0 then
			if btype[1] == 1 then
				sim.partChangeType(i, tpt.element('fire'))
				tpt.set_property('type', 0, x+1, y)
				tpt.set_property('type', 0, x-1, y)
				tpt.set_property('type', 0, x, y+1)
				tpt.set_property('type', 0, x, y-1)
			end
			if btype[2] == 1 then
				sim.partChangeType(i, tpt.element('BOMB'))
			end
			if btype[3] == 1 then
				sim.partChangeType(i, tpt.element('fire'))
				tpt.set_property('type', 0, x+1, y)
				tpt.set_property('type', 0, x-1, y)
				tpt.set_property('type', 0, x, y+1)
				tpt.set_property('type', 0, x, y-1)
			end
			if btype[4] == 1 then
				sim.partChangeType(i, tpt.element('DEST'))
			end
		--trails
		end
		if btype[3] == 1 then
			tpt.create(x,y + 1,tpt.element("FIRE"))
			tpt.create(x,y - 1,tpt.element("FIRE"))
			tpt.create(x + 1,y,tpt.element("FIRE"))
			tpt.create(x + 1,y,tpt.element("FIRE"))
		end
		if btype[5] == 1 then
			tpt.create(x,y + 1,tpt.element("SMKE"))
			tpt.create(x,y - 1,tpt.element("SMKE"))
			tpt.create(x + 1,y,tpt.element("SMKE"))
			tpt.create(x + 1,y,tpt.element("SMKE"))
		end
		--void
		if reaction ~= 0 and reaction ~= tpt.element('STKM') and reaction ~= tpt.element('LEAD') then
			if btype[1] == 1 then
				sim.partChangeType(i, tpt.element('fire'))
				tpt.set_property('type', 0, x+1, y)
				tpt.set_property('type', 0, x-1, y)
				tpt.set_property('type', 0, x, y+1)
				tpt.set_property('type', 0, x, y-1)
			end
			if btype[3] == 1 and reaction ~= tpt.element('FIRE') then
				sim.partChangeType(i, tpt.element('fire'))
				tpt.set_property('type', 0, x+1, y)
				tpt.set_property('type', 0, x-1, y)
				tpt.set_property('type', 0, x, y+1)
				tpt.set_property('type', 0, x, y-1)
			end
			if btype[5] == 1 and reaction ~= tpt.element('SMKE') then
				sim.partChangeType(i, tpt.element('DEST'))
				tpt.set_property('type', tpt.element('BOMB'), x+1, y)
				tpt.set_property('type', tpt.element('BOMB'), x-1, y)
				tpt.set_property('type', tpt.element('BOMB'), x, y+1)
				tpt.set_property('type', tpt.element('BOMB'), x, y-1)
			end
		end
		--setting bullet velocity
		if tmp == 2 then
			if mousex < x then
				tpt.set_property('vx', math.cos(math.atan(rise/run)) * -5,i)
				tpt.set_property('vy', math.sin(math.atan(rise/run)) * -5,i)
			else
				tpt.set_property('vx', math.cos(math.atan(rise/run)) * 5,i)
				tpt.set_property('vy', math.sin(math.atan(rise/run)) * 5,i)
			end
			tpt.set_property('tmp',0,i)
		end
	end
	tpt.element_func(bulletfunc,tpt.element('LEAD'))
	--keys for gun
	function keys(key_char,keyNum,event)
		if key_char == "j" then
			able = 1
			tpt.selectedl="DEFAULT_PT_STKM"
		end
		if key_char == "m" then
			able = 0
		end
	end
	tpt.register_keypress(keys)
	function tick()
		--COOL FREAKEN HAT
		if hat == 1 and tpt.get_property("type",gs) == tpt.element("stkm")  then 
			tpt.fillrect(gx-4, gy-7, 8, 8, 0, 0, 0)
			tpt.fillrect(gx-3, gy-3, 6, 4, 128, 64, 0)
			tpt.drawline(gx-5, gy, gx+5, gy, 128, 64, 0)
		end
		--math junk
		mousex = tpt.mousex
		mousey = tpt.mousey
		rise = mousey - gy + 2
		run = mousex - gx + 2
		--drawing the gun
		if able == 1 and tpt.get_property("type",gs) == tpt.element("stkm") then
			if mousex < gx then
				tpt.drawline(gx-2,gy+2,gx-(math.cos(math.atan(rise/run)) * 5)-2,gy-(math.sin(math.atan(rise/run)) * 5)+2,180,180,180)
			else
				tpt.drawline(gx+2,gy+2,gx+(math.cos(math.atan(rise/run)) * 5)+2,gy+(math.sin(math.atan(rise/run)) * 5)+2,180,180,180)
			end
		end
		--bullets button
		if  tpt.hud() == 1 then
			tpt.drawrect(65, 0, 54, 14, 204, 204, 204)
			tpt.fillrect(65, 0, 54, 14, 0, 0, 0, 255)
			tpt.drawtext(77, 4, "Bullets", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			topressl = 1
			if tpt.mousex >= 65 and tpt.mousey >= 0 and tpt.mousex <= 119 and tpt.mousey <= 14 then
				tpt.drawrect(65, 0, 54, 14, 255, 255, 255)
			end
		end
		if toopress == 1 then
			tpt.fillrect(205, 0, 60, 16, 0, 0, 0)
			tpt.drawrect(205, 0, 60, 16, 204, 204, 204)
			tpt.drawtext(217, 4, "Gun mod", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			if tpt.mousex >= 205 and tpt.mousey >= 0 and tpt.mousex <= 265 and tpt.mousey <= 16 then
				tpt.drawrect(205, 0, 60, 16, 255, 255, 255)
			end
		end
		if toopressl == 1 then
			if topressl == 1 then
				tpt.fillrect(65, 0, 54, 14, 255, 255, 255, 255)
				tpt.drawtext(77, 4, "Bullets", 0, 0, 0, 255)
			end
			tpt.drawrect(150,80,300,300, 255, 255, 255)
			tpt.fillrect(150,80,300,300, 0, 0, 0, 255)
			tpt.drawtext(159,85, "STKM Bullets selection", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			--bullet select
			tpt.drawrect(265, 132, 9, 9, 204, 204, 204)
			tpt.drawrect(265, 164, 9, 9, 204, 204, 204)
			tpt.drawrect(265, 148, 9, 9, 204, 204, 204)
			tpt.drawrect(265, 180, 9, 9, 204, 204, 204)
			tpt.drawrect(265, 196, 9, 9, 204, 204, 204)
			if  tpt.mousex >= 265 and tpt.mousey >= 132 and tpt.mousex <= 272 and tpt.mousey <= 141 then
				tpt.drawrect(265, 132, 9, 9, 255, 255, 255)
			end
			if  tpt.mousex >= 265 and tpt.mousey >= 164 and tpt.mousex <= 272 and tpt.mousey <= 173 then
				tpt.drawrect(265, 164, 9, 9, 255, 255, 255)
			end
			if  tpt.mousex >= 265 and tpt.mousey >= 148 and tpt.mousex <= 272 and tpt.mousey <= 157 then
				tpt.drawrect(265, 148, 9, 9, 255, 255, 255)
			end
			if  tpt.mousex >= 265 and tpt.mousey >= 180 and tpt.mousex <= 272 and tpt.mousey <= 189 then
				tpt.drawrect(265, 180, 9, 9, 255, 255, 255)
			end
			if  tpt.mousex >= 265 and tpt.mousey >= 196 and tpt.mousex <= 272 and tpt.mousey <= 205 then
				tpt.drawrect(265, 196, 9, 9, 255, 255, 255)
			end
			--close
			tpt.drawrect(160, 354, 60, 16, 204, 204, 204)
			tpt.drawtext(178, 358, "Close", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			if  tpt.mousex >= 160 and tpt.mousey >= 354 and tpt.mousex <= 220 and tpt.mousey <= 370 then
				tpt.drawrect(160, 354, 60, 16, 255, 255, 255)
			end
			--hat
			tpt.drawrect(320, 354, 120, 16, 204, 204, 204)
			tpt.drawtext(333, 359, "CoOL FrEaKIn HAt", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			if  tpt.mousex >= 320 and tpt.mousey >= 354 and tpt.mousex <= 440 and tpt.mousey <= 370 then
				tpt.drawrect(320, 354, 120, 16, 255, 255, 255)
			end
			--text
			tpt.drawtext(180, 260, "To use, spawn a stkm and press j to enable.", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			tpt.drawtext(180, 270, "when done press m to disable. aim using your mouse and ", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			tpt.drawtext(180, 280, "shooting use left or right click to shoot one round.", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			tpt.drawtext(180, 290, "The 'bullets' button hides with hud(h-key)", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			tpt.drawtext(180, 300, "get the colour nametag scipt for a cooler hud!!!", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			tpt.drawtext(205, 134, "Default", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			tpt.drawtext(205, 150, "Tracer", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			tpt.drawtext(205, 166, "Bomb-tipped", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			tpt.drawtext(205, 182, "Dest-tipped", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			tpt.drawtext(205, 197, "missle", colourRGB[1], colourRGB[2], colourRGB[3], 255)
			--other stuff
			tpt.drawpixel(180,138,62,62,94)
			tpt.drawpixel(181,137,62,62,94)
			tpt.drawpixel(181,136,62,62,94)
			tpt.drawpixel(181,135,62,62,94)
			tpt.drawpixel(182,134,62,62,94)
			tpt.drawpixel(183,137,62,62,94)
			tpt.drawpixel(183,136,62,62,94)
			tpt.drawpixel(183,135,62,62,94)
			tpt.drawpixel(184,138,62,62,94)
			tpt.drawpixel(185,137,62,62,94)
			tpt.drawpixel(185,136,62,62,94)
			tpt.drawpixel(185,135,62,62,94)
			tpt.drawpixel(186,134,62,62,94)
			tpt.drawpixel(187,137,62,62,94)
			tpt.drawpixel(187,136,62,62,94)
			tpt.drawpixel(187,135,62,62,94)
			tpt.drawpixel(188,138,62,62,94)
			tpt.drawpixel(189,137,62,62,94)
			tpt.drawpixel(189,136,62,62,94)
			tpt.drawpixel(189,135,62,62,94)
			tpt.drawpixel(190,134,62,62,94)
			tpt.drawline(191, 134, 196, 134, 122, 76, 17)
			tpt.drawline(191, 135, 197, 135, 111, 65, 6)
			tpt.drawline(191, 136, 197, 136, 100, 58, 6)
			tpt.drawline(191, 137, 197, 137, 88, 52, 5)
			tpt.drawline(191, 138, 196, 138, 87, 50, 4)
			tpt.drawpixel(192,134,82,32,0)
			tpt.drawpixel(191,135,82,32,0)
			tpt.drawpixel(191,137,39,0,0)
			tpt.drawpixel(192,136,39,0,0)
			tpt.drawpixel(193,135,39,0,0)
			tpt.drawpixel(192,138,82,32,0)
			tpt.drawpixel(193,137,82,32,0)
			tpt.drawline(191, 150, 196, 150, 122, 76, 17)
			tpt.drawline(191, 151, 197, 151, 111, 65, 6)
			tpt.drawline(191, 152, 197, 152, 100, 58, 6)
			tpt.drawline(191, 153, 197, 153, 88, 52, 5)
			tpt.drawline(191, 154, 196, 154, 87, 50, 4)
			tpt.drawpixel(192,150,82,32,0)
			tpt.drawpixel(191,151,82,32,0)
			tpt.drawpixel(191,153,39,0,0)
			tpt.drawpixel(192,152,39,0,0)
			tpt.drawpixel(193,151,39,0,0)
			tpt.drawpixel(192,154,82,32,0)
			tpt.drawpixel(193,153,82,32,0)
			tpt.drawline(180, 150, 190, 150, 67, 44, 19)
			tpt.drawline(180, 151, 190, 151, 126, 94, 48)
			tpt.drawline(180, 152, 190, 152, 158, 120, 65)
			tpt.drawline(180, 153, 190, 153, 126, 94, 48)
			tpt.drawline(180, 154, 190, 154, 67, 44, 19)
			tpt.drawpixel(180,170,62,62,94)
			tpt.drawpixel(181,169,62,62,94)
			tpt.drawpixel(181,168,62,62,94)
			tpt.drawpixel(181,167,62,62,94)
			tpt.drawpixel(182,166,62,62,94)
			tpt.drawpixel(183,169,62,62,94)
			tpt.drawpixel(183,168,62,62,94)
			tpt.drawpixel(183,167,62,62,94)
			tpt.drawpixel(184,170,62,62,94)
			tpt.drawpixel(185,169,62,62,94)
			tpt.drawpixel(185,168,62,62,94)
			tpt.drawpixel(185,167,62,62,94)
			tpt.drawpixel(186,166,62,62,94)
			tpt.drawpixel(187,169,62,62,94)
			tpt.drawpixel(187,168,62,62,94)
			tpt.drawpixel(187,167,62,62,94)
			tpt.drawpixel(188,170,62,62,94)
			tpt.drawpixel(189,169,62,62,94)
			tpt.drawpixel(189,168,62,62,94)
			tpt.drawpixel(189,167,62,62,94)
			tpt.drawpixel(190,166,62,62,94)
			tpt.drawline(191, 166, 196, 166, 122, 76, 17)
			tpt.drawline(191, 167, 197, 167, 111, 65, 6)
			tpt.drawline(191, 168, 197, 168, 100, 58, 6)
			tpt.drawline(191, 169, 197, 169, 88, 52, 5)
			tpt.drawline(191, 170, 196, 170, 87, 50, 4)
			tpt.drawline(197, 167, 197, 169, 240, 240, 240)
			tpt.drawline(196, 166, 196, 170, 240, 240, 240)
			tpt.drawline(195, 166, 195, 170, 240, 240, 240)
			tpt.drawpixel(192,166,82,32,0)
			tpt.drawpixel(191,167,82,32,0)
			tpt.drawpixel(191,169,39,0,0)
			tpt.drawpixel(192,168,39,0,0)
			tpt.drawpixel(193,167,39,0,0)
			tpt.drawpixel(192,170,82,32,0)
			tpt.drawpixel(193,169,82,32,0)
			tpt.drawpixel(180,186,62,62,94)
			tpt.drawpixel(181,185,62,62,94)
			tpt.drawpixel(181,184,62,62,94)
			tpt.drawpixel(181,183,62,62,94)
			tpt.drawpixel(182,182,62,62,94)
			tpt.drawpixel(183,185,62,62,94)
			tpt.drawpixel(183,184,62,62,94)
			tpt.drawpixel(183,183,62,62,94)
			tpt.drawpixel(184,186,62,62,94)
			tpt.drawpixel(185,185,62,62,94)
			tpt.drawpixel(185,184,62,62,94)
			tpt.drawpixel(185,183,62,62,94)
			tpt.drawpixel(186,182,62,62,94)
			tpt.drawpixel(187,185,62,62,94)
			tpt.drawpixel(187,184,62,62,94)
			tpt.drawpixel(187,183,62,62,94)
			tpt.drawpixel(188,186,62,62,94)
			tpt.drawpixel(189,185,62,62,94)
			tpt.drawpixel(189,184,62,62,94)
			tpt.drawpixel(189,183,62,62,94)
			tpt.drawpixel(190,182,62,62,94)
			tpt.drawline(191, 182, 196, 182, 122, 76, 17)
			tpt.drawline(191, 183, 197, 183, 111, 65, 6)
			tpt.drawline(191, 184, 197, 184, 100, 58, 6)
			tpt.drawline(191, 185, 197, 185, 88, 52, 5)
			tpt.drawline(191, 186, 196, 186, 87, 50, 4)
			tpt.drawline(197, 183, 197, 185, 59, 10, 10)
			tpt.drawline(196, 182, 196, 186, 59, 10, 10)
			tpt.drawline(195, 182, 195, 186, 59, 10, 10)
			tpt.drawpixel(192,182,82,32,0)
			tpt.drawpixel(191,183,82,32,0)
			tpt.drawpixel(191,184,39,0,0)
			tpt.drawpixel(192,185,39,0,0)
			tpt.drawpixel(193,184,39,0,0)
			tpt.drawpixel(192,183,82,32,0)
			tpt.drawpixel(193,185,82,32,0)
			tpt.drawpixel(180,196,254,0,0)
			tpt.drawpixel(181,197,254,0,0)
			tpt.drawpixel(182,197,254,0,0)
			tpt.drawline(180, 198, 196, 198, 64, 64, 96)
			tpt.drawline(183, 199, 199, 199, 64, 64, 96)
			tpt.drawline(180, 200, 196, 200, 64, 64, 96)
			tpt.drawpixel(180,202,254,0,0)
			tpt.drawpixel(181,201,254,0,0)
			tpt.drawpixel(182,201,254,0,0)
			tpt.drawpixel(180,199,254,0,0)
			tpt.drawpixel(181,199,254,0,0)
			tpt.drawpixel(182,199,254,0,0)
			--highlight selected bullet
			if btype[1] == 1 then
				tpt.fillrect(265, 132, 9, 9, 255, 255, 255)
			end
			if btype[2] == 1 then
				tpt.fillrect(265, 164, 9, 9, 255, 255, 255)
			end
			if btype[3] == 1 then
				tpt.fillrect(265, 148, 9, 9, 255, 255, 255)
			end
			if btype[4] == 1 then
				tpt.fillrect(265, 180, 9, 9, 255, 255, 255)
			end
			if btype[5] == 1 then
				tpt.fillrect(265, 196, 9, 9, 255, 255, 255)
			end
		end
	end
	local term,term2 = true,true
	function pressthingy(mousex,mousey,button,event,wheel)
		if event == 2 then
			term,term2 = true,true
		end 
		if able == 1 and event == 3 and term == true then
			shoot = 1
			term = false
		else
			shoot = 0
		end
		if toopress == 1 then
			if tpt.mousex >= 205 and tpt.mousey >= 0 and tpt.mousex <= 265 and tpt.mousey <= 16 then
				opengun,toopress,open,windowclick = 1,0,0,1
			end
		end
		if topressl == 1 then
			if tpt.mousex >= 65 and tpt.mousey >= 0 and tpt.mousex <= 119 and tpt.mousey <= 14 and tpt.hud() == 1 then
				opengun,windowclick = 1,1
			end
		end
		if opengun == 1 then
			--selecting bullets
			if  tpt.mousex >= 265 and tpt.mousey >= 132 and tpt.mousex <= 272 and tpt.mousey <= 141 then
				btype = {1,0,0,0,0}
			end
			if  tpt.mousex >= 265 and tpt.mousey >= 164 and tpt.mousex <= 272 and tpt.mousey <= 173 then
				btype = {0,1,0,0,0}
			end
			if  tpt.mousex >= 265 and tpt.mousey >= 148 and tpt.mousex <= 272 and tpt.mousey <= 157 then
				btype = {0,0,1,0,0}
			end
			if  tpt.mousex >= 265 and tpt.mousey >= 180 and tpt.mousex <= 272 and tpt.mousey <= 189 then
				btype = {0,0,0,1,0}
			end
			if  tpt.mousex >= 265 and tpt.mousey >= 196 and tpt.mousex <= 272 and tpt.mousey <= 205 then
				btype = {0,0,0,0,1}
			end
			if  tpt.mousex >= 160 and tpt.mousey >= 354 and tpt.mousex <= 220 and tpt.mousey <= 370 then
				opengun,toopressl,windowclick = 0,0,0
			end
			if  tpt.mousex >= 320 and tpt.mousey >= 354 and tpt.mousex <= 440 and tpt.mousey <= 370 and event == 3 and term2 == true then
				term2 = false
				--hat toggle
				if hat == 1 then hat = 0 else hat = 1 end
			end
			toopressl = 1
			return false
		else
			toopressl = 0
			return true
		end
	end
	tpt.register_mouseclick(pressthingy)
	tpt.register_mouseclick(tick)
	tpt.register_step(tick)
end