
print("RAD-MOD V 1.2.1b By Kev_AK ")
print("Radioactive elements, particles and isotopes")
print("----------------------------------------------")

-------------INERTS----------NOBLEGASES----------------------------
local he = elem.allocate("KEV", "HE4")
local rad = elem.allocate("KEV", "RN")
elem.element(elem.KEV_PT_HE4, elem.element(elem.DEFAULT_PT_NBLE))
elem.element(rad, elem.element(elem.DEFAULT_PT_NBLE))
elem.property(elem.KEV_PT_HE4, "Name", "HE-4")
elem.property(rad, "Name", "RN")
elem.property(elem.KEV_PT_HE4, "Description", "Helium 4. Low Weight Gas Decays into HYGN.")
elem.property(rad, "Description", "Radon. Inert Gas. Radioactive")
elem.property(elem.KEV_PT_HE4, "Color", 0xFFF5EE)
elem.property(rad, "Color", 0x3CB371)
elem.property(elem.KEV_PT_HE4, "Flammable", 0)
elem.property(rad, "Flammable", 0)
elem.property(elem.KEV_PT_HE4, "Explosive", 0)
elem.property(rad, "Explosive", 0)
elem.property(elem.KEV_PT_HE4, "Properties", elem.TYPE_GAS+elem.PROP_LIFE_DEC+elem.PROP_CONDUCTS)
elem.property(rad, "Properties", elem.TYPE_GAS+elem.PROP_LIFE_DEC+elem.PROP_CONDUCTS+elem.PROP_DEADLY)
elem.property(elem.KEV_PT_HE4, "Weight", 0.01)
elem.property(rad, "Weight", 5.88)
elem.property(elem.KEV_PT_HE4, "Gravity", -1)
elem.property(rad, "Gravity", 0.7)
elem.property(elem.KEV_PT_HE4, "Diffusion", 4.99)
elem.property(rad, "Diffusion", 1.0)
elem.property(elem.KEV_PT_HE4, "AirLoss", 0.01)
elem.property(rad, "AirLoss", 0.36)
elem.property(elem.KEV_PT_HE4, "AirDrag", 0.02)
elem.property(rad, "AirDrag", 0.35)

    local function hel4Update(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if math.random(1, 1000) == 1 then
	        local descompA = math.random(-20,20) 
	        local descompB = math.random(-20,0)
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.set_property("vx", math.random(-15,15), i)
	        tpt.set_property("vy", math.random(-15,15), i)
	        tpt.set_property("life", 25, i)
		if math.abs(descompA) + math.abs(descompB) > 10 then
		local r3 = math.random(1,2)
			if descompC == 1 then
			tpt.set_property("type", "neut", i)
			end
			if descompC == 2 then
			tpt.set_property("type", "hygn", i)
			end
		end
	    end

            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_SPRK then
               sim.partProperty(i, "type", elem.DEFAULT_PT_PLSM)
               sim.partProperty(r, "type", elem.DEFAULT_PT_PLSM)
               end
            if sim.partProperty(r, "ctype") == elem.DEFAULT_PT_NEUT then
               sim.partProperty(i, "type", elem.DEFAULT_PT_HYGN)
               sim.partProperty(r, "type", elem.DEFAULT_PT_NEUT)
               end
     end
    end    

    local function radonUpdate(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
            if math.random(1, 1000) == 1 then
	        local decayA = math.random(-20,20) 
	        local decayB = math.random(-20,0)
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "oxyg")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "hygn")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.set_property("vx", math.random(-35,35), i)
	        tpt.set_property("vy", math.random(-35,35), i)
	        tpt.set_property("life", 1000, i)
		if math.abs(decayA) + math.abs(decayB) > 10 then
		local decayC = math.random(1,4)
			if decayC == 1 then
			tpt.set_property("type", "hygn", i)
			end
			if decayC == 2 then
			tpt.set_property("type", "phot", i)
			end
			if decayC == 3 then
			tpt.set_property("type", "prot", i)
			end
			if decayC == 4 then
			tpt.set_property("type", "neut", i)
			end
		end
	   end

            if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
               sim.partProperty(i, "type", elem.DEFAULT_PT_PLSM)
               sim.partProperty(r, "type", elem.DEFAULT_PT_PLSM)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
               sim.partProperty(i, "type", hel)
               sim.partProperty(r, "type", elem.DEFAULT_PT_HYGN)
               end
    end
   end    

------------------------------HALOGENS----------------------------------------------------------------------------------------------------

local fluor = elem.allocate("KEV", "F18")
elem.element(elem.KEV_PT_F18, elem.element(elem.DEFAULT_PT_WTRV))
elem.property(elem.KEV_PT_F18, "Name", "F-18")
elem.property(elem.KEV_PT_F18, "Description", "Fluor 18. Explodes Easily, corrodes almost all. Burns in contact with HYGN.")
elem.property(elem.KEV_PT_F18, "Color", 0xBCEE68)
elem.property(elem.KEV_PT_F18, "Flammable", 1250)
elem.property(elem.KEV_PT_F18, "Explosive", 3600)
elem.property(elem.KEV_PT_F18, "Properties", elem.TYPE_GAS+elem.PROP_DEADLY)
elem.property(elem.KEV_PT_F18, "Weight", 20)
elem.property(elem.KEV_PT_F18, "HighTemperatureTransition", elem.DEFAULT_PT_PLSM)
elem.property(elem.KEV_PT_F18, "HighTemperature", 673)
elem.property(elem.KEV_PT_F18, "LowTemperatureTransition", elem.DEFAULT_PT_CFLM)
elem.property(elem.KEV_PT_F18, "LowTemperature", 73)

    local function fUpdate(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
          if math.random(1, 1000) == 1 then
	        local decA = math.random(-20,20) 
	        local decB = math.random(-20,0)
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "prot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.set_property("vx", math.random(-25,25), i)
	        tpt.set_property("vy", math.random(-25,25), i)
	        tpt.set_property("life", 1000, i)
                tpt.set_property("life", 1, r)
		if math.abs(decA) + math.abs(decB) > 10 then
		local decC = math.random(1,4)
			if decC == 1 then
			tpt.set_property("type", "neut", i)
			end
			if decC == 2 then
			tpt.set_property("type", "neut", i)
			end
			if decC == 3 then
			tpt.set_property("type", "prot", i)
			end
			if decC == 4 then
			tpt.set_property("type", "prot", i)
			end
		end
	   end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_HYGN then
               sim.partProperty(i, "type", elem.DEFAULT_PT_PLSM)
               sim.partProperty(r, "type", elem.DEFAULT_PT_WTRV)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_URAN then
               sim.partProperty(i, "type", elem.KEV_PT_U235)
               sim.partProperty(r, "type", elem.KEV_PT_U235)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_OXYG then
               sim.partProperty(i, "type", elem.DEFAULT_PT_PLSM)
               sim.partProperty(r, "type", elem.DEFAULT_PT_CO2)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_GLAS then
               sim.partProperty(r, "type", elem.DEFAULT_PT_BGLA)
               sim.partKill(i)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_LCRY then
               sim.partProperty(r, "type", elem.DEFAULT_PT_BGLA)
               sim.partKill(i)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_IRON then
               sim.partProperty(r, "type", elem.DEFAULT_PT_BRMT)
               sim.partKill(i)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_COAL then
               sim.partProperty(r, "type", elem.DEFAULT_PT_BCOL)
               sim.partKill(i)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_QRTZ then
               sim.partProperty(r, "type", elem.DEFAULT_PT_BQRT)
               sim.partKill(i)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_BRCK then
               sim.partProperty(r, "type", elem.DEFAULT_PT_STNE)
               sim.partKill(i)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_PSCN then
               sim.partProperty(r, "type", elem.DEFAULT_PT_BREL)
               sim.partKill(i)
               end
            if sim.partProperty(r, "type") == elem.DEFAULT_PT_NSCN then
               sim.partProperty(r, "type", elem.DEFAULT_PT_BREL)
               sim.partKill(i)
               end
     end
    end     


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------RADIOACTIVES-AND-EXPLOSIVES----------------------------------------------------------------------------------------------------------------------------------------
local beryl = elem.allocate("KEV", "BRYL")
local polon = elem.allocate("KEV", "PO84")
local star = elem.allocate("KEV", "SLIT")
local mox = elem.allocate("KEV", "MOX")
local amer = elem.allocate("KEV", "AM")
local thor = elem.allocate("KEV", "TH")
local c137 = elem.allocate("KEV", "CS37")
local radio = elem.allocate("KEV", "RA")
local zircaloy= elem.allocate("KEV", "ZLOY")
local uranoxid = elem.allocate("KEV", "UO2")
local u235 = elem.allocate("KEV", "U235")
elem.element(elem.KEV_PT_BRYL, elem.element(elem.DEFAULT_PT_PSCN))
elem.element(elem.KEV_PT_PO84, elem.element(elem.DEFAULT_PT_PSCN))
elem.element(elem.KEV_PT_SLIT, elem.element(elem.DEFAULT_PT_DMND))
elem.element(elem.KEV_PT_MOX, elem.element(elem.DEFAULT_PT_PLUT))
elem.element(amer, elem.element(elem.DEFAULT_PT_URAN))
elem.element(elem.KEV_PT_TH, elem.element(elem.DEFAULT_PT_PLUT))
elem.element(c137, elem.element(elem.DEFAULT_PT_VIBR))
elem.element(radio, elem.element(elem.DEFAULT_PT_PLUT))
elem.element(elem.KEV_PT_ZLOY, elem.element(elem.DEFAULT_PT_IRON))
elem.element(elem.KEV_PT_UO2, elem.element(elem.DEFAULT_PT_URAN))
elem.element(elem.KEV_PT_U235, elem.element(elem.DEFAULT_PT_PLUT))
elem.property(elem.KEV_PT_BRYL, "Name", "BRYL")
elem.property(elem.KEV_PT_PO84, "Name", "PO84")
elem.property(elem.KEV_PT_SLIT, "Name", "SLIT")
elem.property(elem.KEV_PT_MOX, "Name", "MOX")
elem.property(amer, "Name", "AM")
elem.property(elem.KEV_PT_TH, "Name", "TH")
elem.property(c137, "Name", "CS37")
elem.property(radio, "Name", "RA")
elem.property(elem.KEV_PT_UO2, "Name", "UO2")
elem.property(elem.KEV_PT_ZLOY, "Name", "ZLOY")
elem.property(elem.KEV_PT_U235, "Name", "U235")
elem.property(elem.KEV_PT_BRYL, "Description", "Beryllium. Transforms NEUT into PROT, releases air pressure when SPRK pass through.")
elem.property(elem.KEV_PT_PO84, "Description", "Polonium. Emits NEUT when is mixed with BRYL and sparked.")
elem.property(elem.KEV_PT_SLIT, "Description", "Starlite. Super Material. The best insulator ever made. Resists the maximum amount of heat possible.")
elem.property(elem.KEV_PT_MOX, "Description", "Mixed Oxide Nuclear Combustible. A mix of PLUT and UO2. Fisible.")
elem.property(amer, "Description", "Americium. Radioactive, Emits too much radiation. Fisible under pressure.")
elem.property(elem.KEV_PT_TH, "Description", "Thorium. Radioactive, When Descomposes transforms in URAN, burns when PROT touch it.")
elem.property(c137, "Description", "Caesium 137. Radioactive, when decays it produce Be and Xe.")
elem.property(radio, "Description", "Radium. Radioactive, When Descomposes transforms in Rn, when touches Be emits neutrons.")
elem.property(elem.KEV_PT_ZLOY, "Description", "Zircaloy 4. Absorbs neutrons, resists high temperatures and its used as a cladding of nuclear cells.")
elem.property(elem.KEV_PT_UO2, "Description", "Uranium Oxide. Radioactive and fissible.")
elem.property(elem.KEV_PT_U235, "Description", "Uranium 235. Fisible, used in Nuclear Reactors mixed with U238.")
elem.property(elem.KEV_PT_BRYL, "Color", 0x8B7D7B)
elem.property(elem.KEV_PT_PO84, "Color", 0xEEE0E5)
elem.property(elem.KEV_PT_SLIT, "Color", 0xF5F5DC)
elem.property(elem.KEV_PT_ZLOY, "Color", 0x4A708B)
elem.property(elem.KEV_PT_MOX, "Color", 0x6B8E23)
elem.property(amer, "Color", 0x636363)
elem.property(elem.KEV_PT_TH, "Color", 0x8B7500)
elem.property(c137, "Color", 0x6C7B8B)
elem.property(radio, "Color", 0x33A1C9)
elem.property(elem.KEV_PT_UO2, "Color", 0xFFFF00)
elem.property(elem.KEV_PT_U235, "Color", 0xCDCD00)
elem.property(elem.KEV_PT_MOX, "Flammable", 0)
elem.property(amer, "Flammable", 0)
elem.property(elem.KEV_PT_TH, "Flammable", 0)
elem.property(c137, "Flammable", 0)
elem.property(radio, "Flammable", 1.88)
elem.property(elem.KEV_PT_UO2, "Flammable", 0)
elem.property(elem.KEV_PT_MOX, "Explosive", 960)
elem.property(amer, "Explosive", 0)
elem.property(elem.KEV_PT_TH, "Explosive", 0)
elem.property(c137, "Explosive", 0)
elem.property(radio, "Explosive", 138)
elem.property(elem.KEV_PT_UO2, "Explosive", 16)
elem.property(elem.KEV_PT_BRYL, "Properties", elem.TYPE_SOLID+elem.PROP_DEADLY+elem.PROP_HOT_GLOW+elem.PROP_LIFE_DEC+elem.PROP_CONDUCTS)
elem.property(elem.KEV_PT_PO84, "Properties", elem.TYPE_SOLID+elem.PROP_DEADLY+elem.PROP_HOT_GLOW+elem.PROP_LIFE_DEC+elem.PROP_CONDUCTS)
elem.property(elem.KEV_PT_SLIT, "Properties", elem.TYPE_SOLID+elem.PROP_NEUTPASS)
elem.property(elem.KEV_PT_MOX, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_NEUTPASS+elem.PROP_NEUTPENETRATE)
elem.property(amer, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_NEUTPASS)
elem.property(elem.KEV_PT_ZLOY, "Properties", elem.TYPE_SOLID+elem.PROP_NEUTABSORB+elem.PROP_HOT_GLOW+elem.PROP_LIFE_DEC+elem.PROP_CONDUCTS)
elem.property(elem.KEV_PT_TH, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_NEUTPASS+elem.PROP_RADIOACTIVE+elem.PROP_HOT_GLOW+elem.PROP_LIFE_DEC+elem.PROP_CONDUCTS)
elem.property(c137, "Properties", elem.TYPE_SOLID+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_HOT_GLOW)
elem.property(radio, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_NEUTPASS)
elem.property(elem.KEV_PT_UO2, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_NEUTPASS)
elem.property(elem.KEV_PT_U235, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_NEUTPASS)
elem.property(elem.KEV_PT_BRYL, "Weight", 125.07)
elem.property(elem.KEV_PT_PO84	, "Weight", 185.07)
elem.property(elem.KEV_PT_SLIT, "Weight", 98.65)
elem.property(elem.KEV_PT_MOX, "Weight", 45.44)
elem.property(amer, "Weight", 23.98)
elem.property(elem.KEV_PT_TH, "Weight", 32.03)
elem.property(c137, "Weight", 37.09)
elem.property(radio, "Weight", 26.02)
elem.property(elem.KEV_PT_UO2, "Weight", 38.02)
elem.property(elem.KEV_PT_U235, "Weight", 58.02)
elem.property(elem.KEV_PT_ZLOY, "MenuSection", SC_NUCLEAR)
elem.property(elem.KEV_PT_BRYL, "MenuSection", SC_NUCLEAR)
elem.property(elem.KEV_PT_MOX, "MenuSection", SC_NUCLEAR)
elem.property(amer, "MenuSection", SC_NUCLEAR)
elem.property(elem.KEV_PT_TH, "MenuSection", SC_NUCLEAR)
elem.property(c137, "MenuSection", SC_NUCLEAR)
elem.property(radio, "MenuSection", SC_NUCLEAR)
elem.property(elem.KEV_PT_UO2, "MenuSection", SC_NUCLEAR)
elem.property(elem.KEV_PT_TH, "HighTemperature", 1853.15)
elem.property(elem.KEV_PT_TH, "HighTemperatureTransition", elem.DEFAULT_PT_URAN)
elem.property(elem.KEV_PT_ZLOY, "HighTemperature", 6500.15)
elem.property(elem.KEV_PT_ZLOY, "HighTemperatureTransition", elem.DEFAULT_PT_LAVA)
elem.property(elem.KEV_PT_PO84, "HighTemperature", 1960.15)
elem.property(elem.KEV_PT_PO84, "HighTemperatureTransition", elem.DEFAULT_PT_LAVA)
elem.property(elem.KEV_PT_MOX, "Loss", 0.15)
elem.property(amer, "Loss", 0.32)
elem.property(elem.KEV_PT_TH, "Loss", 0.16)
elem.property(c137, "Loss", 0.12)
elem.property(radio, "Loss", 0.24)
elem.property(elem.KEV_PT_U235, "Loss", 0.11)
elem.property(elem.KEV_PT_UO2, "Loss", 0.12)
elem.property(elem.KEV_PT_MOX, "AirLoss", 0.25)
elem.property(amer, "AirLoss", 0.23)
elem.property(elem.KEV_PT_TH, "AirLoss", 0.19)
elem.property(c137, "AirLoss", 0.17)
elem.property(radio, "AirLoss", 0.15)
elem.property(elem.KEV_PT_UO2, "AirLoss", 0.19)
elem.property(elem.KEV_PT_U235, "AirLoss", 0.09)
elem.property(thor, "AirDrag", 0.12)
elem.property(c137, "AirDrag", 0.02)
elem.property(radio, "AirDrag", 0.22)
elem.property(elem.KEV_PT_UO2, "AirDrag", 0.12)
elem.property(elem.KEV_PT_U235, "AirDrag", 0.20)
elem.property(thor, "Advection", 0.5)
elem.property(c137, "Advection", 0.15)
elem.property(radio, "Advection", 0.1)
elem.property(elem.KEV_PT_UO2, "Advection", 1.5)
elem.property(elem.KEV_PT_U235, "Advection", 1.3)
elem.property(elem.KEV_PT_TH, "Hardness", 13.55)
elem.property(c137, "Hardness", 16.78)
elem.property(radio, "Hardness", 17.96)
elem.property(elem.KEV_PT_SLIT, "Hardness", 155.00)
elem.property(elem.KEV_PT_UO2, "Hardness", 18.5)
elem.property(elem.KEV_PT_U235, "Hardness", 125.5)
elem.property(elem.KEV_PT_ZLOY, "Hardness", 155.5)
elem.property(elem.KEV_PT_PO84, "Hardness", 115.5)
elem.property(elem.KEV_PT_SLIT, "HeatConduct", 0.1)
elem.property(elem.KEV_PT_ZLOY, "HeatConduct", 54)
    
local function beUpdate(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
                sim.partProperty(i, "type", elem.KEV_PT_BRYL)
                sim.partProperty(r, "type", elem.DEFAULT_PT_PROT)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_PHOT then
                sim.partProperty(i, "type", elem.KEV_PT_BRYL)
                sim.partProperty(r, "type", elem.DEFAULT_PT_HYGN)
                end              
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                sim.pressure(x/4,y/4,15)
                sim.partProperty(i, "type", elem.KEV_PT_BRYL)
                end   
             if sim.partProperty(r, "ctype") == elem.KEV_PT_PO84 and sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                sim.pressure(x/4,y/4,45)
                sim.partProperty(i, "type", elem.KEV_PT_BRYL)
                end 
             if sim.partProperty(r, "ctype") == elem.KEV_PT_ZLOY and sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                sim.pressure(x/4,y/4,85)
                sim.partProperty(i, "type", elem.KEV_PT_BRYL)
                end
     end
    end  

local function po84Update(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if sim.partProperty(r, "ctype") == elem.KEV_PT_BRYL and sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK then
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                end
             if math.random(1, 10000) == 1 then
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
	        tpt.set_property("life", 60000, i)
		end
     end
    end 


    local function uo2Update(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if math.random(1, 10000) == 1 then
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
	        tpt.set_property("life", 60000, i)
		end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT and math.random(1,16) == 1 then
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "type", elem.DEFAULT_PT_URAN)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "uran")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
                tpt.set_property("life", 10, i)
                sim.pressure(x/4,y/4,15)
                tpt.set_property("temp", 4999, x, y)
                end 

             if sim.partProperty(r, "type") == elem.KEV_PT_F18 then
                sim.partProperty(i, "type", elem.DEFAULT_PT_URAN)
                sim.partProperty(r, "type", elem.KEV_PT_U235)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_PLUT then
                sim.partProperty(i, "type", elem.KEV_PT_MOX)
                sim.partProperty(r, "type", elem.KEV_PT_MOX)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT and math.random(1,600) == 1 then
                sim.partProperty(i, "type", elem.KEV_PT_U235)
                sim.partProperty(r, "type", elem.KEV_PT_TH)
                end
             if sim.partProperty(r, "type") == elem.KEV_PT_H2SO4 and math.random(1,3) == 1 then
                sim.partProperty(i, "type", elem.KEV_PT_U235)
                sim.partProperty(r, "type", elem.KEV_PT_TH)
                end
     end
    end 

    
    
    local function thUpdate(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if math.random(1, 1000) == 1 then
	        local decA = math.random(-20,20) 
	        local decB = math.random(-20,0)
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "oxyg")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "hygn")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
	        tpt.set_property("vx", math.random(-25,25), i)
	        tpt.set_property("vy", math.random(-25,25), i)
	        tpt.set_property("life", 10000, i)
		if math.abs(decA) + math.abs(decB) > 10 then
		local decC = math.random(1,4)
			if decC == 1 then
			tpt.set_property("type", "phot", i)
			end
			if decC == 2 then
			tpt.set_property("type", "phot", i)
			end
			if decC == 3 then
			tpt.set_property("type", "prot", i)
			end
			if decC == 4 then
			tpt.set_property("type", "prot", i)
			end
		end
	   end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.set_property("life", 10000, i)
                sim.pressure(x/4,y/4,85)
                tpt.set_property("temp", math.huge, x, y)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
                sim.partProperty(i, "type", elem.DEFAULT_PT_DEUT)
                sim.partProperty(r, "type", elem.DEFAULT_PT_URAN)
                end
             if sim.partProperty(r, "type") == sulfacid then
                sim.partProperty(i, "type", sulfoxid)
                sim.partProperty(r, "type", elem.DEFAULT_PT_URAN)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
                sim.partProperty(i, "ctype", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "ctype", elem.DEFAULT_PT_PROT)
                end   
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_THDR then
                sim.partProperty(i, "type", hel)
                sim.partProperty(r, "type", elem.DEFAULT_PT_URAN)
                end         
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_DEST then
                sim.partProperty(i, "type", elem.DEFAULT_PT_URAN)
                sim.partKill(i)
                end 
     end
    end 

    local function raUpdate(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if math.random(1, 10000) == 1 then
	        local descompA = math.random(-20,20) 
	        local descompB = math.random(-20,0)
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "oxyg")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "hygn")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "prot")
	        tpt.set_property("vx", math.random(-15,15), i)
	        tpt.set_property("vy", math.random(-15,15), i)
	        tpt.set_property("life", 100500, i)
		if math.abs(descompA) + math.abs(descompB) > 10 then
		local r3 = math.random(1,4)
			if descompC == 1 then
			tpt.set_property("type", "elec", i)
			end
			if descompC == 2 then
			tpt.set_property("type", "phot", i)
			end
			if descompC == 3 then
			tpt.set_property("type", "prot", i)
			end
			if descompC == 4 then
			tpt.set_property("type", "neut", i)
			end
		end
	   end
             
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_HYGN then
                sim.partProperty(i, "type", rad)
                sim.partProperty(r, "type", hel)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
                sim.partProperty(i, "type", rad)
                sim.partProperty(r, "type", elem.DEFAULT_PT_WTRV)
                end 
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_THDR then
                sim.partProperty(i, "type", hel)
                sim.partProperty(r, "type", rad)
                end         
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_DEST then
                sim.partProperty(i, "type", elem.DEFAULT_PT_URAN)
                sim.partKill(i)
                end 
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_PLUT then
                sim.partProperty(r, "type", elem.DEFAULT_PT_URAN)
                sim.partKill(i)
                end
             if sim.partProperty(r, "type") == elem.KEV_PT_BRYL and math.random(1,3600) == 1 then
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "type", elem.KEV_PT_BEO)
                end
             if sim.partProperty(r, "type") == elem.KEV_PT_BRYL then
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "hygn")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                end
     end
    end 

    local function cs137Update(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if math.random(1, 1000) == 1 then
	        local r = math.random(-60,60) 
	        local r2 = math.random(-60,0)
                tpt.set_property("temp", 2273, r)
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "elec")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "elec")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "prot")
	        tpt.set_property("vx", math.random(-15,15), i)
	        tpt.set_property("vy", math.random(-15,15), i)
	        tpt.set_property("life", 100000, i)
		if math.abs(r) + math.abs(r2) > 10 then
		local r3 = math.random(1,4)
			if r3 == 1 then
			tpt.set_property("type", "phot", i)
			end
			if r3 == 2 then
			tpt.set_property("type", "bryl", i)
			end
                        if r3 == 4 then
			tpt.set_property("type", "elec", i)
			end
			if r3 == 3 then
			tpt.set_property("type", "prot", i)
			end
		end
	   end
             
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
                sim.pressure(x/4,y/4,90)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "smke")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "smke")
	        tpt.create(x+math.random(-5,1), y+math.random(-1,5), "fire")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "fire")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "fire")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "fire")
                tpt.set_property("temp", math.huge, x, y)
                sim.partProperty(i, "type", elem.DEFAULT_PT_EMBR)
                tpt.set_property("life", 100000, i)
                sim.partProperty(r, "type", elem.DEFAULT_PT_SMKE)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_SLTW then
                sim.pressure(x/4,y/4,90)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "smke")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "smke")
	        tpt.create(x+math.random(-5,1), y+math.random(-1,5), "fire")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "fire")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "fire")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "fire")
                tpt.set_property("temp", math.huge, x, y)
                sim.partProperty(i, "type", elem.DEFAULT_PT_EMBR)
                tpt.set_property("life", 100000, i)
                sim.partProperty(r, "type", elem.DEFAULT_PT_SMKE)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_DSTW then
                sim.pressure(x/4,y/4,95)
                sim.partProperty(i, "type", elem.DEFAULT_PT_EMBR)
                sim.partProperty(r, "type", elem.DEFAULT_PT_SMKE)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
                sim.partProperty(i, "type", xen)
                sim.partProperty(r, "ctype", elem.DEFAULT_PT_URAN)
                end   
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_THDR then
                sim.partProperty(i, "type", hel)
                sim.partProperty(r, "type", xen)
                end         
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_DEST then
                sim.partProperty(i, "type", elem.DEFAULT_PT_URAN)
                sim.partKill(i)
                end 
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_PLUT then
                sim.partProperty(r, "type", elem.DEFAULT_PT_EXOT)
                sim.partKill(i)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_GOLD then
                sim.partProperty(r, "type", elem.DEFAULT_PT_PHOT)
                sim.partKill(i)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_PROT then
                sim.partProperty(i, "type", xen)
                sim.partKill(r)
                end  
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_EXOT then
                sim.partProperty(i, "type", elem.DEFAULT_PT_BVBR)
                sim.partProperty(r, "type", elem.DEFAULT_PT_BVBR)
                end
     end
    end 


    local function amUpdate(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if math.random(1, 1000) == 1 then
	        local descompA = math.random(-20,20) 
	        local descompB = math.random(-20,0)
                local descompC = math.random(-25,25)
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "hygn")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "oxyg")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "prot")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "prot")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "prot")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.set_property("vx", math.random(-15,15), i)
	        tpt.set_property("vy", math.random(-15,15), i)
	        tpt.set_property("life", 100, i)
		if math.abs(descompA) + math.abs(descompB) > 10 then
		local r3 = math.random(1,4)
			if descompC == 20 then
			tpt.set_property("type", "elec", i)
			end
			if descompC == 21 then
			tpt.set_property("type", "neut", i)
			end
			if descompC == 23 then
			tpt.set_property("type", "neut", i)
			end
			if descompC == 24 then
			tpt.set_property("type", "prot", i)
			end
		end
	   end
             
             if sim.pressure(x/4, y/4) >= 49.98 then
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "type", elem.DEFAULT_PT_PLUT)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
                tpt.set_property("life", 10, i)
                sim.pressure(x/4,y/4,25)
                tpt.set_property("temp", math.huge, x, y)
                end 
    
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_WATR then
                sim.partProperty(i, "type", thor)
                sim.partProperty(r, "type", elem.DEFAULT_PT_CAUS)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_LN2 then
                sim.partProperty(i, "type", nitg)
                sim.partProperty(r, "type", elem.DEFAULT_PT_PLUT)
                end
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
                sim.partProperty(i, "type", hel)
                sim.partProperty(r, "type", rad)
                end   
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_THDR then
                sim.partProperty(i, "type", hel)
                sim.partProperty(r, "type", palad)
                end         
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_DEST then
                sim.partProperty(i, "type", elem.DEFAULT_PT_URAN)
                sim.partKill(i)
                end 
             if sim.partProperty(r, "type") == radio then
                sim.partProperty(r, "type", elem.DEFAULT_PT_URAN)
                sim.partKill(i)
                end  
     end
    end

    local function u235Update(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
              if math.random(1, 1000) == 1 then
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "hygn")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
	        tpt.set_property("life", 12000, i)
		end

             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT and math.random(1,9) == 1 then
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "type", elem.DEFAULT_PT_PLUT)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
                tpt.set_property("life", 10, i)
                sim.pressure(x/4,y/4,25)
                tpt.set_property("temp", 7999, x, y)
                end   

             if sim.pressure(x/4, y/4) >= 20.30 then
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "type", elem.DEFAULT_PT_PLUT)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
                tpt.set_property("life", 10, i)
                sim.pressure(x/4,y/4,25)
                tpt.set_property("temp", 7999, x, y)
                end  
     end
    end

    local function moxUpdate(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if math.random(1, 1000) == 1 then
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "th")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "uran")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
	        tpt.set_property("life", 300000, i)
		end

             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "type", amer)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
                tpt.set_property("life", 10, i)
                sim.pressure(x/4,y/4,25)
                tpt.set_property("temp", 7999, x, y)
                end   

             if sim.pressure(x/4, y/4) >= 10.10 then
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "type", elem.DEFAULT_PT_PLUT)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "plut")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
                tpt.set_property("life", 10, i)
                sim.pressure(x/4,y/4,25)
                tpt.set_property("temp", 7999, x, y)
                end 
     end
    end 

local promethium = elem.allocate("KEV", "PM147")
local lanthanum = elem.allocate("KEV", "LA139")
local cermetcombustible = elem.allocate("KEV", "CMET")
elem.element(elem.KEV_PT_PM147, elem.element(elem.DEFAULT_PT_URAN))
elem.element(elem.KEV_PT_LA139, elem.element(elem.DEFAULT_PT_PSCN))
elem.element(elem.KEV_PT_CMET, elem.element(elem.DEFAULT_PT_VIBR))
elem.property(elem.KEV_PT_PM147, "Name", "PM147")
elem.property(elem.KEV_PT_LA139, "Name", "LA139")
elem.property(elem.KEV_PT_CMET, "Name", "CMET")
elem.property(elem.KEV_PT_PM147, "Description", "Promethium 147. Emits huge amounts of PHOT. Heats up with the time.")
elem.property(elem.KEV_PT_LA139, "Description", "Lanthanum 139. Destabilizes when a NEUT touches it. Emits sparks under pressure. Absorbs HYGN under pressure.")
elem.property(elem.KEV_PT_CMET, "Description", "Ceramic Uranium Oxide and Metallic Aleation combustible cell. Fisible.")
elem.property(elem.KEV_PT_PM147, "Color", 0x00F5FF)
elem.property(elem.KEV_PT_LA139, "Color", 0xEEEED1)
elem.property(elem.KEV_PT_CMET, "Color", 0x6E8B3D)
elem.property(elem.KEV_PT_PM147, "Flammable", 0)
elem.property(elem.KEV_PT_LA139, "Flammable", 0)
elem.property(elem.KEV_PT_CMET, "Flammable", 0)
elem.property(elem.KEV_PT_PM147, "Explosive", 0)
elem.property(elem.KEV_PT_LA139, "Explosive", 0)
elem.property(elem.KEV_PT_CMET, "Explosive", 0)
elem.property(elem.KEV_PT_PM147, "Properties", elem.TYPE_PART+elem.PROP_DEADLY+elem.PROP_RADIOACTIVE+elem.PROP_HOT_GLOW)
elem.property(elem.KEV_PT_LA139, "Properties", elem.TYPE_SOLID+elem.PROP_HOT_GLOW+elem.PROP_LIFE_DEC+elem.PROP_CONDUCTS)
elem.property(elem.KEV_PT_CMET, "Properties", elem.TYPE_SOLID+elem.PROP_HOT_GLOW+elem.PROP_LIFE_DEC+elem.PROP_CONDUCTS)
elem.property(elem.KEV_PT_PM147, "Weight", 50)
elem.property(elem.KEV_PT_LA139, "Weight", 135)
elem.property(elem.KEV_PT_CMET, "Weight", 148)
elem.property(elem.KEV_PT_PM147, "HighTemperatureTransition", elem.DEFAULT_PT_LAVA)
elem.property(elem.KEV_PT_PM147, "HighTemperature", 2673)
elem.property(elem.KEV_PT_LA139, "HighTemperatureTransition", elem.DEFAULT_PT_LAVA)
elem.property(elem.KEV_PT_LA139, "HighTemperature", 1170)
elem.property(elem.KEV_PT_CMET, "HighTemperatureTransition", elem.DEFAULT_PT_LAVA)
elem.property(elem.KEV_PT_CMET, "HighTemperature", 6673)
elem.property(elem.KEV_PT_PM147, "LowTemperatureTransition", elem.DEFAULT_PT_STNE)
elem.property(elem.KEV_PT_PM147, "LowTemperature", 173)


    local function pm147Update(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if math.random(1, 1000) == 1 then
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "uran")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "uran")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "stne")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.set_property("vx", math.random(-1,1), i)
	        tpt.set_property("vy", math.random(-1,1), i)
	        tpt.set_property("life", 10000, i)
		end
              if math.random(1, 10000) == 1 then
	         tpt.set_property("temp", 999, x, y)
		 end
              if math.random(1, 10000) == 1 then
	         tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	         tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	         tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
		 end
     end
    end 

 local function la139Update(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT then
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "uran")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "uran")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "stne")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.set_property("vx", math.random(-1,1), i)
	        tpt.set_property("vy", math.random(-1,1), i)
	        tpt.set_property("life", 10000, i)
		end
              if sim.partProperty(r, "type") == elem.DEFAULT_PT_HYGN and sim.pressure(x/4, y/4) >= 5.10 then
                 sim.partKill(r)
	         tpt.set_property("temp", 766, x, y)
		 end
              if sim.pressure(x/4, y/4) >= 10.10 and math.random(1, 10) == 1 then
	         tpt.create(x+math.random(-1,1), y+math.random(-1,1), "embr")
	         tpt.create(x+math.random(-1,1), y+math.random(-1,1), "embr")
	         tpt.create(x+math.random(-1,1), y+math.random(-1,1), "embr")
	         tpt.set_property("vx", math.random(-1,1), i)
	         tpt.set_property("vy", math.random(-1,1), i)
	         tpt.set_property("life", 10000, i)
		 end
              if sim.partProperty(r, "type") == elem.DEFAULT_PT_SPRK and sim.pressure(x/4, y/4) <= -5.10 then
                 tpt.create(x+math.random(-1,1), y+math.random(-1,1), "hygn")
	         tpt.create(x+math.random(-1,1), y+math.random(-1,1), "hygn")
                 tpt.create(x+math.random(-1,1), y+math.random(-1,1), "hygn")
	         tpt.set_property("temp", -690, x, y)
		 end
     end
    end 
    local function cermetUpdate(i, x, y, s, nt)
    r = sim.partID(x+math.random(-1,1),y+math.random(-1,1))
     if r~= nil then
              if math.random(1, 1000) == 1 then
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "phot")
	        tpt.set_property("vx", math.random(-1,1), i)
	        tpt.set_property("vy", math.random(-1,1), i)
                tpt.set_property('dcolor', gfx.getHexColor(r,g,b,145,170,127), r)
	        tpt.set_property("life", 19900, i)
		end

             if sim.partProperty(r, "type") == elem.DEFAULT_PT_NEUT and math.random(1,12) == 1 then
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "type", elem.DEFAULT_PT_URAN)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "uo2")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "uran")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
                tpt.set_property("life", 10, i)
                sim.pressure(x/4,y/4,25)
                tpt.set_property("temp", 7999, x, y)
                return 1
                end   

             if sim.pressure(x/4, y/4) >= 11.30 then
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(i, "type", elem.DEFAULT_PT_NEUT)
                sim.partProperty(r, "type", elem.KEV_PT_UO2)
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
	        tpt.create(x+math.random(-1,1), y+math.random(-1,1), "neut")
                tpt.create(x+math.random(-1,1), y+math.random(-1,1), "uo2")
	        tpt.set_property("vx", math.random(-2,2), i)
	        tpt.set_property("vy", math.random(-2,2), i)
                tpt.set_property("life", 10, i)
                sim.pressure(x/4,y/4,25)
                tpt.set_property('dcolor', gfx.getHexColor(r,g,b,145,170,127), r)
                tpt.set_property("temp", 7999, x, y)
                end  
     end
    end

elements.property(elements.DEFAULT_PT_URAN, "Description", "Uranium 238. Heavy particles. Generates Heat under Pressure.")
elem.property(elem.KEV_PT_U235, "Update", u235Update)
elem.property(elem.KEV_PT_HE4, "Update", hel4Update)
elem.property(rad, "Update", radonUpdate)
elem.property(elem.KEV_PT_F18, "Update", fUpdate)
elem.property(elem.KEV_PT_MOX, "Update", moxUpdate)
elem.property(amer, "Update",amUpdate)
elem.property(c137, "Update",cs137Update)
elem.property(radio, "Update",raUpdate)
elem.property(elem.KEV_PT_TH, "Update",thUpdate)
elem.property(elem.KEV_PT_UO2, "Update",uo2Update)
elem.property(elem.KEV_PT_BRYL, "Update", beUpdate)
elem.property(elem.KEV_PT_PO84, "Update", po84Update)
elem.property(elem.KEV_PT_PM147, "Update", pm147Update)
elem.property(elem.KEV_PT_LA139, "Update", la139Update)
elem.property(elem.KEV_PT_CMET, "Update", cermetUpdate)

--------------------------------------------------------------------------------------