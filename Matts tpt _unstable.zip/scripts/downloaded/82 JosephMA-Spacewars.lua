
--[[
Spacewars! Simlulate space in space.
Script Version 1.0.4

Changes:
Version 1.0.4:
A better fix for Jacob1's mod.
Version 1.0.3:
Fixed issues with Jacob1's mod.
Version 1.0.2:
Fixed deco bar bug.
Version 1.0.1:
Builder spaceships will now clean up space debris and destroy enemy cities.
Minor performance increase for spaceships.
Ships will now mark and move towards rally points.
]]--

sim.gravityMode(1);
sim.airMode(3);
sim.edgeMode(2);

--Elements
local continent;
local ocean;
local planet;
local desert;
local rock;
local lasr;
local city;
local explosion;
local missile;
local ship;
local bomber;
local mothership;
local builder;
local nukeMissile;

--Settings
local explosionSpread = 0.5;
local fighterLife = 1;
local mothershipLife = 5;
local destroyerLife = 10;

--Variables
local interestPoint = {};
interestPoint[0] = {x = -1, y = -1};
interestPoint[1] = {x = -1, y = -1};
interestPoint[2] = {x = -1, y = -1};
interestPoint[3] = {x = -1, y = -1};
interestPoint[4] = {x = -1, y = -1};
interestPoint[5] = {x = -1, y = -1};

--Desert
desert = elements.allocate("JosephMA", "DSRT");
elements.element(desert, elements.element(elements.DEFAULT_PT_SAND));
elements.property(desert, "HighTemperature", 673.15);
elements.property(desert, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA);
elements.property(desert, "Name", "DSRT");
elements.property(desert, "Description", "Deserts baren sandy lands.");
elements.property(desert, "MenuSection", 16);

--Rock
rock = elements.allocate("JosephMA", "ROCK");
elements.element(rock, elements.element(elements.DEFAULT_PT_BRCK));
elements.property(rock, "HighTemperature", 873.15);
elements.property(rock, "HighTemperatureTransition", elements.DEFAULT_PT_LAVA);
elements.property(rock, "Name", "ROCK");
elements.property(rock, "Description", "Rocks, stony and rocky.");
elements.property(rock, "MenuSection", 16);

--City
city = elements.allocate("JosephMA", "CITY");
elements.element(city, elements.element(elements.DEFAULT_PT_BRCK));
elements.property(city, "Color", 0xFF505070);
elements.property(city, "HighTemperature", 873.15);
elements.property(city, "HighTemperatureTransition", elements.DEFAULT_PT_BRMT);
elements.property(city, "Name", "CITY");
elements.property(city, "Description", "A city people live here.");
elements.property(city, "MenuSection", 16);

local function cityUpdate(i, x, y, s, n)
	if sim.partProperty(i, "tmp2") == 0 then
		sim.partProperty(i, "tmp", math.random(0, 5));
		sim.partProperty(i, "tmp2", 1);
	end
	local life = sim.partProperty(i, "life");
	if math.random(1, 500) == 1 then
		local part;
		if math.random(1, 1000) == 1 then
			part = sim.partCreate(-1, x + math.random(-25, 25), y + math.random(-25, 25), destroyer);
		elseif math.random(1, 200) == 1 then
			part = sim.partCreate(-1, x + math.random(-25, 25), y + math.random(-25, 25), mothership);
		elseif math.random(1, 2) == 1 then
			part = sim.partCreate(-1, x + math.random(-25, 25), y + math.random(-25, 25), ship);
		elseif math.random(1, 2) == 1 then
			part = sim.partCreate(-1, x + math.random(-25, 25), y + math.random(-25, 25), bomber);
		else
			part = sim.partCreate(-1, x + math.random(-25, 25), y + math.random(-25, 25), builder);
		end
		sim.partProperty(part, "tmp", sim.partProperty(i, "tmp"));
		sim.partProperty(i, "life", life + 1);
	end
end

elements.property(city, "Update", cityUpdate);

--Continent
continent = elements.allocate("JosephMA", "CONT");
elements.element(continent, elements.element(elements.DEFAULT_PT_PLNT));
elements.property(continent, "HighTemperature", 473.15);
elements.property(continent, "HighTemperatureTransition", rock);
elements.property(continent, "Name", "CONT");
elements.property(continent, "Description", "Continent makes up planets.");
elements.property(continent, "MenuSection", 16);

local function continentUpdate(i, x, y, s, n)
	local life = sim.partProperty(i, "life");
	if life > 0 then
		for r in sim.neighbors(x,y,1,1) do
			if math.random(1, 8) == 1 and sim.partProperty(r, "type") == ocean then
				sim.partChangeType(r, continent);
				sim.partProperty(r, "life", life - 1);
			end
		end
	elseif math.random(1, 100000000) == 1 then
		for r in sim.neighbors(x,y,1,1) do
			if sim.partProperty(r, "type") == city then
				sim.partProperty(i, "tmp", sim.partProperty(r, "tmp"));
				sim.partProperty(i, "tmp2", sim.partProperty(r, "tmp2"));
				break;
			end
		end
		sim.partChangeType(i, city);
	end
end

elements.property(continent, "Update", continentUpdate);

--Ocean
ocean = elements.allocate("JosephMA", "OCEN");
elements.element(ocean, elements.element(elements.DEFAULT_PT_WATR));
elements.property(ocean, "HighTemperature", 473.15);
elements.property(ocean, "HighTemperatureTransition", desert);
elements.property(ocean, "Name", "OCEN");
elements.property(ocean, "Description", "Oceans able to substain life on planets.");
elements.property(ocean, "MenuSection", 16);

--Planet
planet = elements.allocate("JosephMA", "PLNE");
elements.element(planet, elements.element(elements.DEFAULT_PT_TTAN));
elements.property(planet, "Name", "PLNE");
elements.property(planet, "MenuSection", elem.SC_SPECIAL);
elements.property(planet, "Description", "Creates a randomized planet.");

local function planetUpdate(i, x, y, s, n)
	if math.random(1, 20) == 1 then
		sim.partProperty(i, "life", math.random(0, 10));
		sim.partChangeType(i, continent);
	else
		sim.partChangeType(i, ocean);
	end
end

elements.property(planet, "Update", planetUpdate);

--Laser
laser = elements.allocate("JosephMA", "LASR");
elements.element(laser, elements.element(elements.DEFAULT_PT_PHOT));
elements.property(laser, "Name", "LASR");
elements.property(laser, "Temperature", 295.15);
elements.property(laser, "Description", "Lasers shoot everything up!");
elements.property(laser, "MenuSection", 16);

--Explosion
explosion = elements.allocate("JosephMA", "EXPL");
elements.element(explosion, elements.element(elements.DEFAULT_PT_DUST));
elements.property(explosion, "Name", "EXPL");
elements.property(explosion, "Temperature", 673.15);
elements.property(explosion, "Description", "Explosions, boom!");
elements.property(explosion, "MenuSection", elem.SC_EXPLOSIVE);

local function explosionUpdate(i, x, y, s, n)
	--Spawn explosion
	local temp = tpt.get_property("temp", i);
	local life = tpt.get_property("life", i);
	local spread;
	
	if life == 0 then
		spread = explosionSpread;
	else
		spread = life;
	end
	
	sim.partKill(x - 1, y);
	sim.partKill(x + 1, y);
	sim.partKill(x - 2, y);
	sim.partKill(x + 2, y);
	sim.partKill(x, y - 1);
	sim.partKill(x, y + 1);
	sim.partKill(x, y - 2);
	sim.partKill(x, y + 2);
	sim.partKill(x - 1, y - 1);
	sim.partKill(x + 1, y - 1);
	sim.partKill(x - 1, y + 1);
	sim.partKill(x + 1, y + 1);
	
	for t=0, 50, 1
	do
		local part = sim.partCreate(-3, x, y, elements.DEFAULT_PT_EMBR);
		tpt.set_property("temp", temp, part);
		tpt.set_property("life", math.random() * 100, part);
		local angle = math.random() * 2.0 * math.pi/spread;
		local v = (math.random()) * 5.0/spread;
		tpt.set_property("vx", v * math.cos(angle), part);
		tpt.set_property("vy", v * math.sin(angle), part);
	end
	
	sim.partKill(i);
	return 1;
end

elements.property(explosion, "Update", explosionUpdate);

--Missile
missile = elements.allocate("JosephMA", "MISL");
elements.element(missile, elements.element(elements.DEFAULT_PT_PROT));
elements.property(missile, "Name", "MISL");
elements.property(missile, "Colour", 0x5D5D5C);
elements.property(missile, "Description", "Explodes after a set life time!");
elements.property(missile, "MenuSection", 16);

local function missileUpdate(i, x, y, s, n)
	sim.partProperty(i, "life", sim.partProperty(i, "life") - 1);
	if sim.partProperty(i, "life") <= 0 then
		local part = sim.partCreate(-1, x, y, explosion);
		sim.partProperty(part, "life", 1);
		sim.partKill(i);
		return 1;
	end
	--Smoke Trail
	local part = sim.partCreate(-1, x, y, elements.DEFAULT_PT_SMKE);
	sim.partProperty(part, "life", 20);
end

elements.property(missile, "Update", missileUpdate);

--Ship
ship = elements.allocate("JosephMA", "SHIP");
elements.element(ship, elements.element(elements.DEFAULT_PT_PROT));
elements.property(ship, "HighTemperature", 1273.15);
elements.property(ship, "HighTemperatureTransition", elements.DEFAULT_PT_BRMT);
elements.property(ship, "Name", "SHIP");
elements.property(ship, "Description", "Spacecraft fighter shoots lasers.");
elements.property(ship, "MenuSection", elem.SC_SPECIAL);

local function shipUpdate(i, x, y, s, n)
	--tmp is current team
	local tmp = sim.partProperty(i, "tmp");
	local life = tpt.get_property("life", i);
	if life == 0 then
		tpt.set_property("life", fighterLife, i);
		life = fighterLife;
	end
	local rand = math.random(1, 150);
	if rand <= 75 then
		for r in sim.neighbors(x,y,1,1) do
			local partType = sim.partProperty(r, "type");
			if partType == laser and sim.partProperty(r, "tmp") ~= tmp then
				sim.partKill(r);
				tpt.set_property("life", life - 1, i);
				life = life - 1;
				if life - 1 <= -1 then
					sim.partKill(i);
					return 1;
				end
			end
		end
	end
	--Movement
	if math.random(1, 100) == 1 then
		--Move towards point of interest if it exists
		if interestPoint[tmp].x ~= -1 then
			if interestPoint[tmp].x > x then
				tpt.set_property("vx", math.random(1, 3), i);
			elseif interestPoint[tmp].x < x then
				tpt.set_property("vx", math.random(-3, -1), i);
			end
			if interestPoint[tmp].y > y then
				tpt.set_property("vy", math.random(1, 3), i);
			elseif interestPoint[tmp].y < y then
				tpt.set_property("vy", math.random(-3, -1), i);
			end
		else
			if math.random(1, 2) == 1 then
				tpt.set_property("vx", math.random(-3, 3), i);
			else
				tpt.set_property("vy", math.random(-3, 3), i);
			end
		end
	end
	--Shooting
	if rand == 1 then
		for r in sim.neighbors(x,y,5,5) do
			local partType = sim.partProperty(r, "type");
			if (partType == ship or partType == bomber or partType == city or partType == mothership or parType == destroyer or partType == builder) and sim.partProperty(r, "tmp") ~= tmp then
				local part = sim.partCreate(-3, x, y, laser);
				tpt.set_property("vx", sim.partProperty(r, "x") - x, part);
				tpt.set_property("vy", sim.partProperty(r, "y") - y, part);
				tpt.set_property("tmp", tmp, part);
				tpt.set_property("life", 20, part);
			end
		end
	end
end

elements.property(ship, "Update", shipUpdate);

local function shipGraphics(i, colr, colg, colb)
	local r;
	local g;
	local b;
	local tmp = tpt.get_property("tmp", i);
	if tmp == 0 then
		r = 255;
		g = 0;
		b = 0;
	elseif tmp == 1 then
		r = 0;
		g = 255;
		b = 0;
	elseif tmp == 2 then
		r = 0;
		g = 0;
		b = 255;
	elseif tmp == 3 then
		r = 255;
		g = 204;
		b = 0;
	elseif tmp == 4 then
		r = 255;
		g = 255;
		b = 255;
	elseif tmp == 5 then
		r = 153;
		g = 153;
		b = 153;
	end
	return 1,0x00000001,255,r,g,b,255,255,255,255;
end

elements.property(ship, "Graphics", shipGraphics);

--Bomber
bomber = elements.allocate("JosephMA", "BMBR");
elements.element(bomber, elements.element(elements.DEFAULT_PT_PROT));
elements.property(bomber, "HighTemperature", 1273.15);
elements.property(bomber, "HighTemperatureTransition", elements.DEFAULT_PT_BRMT);
elements.property(bomber, "Name", "BMBR");
elements.property(bomber, "Description", "Spacecraft bomber shoots missiles.");
elements.property(bomber, "MenuSection", elem.SC_SPECIAL);

local function bomberUpdate(i, x, y, s, n)
	--tmp is current team
	local tmp = sim.partProperty(i, "tmp");
	local life = tpt.get_property("life", i);
	if life == 0 then
		tpt.set_property("life", fighterLife, i);
		life = fighterLife;
	end
	local rand = math.random(1, 150);
	if rand <= 75 then
		for r in sim.neighbors(x,y,1,1) do
			local partType = sim.partProperty(r, "type");
			if partType == laser and sim.partProperty(r, "tmp") ~= tmp then
				sim.partKill(r);
				tpt.set_property("life", life - 1, i);
				life = life - 1;
				if life - 1 <= -1 then
					sim.partKill(i);
					return 1;
				end
			end
		end
	end
	--Movement
	if math.random(1, 100) == 1 then
		--Move towards point of interest if it exists
		if interestPoint[tmp].x ~= -1 then
			if interestPoint[tmp].x > x then
				tpt.set_property("vx", 1, i);
			elseif interestPoint[tmp].x < x then
				tpt.set_property("vx", -1, i);
			end
			if interestPoint[tmp].y > y then
				tpt.set_property("vy", 1, i);
			elseif interestPoint[tmp].y < y then
				tpt.set_property("vy", -1, i);
			end
		else
			if math.random(1, 2) == 1 then
				tpt.set_property("vx", math.random(-1, 1), i);
			else
				tpt.set_property("vy", math.random(-1, 1), i);
			end
		end
	end
	--Shooting
	if rand == 1 then
		for r in sim.neighbors(x,y,5,5) do
			local partType = sim.partProperty(r, "type");
			if (partType == ship or partType == bomber or partType == city or partType == mothership or parType == destroyer or partType == builder) and sim.partProperty(r, "tmp") ~= tmp then
				local part = sim.partCreate(-3, x, y, missile);
				tpt.set_property("vx", sim.partProperty(r, "x") - x, part);
				tpt.set_property("vy", sim.partProperty(r, "y") - y, part);
				tpt.set_property("life", 20, part);
				break;
			end
		end
	end
end

elements.property(bomber, "Update", bomberUpdate);

local function bomberGraphics(i, colr, colg, colb)
	local r;
	local g;
	local b;
	local tmp = tpt.get_property("tmp", i);
	if tmp == 0 then
		r = 255;
		g = 0;
		b = 0;
	elseif tmp == 1 then
		r = 0;
		g = 255;
		b = 0;
	elseif tmp == 2 then
		r = 0;
		g = 0;
		b = 255;
	elseif tmp == 3 then
		r = 255;
		g = 204;
		b = 0;
	elseif tmp == 4 then
		r = 255;
		g = 255;
		b = 255;
	elseif tmp == 5 then
		r = 153;
		g = 153;
		b = 153;
	end
	return 1,0x00000001,255,r,g,b,255,255,255,255;
end

elements.property(bomber, "Graphics", bomberGraphics);

--Mothership
mothership = elements.allocate("JosephMA", "MOTH");
elements.element(mothership, elements.element(elements.DEFAULT_PT_PROT));
elements.property(mothership, "HighTemperature", 1273.15);
elements.property(mothership, "HighTemperatureTransition", elements.DEFAULT_PT_BRMT);
elements.property(mothership, "Name", "MOTH");
elements.property(mothership, "Description", "Mothership produces ships and fires fast! Also has nukes onboard");
elements.property(mothership, "MenuSection", elem.SC_SPECIAL);

local function mothershipUpdate(i, x, y, s, n)
	local tmp = sim.partProperty(i, "tmp");
	--tmp is current team
	local life = tpt.get_property("life", i);
	if life == 0 then
		tpt.set_property("life", mothershipLife, i);
		life = mothershipLife;
	end
	local rand = math.random(1, 60);
	if rand == 60 then
		--Set rally point
		interestPoint[tmp].x = x;
		interestPoint[tmp].y = y;
	end
	if rand <= 30 then
		for r in sim.neighbors(x,y,1,1) do
			local partType = sim.partProperty(r, "type");
			if partType == laser and sim.partProperty(r, "tmp") ~= tmp then
				sim.partKill(r);
				tpt.set_property("life", life - 1, i);
				life = life - 1;
				if life - 1 <= -1 then
					sim.partKill(i);
					return 1;
				end
			end
		end
	end
	--Movement
	if math.random(1, 100) == 1 then
		if math.random(1, 2) == 1 then
			tpt.set_property("vx", math.random(-1, 1), i);
		else
			tpt.set_property("vy", math.random(-1, 1), i);
		end
	end
	--Shooting
	if rand == 1 then
		for r in sim.neighbors(x,y,10,10) do
			local partType = sim.partProperty(r, "type");
			if (partType == ship or partType == bomber or partType == city or partType == mothership or parType == destroyer or partType == builder) and sim.partProperty(r, "tmp") ~= tmp then
				if partType ~= city then
					local part = sim.partCreate(-3, x, y, laser);
					tpt.set_property("vx", sim.partProperty(r, "x") - x, part);
					tpt.set_property("vy", sim.partProperty(r, "y") - y, part);
					tpt.set_property("tmp", tmp, part);
					tpt.set_property("life", 20, part);
					part = sim.partCreate(-3, x - 1, y, laser);
					tpt.set_property("vx", sim.partProperty(r, "x") - x, part);
					tpt.set_property("vy", sim.partProperty(r, "y") - y, part);
					tpt.set_property("tmp", tmp, part);
					tpt.set_property("life", 20, part);
					part = sim.partCreate(-3, x + 1, y, laser);
					tpt.set_property("vx", sim.partProperty(r, "x") - x, part);
					tpt.set_property("vy", sim.partProperty(r, "y") - y, part);
					tpt.set_property("tmp", tmp, part);
					tpt.set_property("life", 20, part);
					part = sim.partCreate(-3, x, y - 1, laser);
					tpt.set_property("vx", sim.partProperty(r, "x") - x, part);
					tpt.set_property("vy", sim.partProperty(r, "y") - y, part);
					tpt.set_property("tmp", tmp, part);
					tpt.set_property("life", 20, part);
					part = sim.partCreate(-3, x, y + 1, laser);
					tpt.set_property("vx", sim.partProperty(r, "x") - x, part);
					tpt.set_property("vy", sim.partProperty(r, "y") - y, part);
					tpt.set_property("tmp", tmp, part);
					tpt.set_property("life", 20, part);
				else
					--Destroy or assimilate
					if math.random(1, 2) == 1 then
						--sim.partChangeType(r, elements.DEFAULT_PT_BOMB);
						sim.partChangeType(r, rock);
					else
						sim.partProperty(r, "tmp", tmp)
					end
				end
			end
		end
	end
	--Create more ships
	if math.random(1, 300) == 1 then
		local part;
		if math.random(1, 2) == 1 then
			part = sim.partCreate(-3, x, y, ship);
		else
			part = sim.partCreate(-3, x , y, bomber);
		end
		sim.partProperty(part, "tmp", tmp);
	end
end

elements.property(mothership, "Update", mothershipUpdate);

local function mothershipGraphics(i, colr, colg, colb)
	local r;
	local g;
	local b;
	local tmp = tpt.get_property("tmp", i);
	if tmp == 0 then
		r = 255;
		g = 0;
		b = 0;
	elseif tmp == 1 then
		r = 0;
		g = 255;
		b = 0;
	elseif tmp == 2 then
		r = 0;
		g = 0;
		b = 255;
	elseif tmp == 3 then
		r = 255;
		g = 204;
		b = 0;
	elseif tmp == 4 then
		r = 255;
		g = 255;
		b = 255;
	elseif tmp == 5 then
		r = 153;
		g = 153;
		b = 153;
	end
	local x = tpt.get_property("x",i);
	local y = tpt.get_property("y",i);
	graphics.fillRect(x - 2, y - 2, 5, 5, r, g, b);
end

elements.property(mothership, "Graphics", mothershipGraphics);

--Destroyer
destroyer = elements.allocate("JosephMA", "DSTR");
elements.element(destroyer, elements.element(elements.DEFAULT_PT_PROT));
elements.property(destroyer, "HighTemperature", 1273.15);
elements.property(destroyer, "HighTemperatureTransition", elements.DEFAULT_PT_BRMT);
elements.property(destroyer, "Name", "DSTR");
elements.property(destroyer, "Description", "Destroys all worlds.");
elements.property(destroyer, "MenuSection", elem.SC_SPECIAL);

local function destroyerUpdate(i, x, y, s, n)
	local tmp = sim.partProperty(i, "tmp");
	--tmp is current team
	local life = tpt.get_property("life", i);
	if life == 0 then
		tpt.set_property("life", destroyerLife, i);
		life = destroyerLife;
	end
	local rand = math.random(1, 30);
	if rand == 30 then
		--Set rally point
		interestPoint[tmp].x = x;
		interestPoint[tmp].y = y;
	end
	if rand <= 15 then
		for r in sim.neighbors(x,y,1,1) do
			local partType = sim.partProperty(r, "type");
			if partType == laser and sim.partProperty(r, "tmp") ~= tmp then
				sim.partKill(r);
				tpt.set_property("life", life - 1, i);
				life = life - 1;
				if life - 1 <= -1 then
					sim.partKill(i);
					return 1;
				end
			end
		end
	end
	--Movement
	if math.random(1, 100) == 1 then
		if math.random(1, 2) == 1 then
			tpt.set_property("vx", math.random(-1, 1), i);
		else
			tpt.set_property("vy", math.random(-1, 1), i);
		end
	end
	--Shooting
	if rand == 1 then
		for r in sim.neighbors(x,y,10,10) do
			local partType = sim.partProperty(r, "type");
			if (partType == ship or partType == bomber or partType == city or partType == mothership or parType == destroyer or partType == builder) and sim.partProperty(r, "tmp") ~= tmp then
				if partType ~= city then
					--Nuke missile
					local part = sim.partCreate(-3, x, y, nukeMissile);
					tpt.set_property("vx", sim.partProperty(r, "x") - x, part);
					tpt.set_property("vy", sim.partProperty(r, "y") - y, part);
					--tpt.set_property("tmp", tmp, part);
					tpt.set_property("life", 40, part);
				else
					--Destroy
					if math.random(1, 2) == 1 then
						--sim.partChangeType(r, elements.DEFAULT_PT_BOMB);
						sim.partChangeType(r, rock);
					end
				end
			--[[elseif partType == ocean or partType == continent then
				--Destroy
				if math.random(1, 10) == 1 then
					sim.partChangeType(r, elements.DEFAULT_PT_BOMB);
				else
					sim.partProperty(r, "temp", 2773.15);
				end
			elseif partType == desert then
				--Obliviate
				sim.partChangeType(r, elements.DEFAULT_PT_PLSM);]]--
			end
		end
	end
	--Create more ships
	if math.random(1, 300) == 1 then
		local part;
		if math.random(1, 2) == 1 then
			part = sim.partCreate(-3, x, y, ship);
		else
			part = sim.partCreate(-3, x , y, bomber);
		end
		sim.partProperty(part, "tmp", tmp);
	end
end

elements.property(destroyer, "Update", destroyerUpdate);

local function destroyerGraphics(i, colr, colg, colb)
	local r;
	local g;
	local b;
	local tmp = tpt.get_property("tmp", i);
	if tmp == 0 then
		r = 255;
		g = 0;
		b = 0;
	elseif tmp == 1 then
		r = 0;
		g = 255;
		b = 0;
	elseif tmp == 2 then
		r = 0;
		g = 0;
		b = 255;
	elseif tmp == 3 then
		r = 255;
		g = 204;
		b = 0;
	elseif tmp == 4 then
		r = 255;
		g = 255;
		b = 255;
	elseif tmp == 5 then
		r = 153;
		g = 153;
		b = 153;
	end
	local x = tpt.get_property("x",i);
	local y = tpt.get_property("y",i);
	graphics.fillRect(x - 4, y - 4, 9, 9, r, g, b);
end

elements.property(destroyer, "Graphics", destroyerGraphics);

--Builder
builder = elements.allocate("JosephMA", "BLDR");
elements.element(builder, elements.element(elements.DEFAULT_PT_PROT));
elements.property(builder, "HighTemperature", 1273.15);
elements.property(builder, "HighTemperatureTransition", elements.DEFAULT_PT_BRMT);
elements.property(builder, "Name", "BLDR");
elements.property(builder, "Description", "Spacecraft builder builds space cities.");
elements.property(builder, "MenuSection", elem.SC_SPECIAL);

local function builderUpdate(i, x, y, s, n)
	--tmp is current team
	local life = tpt.get_property("life", i);
	if life == 0 then
		tpt.set_property("life", fighterLife, i);
		life = fighterLife;
	end
	--Damage
	if math.random(1, 2) == 1 then
		for r in sim.neighbors(x,y,1,1) do
			local partType = sim.partProperty(r, "type");
			local tmp = sim.partProperty(i, "tmp");
			if partType == laser and sim.partProperty(r, "tmp") ~= tmp then
				sim.partKill(r);
				tpt.set_property("life", life - 1, i);
				life = life - 1;
				if life - 1 <= -1 then
					sim.partKill(i);
					return 1;
				end
			--Destroy space debris
			elseif partType == elements.DEFAULT_PT_BRMT or partType == elements.DEFAULT_PT_BMTL then
				sim.partKill(r);
			--Destroy enemy cities
			elseif partType == city and sim.partProperty(r, "tmp") ~= tmp then
				sim.partKill(r);
			end
		end
	end
	--Movement
	if math.random(1, 100) == 1 then
		if math.random(1, 2) == 1 then
			tpt.set_property("vx", math.random(-3, 3), i);
		else
			tpt.set_property("vy", math.random(-3, 3), i);
		end
	end
	--Create construction
	if math.random(1, 1000) == 1 then
		--City
		if math.random(1, 100) <= 99 then
			sim.partProperty(i, "tmp2", 1);
			sim.partChangeType(i, city);
		--Obliterator cannon
		else
			sim.partChangeType(i, oblitoraterCannon);
		end
	end
end

elements.property(builder, "Update", builderUpdate);

local function builderGraphics(i, colr, colg, colb)
	local r;
	local g;
	local b;
	local tmp = tpt.get_property("tmp", i);
	if tmp == 0 then
		r = 255;
		g = 0;
		b = 0;
	elseif tmp == 1 then
		r = 0;
		g = 255;
		b = 0;
	elseif tmp == 2 then
		r = 0;
		g = 0;
		b = 255;
	elseif tmp == 3 then
		r = 255;
		g = 204;
		b = 0;
	elseif tmp == 4 then
		r = 255;
		g = 255;
		b = 255;
	elseif tmp == 5 then
		r = 153;
		g = 153;
		b = 153;
	end
	return 1,0x00000001,255,r,g,b,255,255,255,255;
end

elements.property(builder, "Graphics", builderGraphics);

--Nuke Missile
nukeMissile = elements.allocate("JosephMA", "MSLE");
elements.element(nukeMissile, elements.element(elements.DEFAULT_PT_PROT));
elements.property(nukeMissile, "Name", "MSLE");
elements.property(nukeMissile, "Colour", 0x5D5D5C);
elements.property(nukeMissile, "Description", "Nuke missile, explodes after a set life time!");
elements.property(nukeMissile, "MenuSection", 16);

local function nukeMissileUpdate(i, x, y, s, n)
	sim.partProperty(i, "life", sim.partProperty(i, "life") - 1);
	if sim.partProperty(i, "life") <= 0 then
		local part = sim.partCreate(-1, x, y, explosion);
		sim.partProperty(part, "life", 1);
		--Explode
		for r in sim.neighbors(x,y,20,20) do
			local part = sim.partCreate(-3, sim.partProperty(r, "x"), sim.partProperty(r, "y"), elements.DEFAULT_PT_PLSM);
			sim.partProperty(part, "life", 300);
			sim.partKill(r);
		end
		sim.partKill(i);
		return 1;
	end
	--Smoke Trail
	local part = sim.partCreate(-1, x, y, elements.DEFAULT_PT_SMKE);
	sim.partProperty(part, "life", 20);
end

elements.property(nukeMissile, "Update", nukeMissileUpdate);

--Obliterator cannon
oblitoraterCannon = elements.allocate("JosephMA", "OBLC");
elements.element(oblitoraterCannon, elements.element(elements.DEFAULT_PT_BRCK));
elements.property(oblitoraterCannon, "HighTemperature", 873.15);
elements.property(oblitoraterCannon, "HighTemperatureTransition", elements.DEFAULT_PT_BRMT);
elements.property(oblitoraterCannon, "Name", "OBLC");
elements.property(oblitoraterCannon, "Description", "Obliterator cannon destroys the universe.");
elements.property(oblitoraterCannon, "MenuSection", elem.SC_SPECIAL);

local function oblitoraterCannonUpdate(i, x, y, s, n)
	if math.random(1, 500) == 1 then
		for r in sim.neighbors(x,y,100,100) do
			local partType = sim.partProperty(r, "type");
			local tmp = tpt.get_property("tmp", i);
			if (partType == ship or partType == bomber or partType == city or partType == mothership or parType == destroyer or partType == builder) and sim.partProperty(r, "tmp") ~= tmp then
				if partType ~= city then
					--Nuke missile
					local part = sim.partCreate(-3, x, y, nukeMissile);
					tpt.set_property("vx", sim.partProperty(r, "x") - x, part);
					tpt.set_property("vy", sim.partProperty(r, "y") - y, part);
					--tpt.set_property("tmp", tmp, part);
					tpt.set_property("life", 65, part);
				else
					--Destroy
					if math.random(1, 50) <= 49 then
						sim.partChangeType(r, rock);
					else
						sim.partChangeType(r, elements.DEFAULT_PT_BOMB);
					end
				end
			end
		end
		--Fire missiles
		for t=0, 50, 1
		do
			local part = sim.partCreate(-3, x, y, missile);
			tpt.set_property("life", math.random() * 150, part);
			local angle = math.random() * 2.0 * math.pi/0.5;
			local v = (math.random()) * 5.0/0.5;
			tpt.set_property("vx", v * math.cos(angle), part);
			tpt.set_property("vy", v * math.sin(angle), part);
		end
	end
end

elements.property(oblitoraterCannon, "Update", oblitoraterCannonUpdate);

local function oblitoraterCannonGraphics(i, colr, colg, colb)
	local r;
	local g;
	local b;
	local tmp = tpt.get_property("tmp", i);
	if tmp == 0 then
		r = 255;
		g = 0;
		b = 0;
	elseif tmp == 1 then
		r = 0;
		g = 255;
		b = 0;
	elseif tmp == 2 then
		r = 0;
		g = 0;
		b = 255;
	elseif tmp == 3 then
		r = 255;
		g = 204;
		b = 0;
	elseif tmp == 4 then
		r = 255;
		g = 255;
		b = 255;
	elseif tmp == 5 then
		r = 153;
		g = 153;
		b = 153;
	end
	tpt.drawline(sim.partProperty(i, "x"), sim.partProperty(i, "y"), sim.partProperty(i, "x") + 5, sim.partProperty(i, "y"), r, g, b)
	return 1,0x00000001,255,r,g,b,255,255,255,255;
end

elements.property(oblitoraterCannon, "Graphics", oblitoraterCannonGraphics);