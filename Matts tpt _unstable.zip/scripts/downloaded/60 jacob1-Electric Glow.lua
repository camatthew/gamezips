
local jmod = tpt.version.jacob1s_mod --my mod has PROP_POWERED and makes things much simpler
if elem.JACOB1_PT_ELGL then elem.free(elem.JACOB1_PT_ELGL) end --don't error with "Identifier already in use"

local ELGL = elem.allocate("JACOB1", "ELGL")
elem.element(ELGL, elem.element(elem.DEFAULT_PT_LCRY))
elem.property(ELGL, "Name", "ELGL")
elem.property(ELGL, "Description", "Electric Glow.")
elem.property(ELGL, "MenuSection", elem.SC_POWERED)
if jmod then
	elem.property(ELGL, "Properties", elem.property(ELGL, "Properties") + elem.PROP_POWERED)
end
local myr,myg,myb = gfx.getColors(elem.property(ELGL, "Color"))

local function update(i,x,y,s,n)
	local life = sim.partProperty(i, sim.FIELD_LIFE)
	if life == 10 then
		for r in sim.neighbors(x,y,1,1) do --loop through neighbors for things that turn it off
			local rtype = sim.partProperty(r, sim.FIELD_TYPE)
			if rtype == ELGL and sim.partProperty(r, sim.FIELD_LIFE) == 9 then
				sim.partProperty(i, sim.FIELD_LIFE, 9)
			elseif rtype == tpt.el.sprk.id and sim.partProperty(r, sim.FIELD_CTYPE) == tpt.el.nscn.id then
				sim.partProperty(i, sim.FIELD_LIFE, 9)
			end
		end
	else
		if life > 0 then sim.partProperty(i, sim.FIELD_LIFE, life-1) return end --decrease life by 1 every frame
		for r in sim.neighbors(x,y,1,1) do --loop through neighbors for things to turn it on
			local rtype = sim.partProperty(r, sim.FIELD_TYPE)
			if rtype == ELGL and sim.partProperty(r, sim.FIELD_LIFE) == 10 then
				sim.partProperty(i, sim.FIELD_LIFE, 10)
			elseif rtype == tpt.el.sprk.id and sim.partProperty(r, sim.FIELD_CTYPE) == tpt.el.pscn.id then
				sim.partProperty(i, sim.FIELD_LIFE, 10)
			end
		end
	end
end
if not jmod then
	elem.property(ELGL, "Update", update)
end

local function graphics(i,colr,colg,colb)
	local life = sim.partProperty(i, sim.FIELD_LIFE)
	if life == 10 then
		local dcolor = sim.partProperty(i, sim.FIELD_DCOLOUR)
		if dcolor ~= 0 then
			local firer,fireg,fireb,firea = gfx.getColors(dcolor)
			return 0,ren.PMODE_FLAT+ren.FIRE_BLEND+ren.PMODE_GLOW,255,colr,colg,colb,firea,firer,fireg,fireb
		else
			return 0,ren.PMODE_FLAT+ren.FIRE_BLEND+ren.PMODE_GLOW,255,colr,colg,colb,255,myr,myg,myb
		end
	end
	return 0,ren.PMODE_FLAT,255,colr,colg,colb,0,0,0,0
end
elem.property(ELGL, "Graphics", graphics)