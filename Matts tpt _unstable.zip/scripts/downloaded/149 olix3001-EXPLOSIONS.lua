
print("MORE EXPLOSIONS")
print("ACTIVE")
print("---------------------------------")
print("by olix3001")
 tpt.el.gas.color = tpt.el.dmnd.color


local SOMB = elements.allocate("MEX" , "SOMB")
elements.property(elements.MEX_PT_SOMB, "Name", "SBOM")
elements.property(elements.MEX_PT_SOMB, "Description", "SUPER BOMB - BIG BOOOOOOOOM")
elements.property(elements.MEX_PT_SOMB, "LowTemperature", 5000)
elements.property(elements.MEX_PT_SOMB, "Flammable", 99999)
elements.property(elements.MEX_PT_SOMB, "Explosive", 99999)
elements.property(elements.MEX_PT_SOMB, "MenuSection" , elem.SC_NUCLEAR)
elements.property(elements.MEX_PT_SOMB, "MenuVisible" , 1)
elements.property(elements.MEX_PT_SOMB,  "Color", 12603472)

 local function UpdateF(i, x, y, s, nt)
 tpt.create(x, y  - 1, 'gas')

 end
elem.property(elem.MEX_PT_SOMB, "Update", UpdateF)



local FGEN = elements.allocate("MEX" , "FGEN")
elements.property(elements.MEX_PT_FGEN, "Name", "FGEN")
elements.property(elements.MEX_PT_FGEN, "Description", "Fire Generator")
elements.property(elements.MEX_PT_FGEN, "LowTemperature", 5000)
elements.property(elements.MEX_PT_FGEN, "Flammable", 0)
elements.property(elements.MEX_PT_FGEN, "Explosive", 0)
elements.property(elements.MEX_PT_FGEN, "MenuSection" , elem.SC_NUCLEAR)
elements.property(elements.MEX_PT_FGEN, "Color", 16715776)

 local function UpdateGenF(i, x, y, s, nt)
 tpt.create(x, y  - 1, 'fire')
 
 end
elem.property(elem.MEX_PT_FGEN, "Update", UpdateGenF)



local FGEN = elements.allocate("MEX" , "PGEN")
elements.property(elements.MEX_PT_PGEN, "Name", "PGEN")
elements.property(elements.MEX_PT_PGEN, "Description", "Fire Generator")
elements.property(elements.MEX_PT_PGEN, "LowTemperature", 5000)
elements.property(elements.MEX_PT_PGEN, "Flammable", 0)
elements.property(elements.MEX_PT_PGEN, "Explosive", 0)
elements.property(elements.MEX_PT_PGEN, "MenuSection" , elem.SC_NUCLEAR)
elements.property(elements.MEX_PT_PGEN, "Color", 12294655)
elements.property(elements.MEX_PT_PGEN,"MenuVisible" , 1)

 local function UpdateGenP(i, x, y, s, nt)
 tpt.create(x, y  - 1, 'plsm')
 
 end
elem.property(elem.MEX_PT_PGEN, "Update", UpdateGenP)