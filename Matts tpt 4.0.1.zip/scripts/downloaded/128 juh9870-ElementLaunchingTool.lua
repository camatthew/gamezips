
--Created by juh9870
--ALT+drag to start using

local mx=0
local my=0
local tmx=0
local tmy=0
local shooting = false
local pressed = false

local function mp(mousex, mousey, button, event)
	if button==1 then
		if event == 1 then
			-- if mousex<612 and mousey<385 then
				if pressed ==true then
					mx = mousex
					my = mousey
					mx, my = sim.adjustCoords(mx, my)
					shooting = true
					return false
				end
			-- end
		end
		if event == 3 then
			if shooting==true then
				tmx = mousex
				tmy = mousey
				tmx, tmy = sim.adjustCoords(tmx, tmy)
				return false
			end
		end
		if event == 2 then
			if shooting==true then
				local elem = simulation.createParts(mx,my, 0, 0)
				tpt.set_property("vx", (mx-tmx)/4, mx, my)
				tpt.set_property("vy", (my-tmy)/4, mx, my)
				mx = 0
				my = 0
				tmx = 0
				tmy = 0
				shooting=false
				return false
			end
		end
	end
end

local function st()
	if shooting==true then
		tpt.drawline(mx, my,mx+(mx-tmx),my+(my-tmy))
	end
end

local function kc(key, nkey, modifier, event)
	if nkey==308 or nkey == 307 then
		if event == 1 then
			pressed=true
		else
			pressed=false
		end
	end
end

tpt.register_step(st)
tpt.register_keypress(kc)
tpt.register_mouseclick(mp)