
--[[
        Logic gates mod for TPT:
 
        AND: SPRKs nearby NSCN when powered by 2 or more PSCN
        OR: Conducts from PSCN and to NSCN
        NOT: SPRKs nearby NSCN unless powered by PSCN
        XOR: SPRKs nearby NSCN if powered by ONE PSCN
        NAND: SPRKs nearby NSCN unless powered by 2 or more PSCN
        XNOR: SPRKs nearby NSCN unless powered by ONE PSCN
--]]
 
local frame_counter = 0         -- Counter to prevent crazy nots.
local frame_max = 8             -- More stuff to prevent crazy nots.
 
local el_and = elements.allocate("logic", "and")
-- (Begin AND properties)
 elements.element(el_and, elements.element(elements.DEFAULT_PT_BRCK))
 elements.property(el_and, "Name", "AND")
 elements.property(el_and, "Colour", 0x800000)
 elements.property(el_and, "Description", "AND logic gate. Input PSCN, output NSCN")
 elements.property(el_and, "MenuSection", 1)
-- (End AND properties)
 
local el_or = elements.allocate("logic", "or")
-- (Begin OR properties)
 elements.element(el_or, elements.element(elements.DEFAULT_PT_BRCK))
 elements.property(el_or, "Name", "OR")
 elements.property(el_or, "Colour", 0x800000)
 elements.property(el_or, "Description", "OR logic gate. Input PSCN, output NSCN")
 elements.property(el_or, "MenuSection", 1)
-- (End OR properties)
 
local el_not= elements.allocate("logic", "not")
-- (Begin NOT properties)
 elements.element(el_not, elements.element(elements.DEFAULT_PT_BRCK))
 elements.property(el_not, "Name", "NOT")
 elements.property(el_not, "Colour", 0x800000)
 elements.property(el_not, "Description", "NOT logic gate. Input PSCN, output NSCN")
 elements.property(el_not, "MenuSection", 1)
-- (End NOT properties)
 
local el_xor = elements.allocate("logic", "xor")
-- (Begin OR properties)
 elements.element(el_xor, elements.element(elements.DEFAULT_PT_BRCK))
 elements.property(el_xor, "Name", "XOR")
 elements.property(el_xor, "Colour", 0x800000)
 elements.property(el_xor, "Description", "XOR logic gate. Input PSCN, output NSCN")
 elements.property(el_xor, "MenuSection", 1)
-- (End OR properties)
 
local el_nand = elements.allocate("logic", "nand")
-- (Begin NAND properties)
 elements.element(el_nand, elements.element(elements.DEFAULT_PT_BRCK))
 elements.property(el_nand, "Name", "NAND")
 elements.property(el_nand, "Colour", 0x800000)
 elements.property(el_nand, "Description", "NAND logic gate. Input PSCN, output NSCN")
 elements.property(el_nand, "MenuSection", 1)
-- (End NAND properties)
 
local el_xnor = elements.allocate("logic", "xnor")
-- (Begin XNOR properties)
 elements.element(el_xnor, elements.element(elements.DEFAULT_PT_BRCK))
 elements.property(el_xnor, "Name", "XNOR")
 elements.property(el_xnor, "Colour", 0x800000)
 elements.property(el_xnor, "Description", "XNOR logic gate. Input PSCN, output NSCN")
 elements.property(el_xnor, "MenuSection", 1)
-- (End XNOR properties)
 
-- Update Functions
-- AND
function and_update(index, partx, party, surround, nt)
        local n_pscn = 0        -- number of SPRK(PSCN found)
 
        for dx = -2, 2, 1 do
                for dy = -2, 2, 1 do
                        if tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_SPRK and tpt.get_property("ctype", partx + dx, party + dy) == elements.DEFAULT_PT_PSCN then
                                n_pscn = n_pscn + 1 -- Increment PSCN count
                        end
                end
        end
 
        if n_pscn >= 2 then
                for dx = -2, 2, 1 do
                        for dy = -2, 2, 1 do
                                if tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_NSCN and tpt.get_property("life", partx + dx, party + dy) == 0 then
                                        tpt.set_property("life", 4, partx + dx, party + dy)     -- SPRK nscn
                                        tpt.set_property("ctype", elements.DEFAULT_PT_NSCN, partx + dx, party + dy)
                                        tpt.set_property("type", elements.DEFAULT_PT_SPRK, partx + dx, party + dy)
                                end
                        end
                end
        end
        return 0
end
 
-- OR
function or_update(index, partx, party, surround, nt)
        local n_pscn = 0        -- number of SPRK(PSCN found)
 
        for dx = -2, 2, 1 do
                for dy = -2, 2, 1 do
                        if tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_SPRK and tpt.get_property("ctype", partx + dx, party + dy) == elements.DEFAULT_PT_PSCN then
                                n_pscn = n_pscn + 1     -- Increment PSCN count
                        end
                end
        end
 
        if n_pscn >= 1 then
                for dx = -2, 2, 1 do
                        for dy = -2, 2, 1 do
                                if tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_NSCN and tpt.get_property("life", partx + dx, party + dy) == 0 then
                                        tpt.set_property("life", 4, partx + dx, party + dy)     -- SPRK nscn
                                        tpt.set_property("ctype", elements.DEFAULT_PT_NSCN, partx + dx, party + dy)
                                        tpt.set_property("type", elements.DEFAULT_PT_SPRK, partx + dx, party + dy)
                                end
                        end
                end
        end
        return 0
end
 
-- NOT
function not_update(index, partx, party, surround, nt)
        frame_counter = frame_counter + 1;
        if frame_counter == frame_max then
                frame_counter = 0
        end
 
        local n_pscn = 0        -- number of SPRK(PSCN found)
 
        for dx = -2, 2, 1 do
                for dy = -2, 2, 1 do
                        if (tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_SPRK and tpt.get_property("ctype", partx + dx, party + dy) == elements.DEFAULT_PT_PSCN) or (tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_PSCN and tpt.get_property("life", partx + dx, party + dy) > 0) then
                                n_pscn = n_pscn + 1     -- Increment PSCN count
                        end
                end
        end
 
        if n_pscn == 0 and frame_counter == 0 then
                for dx = -2, 2, 1 do
                        for dy = -2, 2, 1 do
                                if tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_NSCN and tpt.get_property("life", partx + dx, party + dy) == 0 then
                                        tpt.set_property("life", 4, partx + dx, party + dy)     -- SPRK nscn
                                        tpt.set_property("ctype", elements.DEFAULT_PT_NSCN, partx + dx, party + dy)
                                        tpt.set_property("type", elements.DEFAULT_PT_SPRK, partx + dx, party + dy)
                                end
                        end
                end
        end
        return 0
end
 
-- XOR
function xor_update(index, partx, party, surround, nt)
        local n_pscn = 0        -- number of SPRK(PSCN found)
 
        for dx = -2, 2, 1 do
                for dy = -2, 2, 1 do
                        if tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_SPRK and tpt.get_property("ctype", partx + dx, party + dy) == elements.DEFAULT_PT_PSCN then
                                n_pscn = n_pscn + 1     -- Increment PSCN count
                        end
                end
        end
 
        if n_pscn == 1 then
                for dx = -2, 2, 1 do
                        for dy = -2, 2, 1 do
                                if tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_NSCN and tpt.get_property("life", partx + dx, party + dy) == 0 then
                                        tpt.set_property("life", 4, partx + dx, party + dy)     -- SPRK nscn
                                        tpt.set_property("ctype", elements.DEFAULT_PT_NSCN, partx + dx, party + dy)
                                        tpt.set_property("type", elements.DEFAULT_PT_SPRK, partx + dx, party + dy)
                                end
                        end
                end
        end
        return 0
end
 
-- NAND
function nand_update(index, partx, party, surround, nt)
        frame_counter = frame_counter + 1;
        if frame_counter == frame_max then
                frame_counter = 0
        end
       
        local n_pscn = 0        -- number of SPRK(PSCN found)
       
 
        for dx = -2, 2, 1 do
                for dy = -2, 2, 1 do
                        if (tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_SPRK and tpt.get_property("ctype", partx + dx, party + dy) == elements.DEFAULT_PT_PSCN) or (tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_PSCN and tpt.get_property("life", partx + dx, party + dy) > 0) then
                                n_pscn = n_pscn + 1     -- Increment PSCN count
                        end
                end
        end
 
        if n_pscn < 2 and frame_counter == 0 then
                for dx = -2, 2, 1 do
                        for dy = -2, 2, 1 do
                                if tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_NSCN and tpt.get_property("life", partx + dx, party + dy) == 0 then
                                        tpt.set_property("life", 4, partx + dx, party + dy)     -- SPRK nscn
                                        tpt.set_property("ctype", elements.DEFAULT_PT_NSCN, partx + dx, party + dy)
                                        tpt.set_property("type", elements.DEFAULT_PT_SPRK, partx + dx, party + dy)
                                end
                        end
                end
        end
        return 0
end
 
-- XNOR
function xnor_update(index, partx, party, surround, nt)
        frame_counter = frame_counter + 1;
        if frame_counter == frame_max then
                frame_counter = 0
        end
       
        local n_pscn = 0        -- number of SPRK(PSCN found)
 
        for dx = -2, 2, 1 do
                for dy = -2, 2, 1 do
                        if (tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_SPRK and tpt.get_property("ctype", partx + dx, party + dy) == elements.DEFAULT_PT_PSCN) or (tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_PSCN and tpt.get_property("life", partx + dx, party + dy) > 0) then
                                n_pscn = n_pscn + 1     -- Increment PSCN count
                        end
                end
        end
 
        if (n_pscn ~= 1) and frame_counter == 0 then
                for dx = -2, 2, 1 do
                        for dy = -2, 2, 1 do
                                if tpt.get_property("type", partx + dx, party + dy) == elements.DEFAULT_PT_NSCN and tpt.get_property("life", partx + dx, party + dy) == 0 then
                                        tpt.set_property("life", 4, partx + dx, party + dy)     -- SPRK nscn
                                        tpt.set_property("ctype", elements.DEFAULT_PT_NSCN, partx + dx, party + dy)
                                        tpt.set_property("type", elements.DEFAULT_PT_SPRK, partx + dx, party + dy)
                                end
                        end
                end
        end
        return 0
end
 
-- Update Function Properties
elements.property(el_and, "Update", and_update)
elements.property(el_or, "Update", or_update)
elements.property(el_not, "Update", not_update)
elements.property(el_xor, "Update", xor_update)
elements.property(el_nand, "Update", nand_update)
elements.property(el_xnor, "Update", xnor_update)
 
--[[  ^_^  ]]-- TPT logic gates mod, iamdumb