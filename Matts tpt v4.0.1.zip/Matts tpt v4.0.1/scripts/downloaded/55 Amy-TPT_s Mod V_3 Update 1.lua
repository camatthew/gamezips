
--TPT's Mod
--Please use cracker64's script manager
--VER 3 UPDATE http://pastebin.com/raw.php?i=jQZ58x68

--Version 3

--Draws starting texts

print("TPT's Mod")
print("Version 3")
print("Update 0")
print("Created by Amy. All elements were reprogrammed and compiled into a single file.")
print("Contact via email or http://powdertoy.co.uk")
print("New programming by RCAProduction")

--TUNG Mod :D

local function moo(i, x, y, surround_space, nt)
	if sim.pressure(x/4, y/4)<-7 and sim.partProperty(i, sim.FIELD_LIFE)~=0 and surround_space~=0 then
		sim.partCreate(-1, x+math.random(-3,3), y+math.random(-3,3), elem.DEFAULT_PT_ELEC)
	end
end
tpt.element_func(moo, tpt.el.tung.id, 0)

tpt.el.tung.description="Tungsten. Brittle metal with a very high melting point. When sparked under a pressure of -7, emits electrons."

--METR Element

local METR = elements.allocate("ELEMENT", "METR")
elements.element(elements.ELEMENT_PT_METR, elements.element(elements.DEFAULT_PT_ELEC))
elements.property(elements.ELEMENT_PT_METR, "Name", "METR")
elements.property(elements.ELEMENT_PT_METR, "Description", "Meteors, Explode on impact. Use sparingly.")
elements.property(elements.ELEMENT_PT_METR, "Colour", 0xFF7A0002)
elements.property(elements.ELEMENT_PT_METR, "MenuSection", elem.SC_EXPLOSIVE)
elements.property(elements.ELEMENT_PT_METR, "MenuVisible", 1)
elements.property(elements.ELEMENT_PT_METR, "Weight", 100)
elements.property(elements.ELEMENT_PT_METR, "Temperature", 9999)
local function graphics1(i, colr, colg, colb)
	return 1,0x00010000,255,225,0,210,255,255,255,255
end
tpt.graphics_func(graphics1,METR)

local function get_property(prop, x, y)
	if x >= 0 and x < sim.XRES and y >=0 and y < sim.YRES then
		return tpt.get_property(prop, x, y)
	end
	return 0
end

math.randomseed(os.time())
local function metr_update(i, x, y, s, n)
	if tpt.get_property("tmp",i)==0 then
		tpt.parts[i].tmp=1
		randvel=math.random(-20,20)/10
		tpt.parts[i].vx=randvel
		tpt.parts[i].vy=math.sqrt(8-(randvel^2))
	end

	xvel=tpt.get_property("vx",i)/2
	yvel=tpt.get_property("vy",i)/2
	if yvel <= 0 or math.abs(xvel) > 1 then
		tpt.delete(i)
	end

	xpos=x-xvel
	ypos=y-yvel
	elemtype=get_property("type",xpos,ypos)

	if elemtype == 0 then
		tpt.create(xpos,ypos,"bray")
		tpt.set_property("temp",5000,xpos,ypos)
	end
	tpt.parts[i].temp=9999

	elemtype25=get_property("type",x+xvel*5,y+yvel*5)
	elemtype24=get_property("type",x+xvel*4,y+yvel*4)
	elemtype23=get_property("type",x+xvel*3,y+yvel*3)
	elemtype22=get_property("type",x+xvel*2,y+yvel*2)
	elemtype21=get_property("type",x+xvel,y+yvel)
	if elemtype25 ~= 0 and elemtype25 ~= elements.ELEMENT_PT_METR and elemtype25 ~= tpt.el.bray.id and elemtype25 ~= tpt.el.dmnd.id and elemtype25 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype24 ~= 0 and elemtype24 ~= elements.ELEMENT_PT_METR and elemtype24 ~= tpt.el.bray.id and elemtype24 ~= tpt.el.dmnd.id and elemtype24 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype23 ~= 0 and elemtype23 ~= elements.ELEMENT_PT_METR and elemtype23 ~= tpt.el.bray.id and elemtype23 ~= tpt.el.dmnd.id and elemtype23 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype22 ~= 0 and elemtype22 ~= elements.ELEMENT_PT_METR and elemtype22 ~= tpt.el.bray.id and elemtype22 ~= tpt.el.dmnd.id and elemtype22 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype21 ~= 0 and elemtype21 ~= elements.ELEMENT_PT_METR and elemtype21 ~= tpt.el.bray.id and elemtype21 ~= tpt.el.dmnd.id and elemtype21 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	end
end

tpt.element_func(metr_update, elements.ELEMENT_PT_METR,1)

--BMBR Element {Amy}

local BMBR = elements.allocate("ELEMENT", "BMBR")
elements.element(elements.ELEMENT_PT_BMBR, elements.element(elements.DEFAULT_PT_ELEC))
elements.property(elements.ELEMENT_PT_BMBR, "Name", "BMBR")
elements.property(elements.ELEMENT_PT_BMBR, "Description", "Right Shooting Bomb.")
elements.property(elements.ELEMENT_PT_BMBR, "Colour", 0xFF31CBD9)
elements.property(elements.ELEMENT_PT_BMBR, "MenuSection", elem.SC_EXPLOSIVE)
elements.property(elements.ELEMENT_PT_BMBR, "MenuVisible", 1)
elements.property(elements.ELEMENT_PT_BMBR, "Weight", 100)
elements.property(elements.ELEMENT_PT_BMBR, "Temperature", 9999)
local function graphics1(i, colr, colg, colb)
	return 1,0x00010000,255,225,0,210,255,255,255,255
end
tpt.graphics_func(graphics1,BMBR)

local function get_property(prop, x, y)
	if x >= 0 and x < sim.XRES and y >=0 and y < sim.YRES then
		return tpt.get_property(prop, x, y)
	end
	return 0
end

math.randomseed(os.time())
local function BMBR_update(i, x, y, s, n)
	if tpt.get_property("tmp",i)==0 then
		tpt.parts[i].tmp=1
		--randvel=math.random(-20,20)/10
		tpt.parts[i].vx=3
		tpt.parts[i].vy=0
	end

	xvel=3
	yvel=0
	if math.abs(xvel) < 1 then
		tpt.delete(i)
	end

	xpos=x-xvel
	ypos=y-yvel
	elemtype=get_property("type",xpos,ypos)

	if elemtype == 0 then
		tpt.create(xpos,ypos,"bray")
		tpt.set_property("temp",5000,xpos,ypos)
	end
	tpt.parts[i].temp=9999

	elemtype25=get_property("type",x+xvel*5,y+yvel*5)
	elemtype24=get_property("type",x+xvel*4,y+yvel*4)
	elemtype23=get_property("type",x+xvel*3,y+yvel*3)
	elemtype22=get_property("type",x+xvel*2,y+yvel*2)
	elemtype21=get_property("type",x+xvel,y+yvel)
	if elemtype25 ~= 0 and elemtype25 ~= elements.ELEMENT_PT_BMBR and elemtype25 ~= tpt.el.bray.id and elemtype25 ~= tpt.el.dmnd.id and elemtype25 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype24 ~= 0 and elemtype24 ~= elements.ELEMENT_PT_BMBR and elemtype24 ~= tpt.el.bray.id and elemtype24 ~= tpt.el.dmnd.id and elemtype24 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype23 ~= 0 and elemtype23 ~= elements.ELEMENT_PT_BMBR and elemtype23 ~= tpt.el.bray.id and elemtype23 ~= tpt.el.dmnd.id and elemtype23 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype22 ~= 0 and elemtype22 ~= elements.ELEMENT_PT_BMBR and elemtype22 ~= tpt.el.bray.id and elemtype22 ~= tpt.el.dmnd.id and elemtype22 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype21 ~= 0 and elemtype21 ~= elements.ELEMENT_PT_BMBR and elemtype21 ~= tpt.el.bray.id and elemtype21 ~= tpt.el.dmnd.id and elemtype21 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	end
end

tpt.element_func(BMBR_update, elements.ELEMENT_PT_BMBR,1)

--BMBL Element {Amy}

local BMBL = elements.allocate("ELEMENT", "BMBL")
elements.element(elements.ELEMENT_PT_BMBL, elements.element(elements.DEFAULT_PT_ELEC))
elements.property(elements.ELEMENT_PT_BMBL, "Name", "BMBL")
elements.property(elements.ELEMENT_PT_BMBL, "Description", "Left Shooting Bomb.")
elements.property(elements.ELEMENT_PT_BMBL, "Colour", 0xFF20878E)
elements.property(elements.ELEMENT_PT_BMBL, "MenuSection", elem.SC_EXPLOSIVE)
elements.property(elements.ELEMENT_PT_BMBL, "MenuVisible", 1)
elements.property(elements.ELEMENT_PT_BMBL, "Weight", 100)
elements.property(elements.ELEMENT_PT_BMBL, "Temperature", 9999)
local function graphics1(i, colr, colg, colb)
	return 1,0x00010000,255,225,0,210,255,255,255,255
end
tpt.graphics_func(graphics1,BMBL)

local function get_property(prop, x, y)
	if x >= 0 and x < sim.XRES and y >=0 and y < sim.YRES then
		return tpt.get_property(prop, x, y)
	end
	return 0
end

math.randomseed(os.time())
local function BMBL_update(i, x, y, s, n)
	if tpt.get_property("tmp",i)==0 then
		tpt.parts[i].tmp=1
		--randvel=math.random(-20,20)/10
		tpt.parts[i].vx=-3
		tpt.parts[i].vy=0
	end

	xvel=-3
	yvel=0
	if math.abs(xvel) < 1 then
		tpt.delete(i)
	end

	xpos=x-xvel
	ypos=y-yvel
	elemtype=get_property("type",xpos,ypos)

	if elemtype == 0 then
		tpt.create(xpos,ypos,"bray")
		tpt.set_property("temp",5000,xpos,ypos)
	end
	tpt.parts[i].temp=9999

	elemtype25=get_property("type",x+xvel*5,y+yvel*5)
	elemtype24=get_property("type",x+xvel*4,y+yvel*4)
	elemtype23=get_property("type",x+xvel*3,y+yvel*3)
	elemtype22=get_property("type",x+xvel*2,y+yvel*2)
	elemtype21=get_property("type",x+xvel,y+yvel)
	if elemtype25 ~= 0 and elemtype25 ~= elements.ELEMENT_PT_BMBL and elemtype25 ~= tpt.el.bray.id and elemtype25 ~= tpt.el.dmnd.id and elemtype25 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype24 ~= 0 and elemtype24 ~= elements.ELEMENT_PT_BMBL and elemtype24 ~= tpt.el.bray.id and elemtype24 ~= tpt.el.dmnd.id and elemtype24 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype23 ~= 0 and elemtype23 ~= elements.ELEMENT_PT_BMBL and elemtype23 ~= tpt.el.bray.id and elemtype23 ~= tpt.el.dmnd.id and elemtype23 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype22 ~= 0 and elemtype22 ~= elements.ELEMENT_PT_BMBL and elemtype22 ~= tpt.el.bray.id and elemtype22 ~= tpt.el.dmnd.id and elemtype22 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype21 ~= 0 and elemtype21 ~= elements.ELEMENT_PT_BMBL and elemtype21 ~= tpt.el.bray.id and elemtype21 ~= tpt.el.dmnd.id and elemtype21 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	end
end

tpt.element_func(BMBL_update, elements.ELEMENT_PT_BMBL,1)

--MRTR {Amy}

local MRTR = elements.allocate("ELEMENT", "MRTR")
elements.element(elements.ELEMENT_PT_MRTR, elements.element(elements.DEFAULT_PT_ELEC))
elements.property(elements.ELEMENT_PT_MRTR, "Name", "MRTR")
elements.property(elements.ELEMENT_PT_MRTR, "Description", "Mortar Right.")
elements.property(elements.ELEMENT_PT_MRTR, "Colour", 0xFF2E01E3)
elements.property(elements.ELEMENT_PT_MRTR, "MenuSection", elem.SC_EXPLOSIVE)
elements.property(elements.ELEMENT_PT_MRTR, "MenuVisible", 1)
elements.property(elements.ELEMENT_PT_MRTR, "Weight", 100)
elements.property(elements.ELEMENT_PT_MRTR, "Temperature", 9999)
local function graphics1(i, colr, colg, colb)
	return 1,0x00010000,255,225,0,210,255,255,255,255
end
tpt.graphics_func(graphics1,MRTR)

local function get_property(prop, x, y)
	if x >= 0 and x < sim.XRES and y >=0 and y < sim.YRES then
		return tpt.get_property(prop, x, y)
	end
	return 0
end

math.randomseed(os.time())
local function MRTR_update(i, x, y, s, n)
	if tpt.get_property("tmp",i)==0 then
		tpt.parts[i].tmp=1
		--randvel=math.random(-20,20)/10
		tpt.parts[i].vx=3
		tpt.parts[i].vy=3
	end

	xvel=3
	yvel=3
	if math.abs(xvel) < 1 then
		tpt.delete(i)
	end

	xpos=x-xvel
	ypos=y-yvel
	elemtype=get_property("type",xpos,ypos)

	if elemtype == 0 then
		tpt.create(xpos,ypos,"bray")
		tpt.set_property("temp",5000,xpos,ypos)
	end
	tpt.parts[i].temp=9999

	elemtype25=get_property("type",x+xvel*5,y+yvel*5)
	elemtype24=get_property("type",x+xvel*4,y+yvel*4)
	elemtype23=get_property("type",x+xvel*3,y+yvel*3)
	elemtype22=get_property("type",x+xvel*2,y+yvel*2)
	elemtype21=get_property("type",x+xvel,y+yvel)
	if elemtype25 ~= 0 and elemtype25 ~= elements.ELEMENT_PT_MRTR and elemtype25 ~= tpt.el.bray.id and elemtype25 ~= tpt.el.dmnd.id and elemtype25 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype24 ~= 0 and elemtype24 ~= elements.ELEMENT_PT_MRTR and elemtype24 ~= tpt.el.bray.id and elemtype24 ~= tpt.el.dmnd.id and elemtype24 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype23 ~= 0 and elemtype23 ~= elements.ELEMENT_PT_MRTR and elemtype23 ~= tpt.el.bray.id and elemtype23 ~= tpt.el.dmnd.id and elemtype23 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype22 ~= 0 and elemtype22 ~= elements.ELEMENT_PT_MRTR and elemtype22 ~= tpt.el.bray.id and elemtype22 ~= tpt.el.dmnd.id and elemtype22 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype21 ~= 0 and elemtype21 ~= elements.ELEMENT_PT_MRTR and elemtype21 ~= tpt.el.bray.id and elemtype21 ~= tpt.el.dmnd.id and elemtype21 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	end
end

tpt.element_func(MRTR_update, elements.ELEMENT_PT_MRTR,1)

--MRTL {Amy}

local MRTL = elements.allocate("ELEMENT", "MRTL")
elements.element(elements.ELEMENT_PT_MRTL, elements.element(elements.DEFAULT_PT_ELEC))
elements.property(elements.ELEMENT_PT_MRTL, "Name", "MRTL")
elements.property(elements.ELEMENT_PT_MRTL, "Description", "Motar Left.")
elements.property(elements.ELEMENT_PT_MRTL, "Colour", 0xFF5068E4)
elements.property(elements.ELEMENT_PT_MRTL, "MenuSection", elem.SC_EXPLOSIVE)
elements.property(elements.ELEMENT_PT_MRTL, "MenuVisible", 1)
elements.property(elements.ELEMENT_PT_MRTL, "Weight", 100)
elements.property(elements.ELEMENT_PT_MRTL, "Temperature", 9999)
local function graphics1(i, colr, colg, colb)
	return 1,0x00010000,255,225,0,210,255,255,255,255
end
tpt.graphics_func(graphics1,MRTL)

local function get_property(prop, x, y)
	if x >= 0 and x < sim.XRES and y >=0 and y < sim.YRES then
		return tpt.get_property(prop, x, y)
	end
	return 0
end

math.randomseed(os.time())
local function MRTL_update(i, x, y, s, n)
	if tpt.get_property("tmp",i)==0 then
		tpt.parts[i].tmp=1
		--randvel=math.random(-20,20)/10
		tpt.parts[i].vx=-3
		tpt.parts[i].vy=3
	end

	xvel=-3
	yvel=3
	if math.abs(xvel) < 1 then
		tpt.delete(i)
	end

	xpos=x-xvel
	ypos=y-yvel
	elemtype=get_property("type",xpos,ypos)

	if elemtype == 0 then
		tpt.create(xpos,ypos,"bray")
		tpt.set_property("temp",5000,xpos,ypos)
	end
	tpt.parts[i].temp=9999

	elemtype25=get_property("type",x+xvel*5,y+yvel*5)
	elemtype24=get_property("type",x+xvel*4,y+yvel*4)
	elemtype23=get_property("type",x+xvel*3,y+yvel*3)
	elemtype22=get_property("type",x+xvel*2,y+yvel*2)
	elemtype21=get_property("type",x+xvel,y+yvel)
	if elemtype25 ~= 0 and elemtype25 ~= elements.ELEMENT_PT_MRTL and elemtype25 ~= tpt.el.bray.id and elemtype25 ~= tpt.el.dmnd.id and elemtype25 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype24 ~= 0 and elemtype24 ~= elements.ELEMENT_PT_MRTL and elemtype24 ~= tpt.el.bray.id and elemtype24 ~= tpt.el.dmnd.id and elemtype24 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype23 ~= 0 and elemtype23 ~= elements.ELEMENT_PT_MRTL and elemtype23 ~= tpt.el.bray.id and elemtype23 ~= tpt.el.dmnd.id and elemtype23 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype22 ~= 0 and elemtype22 ~= elements.ELEMENT_PT_MRTL and elemtype22 ~= tpt.el.bray.id and elemtype22 ~= tpt.el.dmnd.id and elemtype22 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	elseif elemtype21 ~= 0 and elemtype21 ~= elements.ELEMENT_PT_MRTL and elemtype21 ~= tpt.el.bray.id and elemtype21 ~= tpt.el.dmnd.id and elemtype21 ~= tpt.el.void.id then
		tpt.set_property("type","bomb",i)
		tpt.set_property("life",0,i)
		tpt.set_property("tmp",0,i)
	end
end

tpt.element_func(MRTL_update, elements.ELEMENT_PT_MRTL,1)

--PLSM Copy For Explosives {Amy}

local amy1 = elements.allocate("AMY", "IGNT")
elements.element(elements.AMY_PT_IGNT, elements.element(elements.DEFAULT_PT_GAS))
elements.property(elements.AMY_PT_IGNT, "Name", "IGNT")
elements.property(elements.AMY_PT_IGNT, "Description", "Igniter. Use to ignite explosives, hotter than fire.")
elements.property(elements.AMY_PT_IGNT, "Colour", 0xFFE52961)
elements.property(elements.AMY_PT_IGNT, "MenuSection", 5)
elements.property(elements.AMY_PT_IGNT, "MenuVisible", 1)
elements.property(elements.AMY_PT_IGNT, "Temperature", 5000)
elements.property(elements.AMY_PT_IGNT, "Weight", 0)
elements.property(elements.AMY_PT_IGNT, "Flammable", 1)
elements.property(elements.AMY_PT_IGNT, "Explosive", 0)

--Strong Metal {Amy}

local STEL = elements.allocate("AMY", "STEL")
elements.element(elements.AMY_PT_STEL, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.AMY_PT_STEL, "Name", "STEL")
elements.property(elements.AMY_PT_STEL, "Description", "Special Steel. Resists heat transfer, and is nearly impossible to destroy.")
elements.property(elements.AMY_PT_STEL, "Colour", 0x474747)
elements.property(elements.AMY_PT_STEL, "MenuSection", elem.SC_SOLID)
elements.property(elements.AMY_PT_STEL, "MenuVisible", 1)
elements.property(elements.AMY_PT_STEL, "Weight", 1000)
elements.property(elements.AMY_PT_STEL, "Temperature", 293)
elements.property(elements.AMY_PT_STEL, "HeatConduct", 1)
elements.property(elements.AMY_PT_STEL, "HighTemperature", 7000)

--Strong Brick [Non Conductive] {Amy}

local SNGB = elements.allocate("AMY", "SNGB")
elements.element(elements.AMY_PT_SNGB, elements.element(elements.DEFAULT_PT_BRCK))
elements.property(elements.AMY_PT_SNGB, "Name", "SNGB")
elements.property(elements.AMY_PT_SNGB, "Description", "Extremely Strong Brick. Resists heat transfer.")
elements.property(elements.AMY_PT_SNGB, "Colour", 0x989898)
elements.property(elements.AMY_PT_SNGB, "MenuSection", elem.SC_SOLID)
elements.property(elements.AMY_PT_SNGB, "MenuVisible", 1)
elements.property(elements.AMY_PT_SNGB, "Weight", 1000)
elements.property(elements.AMY_PT_SNGB, "Temperature", 293)
elements.property(elements.AMY_PT_SNGB, "HeatConduct", 1)
elements.property(elements.AMY_PT_SNGB, "HighTemperature", 7000)
elements.property(elements.AMY_PT_SNGB, "HighPressure", 37)

--Strong Glass [No Shatter] {Amy}

local SNGL = elements.allocate("AMY", "SUGL")
elements.element(elements.AMY_PT_SUGL, elements.element(elements.DEFAULT_PT_GLAS))
elements.property(elements.AMY_PT_SUGL, "Name", "SUGL")
elements.property(elements.AMY_PT_SUGL, "Description", "Super Glass. Hard to shatter.")
elements.property(elements.AMY_PT_SUGL, "Colour", 0x007475)
elements.property(elements.AMY_PT_SUGL, "MenuSection", elem.SC_SOLID)
elements.property(elements.AMY_PT_SUGL, "MenuVisible", 1)
elements.property(elements.AMY_PT_SUGL, "Weight", 750)
elements.property(elements.AMY_PT_SUGL, "Temperature", 293)
elements.property(elements.AMY_PT_SUGL, "HeatConduct", 3)
elements.property(elements.AMY_PT_SUGL, "HighTemperature", 6750)
elements.property(elements.AMY_PT_SUGL, "HighPressure", 37)
elements.property(elements.AMY_PT_SUGL, "HighPressureTransition", elem.DEFAULT_PT_BGLA)

--Copper {Amy}

--[[{UNFINISHED}local COPR = elements.allocate("AMY", "COPR")
elements.element(elements.AMY_PT_COPR, elements.element(elements.DEFAULT_PT_GOLD))
elements.property(elements.AMY_PT_COPR, "Name", "COPR")
elements.property(elements.AMY_PT_COPR, "Description", "Copper. Very conductive, with a low melting point.")
elements.property(elements.AMY_PT_COPR, "Colour", 0xB36500)
elements.property(elements.AMY_PT_COPR, "MenuSection", elem.SC_ELEC)
elements.property(elements.AMY_PT_COPR, "MenuVisible", 1)
elements.property(elements.AMY_PT_COPR, "Temperature", 293)
elements.property(elements.AMY_PT_COPR, "HeatConduct", 100)
elements.property(elements.AMY_PT_COPR, "HighTemperature", 1500)

{DISREGARD THESE FUNCTIONS}

--local function get_property(prop, x, y)
--if sim.partNeighbours(x, y, 4, AMY_PT_COPR) == elem.DEFAULT_PT_SPRK then print("SPRKED")
--end
--if sim.partProperty(AMY_PT_COPR, FIELD_TYPE) == "sprk" then sim.partProperty(AMY_PT_COPR, object field, object value)

-- end
function sprk(i,x,y,s,n)
	if sim.partNeighbours(i, x, y, 4, AMY_PT_COPR) == elem.DEFAULT_PT_SPRK then print("SPRKED")
	end
end
]]

--Liquid Hydrogen {Extensively Edited by Amy}

local LHYG = elements.allocate('AMY', 'LHYG')
elements.element(LHYG, elements.element(elements.DEFAULT_PT_GLOW))
elements.property(elements.AMY_PT_LHYG, "Name", "LHYG")
elements.property(elements.AMY_PT_LHYG, "Description", "Liquid Hydrogen.")
elements.property(elements.AMY_PT_LHYG, "Color", 0x99FFFF)
elements.property(elements.AMY_PT_LHYG, "MenuSection", elem.SC_LIQUID)
elements.property(elements.AMY_PT_LHYG, "Gravity", 0.4)
elements.property(elements.AMY_PT_LHYG, "Falldown", 2)
elements.property(elements.AMY_PT_LHYG, "Flammable", 16384)
elements.property(elements.AMY_PT_LHYG, "Explosive", 1)
elements.property(elements.AMY_PT_LHYG, "Temperature", 0)
elements.property(elements.AMY_PT_LHYG, "HighTemperature", 60)
elements.property(elements.AMY_PT_LHYG, "HighTemperatureTransition", elem.DEFAULT_PT_HYGN)
local function Lflare(i, colr, colg, colb)
	return 1, 0x00000004, 255, 153, 255, 255, 255, 153, 255, 255
end
tpt.graphics_func(Lflare, elements.AMY_PT_LHYG)

--Change HYGN so it changes states with LHYG

elements.property(elements.DEFAULT_PT_HYGN, "LowTemperature", 60)
elements.property(elements.DEFAULT_PT_HYGN, "LowTemperatureTransition", elements.AMY_PT_LHYG)

--BPDR Element

local element1 = elements.allocate("FEYNMAN", "BPDR")
elements.element(elements.FEYNMAN_PT_BPDR, elements.element(elements.DEFAULT_PT_BCOL))
elements.property(elements.FEYNMAN_PT_BPDR, "Name", "BPDR")
elements.property(elements.FEYNMAN_PT_BPDR, "Description", "Black Powder, Very explosive.")
elements.property(elements.FEYNMAN_PT_BPDR, "Colour", 0x353535)
elements.property(elements.FEYNMAN_PT_BPDR, "MenuSection", 5)
elements.property(elements.FEYNMAN_PT_BPDR, "Gravity", .5)
elements.property(elements.FEYNMAN_PT_BPDR, "Flammable", 10000)
elements.property(elements.FEYNMAN_PT_BPDR, "Explosive", 1)
elements.property(elements.FEYNMAN_PT_BPDR, "Loss", 1)
elements.property(elements.FEYNMAN_PT_BPDR, "AirLoss", .5)
elements.property(elements.FEYNMAN_PT_BPDR, "AirDrag", .01)
elements.property(elements.FEYNMAN_PT_BPDR, "Advection", .01)
elements.property(elements.FEYNMAN_PT_BPDR, "Weight", 0)
elements.property(elements.FEYNMAN_PT_BPDR, "Diffusion", 0)

--Clouds Mod

local a = elements.allocate("MOD", "UCLD")
elements.element(elements.MOD_PT_UCLD, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.MOD_PT_UCLD, "Name", "UCLD")
elements.property(elements.MOD_PT_UCLD, "Description", "Uranium Cloud. First type of radioactive cloud.")
elements.property(elements.MOD_PT_UCLD, "Colour", 0xAAAAFF)
elements.property(elements.MOD_PT_UCLD, "MenuSection", 10)
elements.property(elements.MOD_PT_UCLD, "Gravity", 0)
elements.property(elements.MOD_PT_UCLD, "Explosive", 0)
elements.property(elements.MOD_PT_UCLD, "Weight", 0)
elements.property(elements.MOD_PT_UCLD, "Diffusion", 1)
elements.property(elements.MOD_PT_UCLD, "Hardness", 0)
elements.property(elements.MOD_PT_UCLD, "Flammable", 0)
elements.property(elements.MOD_PT_UCLD, "AirDrag", 0.01)
local function rain(i,x,y,s,n)
	if math.random(1,500) < 5 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'uran')
	end
	if math.random(1,500) == 20 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'boyl')
	end
end
tpt.element_func(rain,a)

local b = elements.allocate("MOD2", "RACD")
elements.element(elements.MOD2_PT_RACD, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.MOD2_PT_RACD, "Name", "RACD")
elements.property(elements.MOD2_PT_RACD, "Description", "Rain Cloud.")
elements.property(elements.MOD2_PT_RACD, "Colour", 0xA9ACB6)
elements.property(elements.MOD2_PT_RACD, "MenuSection", 6)
elements.property(elements.MOD2_PT_RACD, "Gravity", 0)
elements.property(elements.MOD2_PT_RACD, "Explosive", 0)
elements.property(elements.MOD2_PT_RACD, "Weight", 0)
elements.property(elements.MOD2_PT_RACD, "Diffusion", 1)
elements.property(elements.MOD2_PT_RACD, "Hardness", 0)
elements.property(elements.MOD2_PT_RACD, "Flammable", 0)
elements.property(elements.MOD2_PT_RACD, "AirDrag", 0.01)
elements.property(elements.MOD2_PT_RACD, "LowTemperature", 273.15)
elements.property(elements.MOD2_PT_RACD, "Temperature", 295.15)

local function rain(i,x,y,s,n)
	if math.random(1,500) == 20 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'watr')
	end
end
tpt.element_func(rain,b)

local c = elements.allocate("MOD3", "SCLD")
elements.element(elements.MOD3_PT_SCLD, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.MOD3_PT_SCLD, "Name", "SCLD")
elements.property(elements.MOD3_PT_SCLD, "Description", "Snow Cloud.")
elements.property(elements.MOD3_PT_SCLD, "Colour", 0x8F8FBC)
elements.property(elements.MOD3_PT_SCLD, "MenuSection", 6)
elements.property(elements.MOD3_PT_SCLD, "Gravity", 0)
elements.property(elements.MOD3_PT_SCLD, "Explosive", 0)
elements.property(elements.MOD3_PT_SCLD, "Weight", 0)
elements.property(elements.MOD3_PT_SCLD, "Diffusion", 1)
elements.property(elements.MOD3_PT_SCLD, "Hardness", 0)
elements.property(elements.MOD3_PT_SCLD, "Flammable", 0)
elements.property(elements.MOD3_PT_SCLD, "AirDrag", 0.01)
elements.property(elements.MOD3_PT_SCLD, "HighTemperature", 273.15)
elements.property(elements.MOD3_PT_SCLD, "HighTemperatureTransition", elements.MOD_PT_RACD)
elements.property(elements.MOD3_PT_SCLD, "Temperature", 263.15 )
elements.property(elements.MOD3_PT_SCLD, "LowTemperature", 245.15)
elements.property(elements.MOD3_PT_SCLD, "LowTemperatureTransition", elements.DEFAULT_PT_ICE)

local function rain(i,x,y,s,n)
	if math.random(1,500) == 20 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'snow')
	end
end
tpt.element_func(rain,c)

elements.property(elements.MOD2_PT_RACD, "LowTemperatureTransition", elements.MOD_PT_SCLD)

local d = elements.allocate("MOD4", "DRCD")
elements.element(elements.MOD4_PT_DRCD, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.MOD4_PT_DRCD, "Name", "DRCD")
elements.property(elements.MOD4_PT_DRCD, "Description", "Distilled Rain Cloud.")
elements.property(elements.MOD4_PT_DRCD, "Colour", 0x506987)
elements.property(elements.MOD4_PT_DRCD, "MenuSection", 6)
elements.property(elements.MOD4_PT_DRCD, "Gravity", 0)
elements.property(elements.MOD4_PT_DRCD, "Explosive", 0)
elements.property(elements.MOD4_PT_DRCD, "Weight", 0)
elements.property(elements.MOD4_PT_DRCD, "Diffusion", 1)
elements.property(elements.MOD4_PT_DRCD, "Hardness", 0)
elements.property(elements.MOD4_PT_DRCD, "Flammable", 0)
elements.property(elements.MOD4_PT_DRCD, "AirDrag", 0.01)
elements.property(elements.MOD4_PT_DRCD, "LowTemperature", 273.15)
elements.property(elements.MOD4_PT_DRCD, "LowTemperatureTransition", elements.MOD_PT_SCLD)
elements.property(elements.MOD4_PT_DRCD, "Temperature", 295.15)

local function rain(i,x,y,s,n)
	if math.random(1,500) == 20 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'dstw')
	end
end
tpt.element_func(rain,d)

local e = elements.allocate("MOD5", "SRCD")
elements.element(elements.MOD5_PT_SRCD, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.MOD5_PT_SRCD, "Name", "SRCD")
elements.property(elements.MOD5_PT_SRCD, "Description", "Saltwater Rain Cloud.")
elements.property(elements.MOD5_PT_SRCD, "Colour", 0x380474)
elements.property(elements.MOD5_PT_SRCD, "MenuSection", 6)
elements.property(elements.MOD5_PT_SRCD, "MenuVisible", 0)
elements.property(elements.MOD5_PT_SRCD, "Gravity", 0)
elements.property(elements.MOD5_PT_SRCD, "Explosive", 0)
elements.property(elements.MOD5_PT_SRCD, "Weight", 0)
elements.property(elements.MOD5_PT_SRCD, "Diffusion", 1)
elements.property(elements.MOD5_PT_SRCD, "Hardness", 0)
elements.property(elements.MOD5_PT_SRCD, "Flammable", 0)
elements.property(elements.MOD5_PT_SRCD, "AirDrag", 0.01)
elements.property(elements.MOD5_PT_SRCD, "LowTemperature", 273.15)
elements.property(elements.MOD5_PT_SRCD, "LowTemperatureTransition", elements.MOD_PT_SCLD)
elements.property(elements.MOD5_PT_SRCD, "Temperature", 295.15)

local function rain(i,x,y,s,n)
	if math.random(1,500) == 20 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'sltw')
	end
end
tpt.element_func(rain,e)

local f = elements.allocate("MOD6", "TSCD")
elements.element(elements.MOD6_PT_TSCD, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.MOD6_PT_TSCD, "Name", "TSCD")
elements.property(elements.MOD6_PT_TSCD, "Description", "Thunderstorm Cloud.")
elements.property(elements.MOD6_PT_TSCD, "Colour", 0x302B54)
elements.property(elements.MOD6_PT_TSCD, "MenuSection", 6)
elements.property(elements.MOD6_PT_TSCD, "MenuVisible", 0)
elements.property(elements.MOD6_PT_TSCD, "Gravity", 0)
elements.property(elements.MOD6_PT_TSCD, "Explosive", 0)
elements.property(elements.MOD6_PT_TSCD, "Weight", 0)
elements.property(elements.MOD6_PT_TSCD, "Diffusion", 1)
elements.property(elements.MOD6_PT_TSCD, "Hardness", 0)
elements.property(elements.MOD6_PT_TSCD, "Flammable", 0)
elements.property(elements.MOD6_PT_TSCD, "AirDrag", 0.01)
elements.property(elements.MOD6_PT_TSCD, "LowTemperature", 273.15)
elements.property(elements.MOD6_PT_TSCD, "LowTemperatureTransition", elements.MOD_PT_SCLD)
elements.property(elements.MOD6_PT_TSCD, "Temperature", 303.15)

local function rain(i,x,y,s,n)
	if math.random(1,500) == 20 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'ligh')
	end
end
tpt.element_func(rain,f)

--Explosives

--The Highly Explosive mod for Powder Toy

local function explosion(x, y, s)
	for px = -1, 1 do
		for py = -1, 1 do
			tpt.create(x + px, y - py, "PLSM")
			local pressure = sim.pressure((x + px) / 4.0, (y + py) / 4.0)
			sim.pressure((x + px) / 4.0, (y + py) / 4.0, pressure + s * 10)
			sim.velocityX((x + px) / 4.0, y / 4.0, px * s)
			sim.velocityY((x + px) / 4.0, (y - py) / 4.0, -py * s)
		end
	end
end

local WBOMB = elements.allocate("MEXPL", "HELD")
elements.element(elements.MEXPL_PT_HELD, elements.element(elements.DEFAULT_PT_GLOW))
elements.property(elements.MEXPL_PT_HELD, "Color", "0xFFFEAF27")
elements.property(elements.MEXPL_PT_HELD, "Name", "HELD")
elements.property(elements.MEXPL_PT_HELD, "Description", "Highly Explosive Liquid.")
elements.property(elements.MEXPL_PT_HELD, "MenuVisible", 1)
elements.property(elements.MEXPL_PT_HELD, "MenuSection", 5)
elements.property(elements.MEXPL_PT_HELD, "Advection", 0.1)
elements.property(elements.MEXPL_PT_HELD, "AirDrag", 0.1)
elements.property(elements.MEXPL_PT_HELD, "AirLoss", 0.9)
elements.property(elements.MEXPL_PT_HELD, "Loss", 0.9)
elements.property(elements.MEXPL_PT_HELD, "Falldown", 2)
elements.property(elements.MEXPL_PT_HELD, "Hardness", 0.8)
elements.property(elements.MEXPL_PT_HELD, "Weight", 12)
elements.property(elements.MEXPL_PT_HELD, "Temperature", 340)
elements.property(elements.MEXPL_PT_HELD, "HeatConduct", 100)
elements.property(elements.MEXPL_PT_HELD, "State", 2)
elements.property(elements.MEXPL_PT_HELD, "Properties", 2)
elements.property(elements.MEXPL_PT_HELD, "Explosive", 1)

local function HELD_update(i, x, y, s, n)
	local r = 1
	if sim.pressure(x / 4.0, y / 4.0) >= 7.5 then
		explosion(x, y, 1)
		tpt.delete(i)
	elseif tpt.get_property("temp", i) >= 450 then
		explosion(x, y, 1)
		tpt.delete(i)
	end
end

tpt.element_func(HELD_update, elements.MEXPL_PT_HELD)

local SBOMB = elements.allocate("MEXPL", "HESD")
elements.element(elements.MEXPL_PT_HESD, elements.element(elements.DEFAULT_PT_BANG))
elements.property(elements.MEXPL_PT_HESD, "Color", "0xFFFF5000")
elements.property(elements.MEXPL_PT_HESD, "Name", "HESD")
elements.property(elements.MEXPL_PT_HESD, "Description", "Highly Explosive Solid.")
elements.property(elements.MEXPL_PT_HESD, "MenuVisible", 1)
elements.property(elements.MEXPL_PT_HESD, "MenuSection", 5)
elements.property(elements.MEXPL_PT_HESD, "Hardness", 0.8)
elements.property(elements.MEXPL_PT_HESD, "Temperature", 293)
elements.property(elements.MEXPL_PT_HESD, "HeatConduct", 100)
elements.property(elements.MEXPL_PT_HESD, "Falldown", 0)
elements.property(elements.MEXPL_PT_HESD, "State", 1)
elements.property(elements.MEXPL_PT_HESD, "Properties", 4)
elements.property(elements.MEXPL_PT_HESD, "Explosive", 1)

local function HESD_update(i, x, y, s, n)
	local r = 1
	if sim.pressure(x / 4.0, y / 4.0) >= 7.5 then
		explosion(x, y, 1)
		tpt.delete(i)
	elseif tpt.get_property("temp", i) >= 450 then
		explosion(x, y, 1)
		tpt.delete(i)
	end
end

tpt.element_func(HESD_update, elements.MEXPL_PT_HESD)

local GBOMB = elements.allocate("MEXPL", "HEGS")
elements.element(elements.MEXPL_PT_HEGS, elements.element(elements.DEFAULT_PT_GAS))
elements.property(elements.MEXPL_PT_HEGS, "Color", "0xFFEBFE5D")
elements.property(elements.MEXPL_PT_HEGS, "Name", "HEGS")
elements.property(elements.MEXPL_PT_HEGS, "Description", "Highly Explosive Gas.")
elements.property(elements.MEXPL_PT_HEGS, "MenuVisible", 1)
elements.property(elements.MEXPL_PT_HEGS, "MenuSection", 5)
elements.property(elements.MEXPL_PT_HEGS, "Hardness", 0.8)
elements.property(elements.MEXPL_PT_HEGS, "Temperature", 390)
elements.property(elements.MEXPL_PT_HEGS, "HeatConduct", 100)
elements.property(elements.MEXPL_PT_HEGS, "Falldown", 0)
elements.property(elements.MEXPL_PT_HEGS, "Diffusion", 0.5)
elements.property(elements.MEXPL_PT_HEGS, "State", 3)
elements.property(elements.MEXPL_PT_HEGS, "Explosive", 1)

local function HEGS_update(i, x, y, s, n)
	local r = 1
	if sim.pressure(x / 4.0, y / 4.0) >= 7.5 then
		explosion(x, y, 1)
		tpt.delete(i)
	elseif tpt.get_property("temp", i) >= 450 then
		explosion(x, y, 1)
		tpt.delete(i)
	end
end

tpt.element_func(HEGS_update, elements.MEXPL_PT_HEGS)

local PBOMB = elements.allocate("MEXPL", "HEPR")
elements.element(elements.MEXPL_PT_HEPR, elements.element(elements.DEFAULT_PT_DUST))
elements.property(elements.MEXPL_PT_HEPR, "Color", "0xFFFFFF00")
elements.property(elements.MEXPL_PT_HEPR, "Name", "HEPR")
elements.property(elements.MEXPL_PT_HEPR, "Description", "Highly Explosive Powder.")
elements.property(elements.MEXPL_PT_HEPR, "MenuVisible", 1)
elements.property(elements.MEXPL_PT_HEPR, "MenuSection", 5)
elements.property(elements.MEXPL_PT_HEPR, "Hardness", 0.8)
elements.property(elements.MEXPL_PT_HEPR, "Temperature", 293)
elements.property(elements.MEXPL_PT_HEPR, "HeatConduct", 100)
elements.property(elements.MEXPL_PT_HEPR, "Falldown", 1)
elements.property(elements.MEXPL_PT_HEPR, "Explosive", 1)
elements.property(elements.MEXPL_PT_HELD, "Advection", 0.1)
elements.property(elements.MEXPL_PT_HELD, "AirDrag", 0.1)
elements.property(elements.MEXPL_PT_HELD, "AirLoss", 0.9)
elements.property(elements.MEXPL_PT_HELD, "Loss", 0.9)
elements.property(elements.MEXPL_PT_HELD, "Hardness", 0.8)
elements.property(elements.MEXPL_PT_HELD, "Weight", 12)
elements.property(elements.MEXPL_PT_HEPR, "State", 1)
elements.property(elements.MEXPL_PT_HEPR, "Properties", 4)

local function HEPR_update(i, x, y, s, n)
	local r = 1
	if sim.pressure(x / 4.0, y / 4.0) >= 7.5 then
		explosion(x, y, 1)
		tpt.delete(i)
	elseif tpt.get_property("temp", i) >= 450 then
		explosion(x, y, 1)
		tpt.delete(i)
	end
end

tpt.element_func(HEPR_update, elements.MEXPL_PT_HEPR)

elements.property(elements.MEXPL_PT_HESD, "HighTemperature", 327)
elements.property(elements.MEXPL_PT_HESD, "HighTemperatureTransition", elements.MEXPL_PT_HELD)
elements.property(elements.MEXPL_PT_HESD, "HighPressure", 2)
elements.property(elements.MEXPL_PT_HESD, "HighPressureTransition", elements.MEXPL_PT_HEPR)
elements.property(elements.MEXPL_PT_HEPR, "HighTemperature", 326)
elements.property(elements.MEXPL_PT_HEPR, "HighTemperatureTransition", elements.MEXPL_PT_HELD)
elements.property(elements.MEXPL_PT_HEGS, "LowTemperature", 365)
elements.property(elements.MEXPL_PT_HEGS, "LowTemperatureTransition", elements.MEXPL_PT_HELD)
elements.property(elements.MEXPL_PT_HELD, "HighTemperature", 365)
elements.property(elements.MEXPL_PT_HELD, "HighTemperatureTransition", elements.MEXPL_PT_HEGS)
elements.property(elements.MEXPL_PT_HELD, "LowTemperature", 327)
elements.property(elements.MEXPL_PT_HELD, "LowTemperatureTransition", elements.MEXPL_PT_HESD)

--"New Elements"

local function heat()
	tpt.set_property("temp", 9999, "HETR")
	tpt.set_property("temp", 0, "COLR")
end
tpt.register_step(heat)

elements.allocate('YOSHI', 'HETR')
elements.element(elements.YOSHI_PT_HETR, elements.element(elements.DEFAULT_PT_DMND))
elements.property(elements.YOSHI_PT_HETR, 'Name', 'HETR')
elements.property(elements.YOSHI_PT_HETR, 'Description', 'Heats Elements.')
elements.property(elements.YOSHI_PT_HETR, 'Color', '0xFF1111')
elements.property(elements.YOSHI_PT_HETR, 'MenuSection', '2')
elements.property(elements.YOSHI_PT_HETR, 'HeatConduct', '65535')
local g = function(i, x, y, s, n)
	--Update Function
end
tpt.element_func(g, tpt.element('HETR'))

local function heat()
end
tpt.register_step(heat)

elements.allocate('YOSHI', 'COLR')
elements.element(elements.YOSHI_PT_COLR, elements.element(elements.DEFAULT_PT_DMND))
elements.property(elements.YOSHI_PT_COLR, 'Name', 'COLR')
elements.property(elements.YOSHI_PT_COLR, 'Description', 'Cools Elements.')
elements.property(elements.YOSHI_PT_COLR, 'Color', '0x1111FF')
elements.property(elements.YOSHI_PT_COLR, 'MenuSection', '2')
elements.property(elements.YOSHI_PT_COLR, 'HeatConduct', '65535')
local g = function(i, x, y, s, n)
	--Update Function
end
tpt.element_func(g, tpt.element('COLR'))

elements.allocate('YOSHI', 'HCTD')
elements.element(elements.YOSHI_PT_HCTD, elements.element(elements.DEFAULT_PT_DMND))
elements.property(elements.YOSHI_PT_HCTD, 'Name', 'HCTD')
elements.property(elements.YOSHI_PT_HCTD, 'Description', 'Heat conductor.')
elements.property(elements.YOSHI_PT_HCTD, 'Color', '0x11FF11')
elements.property(elements.YOSHI_PT_HCTD, 'MenuSection', '2')
elements.property(elements.YOSHI_PT_HCTD, 'HeatConduct', '65535')
local g = function(i, x, y, s, n)
	--Update Function
end
tpt.element_func(g, tpt.element('HCTD'))

local a = elements.allocate("YOSHI", "RCLD")
elements.element(elements.YOSHI_PT_RCLD, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.YOSHI_PT_RCLD, "Name", "RCLD")
elements.property(elements.YOSHI_PT_RCLD, "Description", "Radioactive cloud, Second type.")
elements.property(elements.YOSHI_PT_RCLD, "Colour", 0x11FF22)
elements.property(elements.YOSHI_PT_RCLD, "MenuSection", 10)
elements.property(elements.YOSHI_PT_RCLD, "Gravity", 0)
elements.property(elements.YOSHI_PT_RCLD, "Explosive", 0)
elements.property(elements.YOSHI_PT_RCLD, "Weight", 0)
elements.property(elements.YOSHI_PT_RCLD, "Diffusion", 1)
elements.property(elements.YOSHI_PT_RCLD, "Hardness", 0)
elements.property(elements.YOSHI_PT_RCLD, "Flammable", 100000)
elements.property(elements.YOSHI_PT_RCLD, "AirDrag", 0.01)
local function rain(i,x,y,s,n)
	if math.random(1,500) < 5 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'plut')
	end
	if math.random(1,500) == 20 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'uran')
	end
	if math.random(1,500) == 30 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'isoz')
	end
	if math.random(1,500) == 40 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'deut')
	end
	if math.random(1,500) == 50 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'bvbr')
	end
end
tpt.element_func(rain,a)

--[[ {NOT USEFUL ATM} local a = elements.allocate("YOSHI", "SULF")
elements.element(elements.YOSHI_PT_SULF, elements.element(elements.DEFAULT_PT_COAL))
elements.property(elements.YOSHI_PT_SULF, "Name", "SULF")
elements.property(elements.YOSHI_PT_SULF, "Description", "Basic Sulphur.")
elements.property(elements.YOSHI_PT_SULF, "Colour", 0xFFFF11)
elements.property(elements.YOSHI_PT_SULF, "MenuSection", 9)
elements.property(elements.YOSHI_PT_SULF, "Gravity", 0)
elements.property(elements.YOSHI_PT_SULF, "Explosive", 0)
elements.property(elements.YOSHI_PT_SULF, "Weight", 10)
elements.property(elements.YOSHI_PT_SULF, "Diffusion", 0)
elements.property(elements.YOSHI_PT_SULF, "Hardness", 0)
elements.property(elements.YOSHI_PT_SULF, "Flammable", 10)]]

--[[ {MAY BE USEFUL LATER?}local a = elements.allocate("YOSHI", "SACD")
elements.element(elements.YOSHI_PT_SACD, elements.element(elements.DEFAULT_PT_ACID))
elements.property(elements.YOSHI_PT_SACD, "Name", "SACD")
elements.property(elements.YOSHI_PT_SACD, "Description", "Sulphuric acid, does nothing yet.")
elements.property(elements.YOSHI_PT_SACD, "Colour", 0xEEEE11)
elements.property(elements.YOSHI_PT_SACD, "MenuSection", 7)
elements.property(elements.YOSHI_PT_SACD, "Gravity", 1)
elements.property(elements.YOSHI_PT_SACD, "Explosive", 0)
elements.property(elements.YOSHI_PT_SACD, "Weight", 10)
elements.property(elements.YOSHI_PT_SACD, "Diffusion", 0.1)
elements.property(elements.YOSHI_PT_SACD, "Hardness", 0)
elements.property(elements.YOSHI_PT_SACD, "Flammable", 0)]]--

local a = elements.allocate("YOSHI", "RMTL")
elements.element(elements.YOSHI_PT_RMTL, elements.element(elements.DEFAULT_PT_TTAN))
elements.property(elements.YOSHI_PT_RMTL, "Name", "RMTL")
elements.property(elements.YOSHI_PT_RMTL, "Description", "Realistic metal.")
elements.property(elements.YOSHI_PT_RMTL, "Colour", 0x666666)
elements.property(elements.YOSHI_PT_RMTL, "MenuSection", 9)
elements.property(elements.YOSHI_PT_RMTL, "Gravity", 0)
elements.property(elements.YOSHI_PT_RMTL, "Explosive", 0)
elements.property(elements.YOSHI_PT_RMTL, "Weight", 100)
elements.property(elements.YOSHI_PT_RMTL, "Diffusion", 0)
elements.property(elements.YOSHI_PT_RMTL, "Hardness", 0)
elements.property(elements.YOSHI_PT_RMTL, "Flammable", 0)
elements.property(elements.YOSHI_PT_RMTL, "AirLoss", 0)
elements.property(elements.YOSHI_PT_RMTL, "Temperature", 273.15 + 22)
elements.property(elements.YOSHI_PT_RMTL, "HighTemperature", 1798)
elements.property(elements.YOSHI_PT_RMTL, "HighTemperatureTransition", elements.YOSHI_PT_MRMT)

local a = elements.allocate("YOSHI", "MRMT")
elements.element(elements.YOSHI_PT_MRMT, elements.element(elements.DEFAULT_PT_MERC))
elements.property(elements.YOSHI_PT_MRMT, "Name", "MRMT")
elements.property(elements.YOSHI_PT_MRMT, "Description", "Molten realistic metal.")
elements.property(elements.YOSHI_PT_MRMT, "Colour", 0xFEDCBA)
elements.property(elements.YOSHI_PT_MRMT, "MenuSection", 4)
elements.property(elements.YOSHI_PT_MRMT, "MenuVisible", 0)
elements.property(elements.YOSHI_PT_MRMT, "Gravity", 1)
elements.property(elements.YOSHI_PT_MRMT, "Explosive", 0)
elements.property(elements.YOSHI_PT_MRMT, "Weight", 100)
elements.property(elements.YOSHI_PT_MRMT, "Diffusion", 0)
elements.property(elements.YOSHI_PT_MRMT, "Hardness", 0)
elements.property(elements.YOSHI_PT_MRMT, "Flammable", 0)
elements.property(elements.YOSHI_PT_MRMT, "Temperature", 1799)
elements.property(elements.YOSHI_PT_MRMT, "LowTemperature", 1798)
elements.property(elements.YOSHI_PT_MRMT, "LowTemperatureTransition", elements.YOSHI_PT_RMTL)

local a = elements.allocate("YOSHI", "THNL")
elements.element(elements.YOSHI_PT_THNL, elements.element(elements.DEFAULT_PT_NITR))
elements.property(elements.YOSHI_PT_THNL, "Name", "THNL")
elements.property(elements.YOSHI_PT_THNL, "Description", "Thermonucleum, Extremely explosive.")
elements.property(elements.YOSHI_PT_THNL, "Colour", 0x3F94EC)
elements.property(elements.YOSHI_PT_THNL, "MenuSection", 10)
elements.property(elements.YOSHI_PT_THNL, "Gravity", 1)
elements.property(elements.YOSHI_PT_THNL, "Explosive", 50)
elements.property(elements.YOSHI_PT_THNL, "Weight", 10)
elements.property(elements.YOSHI_PT_THNL, "Diffusion", 0)
elements.property(elements.YOSHI_PT_THNL, "Hardness", 0)
elements.property(elements.YOSHI_PT_THNL, "Flammable", 100000)
elements.property(elements.YOSHI_PT_THNL, "Temperature", 295.15)
elements.property(elements.YOSHI_PT_THNL, "AirDrag", 0.5)

elements.allocate('AU3FGEN', 'GNTM')
elements.element(elements.AU3FGEN_PT_GNTM, elements.element(elements.DEFAULT_PT_DMND))
elements.property(elements.AU3FGEN_PT_GNTM, 'Name', 'GNTM')
elements.property(elements.AU3FGEN_PT_GNTM, 'Description', 'Gentium, Strange and laggy.')
elements.property(elements.AU3FGEN_PT_GNTM, 'Color', '0x1F7F3F')
elements.property(elements.AU3FGEN_PT_GNTM, 'MenuSection', '10')
elements.property(elements.AU3FGEN_PT_GNTM, 'Gravity', '0')
elements.property(elements.AU3FGEN_PT_GNTM, 'Flammable', '65535')
elements.property(elements.AU3FGEN_PT_GNTM, 'Explosive', '1')
elements.property(elements.AU3FGEN_PT_GNTM, 'Loss', '0')
elements.property(elements.AU3FGEN_PT_GNTM, 'AirLoss', '1')
elements.property(elements.AU3FGEN_PT_GNTM, 'AirDrag', '0')
elements.property(elements.AU3FGEN_PT_GNTM, 'Advection', '1')
elements.property(elements.AU3FGEN_PT_GNTM, 'Weight', '1024')
elements.property(elements.AU3FGEN_PT_GNTM, 'Diffusion', '0')
elements.property(elements.AU3FGEN_PT_GNTM, 'Falldown', '0')
local g = function(i, x, y, s, n)
	--Update Function
end
tpt.element_func(g, tpt.element('GNTM'))
local g = function(i, r, g, b)
	local function gfunc(i, r, g, b)
		return 1, 0x0003007F, math.random(0,255), math.random(0,255), math.random(0,255), math.random(0,255), math.random(0,255), math.random(0,255), math.random(0,255), math.random(0,255)
	end
	tpt.graphics_func(gfunc, tpt.element('GNTM'))
end
tpt.graphics_func(g, tpt.element('GNTM'))

--Radioactive Mod

--Changes
-- You can change this from on/off.

on=40
off=0

elements.property(elements.DEFAULT_PT_ACID, "Flammable", off)
-- Added Elements.

local a = elements.allocate("X", "C")
elements.element(elements.X_PT_C, elements.element(elements.DEFAULT_PT_WOOD))
elements.property(elements.X_PT_C, "Name", "SAWD")
elements.property(elements.X_PT_C, "Description", "Saw Dust, Flammable.")
elements.property(elements.X_PT_C, "Colour", 0xFFFF66)
elements.property(elements.X_PT_C, "MenuSection", 8)
elements.property(elements.X_PT_C, "Gravity", 1)
elements.property(elements.X_PT_C, "Flammable", 30)
elements.property(elements.X_PT_C, "Explosive", 0)
elements.property(elements.X_PT_C, "Weight", 20)
elements.property(elements.X_PT_C, "Diffusion", 0.5)
elements.property(elements.X_PT_C, "Falldown", 1)

local a = elements.allocate("C", "Q")
elements.element(elements.C_PT_Q, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.C_PT_Q, "Name", "????")
elements.property(elements.C_PT_Q, "Description", "????")
elements.property(elements.C_PT_Q, "Colour", 0xFFFF0080)
elements.property(elements.C_PT_Q, "MenuSection", 10)
elements.property(elements.C_PT_Q, "Gravity", 0.3)
elements.property(elements.C_PT_Q, "Explosive", 1)
elements.property(elements.C_PT_Q, "Weight", 66)
elements.property(elements.C_PT_Q, "Diffusion", 0)
elements.property(elements.C_PT_Q, "HotAir", -0.1)
elements.property(elements.C_PT_Q, "Hardness", 0)

local q={0x99FFFF,0x9999FF,0xCCFF00,0x00FFCC,0x00CC00,0x330099}
local z=q[math.random(1,6)]

elements.property(elements.C_PT_Q, "Colour", z)

local function light(i,x,y,s,n)
	if math.random(1,300000) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'ligh')
	end
end
tpt.element_func(light,a)

local a = elements.allocate("B", "Q")
elements.element(elements.B_PT_Q, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.B_PT_Q, "Name", "LCLD")
elements.property(elements.B_PT_Q, "Description", "Lava Clouds.")
elements.property(elements.B_PT_Q, "Colour", 0xCC0000)
elements.property(elements.B_PT_Q, "MenuSection", 6)
elements.property(elements.B_PT_Q, "Gravity", 0.1)
elements.property(elements.B_PT_Q, "Explosive", 0)
elements.property(elements.B_PT_Q, "Weight", 66)
elements.property(elements.B_PT_Q, "Temperature", math.huge)
elements.property(elements.B_PT_Q, "Diffusion", 0.1)
elements.property(elements.B_PT_Q, "Hardness", 0)

local function fire(i,x,y,s,n)
	if math.random(1,750) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'lava')
	end
end
tpt.element_func(fire,a)

--[[

local a = elements.allocate("V", "X")
elements.element(elements.V_PT_X, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.V_PT_X, "Name", "CLDS")
elements.property(elements.V_PT_X, "Description", "Clouds. Produce Water.")
elements.property(elements.V_PT_X, "Colour", 0x3366CC)
elements.property(elements.V_PT_X, "MenuSection", 6)
elements.property(elements.V_PT_X, "Gravity", 0.3)
elements.property(elements.V_PT_X, "Explosive", 0)
elements.property(elements.V_PT_X, "Weight", 88)
elements.property(elements.V_PT_X, "Diffusion", 0.2)
elements.property(elements.V_PT_X, "Hardness", 0)

local function rain(i,x,y,s,n)
	if math.random(1,750) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'watr')
	end
end
tpt.element_func(rain,a)]]--

local a = elements.allocate("V", "W")
elements.element(elements.V_PT_W, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.V_PT_W, "Name", "ACLD")
elements.property(elements.V_PT_W, "Description", "Acid Cloud.")
elements.property(elements.V_PT_W, "Colour", 0xFF0066)
elements.property(elements.V_PT_W, "MenuSection", 6)
elements.property(elements.V_PT_W, "Gravity", 0.1)
elements.property(elements.V_PT_W, "Explosive", 0)
elements.property(elements.V_PT_W, "Weight", -400)
elements.property(elements.V_PT_W, "Diffusion", 0.1)
elements.property(elements.V_PT_W, "Hardness", 0)

local function acid(i,x,y,s,n)
	if math.random(1,750) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'acid')
	end
end
tpt.element_func(acid,a)

local a = elements.allocate("T", "N")
elements.element(elements.T_PT_N, elements.element(elements.DEFAULT_PT_LAVA))
elements.property(elements.T_PT_N, "Name", "NBLI")
elements.property(elements.T_PT_N, "Description", "A liquid that releases NBLE. Very Hot.")
elements.property(elements.T_PT_N, "Colour", 0xFF3300)
elements.property(elements.T_PT_N, "Temperature", math.huge)
elements.property(elements.T_PT_N, "Gravity", 3)
elements.property(elements.T_PT_N, "Diffusion", 0.2)

local function RLS(i,x,y,s,n)
	if math.random(1,550) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'nble')
		if math.random(1,1300) == 10 then
			tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'plsm')
		end
	end
end
tpt.element_func(RLS,a)
l="IFOUNDIT"
local a = elements.allocate("R","D")
elements.element(elements.R_PT_D, elements.element(elements.DEFAULT_PT_PHOT))
elements.property(elements.R_PT_D, "Name", "SPRB")
elements.property(elements.R_PT_D, "Color", 0xFF0099)
elements.property(elements.R_PT_D, "MenuSection", elem.SC_SPECIAL)
elements.property(elements.R_PT_D, "Advection", 0.2)
elements.property(elements.R_PT_D, "Collision", 1.0)
elements.property(elements.R_PT_D, "Gravity", 3.0)
elements.property(elements.R_PT_D, "Diffusion", 0.3)
elements.property(elements.R_PT_D, "Weight", 40.45)
elements.property(elements.R_PT_D, "Temperature", 100000.0)
elements.property(elements.R_PT_D, "HeatConduct", 100000.0)
elements.property(elements.R_PT_D, "Description", "Super Ball. Very Hot. Bounces.")
elements.property(elements.R_PT_D, "Properties", PROP_DEADLY)

local a = elements.allocate("V1", "X1")
elements.element(elements.V1_PT_X1, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.V1_PT_X1, "Name", "STRM")
elements.property(elements.V1_PT_X1, "Description", "Storm Clouds. Produces More Water Than RCLD, and Lightning.")
elements.property(elements.V1_PT_X1, "Colour", 0x999999)
elements.property(elements.V1_PT_X1, "MenuSection", 6)
elements.property(elements.V1_PT_X1, "Gravity", 0.1)
elements.property(elements.V1_PT_X1, "Explosive", 0)
elements.property(elements.V1_PT_X1, "Weight", 30)
elements.property(elements.V1_PT_X1, "Diffusion", 0.1)
elements.property(elements.V1_PT_X1, "Hardness", 0)

local function rain2(i,x,y,s,n)
	if math.random(1,350) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'watr')
		if math.random(1,750) == 10 then
			tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'ligh')
		end
	end
end
tpt.element_func(rain2,a)

local a = elements.allocate("N", "H")
elements.element(elements.N_PT_H, elements.element(elements.DEFAULT_PT_WOOD))
elements.property(elements.N_PT_H, "Name", "TR0N")
elements.property(elements.N_PT_H, "Description", "Produces TRON. A Solid. A Home.")
elements.property(elements.N_PT_H, "Colour", 0x66FFFF)
elements.property(elements.N_PT_H, "Flammable", 0)
elements.property(elements.N_PT_H, "MenuSection", elem.SC_SPECIAL)

local function tron(i,x,y,s,n)
	if math.random(1,100) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'tron')
	end
end
tpt.element_func(tron,a)

local a = elements.allocate("E", "O")
elements.element(elements.E_PT_O, elements.element(elements.DEFAULT_PT_GUN))
elements.property(elements.E_PT_O, "Name", "PC-4")
elements.property(elements.E_PT_O, "Description", "Powder C4. Explosive.")
elements.property(elements.E_PT_O, "Colour", 0xFF33FF)
elements.property(elements.E_PT_O, "Gravity", 2.0)
elements.property(elements.E_PT_O, "Diffusion", 0.2)
elements.property(elements.E_PT_O, "Weight", 30.20)
elements.property(elements.E_PT_O, "Flammable", 3000.34)

local a = elements.allocate("J", "O")
elements.element(elements.J_PT_O, elements.element(elements.DEFAULT_PT_DUST))
elements.property(elements.J_PT_O, "Name", "FLY")
elements.property(elements.J_PT_O, "Description", "Fly. Annoying Pestering Bug.")
elements.property(elements.J_PT_O, "Colour", 0x333333)
elements.property(elements.J_PT_O, "MenuSection", 11)
elements.property(elements.J_PT_O, "Gravity", 0.1)
elements.property(elements.J_PT_O, "Flammable", 1)
elements.property(elements.J_PT_O, "Explosive", 0)
elements.property(elements.J_PT_O, "Weight", -3000)
elements.property(elements.J_PT_O, "Diffusion", 0.9)
elements.property(elements.J_PT_O, "Falldown", 0.8)

local a = elements.allocate("C", "T")
elements.element(elements.C_PT_T, elements.element(elements.DEFAULT_PT_GLOW))
elements.property(elements.C_PT_T, "Name", "NPLM")
elements.property(elements.C_PT_T, "Description", "Napalm. Very explosive.")
elements.property(elements.C_PT_T, "Colour", 0x380520)
elements.property(elements.C_PT_T, "MenuSection", 5)
elements.property(elements.C_PT_T, "Gravity", 0.5)
elements.property(elements.C_PT_T, "Flammable", 1000)
elements.property(elements.C_PT_T, "Explosive", 1)
elements.property(elements.C_PT_T, "Loss", 0)
elements.property(elements.C_PT_T, "Weight", 20)

local a = elements.allocate("G", "H")
elements.element(elements.G_PT_H, elements.element(elements.DEFAULT_PT_WOOD))
elements.property(elements.G_PT_H, "Name", "BHIV")
elements.property(elements.G_PT_H, "Description", "BEE Hive. Produces BEEs. Obviously.")
elements.property(elements.G_PT_H, "Colour", 0x999966)
elements.property(elements.G_PT_H, "Flammable", 10)
elements.property(elements.G_PT_H, "MenuSection", elem.SC_SPECIAL)

local function bee(i,x,y,s,n)
	if math.random(1,330) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'bee')
	end
end
tpt.element_func(bee,a)

local a = elements.allocate("B", "O")
elements.element(elements.B_PT_O, elements.element(elements.DEFAULT_PT_DUST))
elements.property(elements.B_PT_O, "Name", "BEE")
elements.property(elements.B_PT_O, "Description", "BEE. Pestering Demons. Move Faster Then FLY.")
elements.property(elements.B_PT_O, "Colour", 0xFFFF00)
elements.property(elements.B_PT_O, "MenuSection", 11)
elements.property(elements.B_PT_O, "Gravity", 0.1)
elements.property(elements.B_PT_O, "Flammable", 10)
elements.property(elements.B_PT_O, "Explosive", 0)
elements.property(elements.B_PT_O, "Weight", -6000)
elements.property(elements.B_PT_O, "Diffusion", 2)
elements.property(elements.B_PT_O, "Falldown", 0.2)
local function beeh(i,x,y,s,n)
	if math.random(1,9000) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'bhiv')
	end
end
tpt.element_func(beeh,a)

local a = elements.allocate("T", "X")
elements.element(elements.T_PT_X, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.T_PT_X, "Name", "TORN")
elements.property(elements.T_PT_X, "Description", "Tornado. Work in progress.")
elements.property(elements.T_PT_X, "Colour", 0x333333)
elements.property(elements.T_PT_X, "MenuSection", 11)
elements.property(elements.T_PT_X, "Gravity", 0.5)
elements.property(elements.T_PT_X, "Explosive", 0)
elements.property(elements.T_PT_X, "HotAir", -0.5)
elements.property(elements.T_PT_X, "Weight", 99)
elements.property(elements.T_PT_X, "Diffusion", 0.2)
elements.property(elements.T_PT_X, "Hardness", 0)

local function rt(i,x,y,s,n)
	if math.random(1,550) == 10 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'watr')
	end
end
tpt.element_func(rt,a)

local a = elements.allocate("A","G")
elements.element(elements.A_PT_G, elements.element(elements.DEFAULT_PT_HYGN))
elements.property(elements.A_PT_G, "Name", "LAG")
elements.property(elements.A_PT_G, "Description", "Worlds Worst Creation.")
elements.property(elements.A_PT_G, "Colour", 0x578985)
elements.property(elements.A_PT_G, "MenuSection", 10)
elements.property(elements.A_PT_G, "HotAir", 0.1)
local function acid(i,x,y,s,n)
	if math.random(1,100) == 50 then
		tpt.create(x + math.random(-1,1), y + math.random(-1,1), 'lag')
	end
	if math.random(1,100) == 50 then
		tpt.create(x + math.random(-1,1), y + math.random(-3,3), 'hygn')
	end
	if math.random(1,100) == 50 then
		tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'neut')
	end
	if math.random(1,100) == 50 then
		tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'prot')
	end
	if math.random(1,100) == 50 then
		tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'elec')
		if math.random(1,100) == 50 then
			tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'phot')
		end
		if math.random(1,100) == 50 then
			tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'neut')
		end
		if math.random(1,100) == 50 then
			tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'tron')

			if math.random(1,100) == 50 then
				tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'nble')
				if math.random(1,100) == 50 then
					tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'boyl')
					if math.random(1,100) == 50 then
						tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'watr')
						if math.random(1,100) == 50 then
							tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'dstw')
							if math.random(1,100) == 50 then
								tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'sltw')
								if math.random(1,100) == 50 then
									tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'glow')
									if math.random(1,100) == 50 then
										tpt.create(x + math.random(-4,4), y + math.random(-6, 6), 'soap')
									end
								end
							end
						end
					end
				end
			end
		end
	end
end
tpt.element_func(acid,a)

--WTF

local WTF = elements.allocate('CJB', 'WTF')
elements.element(elements.CJB_PT_WTF, elements.element(elements.DEFAULT_PT_BCOL))
elements.property(elements.CJB_PT_WTF, 'Name', 'WTF')
elements.property(elements.CJB_PT_WTF, 'Description', 'Derpy, volatile gas/solid/I have no bloody idea.')
elements.property(elements.CJB_PT_WTF, 'Color', '0xB87503')
elements.property(elements.CJB_PT_WTF, 'MenuSection', '11')
elements.property(elements.CJB_PT_WTF, 'Gravity', '0.4')
elements.property(elements.CJB_PT_WTF, 'Flammable', '16384')
elements.property(elements.CJB_PT_WTF, 'Explosive', '1')
elements.property(elements.CJB_PT_WTF, 'Loss', '1')
elements.property(elements.CJB_PT_WTF, 'AirLoss', '20')
elements.property(elements.CJB_PT_WTF, 'AirDrag', '0.02')
elements.property(elements.CJB_PT_WTF, 'Advection', '1')
elements.property(elements.CJB_PT_WTF, 'Weight', '20')
elements.property(elements.CJB_PT_WTF, 'Diffusion', '16384')
elements.property(elements.CJB_PT_WTF, 'Temperature', '16384')
elements.property(elements.CJB_PT_WTF, 'HotAir', '900')
local function Lflare(i, colr, colg, colb)
	return 1, 0x00000004, 255, 184, 117, 3, 255, 184, 117, 3
end
tpt.graphics_func(Lflare, WTF)

--Quarks

local QURK = elements.allocate("AMY", "QURK")
elements.element(elements.AMY_PT_QURK, elements.element(elements.DEFAULT_PT_NEUT))
elements.property(elements.AMY_PT_QURK, "Name", "QURK")
elements.property(elements.AMY_PT_QURK, "Description", "Quarks. Make up all particles in existance.")
elements.property(elements.AMY_PT_QURK, "Colour", 0x1E1E1E)
elements.property(elements.AMY_PT_QURK, "MenuSection", elem.SC_NUCLEAR)
elements.property(elements.AMY_PT_QURK, "MenuVisible", 1)
elements.property(elements.AMY_PT_QURK, "Temperature",10000)
elements.property(elements.AMY_PT_QURK, "Weight", -1)
elements.property(elements.AMY_PT_QURK, "HeatConduct", 0)

math.randomseed(os.time())
local function QURK_update(i, x, y, s, n)
	if tpt.get_property("tmp",i)==0 then
		tpt.parts[i].tmp=1
		randvel=math.random(-20,20)
		randvel2=math.random(-20,20)
		tpt.parts[i].vx=randvel
		tpt.parts[i].vy=randvel2
	end

	xvel=tpt.parts[i].vx
	yvel=tpt.parts[i].vy

	xpos=x+xvel
	ypos=y+yvel

	if xpos >= 608 then
		tpt.delete(i)
	end
	if ypos >= 380 then
		tpt.delete(i)
	end

	tpt.parts[i].temp=10000
end

for i = 1,255 do
	sim.can_move(elem.AMY_PT_QURK, i, 2)
end

local function graphics1(i, colr, colg, colb)
	return 1,0x00010010,255,25,25,25,255,25,25,25
end
tpt.graphics_func(graphics1,QURK)

tpt.element_func(QURK_update, elements.AMY_PT_QURK,1)

--Neutrinos

local NEUR = elements.allocate("AMY", "NEUR")
elements.element(elements.AMY_PT_NEUR, elements.element(elements.DEFAULT_PT_NEUT))
elements.property(elements.AMY_PT_NEUR, "Name", "NEUR")
elements.property(elements.AMY_PT_NEUR, "Description", "Neutrinos. Pass through everything.")
elements.property(elements.AMY_PT_NEUR, "Colour", 0x27FE99)
elements.property(elements.AMY_PT_NEUR, "MenuSection", elem.SC_NUCLEAR)
elements.property(elements.AMY_PT_NEUR, "MenuVisible", 1)
elements.property(elements.AMY_PT_NEUR, "Temperature", 0)
elements.property(elements.AMY_PT_NEUR, "Weight", -10)
elements.property(elements.AMY_PT_NEUR, "Diffusion", 1)
elements.property(elements.AMY_PT_NEUR, "HeatConduct", 0)

math.randomseed(os.time())
local function NEUR_update(i, x, y, s, n)
	if tpt.get_property("tmp",i)==0 then
		tpt.parts[i].tmp=1
		randvel=math.random(-20,20)/5
		randvel2=math.random(-20,20)/5
		tpt.parts[i].vx=randvel
		tpt.parts[i].vy=randvel2
	end

	xvel=tpt.parts[i].vx
	yvel=tpt.parts[i].vy

	xpos=x+xvel
	ypos=y+yvel

	if xpos >= 608 then
		tpt.delete(i)
	end
	if ypos >= 380 then
		tpt.delete(i)
	end

	tpt.parts[i].temp=300

end

for i = 1,255 do
	sim.can_move(elem.AMY_PT_NEUR, i, 2)
end

local function graphics1(i, colr, colg, colb)
	return 1,0x00010000,255,39,254,153,255,39,254,153
end
tpt.graphics_func(graphics1,NEUR)

--Credits Window
if not tpt.version.jacob1s_mod then
	local a = "1"
	local b = Window:new(-1,-1,200,200)
	local c = Label:new(10,5,140,16, "TPT's Mod")
	local d = Label:new(10,25,121,16, "Compiled by Amy")
	local e = Label:new(10,85,170,16, "Credit to: jacob1, FeynmanLogomaker,")
	local f = Label:new(135,5,88,16, ("RCA"))
	local g = Label:new(10,95,180,16, "timpfeifer, CeeJayBee, Videogamer555,")
	local h = Label:new(10,105,170,16,"00yoshi, and RadioActiveLua.")
	local i = Label:new(10,125,180,16,"Report Bugs/Suggest for Next Version:")
	local j = Label:new(10,135,160,16,"rcaproductionmaster@gmail.com")

	local Close = Button:new(10, 174, 60, 16, "Close")

	Close:action(function() interface.closeWindow(b) end)
	b:onTryExit(function() interface.closeWindow(b) end)

	b:addComponent(Close);

	local Button1 = Button:new(613, 97, 15, 15, "CR", "Open Info and Credits.")

	Button1:action(function() interface.showWindow(b) end)

	bb = Label:new(10,45,138,16, "Special Thanks To jacob1")
	cc = Label:new(10,55,60,16, "Version 3")
	dd = Label:new(10,65,57,16, "Update 0")

	b:addComponent(bb)
	b:addComponent(dd)
	b:addComponent(cc)
	b:addComponent(c)
	b:addComponent(d)
	b:addComponent(e)
	b:addComponent(f)
	b:addComponent(g)
	b:addComponent(h)
	b:addComponent(i)
	b:addComponent(j)

	interface.addComponent(Button1)
end